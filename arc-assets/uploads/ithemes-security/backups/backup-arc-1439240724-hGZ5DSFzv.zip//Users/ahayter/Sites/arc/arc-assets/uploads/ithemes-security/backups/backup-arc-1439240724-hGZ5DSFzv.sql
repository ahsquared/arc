DROP TABLE IF EXISTS `arc1542_commentmeta`;

CREATE TABLE `arc1542_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_comments`;

CREATE TABLE `arc1542_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_comments` VALUES("1","1","Mr WordPress","","https://wordpress.org/","","2015-06-15 19:42:40","2015-06-15 19:42:40","Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.","0","1","","","0","0");


DROP TABLE IF EXISTS `arc1542_itsec_lockouts`;

CREATE TABLE `arc1542_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_log`;

CREATE TABLE `arc1542_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_temp`;

CREATE TABLE `arc1542_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_links`;

CREATE TABLE `arc1542_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_options`;

CREATE TABLE `arc1542_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=350 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_options` VALUES("1","siteurl","http://arc.dev","yes");
INSERT INTO `arc1542_options` VALUES("2","home","http://arc.dev","yes");
INSERT INTO `arc1542_options` VALUES("3","blogname","ARC","yes");
INSERT INTO `arc1542_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `arc1542_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `arc1542_options` VALUES("6","admin_email","andre.hayter@gmail.com","yes");
INSERT INTO `arc1542_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `arc1542_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `arc1542_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `arc1542_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `arc1542_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `arc1542_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `arc1542_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `arc1542_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `arc1542_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `arc1542_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `arc1542_options` VALUES("18","default_category","1","yes");
INSERT INTO `arc1542_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `arc1542_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `arc1542_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `arc1542_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `arc1542_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `arc1542_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `arc1542_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `arc1542_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `arc1542_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `arc1542_options` VALUES("29","gzipcompression","0","yes");
INSERT INTO `arc1542_options` VALUES("30","hack_file","0","yes");
INSERT INTO `arc1542_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `arc1542_options` VALUES("32","moderation_keys","","no");
INSERT INTO `arc1542_options` VALUES("33","active_plugins","a:2:{i:0;s:41:\"better-wp-security/better-wp-security.php\";i:1;s:23:\"wordfence/wordfence.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("34","category_base","","yes");
INSERT INTO `arc1542_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `arc1542_options` VALUES("36","advanced_edit","0","yes");
INSERT INTO `arc1542_options` VALUES("37","comment_max_links","2","yes");
INSERT INTO `arc1542_options` VALUES("38","gmt_offset","","yes");
INSERT INTO `arc1542_options` VALUES("39","default_email_category","1","yes");
INSERT INTO `arc1542_options` VALUES("40","recently_edited","","no");
INSERT INTO `arc1542_options` VALUES("41","template","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("42","stylesheet","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("43","comment_whitelist","1","yes");
INSERT INTO `arc1542_options` VALUES("44","blacklist_keys","","no");
INSERT INTO `arc1542_options` VALUES("45","comment_registration","0","yes");
INSERT INTO `arc1542_options` VALUES("46","html_type","text/html","yes");
INSERT INTO `arc1542_options` VALUES("47","use_trackback","0","yes");
INSERT INTO `arc1542_options` VALUES("48","default_role","subscriber","yes");
INSERT INTO `arc1542_options` VALUES("49","db_version","31536","yes");
INSERT INTO `arc1542_options` VALUES("50","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `arc1542_options` VALUES("51","upload_path","","yes");
INSERT INTO `arc1542_options` VALUES("52","blog_public","0","yes");
INSERT INTO `arc1542_options` VALUES("53","default_link_category","2","yes");
INSERT INTO `arc1542_options` VALUES("54","show_on_front","posts","yes");
INSERT INTO `arc1542_options` VALUES("55","tag_base","","yes");
INSERT INTO `arc1542_options` VALUES("56","show_avatars","1","yes");
INSERT INTO `arc1542_options` VALUES("57","avatar_rating","G","yes");
INSERT INTO `arc1542_options` VALUES("58","upload_url_path","","yes");
INSERT INTO `arc1542_options` VALUES("59","thumbnail_size_w","150","yes");
INSERT INTO `arc1542_options` VALUES("60","thumbnail_size_h","150","yes");
INSERT INTO `arc1542_options` VALUES("61","thumbnail_crop","1","yes");
INSERT INTO `arc1542_options` VALUES("62","medium_size_w","300","yes");
INSERT INTO `arc1542_options` VALUES("63","medium_size_h","300","yes");
INSERT INTO `arc1542_options` VALUES("64","avatar_default","mystery","yes");
INSERT INTO `arc1542_options` VALUES("65","large_size_w","1024","yes");
INSERT INTO `arc1542_options` VALUES("66","large_size_h","1024","yes");
INSERT INTO `arc1542_options` VALUES("67","image_default_link_type","file","yes");
INSERT INTO `arc1542_options` VALUES("68","image_default_size","","yes");
INSERT INTO `arc1542_options` VALUES("69","image_default_align","","yes");
INSERT INTO `arc1542_options` VALUES("70","close_comments_for_old_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("71","close_comments_days_old","14","yes");
INSERT INTO `arc1542_options` VALUES("72","thread_comments","1","yes");
INSERT INTO `arc1542_options` VALUES("73","thread_comments_depth","5","yes");
INSERT INTO `arc1542_options` VALUES("74","page_comments","0","yes");
INSERT INTO `arc1542_options` VALUES("75","comments_per_page","50","yes");
INSERT INTO `arc1542_options` VALUES("76","default_comments_page","newest","yes");
INSERT INTO `arc1542_options` VALUES("77","comment_order","asc","yes");
INSERT INTO `arc1542_options` VALUES("78","sticky_posts","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("79","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("80","widget_text","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("81","widget_rss","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("82","uninstall_plugins","a:1:{s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:12:\"on_uninstall\";}}","no");
INSERT INTO `arc1542_options` VALUES("83","timezone_string","America/New_York","yes");
INSERT INTO `arc1542_options` VALUES("84","page_for_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("85","page_on_front","0","yes");
INSERT INTO `arc1542_options` VALUES("86","default_post_format","0","yes");
INSERT INTO `arc1542_options` VALUES("87","link_manager_enabled","0","yes");
INSERT INTO `arc1542_options` VALUES("88","initial_db_version","31535","yes");
INSERT INTO `arc1542_options` VALUES("89","arc1542_user_roles","a:6:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"UT_site_admin\";a:2:{s:4:\"name\";s:13:\"UT Site Admin\";s:12:\"capabilities\";a:39:{s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_pages\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_pages\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:18:\"edit_theme_options\";b:1;s:24:\"gravityforms_create_form\";b:1;s:27:\"gravityforms_delete_entries\";b:1;s:25:\"gravityforms_delete_forms\";b:1;s:25:\"gravityforms_edit_entries\";b:1;s:29:\"gravityforms_edit_entry_notes\";b:1;s:23:\"gravityforms_edit_forms\";b:1;s:27:\"gravityforms_export_entries\";b:1;s:17:\"gravityforms_feed\";b:1;s:25:\"gravityforms_view_entries\";b:1;s:29:\"gravityforms_view_entry_notes\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"upload_files\";b:1;s:10:\"view_stats\";b:1;s:14:\"show_admin_bar\";b:1;}}}","yes");
INSERT INTO `arc1542_options` VALUES("90","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("91","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("92","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("93","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("94","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("95","sidebars_widgets","a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:11:\"sidebar-404\";N;s:9:\"sidebar-3\";N;s:9:\"sidebar-4\";N;s:9:\"sidebar-5\";N;s:9:\"sidebar-6\";N;s:9:\"sidebar-7\";N;s:9:\"sidebar-8\";N;s:9:\"sidebar-9\";N;s:13:\"array_version\";i:3;}","yes");
INSERT INTO `arc1542_options` VALUES("97","cron","a:15:{i:1439000966;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439003267;a:1:{s:21:\"wordfence_hourly_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1439019760;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1439020380;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1439063078;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1439063134;a:2:{s:16:\"itsec_purge_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"itsec_purge_lockouts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1439082467;a:2:{s:26:\"wordfence_daily_autoUpdate\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"wordfence_daily_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1439088113;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439172737;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439260373;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439346122;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439431283;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439517658;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1439841600;a:1:{s:31:\"wordfence_email_activity_report\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `arc1542_options` VALUES("106","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1438996820;s:7:\"checked\";a:1:{s:10:\"ut-thehill\";s:5:\"1.0.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("108","_transient_random_seed","408b2693dc2097230baad992d5a304a5","yes");
INSERT INTO `arc1542_options` VALUES("134","itsec_data","a:5:{s:5:\"build\";i:4036;s:20:\"activation_timestamp\";i:1434397534;s:17:\"already_supported\";b:1;s:15:\"setup_completed\";b:1;s:18:\"tooltips_dismissed\";b:1;}","yes");
INSERT INTO `arc1542_options` VALUES("135","itsec_global","a:24:{s:11:\"write_files\";b:1;s:18:\"notification_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:12:\"digest_email\";b:1;s:12:\"backup_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:19:\"email_notifications\";b:1;s:8:\"log_type\";i:0;s:12:\"log_rotation\";i:14;s:12:\"log_location\";s:66:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/logs\";s:11:\"did_upgrade\";b:0;s:14:\"allow_tracking\";b:0;s:10:\"nginx_file\";s:36:\"/Users/ahayter/Sites/test/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:8:\"log_info\";s:13:\"arc-g8FzN7rLD\";s:9:\"lock_file\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("136","itsec_initials","a:3:{s:5:\"login\";b:0;s:5:\"admin\";b:0;s:11:\"file_editor\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("138","itsec_ipcheck","a:1:{s:7:\"api_ban\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("139","itsec_four_oh_four","a:5:{s:7:\"enabled\";b:1;s:12:\"check_period\";i:5;s:15:\"error_threshold\";i:20;s:10:\"white_list\";a:9:{i:0;s:12:\"/favicon.ico\";i:1;s:11:\"/robots.txt\";i:2;s:21:\"/apple-touch-icon.png\";i:3;s:33:\"/apple-touch-icon-precomposed.png\";i:4;s:17:\"/wp-content/cache\";i:5;s:18:\"/browserconfig.xml\";i:6;s:16:\"/crossdomain.xml\";i:7;s:11:\"/labels.rdf\";i:8;s:27:\"/trafficbasedsspsitemap.xml\";}s:5:\"types\";a:5:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".gif\";i:4;s:4:\".css\";}}","yes");
INSERT INTO `arc1542_options` VALUES("140","itsec_away_mode","a:4:{s:4:\"type\";i:1;s:7:\"enabled\";b:0;s:5:\"start\";i:1434412800;s:3:\"end\";i:1434520800;}","yes");
INSERT INTO `arc1542_options` VALUES("141","itsec_ban_users","a:4:{s:7:\"default\";b:1;s:7:\"enabled\";b:1;s:9:\"host_list\";a:46:{i:0;s:10:\"8.21.4.254\";i:1;s:15:\"65.46.48.192/30\";i:2;s:17:\"65.160.238.176/28\";i:3;s:14:\"85.92.222.0/24\";i:4;s:14:\"206.51.36.0/22\";i:5;s:14:\"216.52.23.0/24\";i:6;s:14:\"38.100.19.8/29\";i:7;s:14:\"38.100.21.0/24\";i:8;s:15:\"38.100.41.64/26\";i:9;s:14:\"38.105.71.0/25\";i:10;s:14:\"38.105.83.0/27\";i:11;s:16:\"38.112.21.140/30\";i:12;s:15:\"38.118.42.32/29\";i:13;s:17:\"65.213.208.128/27\";i:14;s:16:\"65.222.176.96/27\";i:15;s:16:\"65.222.185.72/29\";i:16;s:16:\"38.103.17.160/27\";i:17;s:14:\"66.113.96.0/20\";i:18;s:16:\"70.35.113.192/27\";i:19;s:14:\"204.15.80.0/22\";i:20;s:15:\"66.17.15.128/26\";i:21;s:15:\"69.84.207.32/27\";i:22;s:16:\"69.84.207.128/25\";i:23;s:14:\"72.36.128.0/17\";i:24;s:13:\"72.232.0.0/16\";i:25;s:13:\"72.233.0.0/17\";i:26;s:13:\"216.32.0.0/14\";i:27;s:17:\"67.192.231.224/29\";i:28;s:15:\"208.90.236.0/22\";i:29;s:18:\"209.147.127.208/28\";i:30;s:16:\"198.186.190.0/23\";i:31;s:16:\"198.186.192.0/23\";i:32;s:16:\"198.186.194.0/24\";i:33;s:16:\"207.210.99.32/29\";i:34;s:11:\"4.53.120.22\";i:35;s:13:\"66.194.6.0/24\";i:36;s:17:\"67.117.201.128/28\";i:37;s:13:\"69.67.32.0/20\";i:38;s:15:\"131.191.87.0/24\";i:39;s:14:\"204.15.64.0/21\";i:40;s:15:\"208.80.192.0/21\";i:41;s:15:\"212.62.26.64/27\";i:42;s:16:\"213.168.226.0/24\";i:43;s:16:\"213.168.241.0/30\";i:44;s:16:\"213.168.242.0/30\";i:45;s:17:\"213.236.150.16/28\";}s:10:\"agent_list\";a:1:{i:0;s:0:\"\";}}","yes");
INSERT INTO `arc1542_options` VALUES("143","itsec_brute_force","a:5:{s:7:\"enabled\";b:1;s:17:\"max_attempts_host\";i:5;s:17:\"max_attempts_user\";i:10;s:12:\"check_period\";i:5;s:14:\"auto_ban_admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("144","itsec_backup","a:9:{s:6:\"method\";i:0;s:8:\"location\";s:69:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:3:{i:0;s:14:\"itsec_lockouts\";i:1;s:9:\"itsec_log\";i:2;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:9:\"all_sites\";b:0;s:8:\"last_run\";i:1438996030;}","yes");
INSERT INTO `arc1542_options` VALUES("145","itsec_file_change","a:9:{s:7:\"enabled\";b:1;s:5:\"split\";b:1;s:6:\"method\";b:1;s:9:\"file_list\";a:1:{i:0;s:0:\"\";}s:5:\"types\";a:6:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".log\";i:4;s:3:\".mo\";i:5;s:3:\".po\";}s:5:\"email\";b:1;s:12:\"notify_admin\";b:1;s:10:\"last_chunk\";i:3;s:8:\"last_run\";d:1438981630;}","yes");
INSERT INTO `arc1542_options` VALUES("146","itsec_hide_backend","a:7:{s:7:\"enabled\";b:1;s:4:\"slug\";s:8:\"arclogin\";s:12:\"theme_compat\";b:1;s:17:\"theme_compat_slug\";s:9:\"not_found\";s:16:\"post_logout_slug\";s:0:\"\";s:12:\"show-tooltip\";b:0;s:8:\"register\";s:15:\"wp-register.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("147","itsec_malware","a:2:{s:7:\"enabled\";b:1;s:7:\"api_key\";s:64:\"91f63fb64116aa3269a33bb0e05891edf78a823f2fc7383ef3a03850c1f2bd59\";}","yes");
INSERT INTO `arc1542_options` VALUES("148","itsec_ssl","a:3:{s:8:\"frontend\";i:0;s:5:\"login\";b:0;s:5:\"admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("150","itsec_strong_passwords","a:2:{s:7:\"enabled\";b:1;s:4:\"roll\";s:6:\"author\";}","yes");
INSERT INTO `arc1542_options` VALUES("151","itsec_tweaks","a:22:{s:13:\"protect_files\";b:1;s:18:\"directory_browsing\";b:1;s:15:\"request_methods\";b:1;s:24:\"suspicious_query_strings\";b:1;s:16:\"long_url_strings\";b:1;s:17:\"write_permissions\";b:1;s:11:\"uploads_php\";b:1;s:13:\"generator_tag\";b:1;s:18:\"wlwmanifest_header\";b:1;s:14:\"edituri_header\";b:1;s:12:\"comment_spam\";b:1;s:14:\"random_version\";b:1;s:11:\"file_editor\";b:1;s:14:\"disable_xmlrpc\";i:1;s:12:\"login_errors\";b:1;s:21:\"force_unique_nicename\";b:1;s:27:\"disable_unused_author_pages\";b:1;s:22:\"non_english_characters\";b:0;s:13:\"theme_updates\";b:0;s:14:\"plugin_updates\";b:0;s:12:\"core_updates\";b:0;s:11:\"safe_jquery\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("153","recently_activated","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("157","itsec_temp_whitelist_ip","a:2:{s:2:\"ip\";s:3:\"::1\";s:3:\"exp\";i:1434483993;}","yes");
INSERT INTO `arc1542_options` VALUES("158","itsec_message_queue","a:2:{s:9:\"last_sent\";i:1439255124;s:8:\"messages\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("164","WPLANG","","yes");
INSERT INTO `arc1542_options` VALUES("188","itsec_local_file_list_0","a:389:{s:18:\"wp-admin/about.php\";a:2:{s:1:\"d\";i:1430967808;s:1:\"h\";s:32:\"5863f4e68b87af955a3c6a15a68ca6e0\";}s:23:\"wp-admin/admin-ajax.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"57c0bcd9ee3a9e92656deb0d2d584c24\";}s:25:\"wp-admin/admin-footer.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"62134b74766f43dcca4e776a76f44182\";}s:28:\"wp-admin/admin-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"e3f39d6761a2cdce12638d33ad6171bd\";}s:25:\"wp-admin/admin-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"a013ac49d93a73142cce8ad419c71987\";}s:23:\"wp-admin/admin-post.php\";a:2:{s:1:\"d\";i:1417362144;s:1:\"h\";s:32:\"9405e022d36cdf45f029d94518ce4103\";}s:18:\"wp-admin/admin.php\";a:2:{s:1:\"d\";i:1422546802;s:1:\"h\";s:32:\"3490100547f0bfa48258b7ce974ee5c4\";}s:25:\"wp-admin/async-upload.php\";a:2:{s:1:\"d\";i:1423718130;s:1:\"h\";s:32:\"f83c42723f64875427828b5a179c3058\";}s:20:\"wp-admin/comment.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d7d2857905104581460d4024a44439bc\";}s:20:\"wp-admin/credits.php\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"6d600524bee7a3f198bd1788c559e44a\";}s:26:\"wp-admin/css/about-rtl.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"a2812f9bae76c25229981a60a3452159\";}s:22:\"wp-admin/css/about.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"f0c69f88bca95e586cd57cf7b50d56ce\";}s:31:\"wp-admin/css/admin-menu-rtl.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"9f8a90c453ec305769a851ceba7e13b5\";}s:27:\"wp-admin/css/admin-menu.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"833e64b0003fc66897e82fcfc7fc0121\";}s:33:\"wp-admin/css/color-picker-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f9e65b1bb803a9710e3447d689c1d361\";}s:37:\"wp-admin/css/color-picker-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b95a1b3477b0c06cfa7f65a11d24bbe8\";}s:29:\"wp-admin/css/color-picker.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2d0d4dc75f8710681395c1b31c6c662f\";}s:33:\"wp-admin/css/color-picker.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b4bbb3b27d8fa55598129646b3bf278f\";}s:31:\"wp-admin/css/colors/_admin.scss\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3dbce149457e880a29693684cecd425\";}s:32:\"wp-admin/css/colors/_mixins.scss\";a:2:{s:1:\"d\";i:1409135536;s:1:\"h\";s:32:\"53e25fcbec91e57c9127342e6f2736ee\";}s:35:\"wp-admin/css/colors/_variables.scss\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"3ab501096b1a091972d84c85b284135a\";}s:39:\"wp-admin/css/colors/blue/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"18340a88bc601743b7c70439cec488ed\";}s:43:\"wp-admin/css/colors/blue/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3ef984189150a8810a060747213016b\";}s:35:\"wp-admin/css/colors/blue/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"3518d1b1e45e704aeecc47c0b5e5fae0\";}s:39:\"wp-admin/css/colors/blue/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"998f2d1f4b8565cb04f4c28a3a38b611\";}s:36:\"wp-admin/css/colors/blue/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"d9d03549d79484672c29145aad594db3\";}s:41:\"wp-admin/css/colors/coffee/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"2272c3bc872bdcce77a6b8d0ec902701\";}s:45:\"wp-admin/css/colors/coffee/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"fc48153c9c53bf2d871067cbfca6c8c4\";}s:37:\"wp-admin/css/colors/coffee/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b4cd3218e3c6e52336a8da60cf847d4c\";}s:41:\"wp-admin/css/colors/coffee/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c8796229a84fa15d28de61c772a0d67a\";}s:38:\"wp-admin/css/colors/coffee/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"397e3820b27a234330c95e05250f61ce\";}s:44:\"wp-admin/css/colors/ectoplasm/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58f1d1b2e4ed824585e5cfa1757f49c1\";}s:48:\"wp-admin/css/colors/ectoplasm/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"6f85716a47597c040d5549bbd61ff927\";}s:40:\"wp-admin/css/colors/ectoplasm/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9538ad4bdbecfe10e0bfac3898ee6286\";}s:44:\"wp-admin/css/colors/ectoplasm/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"d392ab4aa1d7ba0fc2c7538e62b30448\";}s:41:\"wp-admin/css/colors/ectoplasm/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"940171d1392bd8071122a905d12b9195\";}s:40:\"wp-admin/css/colors/light/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"ca985fbb17060a4a54e0c2b9c9e4c54a\";}s:44:\"wp-admin/css/colors/light/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"14e0f61252198b7f5bc6b3954f86495c\";}s:36:\"wp-admin/css/colors/light/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"25e706f4ca9277b6f5c09ec85e8360ac\";}s:40:\"wp-admin/css/colors/light/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c64378da84783433e12a436eabb62f79\";}s:37:\"wp-admin/css/colors/light/colors.scss\";a:2:{s:1:\"d\";i:1395957374;s:1:\"h\";s:32:\"20a8567ba70294295c115f7ed9e071b7\";}s:43:\"wp-admin/css/colors/midnight/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7386ebd85ed17227277f38bf986ec649\";}s:47:\"wp-admin/css/colors/midnight/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"46d38df7939457add9e0cb01862625fd\";}s:39:\"wp-admin/css/colors/midnight/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7828a09a10e456933f4f44a27bc9e760\";}s:43:\"wp-admin/css/colors/midnight/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b048ef915d1fa35107bc54d96bdca463\";}s:40:\"wp-admin/css/colors/midnight/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"26dc8daaf0c47c4457b8bc2145f48634\";}s:40:\"wp-admin/css/colors/ocean/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83320550041b6ac4a3b224f8cd66a156\";}s:44:\"wp-admin/css/colors/ocean/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9b6c0b762c7c8c9edb0fdf22fd85084f\";}s:36:\"wp-admin/css/colors/ocean/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58be4f65a594e084222693e8fba9867e\";}s:40:\"wp-admin/css/colors/ocean/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b020388806a04a345a11b54a667b0f0a\";}s:37:\"wp-admin/css/colors/ocean/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"1a7c5bfd9faf7f6cc77cd9b166062568\";}s:42:\"wp-admin/css/colors/sunrise/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"1579864ea35ebc26521222e136a961e7\";}s:46:\"wp-admin/css/colors/sunrise/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"be0732f8240abe60df1783354817ade5\";}s:38:\"wp-admin/css/colors/sunrise/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"43709ad04cfe4981c074767db4cec654\";}s:42:\"wp-admin/css/colors/sunrise/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83453647da515355dc45a661ab42ea38\";}s:39:\"wp-admin/css/colors/sunrise/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"5692871a8a7a1914ee0968ddf9923dec\";}s:27:\"wp-admin/css/common-rtl.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"81f0f785dbd8eee0a11d054a3cbdf606\";}s:23:\"wp-admin/css/common.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"6942f692b44491261619b43859b8acfc\";}s:39:\"wp-admin/css/customize-controls-rtl.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"1d0e5ded99e0c19c6deab1602412ad4d\";}s:43:\"wp-admin/css/customize-controls-rtl.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"27d9de08d110062db4c26b9fea3b21cc\";}s:35:\"wp-admin/css/customize-controls.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"183493ffd9bb469e92882434bb95f33c\";}s:39:\"wp-admin/css/customize-controls.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"f94aad7c60a799b4bf28b0e6ea0b0134\";}s:38:\"wp-admin/css/customize-widgets-rtl.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7ab3411bcab95d99021791a7da6a39c8\";}s:42:\"wp-admin/css/customize-widgets-rtl.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"86d0504f3f24934ce87ed755d6d16a98\";}s:34:\"wp-admin/css/customize-widgets.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7cec3fb121b9608cfb8c6a089bdc1a78\";}s:38:\"wp-admin/css/customize-widgets.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"868832fcafbffba43f5ba4fbf31d3ca5\";}s:30:\"wp-admin/css/dashboard-rtl.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"ebb761dcfd6cb62a9983a41f6c69266a\";}s:26:\"wp-admin/css/dashboard.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"c178ee058ec19c709f30baed82db8392\";}s:37:\"wp-admin/css/deprecated-media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"558fe352dfdab9790dab9710438af5a9\";}s:41:\"wp-admin/css/deprecated-media-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"017b6102507494583f9241b9f8854959\";}s:33:\"wp-admin/css/deprecated-media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0ada8c65bb367cab1cabc0defa1ac6a6\";}s:37:\"wp-admin/css/deprecated-media.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"625227ce35e802591f85a974db531d36\";}s:25:\"wp-admin/css/edit-rtl.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"be99c57389c7d414f0f58f33678a0824\";}s:21:\"wp-admin/css/edit.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"dca1f2c9b549b0c85b279a27e4adc142\";}s:31:\"wp-admin/css/farbtastic-rtl.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"118f1189ffbb71e014402121b5456bc2\";}s:27:\"wp-admin/css/farbtastic.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"f9e33829b8faed7d7bbef843fb683255\";}s:26:\"wp-admin/css/forms-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"fe5319684165959b7b00b618009c3e81\";}s:22:\"wp-admin/css/forms.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8f95818bedd2456f61d3f82926bbe549\";}s:23:\"wp-admin/css/ie-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0b9e0977caa2f7f8f935d5b5536cf6d7\";}s:27:\"wp-admin/css/ie-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"46dca3fdd473c8b6cec51e3ff5d700c6\";}s:19:\"wp-admin/css/ie.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f146885900f710c867cd48f030851e97\";}s:23:\"wp-admin/css/ie.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"494254d427a06ead698729501d1706c9\";}s:28:\"wp-admin/css/install-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2a0fc0a9434d3aa6abfda715dfe80ca2\";}s:32:\"wp-admin/css/install-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"e3e8c235f96ea51104cde0104ae12010\";}s:24:\"wp-admin/css/install.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"42c906bd2400b2ab11aa44a8f8396a9e\";}s:28:\"wp-admin/css/install.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"333fb17a509abf264fd13c529939608b\";}s:25:\"wp-admin/css/l10n-rtl.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"fcb0063a38cf8348351737634db3f947\";}s:21:\"wp-admin/css/l10n.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"5dda0b5411fecbe1fac83dfe21c7540e\";}s:32:\"wp-admin/css/list-tables-rtl.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"a44b142006df40f488aec4ea1357883c\";}s:28:\"wp-admin/css/list-tables.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"b34413b3174ac624919ce065ebb29aba\";}s:26:\"wp-admin/css/login-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"35f23fc2280b36e67ad2afb8c6737a03\";}s:30:\"wp-admin/css/login-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"563cb2edac2f1e28bc7ba07afcdda851\";}s:22:\"wp-admin/css/login.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0e01b8fa9ea4487455a587c852b405c5\";}s:26:\"wp-admin/css/login.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c4661abb4164f292618baa46c3b04235\";}s:26:\"wp-admin/css/media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b5f2073fd98bf22e2f2b2353a2475f9f\";}s:22:\"wp-admin/css/media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f578fae6b47beea325ee8dc1a8551e88\";}s:30:\"wp-admin/css/nav-menus-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"91ff408d32eacbd28e621c34b7565f8d\";}s:26:\"wp-admin/css/nav-menus.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d3266344ddb105a2e774a071dd05a361\";}s:38:\"wp-admin/css/press-this-editor-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8de2501460648d4cb12d23774d21dd5f\";}s:34:\"wp-admin/css/press-this-editor.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"953fa7568d1de29bc722de0c8d27c59d\";}s:31:\"wp-admin/css/press-this-rtl.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"7f2b2879d22aa540d113a4af70999990\";}s:35:\"wp-admin/css/press-this-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"c6dcd57eb62b059f20223ca862046a02\";}s:27:\"wp-admin/css/press-this.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"dca19314e2e3871f91e07bcf64b23e53\";}s:31:\"wp-admin/css/press-this.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"48180a7b52dd60bec1fc7a0ae2be0826\";}s:30:\"wp-admin/css/revisions-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"cc328e9ddbef2ef2c495786078ff612a\";}s:26:\"wp-admin/css/revisions.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d266c3e67470bf8f70d91d920b1b50f1\";}s:27:\"wp-admin/css/themes-rtl.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"ed00d87745e51769e94fb921930d997d\";}s:23:\"wp-admin/css/themes.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"0f2c9837f4d58bec62e54c49bc2b7794\";}s:28:\"wp-admin/css/widgets-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d81963de7dff71f3295c5a42fba00ab7\";}s:24:\"wp-admin/css/widgets.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"4dc79b8deabc48edc3cb04b90633810d\";}s:29:\"wp-admin/css/wp-admin-rtl.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"7fbe22c3651b774033fa758ca07ccbbb\";}s:33:\"wp-admin/css/wp-admin-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"030caf3660328d0bb366809887d33a2a\";}s:25:\"wp-admin/css/wp-admin.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"ada11abbeb8553e9524605cbfc29d26d\";}s:29:\"wp-admin/css/wp-admin.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"225d1ef58b5ab0f793d3952967df269a\";}s:30:\"wp-admin/custom-background.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"89d8a54f939a110003510e982d8fe57f\";}s:26:\"wp-admin/custom-header.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5488cf2e8e9630388723c51a7a0726bc\";}s:22:\"wp-admin/customize.php\";a:2:{s:1:\"d\";i:1428009388;s:1:\"h\";s:32:\"5481909613787611390e7c3548337820\";}s:26:\"wp-admin/edit-comments.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"294f99f28d493d34925d56791d4b16ab\";}s:31:\"wp-admin/edit-form-advanced.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"833ab8eb05e8b63fb56b8c62363b9591\";}s:30:\"wp-admin/edit-form-comment.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"8325c6fe38489470c57f3f4832e17892\";}s:27:\"wp-admin/edit-link-form.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"fa37a6bab69f64e1479847f5008e4725\";}s:26:\"wp-admin/edit-tag-form.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"463fb3100f9f45fbd0ca2f297725e68f\";}s:22:\"wp-admin/edit-tags.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4dfc7b236b076202eda683d2616fb77e\";}s:17:\"wp-admin/edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"e181a2ab1d1838d41a71df7d75fe8a91\";}s:19:\"wp-admin/export.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d62d73bc749f99ef989dba3f5fc85f4a\";}s:21:\"wp-admin/freedoms.php\";a:2:{s:1:\"d\";i:1429072708;s:1:\"h\";s:32:\"65830b9bbe81aac353761e4c5879c2b8\";}s:32:\"wp-admin/images/bubble_bg-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"16523d5bf9efd8ca3b92e7631edfc513\";}s:29:\"wp-admin/images/bubble_bg.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3d2cb3f7baa628c9e51a326356e72038\";}s:34:\"wp-admin/images/date-button-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2952932c246bf9828429361643a8bb63\";}s:31:\"wp-admin/images/date-button.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"979d8e2e08aada49819556950ec48ff6\";}s:27:\"wp-admin/images/loading.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2d5b92b61674c850bff00cecaf0864ec\";}s:38:\"wp-admin/images/media-button-image.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7ea2c9c157c38edb40b1ce62d572d5b3\";}s:38:\"wp-admin/images/media-button-music.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"eff55df37f325c5aae2f02e4d913de95\";}s:38:\"wp-admin/images/media-button-other.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8bc6b46bc70c7c1918dce62c4fe3229c\";}s:38:\"wp-admin/images/media-button-video.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"abaac3dfd81fbf72e578f13451eae7d0\";}s:29:\"wp-admin/images/resize-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"f5e118653f892606682ee9c51d0aba99\";}s:33:\"wp-admin/images/resize-rtl-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"f7c99ee74014fe92541012303aaadc7d\";}s:30:\"wp-admin/images/resize-rtl.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"db9217196313c95a59d43601da19c51d\";}s:26:\"wp-admin/images/resize.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3fba1544df24f40dde5876c8c0aec461\";}s:27:\"wp-admin/images/sort-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"186e51267fca5d20b230c72d9a8983ee\";}s:24:\"wp-admin/images/sort.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2e8acb8dee99bfbcb61bd46c486a995d\";}s:30:\"wp-admin/images/spinner-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"5c1371bcb4392968647852a9c9df5d6c\";}s:27:\"wp-admin/images/spinner.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"b0a3dde331637e27aa6476d476481871\";}s:40:\"wp-admin/images/wordpress-logo-white.svg\";a:2:{s:1:\"d\";i:1384078330;s:1:\"h\";s:32:\"e1af633d59dcb5988cacff73b6dee9ff\";}s:34:\"wp-admin/images/wordpress-logo.svg\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f34ef6259364f7ef0ccf67cd1dddc970\";}s:35:\"wp-admin/images/wpspin_light-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7def33aad959cd289d49ddf2a41f076d\";}s:32:\"wp-admin/images/wpspin_light.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"dd4e6dd268a70ce4c1c5143b1a4092dd\";}s:26:\"wp-admin/images/xit-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8fb0729c541cbdc4609faf3f4ad02fc7\";}s:23:\"wp-admin/images/xit.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"e5012902a358fbb96031acdcf048d7ca\";}s:19:\"wp-admin/import.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6e389b5d3ce9c49472c2f65737894057\";}s:27:\"wp-admin/includes/admin.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"be54224152f2b4ec6879ffdbba435129\";}s:34:\"wp-admin/includes/ajax-actions.php\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"8d262c73247924453f1692cd240c75c3\";}s:30:\"wp-admin/includes/bookmark.php\";a:2:{s:1:\"d\";i:1416132982;s:1:\"h\";s:32:\"5682d92e5f2542298a6ab34186891a61\";}s:36:\"wp-admin/includes/class-ftp-pure.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"2cfd5c1b2e4288cef60faddbedeff8d3\";}s:39:\"wp-admin/includes/class-ftp-sockets.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"54d9e85b94c4e6368813852b9a81273c\";}s:31:\"wp-admin/includes/class-ftp.php\";a:2:{s:1:\"d\";i:1415803464;s:1:\"h\";s:32:\"ad8496325608fb75875c49f64c0b84fc\";}s:34:\"wp-admin/includes/class-pclzip.php\";a:2:{s:1:\"d\";i:1255652782;s:1:\"h\";s:32:\"01363728c843ff93e96b6983ce38eba6\";}s:50:\"wp-admin/includes/class-wp-comments-list-table.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"03b99541cc4e471541f6eb52fc993cdb\";}s:46:\"wp-admin/includes/class-wp-filesystem-base.php\";a:2:{s:1:\"d\";i:1424944104;s:1:\"h\";s:32:\"053d3e7194eb24bd010794b2e45f8070\";}s:48:\"wp-admin/includes/class-wp-filesystem-direct.php\";a:2:{s:1:\"d\";i:1419122424;s:1:\"h\";s:32:\"7c687f407b517d35e8986321df4b3059\";}s:48:\"wp-admin/includes/class-wp-filesystem-ftpext.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"b18e349ccc50fc1b3f7e240dd365347e\";}s:52:\"wp-admin/includes/class-wp-filesystem-ftpsockets.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"4eb43c52d18090a544df4676af189b9e\";}s:46:\"wp-admin/includes/class-wp-filesystem-ssh2.php\";a:2:{s:1:\"d\";i:1425889948;s:1:\"h\";s:32:\"d43d02e98585870d63d76fd7e23cb732\";}s:39:\"wp-admin/includes/class-wp-importer.php\";a:2:{s:1:\"d\";i:1421463082;s:1:\"h\";s:32:\"d04b79a26c434bac92572eb31da8a135\";}s:47:\"wp-admin/includes/class-wp-links-list-table.php\";a:2:{s:1:\"d\";i:1421288062;s:1:\"h\";s:32:\"7050b4928ed9e9a71e7b34570ff74557\";}s:41:\"wp-admin/includes/class-wp-list-table.php\";a:2:{s:1:\"d\";i:1424656106;s:1:\"h\";s:32:\"15b7819b8098a83efa5b124cd8736842\";}s:47:\"wp-admin/includes/class-wp-media-list-table.php\";a:2:{s:1:\"d\";i:1427846246;s:1:\"h\";s:32:\"5eaa024ba0f05d24b8ee56be1dc7c6f6\";}s:50:\"wp-admin/includes/class-wp-ms-sites-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"1603c869a83696c7f27c914b13aa7b68\";}s:51:\"wp-admin/includes/class-wp-ms-themes-list-table.php\";a:2:{s:1:\"d\";i:1421093842;s:1:\"h\";s:32:\"b7d8cddc268e99caa0fd867cc57a9d15\";}s:50:\"wp-admin/includes/class-wp-ms-users-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"e4f826892bb47ac498e17de592c4b023\";}s:56:\"wp-admin/includes/class-wp-plugin-install-list-table.php\";a:2:{s:1:\"d\";i:1428032968;s:1:\"h\";s:32:\"c169312a5c0d45bf60729cefc606cd43\";}s:49:\"wp-admin/includes/class-wp-plugins-list-table.php\";a:2:{s:1:\"d\";i:1427232808;s:1:\"h\";s:32:\"52c76d175bde8b9781e1600a6adcb812\";}s:47:\"wp-admin/includes/class-wp-posts-list-table.php\";a:2:{s:1:\"d\";i:1428178106;s:1:\"h\";s:32:\"eff04c61fdbf46485b95e161271493d8\";}s:41:\"wp-admin/includes/class-wp-press-this.php\";a:2:{s:1:\"d\";i:1429421668;s:1:\"h\";s:32:\"18e8b8c6e4c4abc97ffa4d4acb283651\";}s:47:\"wp-admin/includes/class-wp-terms-list-table.php\";a:2:{s:1:\"d\";i:1423035984;s:1:\"h\";s:32:\"5eb2173c2679ce21f141199be9f1165c\";}s:55:\"wp-admin/includes/class-wp-theme-install-list-table.php\";a:2:{s:1:\"d\";i:1425783808;s:1:\"h\";s:32:\"8ff475a867be95d6fdfd7fae9add0f34\";}s:48:\"wp-admin/includes/class-wp-themes-list-table.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"40cc946d84ea606286c8f15479544835\";}s:45:\"wp-admin/includes/class-wp-upgrader-skins.php\";a:2:{s:1:\"d\";i:1424639244;s:1:\"h\";s:32:\"3c5d0b0c99fe3af5504756355d661688\";}s:39:\"wp-admin/includes/class-wp-upgrader.php\";a:2:{s:1:\"d\";i:1428034708;s:1:\"h\";s:32:\"1fd2dd8f3265df13718ff7c90aa2eeb2\";}s:47:\"wp-admin/includes/class-wp-users-list-table.php\";a:2:{s:1:\"d\";i:1428196168;s:1:\"h\";s:32:\"936fe59e0bf3a8ed7ae1d91a34854015\";}s:29:\"wp-admin/includes/comment.php\";a:2:{s:1:\"d\";i:1414792582;s:1:\"h\";s:32:\"a2a4e95cdac0b8a2e42733ae29dea751\";}s:39:\"wp-admin/includes/continents-cities.php\";a:2:{s:1:\"d\";i:1242345926;s:1:\"h\";s:32:\"024b57d99bbe8b9e133316d1e98fc79d\";}s:31:\"wp-admin/includes/dashboard.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"7755ef730ecdc36415c482dbaf471b04\";}s:32:\"wp-admin/includes/deprecated.php\";a:2:{s:1:\"d\";i:1426101928;s:1:\"h\";s:32:\"0c665b41c9d916f3cbb7786711960e4b\";}s:28:\"wp-admin/includes/export.php\";a:2:{s:1:\"d\";i:1420715126;s:1:\"h\";s:32:\"78e46f3d610ca92a41acbea60e546496\";}s:26:\"wp-admin/includes/file.php\";a:2:{s:1:\"d\";i:1430292030;s:1:\"h\";s:32:\"aaf31744d17c235f7835b359cb5768d1\";}s:32:\"wp-admin/includes/image-edit.php\";a:2:{s:1:\"d\";i:1425070286;s:1:\"h\";s:32:\"dd6f097ac32ab3dac81fe65287bafde3\";}s:27:\"wp-admin/includes/image.php\";a:2:{s:1:\"d\";i:1425978448;s:1:\"h\";s:32:\"c13371e2d82ee708e7e8f3d09e84faa2\";}s:28:\"wp-admin/includes/import.php\";a:2:{s:1:\"d\";i:1419124224;s:1:\"h\";s:32:\"deb1db7743721bdda9411c8a5c04d70f\";}s:32:\"wp-admin/includes/list-table.php\";a:2:{s:1:\"d\";i:1405303756;s:1:\"h\";s:32:\"039a82ba14a35438ace23efba15fdf82\";}s:27:\"wp-admin/includes/media.php\";a:2:{s:1:\"d\";i:1428197726;s:1:\"h\";s:32:\"7ffe0152492297cb75fd7d96ef5b6461\";}s:26:\"wp-admin/includes/menu.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"58264a1bca858e1f712ec7f98f109899\";}s:32:\"wp-admin/includes/meta-boxes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"97773e9daa2b252b840c25f1ee5fda9f\";}s:26:\"wp-admin/includes/misc.php\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d28646b454f9f4e03fcf3be9b8d580cb\";}s:35:\"wp-admin/includes/ms-deprecated.php\";a:2:{s:1:\"d\";i:1425870568;s:1:\"h\";s:32:\"0b2f626d4faa139d644e4c0969f6aa58\";}s:24:\"wp-admin/includes/ms.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"aba87ff132e62a01485b10c37340f5bd\";}s:30:\"wp-admin/includes/nav-menu.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"914aebacbcbf40acb90559e04f53fe70\";}s:36:\"wp-admin/includes/plugin-install.php\";a:2:{s:1:\"d\";i:1428390566;s:1:\"h\";s:32:\"3eba38bff1614bec4d1a1f9650d04fff\";}s:28:\"wp-admin/includes/plugin.php\";a:2:{s:1:\"d\";i:1421457562;s:1:\"h\";s:32:\"ada165c90f5c7985fccb101bdf3afb38\";}s:26:\"wp-admin/includes/post.php\";a:2:{s:1:\"d\";i:1428198746;s:1:\"h\";s:32:\"d889e18d2c2714b9841da7bd03774b74\";}s:30:\"wp-admin/includes/revision.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"02ae8504c79255eebb2b7a6de6f65ca6\";}s:28:\"wp-admin/includes/schema.php\";a:2:{s:1:\"d\";i:1423568848;s:1:\"h\";s:32:\"d3e3579ef079b924c3dd4789fb6df040\";}s:28:\"wp-admin/includes/screen.php\";a:2:{s:1:\"d\";i:1426015948;s:1:\"h\";s:32:\"f5423c59bdc088834ed8e526c8bce73e\";}s:30:\"wp-admin/includes/taxonomy.php\";a:2:{s:1:\"d\";i:1422545662;s:1:\"h\";s:32:\"e345a18b9436e50ee17c4af7ffe1b2b5\";}s:30:\"wp-admin/includes/template.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"6699a307eb2ae234e38c6406b38956c3\";}s:35:\"wp-admin/includes/theme-install.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"e66174127b56d0eb51c685c32ad68455\";}s:27:\"wp-admin/includes/theme.php\";a:2:{s:1:\"d\";i:1429733486;s:1:\"h\";s:32:\"ebfda92f8dec9d6ba85462864b78c05a\";}s:41:\"wp-admin/includes/translation-install.php\";a:2:{s:1:\"d\";i:1423841006;s:1:\"h\";s:32:\"81931f61c70a5dbaa17236c86fe965ba\";}s:33:\"wp-admin/includes/update-core.php\";a:2:{s:1:\"d\";i:1430951968;s:1:\"h\";s:32:\"89bb7c2af227e6554315c3ee61ddff63\";}s:28:\"wp-admin/includes/update.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"83440a93ab1d6d7a2fd9d53a1589fdf4\";}s:29:\"wp-admin/includes/upgrade.php\";a:2:{s:1:\"d\";i:1430975550;s:1:\"h\";s:32:\"f0e28fe081e8a3a12087a695d3cb7a68\";}s:26:\"wp-admin/includes/user.php\";a:2:{s:1:\"d\";i:1428259468;s:1:\"h\";s:32:\"17eacf5ff7e5f4827a64d6c5424fd956\";}s:29:\"wp-admin/includes/widgets.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"f94a23c52573d5aab9c36b0c612e52c8\";}s:18:\"wp-admin/index.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2c75aa13fe1b4abb250879085a2efb0f\";}s:27:\"wp-admin/install-helper.php\";a:2:{s:1:\"d\";i:1416822444;s:1:\"h\";s:32:\"5480b0fabf52c37eee8bfed6db52335a\";}s:20:\"wp-admin/install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a48aee948fe2ea5d3a6b9a325b604f5\";}s:24:\"wp-admin/js/accordion.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"f25e56e30af6382e3770be437493373a\";}s:28:\"wp-admin/js/accordion.min.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"cfa0d94d00f7a8a147c3815dc819e114\";}s:26:\"wp-admin/js/bookmarklet.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"599601c1e1bcbf766f466722e50cb06b\";}s:30:\"wp-admin/js/bookmarklet.min.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"07603898b017e6cc23f7a5b90c003314\";}s:27:\"wp-admin/js/color-picker.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"0e948ad7ea32644d4dcadc0f54fac1e3\";}s:31:\"wp-admin/js/color-picker.min.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"1aa57d225b7d9bb8bfa8500e0c2de029\";}s:22:\"wp-admin/js/comment.js\";a:2:{s:1:\"d\";i:1384047010;s:1:\"h\";s:32:\"a3fefb4998b3f534e144db4f235d0f03\";}s:26:\"wp-admin/js/comment.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"38ff692f79a3e57df9b9192a9e43b4ea\";}s:21:\"wp-admin/js/common.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"dc9e2fa5c5e058e9a9466f48322e0f32\";}s:25:\"wp-admin/js/common.min.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"d3a3f5d88670f6fea04b6f523f67b528\";}s:32:\"wp-admin/js/custom-background.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"f26af7294ee07fb9a0cb88c2a8697623\";}s:36:\"wp-admin/js/custom-background.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"82d07f23593e578820b19fc9faad65a0\";}s:28:\"wp-admin/js/custom-header.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"32b3005887a4cb606fecc09c756605bb\";}s:33:\"wp-admin/js/customize-controls.js\";a:2:{s:1:\"d\";i:1428977430;s:1:\"h\";s:32:\"7c0e981e54ea85d7971d0a9b25a9c263\";}s:37:\"wp-admin/js/customize-controls.min.js\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"fa9142f8d88f8566d3dd0b40b602ce2e\";}s:32:\"wp-admin/js/customize-widgets.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"07f1519a2a074eb51cce3ec5cb9810d5\";}s:36:\"wp-admin/js/customize-widgets.min.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"ef95bf9c8588420084c724b541ec9fa0\";}s:24:\"wp-admin/js/dashboard.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"dcaf4f687c6c523cf0e2d5515234faa5\";}s:28:\"wp-admin/js/dashboard.min.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"39f67345a12faf1a3c53c9289fc59f86\";}s:28:\"wp-admin/js/edit-comments.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f6947b28c386e3637c99d199c4a32a33\";}s:32:\"wp-admin/js/edit-comments.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f303c21d68b4ebff99aab2df75f81db9\";}s:28:\"wp-admin/js/editor-expand.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"001eee141532f8fc1fac023dbb945a92\";}s:32:\"wp-admin/js/editor-expand.min.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"78a1af5d700f31280bfc20621bce8e50\";}s:21:\"wp-admin/js/editor.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"1e33af23a168b21a333bf6ba71ac4671\";}s:25:\"wp-admin/js/editor.min.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"a71c41c4b1c1f15084fe96f5f6d5e095\";}s:25:\"wp-admin/js/farbtastic.js\";a:2:{s:1:\"d\";i:1289507662;s:1:\"h\";s:32:\"a73af354a03241715d8698feea340b92\";}s:22:\"wp-admin/js/gallery.js\";a:2:{s:1:\"d\";i:1384873810;s:1:\"h\";s:32:\"1be9174b160c7eb40e6cdce4031ae89e\";}s:26:\"wp-admin/js/gallery.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"1c986fe3039dbacf126de2f0dc644f6f\";}s:25:\"wp-admin/js/image-edit.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c21931f1eecd6c1532a4c2ca7a7faa5e\";}s:29:\"wp-admin/js/image-edit.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"40c9a1866d7ab4aec2346e02d82f4758\";}s:31:\"wp-admin/js/inline-edit-post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"8c56d38ee4c4c97d875fdbc20ac029dd\";}s:35:\"wp-admin/js/inline-edit-post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"167e7b26c864699559d930fc5ce72a7a\";}s:30:\"wp-admin/js/inline-edit-tax.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"a920718b385e75e18193ee293ffdfd3c\";}s:34:\"wp-admin/js/inline-edit-tax.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4aa2a2e6ee60243f003d3ebb47edf4b4\";}s:23:\"wp-admin/js/iris.min.js\";a:2:{s:1:\"d\";i:1417362262;s:1:\"h\";s:32:\"75c63560c640c4a6c31f5565dfb0e8a9\";}s:31:\"wp-admin/js/language-chooser.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"09e20150c7561d0330d7158f744abb4a\";}s:35:\"wp-admin/js/language-chooser.min.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"1d6822384a71090c74add106e4468581\";}s:19:\"wp-admin/js/link.js\";a:2:{s:1:\"d\";i:1384506970;s:1:\"h\";s:32:\"1c8675dcd035cfb374f67bfcbf117a8c\";}s:23:\"wp-admin/js/link.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"f9ff4694933001933bdec2c133b2252d\";}s:28:\"wp-admin/js/media-gallery.js\";a:2:{s:1:\"d\";i:1384571950;s:1:\"h\";s:32:\"7cf21db8661f9201a784f638f77d2b26\";}s:32:\"wp-admin/js/media-gallery.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"3296d1fa20d292b002bba10490f1ba6e\";}s:27:\"wp-admin/js/media-upload.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"5f66a88c118be462a566029db50aa3a2\";}s:31:\"wp-admin/js/media-upload.min.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"61ea709a3314ba200a885e2465267aa2\";}s:20:\"wp-admin/js/media.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"cf85d75e70304c42f77553ee9b9ec585\";}s:24:\"wp-admin/js/media.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"2e8efd83242126157ff0bffd5e249159\";}s:23:\"wp-admin/js/nav-menu.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"d6facb8a8fe8d2ed1cdef140d006942a\";}s:27:\"wp-admin/js/nav-menu.min.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"e2fe94b081c4f0bb2e673b75b2d72b23\";}s:38:\"wp-admin/js/password-strength-meter.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"4d912846975670c9e2232a19ef7bb41b\";}s:42:\"wp-admin/js/password-strength-meter.min.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"3185f27c8fa4123db79a1d6de055c9d7\";}s:29:\"wp-admin/js/plugin-install.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"90585237ad358716313a1f5d9b9353b9\";}s:33:\"wp-admin/js/plugin-install.min.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"7a6211c90a9364fa26b36f9866d53e9e\";}s:19:\"wp-admin/js/post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"995f94db4b9e67b27b3d71ca72624988\";}s:23:\"wp-admin/js/post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c47dac85d54efe4352e7e5d6045970ab\";}s:22:\"wp-admin/js/postbox.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"87a08ca86f25ee997a627ce4a88ec359\";}s:26:\"wp-admin/js/postbox.min.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"8bf00b23dafb248f022d8b21693e0418\";}s:25:\"wp-admin/js/press-this.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"91993a940f719edbe2ad8a259973527e\";}s:29:\"wp-admin/js/press-this.min.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"682e5b74d3791a9c09b8c5317f84aa4a\";}s:24:\"wp-admin/js/revisions.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"41f746a4087bec7e9b0db4152759d169\";}s:28:\"wp-admin/js/revisions.min.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"3253906cffe4523bc05d0632af4c6af8\";}s:33:\"wp-admin/js/set-post-thumbnail.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"2b5153576d1eee4002fb7ed9e5831251\";}s:37:\"wp-admin/js/set-post-thumbnail.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"8bc5ca12fa38a607d5af2181311b7a5b\";}s:26:\"wp-admin/js/svg-painter.js\";a:2:{s:1:\"d\";i:1386295270;s:1:\"h\";s:32:\"87dcfbe97f902fa77cc4a9889c827afc\";}s:30:\"wp-admin/js/svg-painter.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"8db7f2acb2c205b766167517ccce7f8a\";}s:23:\"wp-admin/js/tags-box.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"74a49b1066cf04c0e5c92020e0ff23af\";}s:27:\"wp-admin/js/tags-box.min.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"e5824b6ec80b938c3c17d7a19e78d9a9\";}s:19:\"wp-admin/js/tags.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"4cc64266f1b35a86c63cc1b2c42f7306\";}s:23:\"wp-admin/js/tags.min.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"172f499d40d4217bbf684cd552031acb\";}s:20:\"wp-admin/js/theme.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"ce08e4628996a70a5d5deac9221e1130\";}s:24:\"wp-admin/js/theme.min.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"3bb1a6dc71edb4b953c6dec624b162c5\";}s:22:\"wp-admin/js/updates.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"79c9c0056693f2eba1f6007ccc6fb20b\";}s:26:\"wp-admin/js/updates.min.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"0f5a5b69ce6a28ec4efcaf68a55c21d5\";}s:27:\"wp-admin/js/user-profile.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"28090921c47b8aab172ab53dcc269d00\";}s:31:\"wp-admin/js/user-profile.min.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"6a1e4023a877503c50771b02f2d332c2\";}s:27:\"wp-admin/js/user-suggest.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"1e33290807fa8b2829ddb0347d0a9305\";}s:31:\"wp-admin/js/user-suggest.min.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"e089545cd7fcde5c7cd70de3a70139e1\";}s:22:\"wp-admin/js/widgets.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"485de2b76d48a457394827f2f5c5e0fb\";}s:26:\"wp-admin/js/widgets.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4c2c339725d1719abe9809b79e89d390\";}s:25:\"wp-admin/js/word-count.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"66256995400e51a5f931a11bc11e1e4e\";}s:29:\"wp-admin/js/word-count.min.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"c71cccaeb645b4e75e963aecff2f5fc6\";}s:28:\"wp-admin/js/wp-fullscreen.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"669dfa41fd076fadd200112960a46fcb\";}s:32:\"wp-admin/js/wp-fullscreen.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"d6a88a01bdc839e38c5a25c3533d32c4\";}s:18:\"wp-admin/js/xfn.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"e2d6eecbd774af1e2bb1a16ec117286b\";}s:22:\"wp-admin/js/xfn.min.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"66b227ca28f41f2e0615b04a390d5e04\";}s:21:\"wp-admin/link-add.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"759747ef8d44c52fadcfa5c457f3f283\";}s:25:\"wp-admin/link-manager.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"416c4e2eadb0a92b516391bed0b8ac02\";}s:28:\"wp-admin/link-parse-opml.php\";a:2:{s:1:\"d\";i:1428015688;s:1:\"h\";s:32:\"446ddcd3dec1e48190e666b238eba7e1\";}s:17:\"wp-admin/link.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"63adfdd74e61e01c62e1a1e41cd37f64\";}s:25:\"wp-admin/load-scripts.php\";a:2:{s:1:\"d\";i:1420268242;s:1:\"h\";s:32:\"3e0837db719900ab7dce30025b92ab30\";}s:24:\"wp-admin/load-styles.php\";a:2:{s:1:\"d\";i:1404431834;s:1:\"h\";s:32:\"e4fe4585bf1930564ff8d572a0a5eac2\";}s:25:\"wp-admin/maint/repair.php\";a:2:{s:1:\"d\";i:1404065416;s:1:\"h\";s:32:\"3ba2182300e632340850329b7065da34\";}s:22:\"wp-admin/media-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d37f8ace789522fe8d82eafda85bfbaf\";}s:25:\"wp-admin/media-upload.php\";a:2:{s:1:\"d\";i:1422964042;s:1:\"h\";s:32:\"54bfe84a40818aa5f0b886ef21e1f6ce\";}s:18:\"wp-admin/media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"a3323d084b4298fcada382ed48eed842\";}s:24:\"wp-admin/menu-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"1f77220052f77c59724983b5d782529a\";}s:17:\"wp-admin/menu.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"c6ee46bcfb7abb6568569add0aa18120\";}s:23:\"wp-admin/moderation.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"541242a293805952a0e22234f09d6fa9\";}s:21:\"wp-admin/ms-admin.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9a05b49740dfcdaf4516851b623606e4\";}s:27:\"wp-admin/ms-delete-site.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"19c0d841bde03b74c53f4f615176518b\";}s:20:\"wp-admin/ms-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"16d42ff617c4a616c3bd94ba103a4582\";}s:23:\"wp-admin/ms-options.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a21d278e00ca7dccfe3a81d4e386afa9\";}s:21:\"wp-admin/ms-sites.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"5d186224ebf4ddd0f1719c9ef4b80468\";}s:22:\"wp-admin/ms-themes.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"521cb94b9501ca24bc495a31c66925d8\";}s:31:\"wp-admin/ms-upgrade-network.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"7cb492260f22ee53816d96be3868be6d\";}s:21:\"wp-admin/ms-users.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4823c8667b23ca83b31bf9093647e5a2\";}s:21:\"wp-admin/my-sites.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"575f48b933eeb0ec3809b68584b56af6\";}s:22:\"wp-admin/nav-menus.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0378f1ac1491adffb9be1acd89a3a3e1\";}s:26:\"wp-admin/network/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"e9e33df9da15a95356e6da0e56889fec\";}s:26:\"wp-admin/network/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"4e85d4354373cc17b9099b130b121f12\";}s:28:\"wp-admin/network/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"38192cde34142cc7ecf558f58ef475f0\";}s:25:\"wp-admin/network/edit.php\";a:2:{s:1:\"d\";i:1417360882;s:1:\"h\";s:32:\"0deb5ea059c21f268c973b5ea0fcd21a\";}s:29:\"wp-admin/network/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"109efa9312c00370894f7e2ba27e9c31\";}s:26:\"wp-admin/network/index.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"8d5631ed02722fccdaef052efbdbcb4a\";}s:25:\"wp-admin/network/menu.php\";a:2:{s:1:\"d\";i:1412279358;s:1:\"h\";s:32:\"1ae13d535ba56678c4e08acf1989a3d5\";}s:34:\"wp-admin/network/plugin-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"3fb5cd9ab947024d84585a0d693dcc12\";}s:35:\"wp-admin/network/plugin-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"6bbd804f795fa5a934f529a51a9886bf\";}s:28:\"wp-admin/network/plugins.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4193887cb9cb7f4d4d3000bdf303bf1e\";}s:28:\"wp-admin/network/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d86926a7511d1d5cd3a2f0a502e7b6a8\";}s:29:\"wp-admin/network/settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"97e11d59cdfc86f0a6bb7b443d6cde65\";}s:26:\"wp-admin/network/setup.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ee19cf426d3e6e397a5d891f08d19ae2\";}s:30:\"wp-admin/network/site-info.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"817cc350d57c04ae4eec460ace8e6d36\";}s:29:\"wp-admin/network/site-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"710cf4cd7985b5acd028f46caf236e4b\";}s:34:\"wp-admin/network/site-settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"996a40c97e25b119ed171083c5f47873\";}s:32:\"wp-admin/network/site-themes.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"91216c7ce232e5b8d4565faf0e0c038a\";}s:31:\"wp-admin/network/site-users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"fada8422fa27bae1ad0d2e0ce6c8138d\";}s:26:\"wp-admin/network/sites.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"e67f0b0fd462649c592e7cbb11d24bad\";}s:33:\"wp-admin/network/theme-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"804f9a460fa9e3646d83f915c51cd36a\";}s:34:\"wp-admin/network/theme-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"26d5b7cd315570d025e09e11313d24e4\";}s:27:\"wp-admin/network/themes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"db78a791b08f071379027c1c93fa0543\";}s:32:\"wp-admin/network/update-core.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a1223f017d52327b385cac03833f52ea\";}s:27:\"wp-admin/network/update.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ba45a05ecc211e8cab75b4d529ff75f7\";}s:28:\"wp-admin/network/upgrade.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"a123393039314ec615e2a706fd64f548\";}s:30:\"wp-admin/network/user-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"318173b6ccb63ed80ba3d08563c3ff14\";}s:29:\"wp-admin/network/user-new.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"96a0ac3684162747bcb8150467241ca2\";}s:26:\"wp-admin/network/users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"5a765cddcc0698c1c79d067b1d9d6732\";}s:20:\"wp-admin/network.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"26ff9c3919857b65f02c596a8505b10a\";}s:31:\"wp-admin/options-discussion.php\";a:2:{s:1:\"d\";i:1429049366;s:1:\"h\";s:32:\"637b93ae37dcc1d6ba58f8e42e7452bf\";}s:28:\"wp-admin/options-general.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f8d0d4d971959bb780039e37d69404e1\";}s:25:\"wp-admin/options-head.php\";a:2:{s:1:\"d\";i:1362172450;s:1:\"h\";s:32:\"bad695605e6db04e400a546f667eb70b\";}s:26:\"wp-admin/options-media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"bf8e37c333ae3154ff77263bf0a17fd8\";}s:30:\"wp-admin/options-permalink.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4b6a1fc27255843534fc5a02d252a624\";}s:28:\"wp-admin/options-reading.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"56e7717583d57de60217fe2d2ec84a61\";}s:28:\"wp-admin/options-writing.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5f94fd48e5cd4a3164026b8e18fa898c\";}s:20:\"wp-admin/options.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2ceb6fed736ecaede0135d13f254b61a\";}s:26:\"wp-admin/plugin-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0d7eedb060331aa2ca7d40b25b56c150\";}s:27:\"wp-admin/plugin-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"c4e4f72fe3511fc7d9a9ccaa7d352c0a\";}s:20:\"wp-admin/plugins.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"adb4146ada0e0cbe08da010f9b189cb0\";}s:21:\"wp-admin/post-new.php\";a:2:{s:1:\"d\";i:1420882162;s:1:\"h\";s:32:\"5ae636173e213f7e459d9cd6d64465e9\";}s:17:\"wp-admin/post.php\";a:2:{s:1:\"d\";i:1425609084;s:1:\"h\";s:32:\"131721684c0879e83aaccf102245a2e1\";}s:23:\"wp-admin/press-this.php\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"e53a55cd2ffb9f76c59963d54bc0124a\";}s:20:\"wp-admin/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9184e53f96bade3e7ae7cda9eddf7a26\";}s:21:\"wp-admin/revision.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f38ac6fdd266bcc623cd3dc27c9b428b\";}s:25:\"wp-admin/setup-config.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"b7b732e94ba1185b442b5efd8cfad02f\";}s:25:\"wp-admin/theme-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4e47516edb5d0f2ff241ee455fab19fc\";}s:26:\"wp-admin/theme-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a1f48e9aef5c17759f3b38807e4cb1f\";}s:19:\"wp-admin/themes.php\";a:2:{s:1:\"d\";i:1429525646;s:1:\"h\";s:32:\"4c673870742ef8131cf78de2a5d7a56e\";}s:18:\"wp-admin/tools.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"7b8738972ea367f2d5d45f5c2b185513\";}s:24:\"wp-admin/update-core.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"75c977ae43d7215f48fa3b44c080ab81\";}s:19:\"wp-admin/update.php\";a:2:{s:1:\"d\";i:1428042748;s:1:\"h\";s:32:\"86b7431cd724423305464f6c19608838\";}s:30:\"wp-admin/upgrade-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"5ef6dfd8ec7550e071581d5c14658efc\";}s:20:\"wp-admin/upgrade.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2d2636f9b8db893c678c6ba5367312de\";}s:19:\"wp-admin/upload.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3227b777a925fc4d90c7bc0408eb0582\";}s:23:\"wp-admin/user/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"99ec00da8d914b4efd2098a3e44ebe2d\";}s:23:\"wp-admin/user/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"8de88527f924b455fb6d14bb7805f25a\";}s:25:\"wp-admin/user/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d920b4fb1be2c2c780081d5b4b7de55a\";}s:26:\"wp-admin/user/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"1ba6cbb9e2a9d3deb348997492ed692e\";}s:23:\"wp-admin/user/index.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"c8fd98f7fdd52d78bdadf74e620789fa\";}s:22:\"wp-admin/user/menu.php\";a:2:{s:1:\"d\";i:1399377496;s:1:\"h\";s:32:\"a529e3d3c2bb86671fb9cc1145cf70ee\";}s:25:\"wp-admin/user/profile.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"b9fa17a9811195800079dda4b1262d03\";}s:27:\"wp-admin/user/user-edit.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"2a7a75a363b0f88f0b6d094a91ef65ea\";}s:22:\"wp-admin/user-edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d666cfa73d8a691a77a5559afef67889\";}s:21:\"wp-admin/user-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3a7fc7ec50ea3e2eabb6f2bef44d5eef\";}s:18:\"wp-admin/users.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"349265703c279fb2dd960cc53f35a581\";}s:20:\"wp-admin/widgets.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"86cb82a0d791c45f2f1a680f8f0a1f3a\";}}","no");
INSERT INTO `arc1542_options` VALUES("200","itsec_salts","1434398983","yes");
INSERT INTO `arc1542_options` VALUES("211","itsec_jquery_version","","yes");
INSERT INTO `arc1542_options` VALUES("213","_transient_twentyfifteen_categories","1","yes");
INSERT INTO `arc1542_options` VALUES("217","current_theme","The Hill","yes");
INSERT INTO `arc1542_options` VALUES("218","theme_mods_ut-thehill","a:2:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"single-menu\";i:2;}}","yes");
INSERT INTO `arc1542_options` VALUES("219","theme_switched","","yes");
INSERT INTO `arc1542_options` VALUES("221","wordfence_version","6.0.15","yes");
INSERT INTO `arc1542_options` VALUES("222","wordfenceActivated","1","yes");
INSERT INTO `arc1542_options` VALUES("223","wf_plugin_act_error","","yes");
INSERT INTO `arc1542_options` VALUES("260","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("268","itsec_local_file_list_1","a:500:{s:25:\"wp-includes/admin-bar.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f42e1641d27e45a1d14c2b2c485b64fb\";}s:23:\"wp-includes/atomlib.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"971c65ba2e8084ec5bea8a000a66c141\";}s:31:\"wp-includes/author-template.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6c8c40c391c10df017503ee469747a00\";}s:33:\"wp-includes/bookmark-template.php\";a:2:{s:1:\"d\";i:1416818542;s:1:\"h\";s:32:\"ad14c4d4216d3c0dffedd6cfe9d84f34\";}s:24:\"wp-includes/bookmark.php\";a:2:{s:1:\"d\";i:1420715126;s:1:\"h\";s:32:\"d7def146f4d11b612afd0273b73ccb37\";}s:21:\"wp-includes/cache.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"7cff89478d2dcf11ba458ce8eabe42d4\";}s:25:\"wp-includes/canonical.php\";a:2:{s:1:\"d\";i:1426827748;s:1:\"h\";s:32:\"3c210ada343fceb636a74f13a551199a\";}s:28:\"wp-includes/capabilities.php\";a:2:{s:1:\"d\";i:1429529248;s:1:\"h\";s:32:\"a883c42b18d321b0b14ceea609b422ff\";}s:33:\"wp-includes/category-template.php\";a:2:{s:1:\"d\";i:1428259768;s:1:\"h\";s:32:\"ac9d76cf7557f99702ccd9646169087f\";}s:24:\"wp-includes/category.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0c2718872a07cb80dd6a86aa352065cd\";}s:38:\"wp-includes/certificates/ca-bundle.crt\";a:2:{s:1:\"d\";i:1417936402;s:1:\"h\";s:32:\"978976c7bbfab9219a6f0a8a66a4da6f\";}s:26:\"wp-includes/class-feed.php\";a:2:{s:1:\"d\";i:1421384784;s:1:\"h\";s:32:\"3caaf84279d992da1005dd15eea99484\";}s:26:\"wp-includes/class-http.php\";a:2:{s:1:\"d\";i:1425882146;s:1:\"h\";s:32:\"51632e4685a44219ed36c86ce389088e\";}s:25:\"wp-includes/class-IXR.php\";a:2:{s:1:\"d\";i:1419986484;s:1:\"h\";s:32:\"6e8556d538b99c1530e1502279505f1d\";}s:26:\"wp-includes/class-json.php\";a:2:{s:1:\"d\";i:1373316934;s:1:\"h\";s:32:\"4cf25341919f07dacd84ace1dc05251a\";}s:28:\"wp-includes/class-oembed.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2d664f85a9f5a098f3c393af66cbf77c\";}s:28:\"wp-includes/class-phpass.php\";a:2:{s:1:\"d\";i:1416513804;s:1:\"h\";s:32:\"23d5464450fa0c001ac9669747e7c6a7\";}s:31:\"wp-includes/class-phpmailer.php\";a:2:{s:1:\"d\";i:1393892714;s:1:\"h\";s:32:\"4271124f375797d87661ee9f98693463\";}s:26:\"wp-includes/class-pop3.php\";a:2:{s:1:\"d\";i:1303432832;s:1:\"h\";s:32:\"a94bb299c353b7e57c9f98900cea2f7d\";}s:31:\"wp-includes/class-simplepie.php\";a:2:{s:1:\"d\";i:1407916578;s:1:\"h\";s:32:\"5973e0728909826d97bef5443b8ef72e\";}s:26:\"wp-includes/class-smtp.php\";a:2:{s:1:\"d\";i:1412000898;s:1:\"h\";s:32:\"8ed550bdfaadf21e1806b0ca8462bb2e\";}s:28:\"wp-includes/class-snoopy.php\";a:2:{s:1:\"d\";i:1373318266;s:1:\"h\";s:32:\"dccbd26d4d7ae80f4d1472923b769e96\";}s:34:\"wp-includes/class-wp-admin-bar.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"5953f90479d0cea18fedb0b87f51bfbc\";}s:38:\"wp-includes/class-wp-ajax-response.php\";a:2:{s:1:\"d\";i:1420949604;s:1:\"h\";s:32:\"723660307dc0646dc48251f6a8b05cc6\";}s:42:\"wp-includes/class-wp-customize-control.php\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"cda99d74caea21726cef82b690fc7b7e\";}s:42:\"wp-includes/class-wp-customize-manager.php\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"47948e7fb3f12eebe546a889eaceac28\";}s:40:\"wp-includes/class-wp-customize-panel.php\";a:2:{s:1:\"d\";i:1424866166;s:1:\"h\";s:32:\"b4aca5bf76a7787e3b29bd5dfb906cd9\";}s:42:\"wp-includes/class-wp-customize-section.php\";a:2:{s:1:\"d\";i:1429047928;s:1:\"h\";s:32:\"2188dac51510b3f0e3099870507ec17f\";}s:42:\"wp-includes/class-wp-customize-setting.php\";a:2:{s:1:\"d\";i:1428261448;s:1:\"h\";s:32:\"d33d741c92f1240b51f2a38ffcbac849\";}s:42:\"wp-includes/class-wp-customize-widgets.php\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"70ba5279c7a3d0184bba8ca239a1cdaf\";}s:31:\"wp-includes/class-wp-editor.php\";a:2:{s:1:\"d\";i:1429523428;s:1:\"h\";s:32:\"0f63883b7e5e082488dff01e77118e10\";}s:30:\"wp-includes/class-wp-embed.php\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"03c12dd24a37d8afd8c58f9b1eb1892c\";}s:30:\"wp-includes/class-wp-error.php\";a:2:{s:1:\"d\";i:1421384784;s:1:\"h\";s:32:\"34c4b827b983331cc1f142640a8391d8\";}s:40:\"wp-includes/class-wp-http-ixr-client.php\";a:2:{s:1:\"d\";i:1417412064;s:1:\"h\";s:32:\"744a72eb50e73ff117c662558802e661\";}s:40:\"wp-includes/class-wp-image-editor-gd.php\";a:2:{s:1:\"d\";i:1425080308;s:1:\"h\";s:32:\"b3d40333d803921f00500043368c6f04\";}s:45:\"wp-includes/class-wp-image-editor-imagick.php\";a:2:{s:1:\"d\";i:1425080308;s:1:\"h\";s:32:\"5099df2c6832e007d4b0f0da99e3a432\";}s:37:\"wp-includes/class-wp-image-editor.php\";a:2:{s:1:\"d\";i:1420887442;s:1:\"h\";s:32:\"8791053a548ba95864e54ce0f5dc9567\";}s:30:\"wp-includes/class-wp-theme.php\";a:2:{s:1:\"d\";i:1429525646;s:1:\"h\";s:32:\"8a1c3686a7f671df92417a6012219564\";}s:31:\"wp-includes/class-wp-walker.php\";a:2:{s:1:\"d\";i:1420955782;s:1:\"h\";s:32:\"9ca7ed9f12d357238927dd01868a806d\";}s:38:\"wp-includes/class-wp-xmlrpc-server.php\";a:2:{s:1:\"d\";i:1429558046;s:1:\"h\";s:32:\"570b5554a3ff5794fc7f721686abcd9c\";}s:24:\"wp-includes/class-wp.php\";a:2:{s:1:\"d\";i:1421447844;s:1:\"h\";s:32:\"e269472186d951996c89336e491d25b0\";}s:37:\"wp-includes/class.wp-dependencies.php\";a:2:{s:1:\"d\";i:1416819502;s:1:\"h\";s:32:\"b7ab545f5b406a17f6bb6adc5c3f6f75\";}s:32:\"wp-includes/class.wp-scripts.php\";a:2:{s:1:\"d\";i:1429038808;s:1:\"h\";s:32:\"3babd10a731b3f204569397bfa77b396\";}s:31:\"wp-includes/class.wp-styles.php\";a:2:{s:1:\"d\";i:1420272622;s:1:\"h\";s:32:\"b534d820c73fc44dd46e49f807817481\";}s:32:\"wp-includes/comment-template.php\";a:2:{s:1:\"d\";i:1429673786;s:1:\"h\";s:32:\"246a8fc6e34d36a20ec859629e787d51\";}s:23:\"wp-includes/comment.php\";a:2:{s:1:\"d\";i:1430897430;s:1:\"h\";s:32:\"dc49984492c7853cbc7d46aa3e554aae\";}s:22:\"wp-includes/compat.php\";a:2:{s:1:\"d\";i:1430897430;s:1:\"h\";s:32:\"dab2403b685fb97975065da248bbf4f9\";}s:20:\"wp-includes/cron.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"fa62b32e2ad772f4543a1d7ef47491c8\";}s:33:\"wp-includes/css/admin-bar-rtl.css\";a:2:{s:1:\"d\";i:1428523708;s:1:\"h\";s:32:\"d8750588b9608c960a4c84111826363b\";}s:37:\"wp-includes/css/admin-bar-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"97d6a50c5da4c75f433f9ed02b5de62e\";}s:29:\"wp-includes/css/admin-bar.css\";a:2:{s:1:\"d\";i:1428523708;s:1:\"h\";s:32:\"55285802152cbf7f33740342b5cf5f0e\";}s:33:\"wp-includes/css/admin-bar.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"acb2a06d6bb17892486bb83171ab57e0\";}s:31:\"wp-includes/css/buttons-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"313eace8c7cc0ef43a877a5e15c8f3bd\";}s:35:\"wp-includes/css/buttons-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c0081aa47a02dc65a5081ddc3dca22db\";}s:27:\"wp-includes/css/buttons.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c7d13152f031f1cc21fbe3975c3d50ac\";}s:31:\"wp-includes/css/buttons.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"494016bf330d1bd60723efcedbf8b3ef\";}s:29:\"wp-includes/css/dashicons.css\";a:2:{s:1:\"d\";i:1420635744;s:1:\"h\";s:32:\"7d009b6317b016a7d127de92c3a0c905\";}s:33:\"wp-includes/css/dashicons.min.css\";a:2:{s:1:\"d\";i:1420635744;s:1:\"h\";s:32:\"5515b659e6fa1b563d7d57287dea2e4e\";}s:30:\"wp-includes/css/editor-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c175f45d5829c12ac0be14efac8bb4c7\";}s:34:\"wp-includes/css/editor-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"60b46fe4c022f4124ba8a0507a4abdeb\";}s:26:\"wp-includes/css/editor.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"4a459a304909052c6cdf05393599790b\";}s:30:\"wp-includes/css/editor.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"bce0fcfa6d2d6f3e058c71e5830617ae\";}s:40:\"wp-includes/css/jquery-ui-dialog-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"81df1614adc93799fc9fd6b4b81c4633\";}s:44:\"wp-includes/css/jquery-ui-dialog-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"3269187936a176a98efc265d8332c5e4\";}s:36:\"wp-includes/css/jquery-ui-dialog.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0a1016dec8649f08c0f31bbb5c36cd01\";}s:40:\"wp-includes/css/jquery-ui-dialog.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"e00e1d287de9b4f665427b781153090b\";}s:35:\"wp-includes/css/media-views-rtl.css\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"ce5832715f15e339b10f1f35564c1e54\";}s:39:\"wp-includes/css/media-views-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"745b6b6ebb69c22bc42f9780fe6a9f49\";}s:31:\"wp-includes/css/media-views.css\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"cec1bd5b35322ae89736b592fd56f90d\";}s:35:\"wp-includes/css/media-views.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"1a18ff7798302a2acb623692d8d08fd9\";}s:37:\"wp-includes/css/wp-auth-check-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"e8a7ffcfde36022642abee85dd4b629c\";}s:41:\"wp-includes/css/wp-auth-check-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"476e2bbfe969e737181ae9cfe762ef24\";}s:33:\"wp-includes/css/wp-auth-check.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8d5e06994737d4e3e35fd0688151f55e\";}s:37:\"wp-includes/css/wp-auth-check.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"eb60fd346a4039fdcf5912fce6dd1ad1\";}s:34:\"wp-includes/css/wp-pointer-rtl.css\";a:2:{s:1:\"d\";i:1428448466;s:1:\"h\";s:32:\"d7e0cd8698b0111eee1a6a5f8b4c924a\";}s:38:\"wp-includes/css/wp-pointer-rtl.min.css\";a:2:{s:1:\"d\";i:1428448466;s:1:\"h\";s:32:\"6c3e135352318e69b359fc37bff0b3bc\";}s:30:\"wp-includes/css/wp-pointer.css\";a:2:{s:1:\"d\";i:1428448466;s:1:\"h\";s:32:\"3d7c74b9bf7260ded6960f7d7c3f1e9c\";}s:34:\"wp-includes/css/wp-pointer.min.css\";a:2:{s:1:\"d\";i:1428448466;s:1:\"h\";s:32:\"f2c8a14e896d48cb9f2c3367228ef562\";}s:20:\"wp-includes/date.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"90759815031baee38d3c9f19e34f4907\";}s:33:\"wp-includes/default-constants.php\";a:2:{s:1:\"d\";i:1420523842;s:1:\"h\";s:32:\"896aa082dcff766aaa24fe882596b32b\";}s:31:\"wp-includes/default-filters.php\";a:2:{s:1:\"d\";i:1429517726;s:1:\"h\";s:32:\"2c0e7ddd27e221d40c8e4ace0c0e76c8\";}s:31:\"wp-includes/default-widgets.php\";a:2:{s:1:\"d\";i:1427319268;s:1:\"h\";s:32:\"fe25b8dcb4c31c6cd35ab0f029e893f0\";}s:26:\"wp-includes/deprecated.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"88e876e7bce7b85fea53b9fa5e5976a9\";}s:34:\"wp-includes/feed-atom-comments.php\";a:2:{s:1:\"d\";i:1404742696;s:1:\"h\";s:32:\"63ab44313b088129ae932d8a423f3673\";}s:25:\"wp-includes/feed-atom.php\";a:2:{s:1:\"d\";i:1404742696;s:1:\"h\";s:32:\"e37135428b98f334acc2ea4406100a57\";}s:24:\"wp-includes/feed-rdf.php\";a:2:{s:1:\"d\";i:1417915944;s:1:\"h\";s:32:\"da3c43fff6f29048bc2c4427a4cf3769\";}s:24:\"wp-includes/feed-rss.php\";a:2:{s:1:\"d\";i:1382682592;s:1:\"h\";s:32:\"b57f6b1959c5f4ed3eb05d4474480c2f\";}s:34:\"wp-includes/feed-rss2-comments.php\";a:2:{s:1:\"d\";i:1417915944;s:1:\"h\";s:32:\"0f9b3cb2a6af84370b5576153951e237\";}s:25:\"wp-includes/feed-rss2.php\";a:2:{s:1:\"d\";i:1417915944;s:1:\"h\";s:32:\"41a8a3186027727d08979f6288205147\";}s:20:\"wp-includes/feed.php\";a:2:{s:1:\"d\";i:1429517726;s:1:\"h\";s:32:\"fc5c053316212fafe8abc20529546a10\";}s:31:\"wp-includes/fonts/dashicons.eot\";a:2:{s:1:\"d\";i:1418168064;s:1:\"h\";s:32:\"cea23664cbf4f6c9484411cbc651d983\";}s:31:\"wp-includes/fonts/dashicons.svg\";a:2:{s:1:\"d\";i:1418168064;s:1:\"h\";s:32:\"0b7e1f9b2978e48c89f99c5befaf77f8\";}s:31:\"wp-includes/fonts/dashicons.ttf\";a:2:{s:1:\"d\";i:1418168064;s:1:\"h\";s:32:\"8a457a7b9d43377c070b0fe91732ed95\";}s:32:\"wp-includes/fonts/dashicons.woff\";a:2:{s:1:\"d\";i:1418168064;s:1:\"h\";s:32:\"78f5e202fde4da61a50d49b27e747eb2\";}s:26:\"wp-includes/formatting.php\";a:2:{s:1:\"d\";i:1430890526;s:1:\"h\";s:32:\"c0b5775359d60b4ed8daa22aee8dd697\";}s:25:\"wp-includes/functions.php\";a:2:{s:1:\"d\";i:1429526366;s:1:\"h\";s:32:\"7d7fc351f1d36f4e77de7d0decea2437\";}s:36:\"wp-includes/functions.wp-scripts.php\";a:2:{s:1:\"d\";i:1429038808;s:1:\"h\";s:32:\"783f21f66263935189cf2a4233366e17\";}s:35:\"wp-includes/functions.wp-styles.php\";a:2:{s:1:\"d\";i:1428263786;s:1:\"h\";s:32:\"fa7c7be644a81c76a9b809b113b43a42\";}s:32:\"wp-includes/general-template.php\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"e2473b593d2e93a6bc0ecb0113543121\";}s:20:\"wp-includes/http.php\";a:2:{s:1:\"d\";i:1417404266;s:1:\"h\";s:32:\"d514a077891ea4247e178a72c9345424\";}s:30:\"wp-includes/ID3/getid3.lib.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"fbbccef47012aa7351a046dde3e6c830\";}s:26:\"wp-includes/ID3/getid3.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"22f0a40a51c7512e0bc5c1f962b26fe2\";}s:38:\"wp-includes/ID3/license.commercial.txt\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"d34bd7474420e22e7da463b44833a5f9\";}s:27:\"wp-includes/ID3/license.txt\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"361298a1f00ff6d56a51e0c3d2233194\";}s:42:\"wp-includes/ID3/module.audio-video.asf.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"41829b48e521eeac30d9d0209673b857\";}s:42:\"wp-includes/ID3/module.audio-video.flv.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"bce0d6883fce649068cd407fc04486b2\";}s:47:\"wp-includes/ID3/module.audio-video.matroska.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"c2599121955a307a446a26437006ec9e\";}s:48:\"wp-includes/ID3/module.audio-video.quicktime.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"f81355bd60d4d566e12e98309d46cbbc\";}s:43:\"wp-includes/ID3/module.audio-video.riff.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"ee82540f026662197f7003474fd92de2\";}s:36:\"wp-includes/ID3/module.audio.ac3.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"bb4e961fad45ec703a9a4183955a90d6\";}s:36:\"wp-includes/ID3/module.audio.dts.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"f26c411cb8f645e88cca4f3837a62428\";}s:37:\"wp-includes/ID3/module.audio.flac.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"f89c2c8567ebbc002ef9a5169a166993\";}s:36:\"wp-includes/ID3/module.audio.mp3.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"23e11aff7e65f6998882dd4aac38fe05\";}s:36:\"wp-includes/ID3/module.audio.ogg.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"c410e4cf76a54e8135904fdbac85e114\";}s:37:\"wp-includes/ID3/module.tag.apetag.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"fd37f9ac6c2ce46977468a5113d4716c\";}s:36:\"wp-includes/ID3/module.tag.id3v1.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"bde568d89cdad9b1616ca1ef77f134dc\";}s:36:\"wp-includes/ID3/module.tag.id3v2.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"555b85af2c6ab97d6a41d89af715fc63\";}s:38:\"wp-includes/ID3/module.tag.lyrics3.php\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"f3a14bbd16d7ac05e3918e96da30eb8d\";}s:26:\"wp-includes/ID3/readme.txt\";a:2:{s:1:\"d\";i:1410476838;s:1:\"h\";s:32:\"9396dfe1c69c938eb17f564c4e5bab18\";}s:28:\"wp-includes/images/blank.gif\";a:2:{s:1:\"d\";i:1416910342;s:1:\"h\";s:32:\"48bb2baaf4353109f7c2665d96aa390b\";}s:38:\"wp-includes/images/crystal/license.txt\";a:2:{s:1:\"d\";i:1393828468;s:1:\"h\";s:32:\"f05db54c63e36918479b6651930dcfe7\";}s:36:\"wp-includes/images/down_arrow-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"a073b8a1ee9b2482017f3628da40a861\";}s:33:\"wp-includes/images/down_arrow.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"65dcc85d3a75ff5776fbe3df0122b7e2\";}s:41:\"wp-includes/images/smilies/icon_arrow.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"bfcab5090b1280bbe495dbead4d2281f\";}s:43:\"wp-includes/images/smilies/icon_biggrin.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"c7597052fe2b16db307d6bd14e7b8c6b\";}s:44:\"wp-includes/images/smilies/icon_confused.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7fefa473594650055a36b9e3062c9a91\";}s:40:\"wp-includes/images/smilies/icon_cool.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"96467eb5ae18dfa22ea1c0fa3e74380e\";}s:39:\"wp-includes/images/smilies/icon_cry.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"453e7a3f8bbb417008f06d576c41d060\";}s:39:\"wp-includes/images/smilies/icon_eek.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"a6c65fa6ff738ef6c46a4e80a65f7aa0\";}s:40:\"wp-includes/images/smilies/icon_evil.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"63bf101bd3d4f7564d3cf31822218d2e\";}s:43:\"wp-includes/images/smilies/icon_exclaim.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"5ce371458c1a2148595f5f3daf7b5fc8\";}s:40:\"wp-includes/images/smilies/icon_idea.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"bdb3226d2568b8c1edf8f453b1e872e6\";}s:39:\"wp-includes/images/smilies/icon_lol.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"d4f04dc65a387ca9b8c0f22ca8c0ec8c\";}s:39:\"wp-includes/images/smilies/icon_mad.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"d7be08b669651a63080cfe7b9004d330\";}s:43:\"wp-includes/images/smilies/icon_mrgreen.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"fde9e44a8aae0e89bd527792b4779aca\";}s:43:\"wp-includes/images/smilies/icon_neutral.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8a95dbfaa99809b0150687ae0cb45aed\";}s:44:\"wp-includes/images/smilies/icon_question.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"d22775b2e32645907141f788c36d4e9d\";}s:40:\"wp-includes/images/smilies/icon_razz.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"17cbe5cbade2b4ec3d85be4ac9409add\";}s:43:\"wp-includes/images/smilies/icon_redface.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"1c6d8b101c821641f983175221346112\";}s:44:\"wp-includes/images/smilies/icon_rolleyes.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"afc8bbc65fcbd2b82a3e2c1ab41a216a\";}s:39:\"wp-includes/images/smilies/icon_sad.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"1a273db3c34f6afb3fed75417ca5e7b6\";}s:41:\"wp-includes/images/smilies/icon_smile.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"b2984729c3b6cdc07508b88b5c0a4d1e\";}s:45:\"wp-includes/images/smilies/icon_surprised.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"299972b5cdd1f1e0690dd95e4038bd87\";}s:43:\"wp-includes/images/smilies/icon_twisted.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"62abd50ca92eb2381a7c60e351f64c46\";}s:40:\"wp-includes/images/smilies/icon_wink.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"d01a4f87055ac0fce8a66739d80434ba\";}s:33:\"wp-includes/images/spinner-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"5c1371bcb4392968647852a9c9df5d6c\";}s:30:\"wp-includes/images/spinner.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"b0a3dde331637e27aa6476d476481871\";}s:32:\"wp-includes/images/wpspin-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7def33aad959cd289d49ddf2a41f076d\";}s:29:\"wp-includes/images/wpspin.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"dd4e6dd268a70ce4c1c5143b1a4092dd\";}s:29:\"wp-includes/images/xit-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8fb0729c541cbdc4609faf3f4ad02fc7\";}s:26:\"wp-includes/images/xit.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"e5012902a358fbb96031acdcf048d7ca\";}s:27:\"wp-includes/js/admin-bar.js\";a:2:{s:1:\"d\";i:1428523708;s:1:\"h\";s:32:\"33030beb6f04ff00e3921848ba5bbf48\";}s:31:\"wp-includes/js/admin-bar.min.js\";a:2:{s:1:\"d\";i:1428523708;s:1:\"h\";s:32:\"78e3a64f61738d7bf52d7627e6260c23\";}s:26:\"wp-includes/js/autosave.js\";a:2:{s:1:\"d\";i:1416602486;s:1:\"h\";s:32:\"63fd697c7d66f00cefc6430b8c53c92f\";}s:30:\"wp-includes/js/autosave.min.js\";a:2:{s:1:\"d\";i:1416602486;s:1:\"h\";s:32:\"2eec8f2c408c881c6715ce0f682f3707\";}s:30:\"wp-includes/js/backbone.min.js\";a:2:{s:1:\"d\";i:1428395906;s:1:\"h\";s:32:\"88fee57a12be8ea719ed85fe29f062d3\";}s:29:\"wp-includes/js/colorpicker.js\";a:2:{s:1:\"d\";i:1353179490;s:1:\"h\";s:32:\"f01017ca562067f4840eb2b6f99f2daf\";}s:33:\"wp-includes/js/colorpicker.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"350af5af9077a62d67bae1f33a4f48fc\";}s:31:\"wp-includes/js/comment-reply.js\";a:2:{s:1:\"d\";i:1384504930;s:1:\"h\";s:32:\"d30ad028653d4eac285a1d4d06567bbd\";}s:35:\"wp-includes/js/comment-reply.min.js\";a:2:{s:1:\"d\";i:1384504930;s:1:\"h\";s:32:\"1b1e9d1d12fcc51a151e7e0688bc695f\";}s:31:\"wp-includes/js/crop/cropper.css\";a:2:{s:1:\"d\";i:1356033332;s:1:\"h\";s:32:\"6b79350bf46e0f692a4d1b2807ed0399\";}s:30:\"wp-includes/js/crop/cropper.js\";a:2:{s:1:\"d\";i:1178329724;s:1:\"h\";s:32:\"1d97b296d918482e1273c56fbff6a8e2\";}s:36:\"wp-includes/js/crop/marqueeHoriz.gif\";a:2:{s:1:\"d\";i:1352328550;s:1:\"h\";s:32:\"8cccae9c1ebafdb83be602e4d44c6f0a\";}s:35:\"wp-includes/js/crop/marqueeVert.gif\";a:2:{s:1:\"d\";i:1352328550;s:1:\"h\";s:32:\"ae9accf100a4b9930639adff52d4dcc7\";}s:32:\"wp-includes/js/customize-base.js\";a:2:{s:1:\"d\";i:1427340988;s:1:\"h\";s:32:\"5dca30a4679d1aedaacebd16a4a1a0ff\";}s:36:\"wp-includes/js/customize-base.min.js\";a:2:{s:1:\"d\";i:1427340988;s:1:\"h\";s:32:\"2eac88d29658e3be60fb3502410e1d18\";}s:34:\"wp-includes/js/customize-loader.js\";a:2:{s:1:\"d\";i:1427318786;s:1:\"h\";s:32:\"2130932604d2718d1e9d11e800ab7e93\";}s:38:\"wp-includes/js/customize-loader.min.js\";a:2:{s:1:\"d\";i:1427318786;s:1:\"h\";s:32:\"920192c0f83cb413dcbd4c2d8907496d\";}s:34:\"wp-includes/js/customize-models.js\";a:2:{s:1:\"d\";i:1398471920;s:1:\"h\";s:32:\"d420d2bafa7a4370a74f45ad61d956ec\";}s:38:\"wp-includes/js/customize-models.min.js\";a:2:{s:1:\"d\";i:1398471920;s:1:\"h\";s:32:\"4f4b04852e86713b9f7490e74ee8820a\";}s:43:\"wp-includes/js/customize-preview-widgets.js\";a:2:{s:1:\"d\";i:1404964696;s:1:\"h\";s:32:\"a01ebc7a7becb4597d71d379bcdab4be\";}s:47:\"wp-includes/js/customize-preview-widgets.min.js\";a:2:{s:1:\"d\";i:1404964696;s:1:\"h\";s:32:\"05c7517e06bb14b5eaa336c261b99b81\";}s:35:\"wp-includes/js/customize-preview.js\";a:2:{s:1:\"d\";i:1426017386;s:1:\"h\";s:32:\"eead944332db05e2cdde148dac2cdabe\";}s:39:\"wp-includes/js/customize-preview.min.js\";a:2:{s:1:\"d\";i:1426017386;s:1:\"h\";s:32:\"b8e325486884be9894b081ebac0d54ad\";}s:33:\"wp-includes/js/customize-views.js\";a:2:{s:1:\"d\";i:1399364054;s:1:\"h\";s:32:\"ad923bbd7a9caf098f594d0e912379c8\";}s:37:\"wp-includes/js/customize-views.min.js\";a:2:{s:1:\"d\";i:1399364054;s:1:\"h\";s:32:\"05b8ea5fb11adb182563ddb989e091d1\";}s:27:\"wp-includes/js/heartbeat.js\";a:2:{s:1:\"d\";i:1415598444;s:1:\"h\";s:32:\"cc2012e2099931cd5db064122a44cb47\";}s:31:\"wp-includes/js/heartbeat.min.js\";a:2:{s:1:\"d\";i:1415598444;s:1:\"h\";s:32:\"1dd3c7ed8699b740ebf4040b1304436d\";}s:29:\"wp-includes/js/hoverIntent.js\";a:2:{s:1:\"d\";i:1426108528;s:1:\"h\";s:32:\"cab3598b438a9e63984f1c6e9dd79b01\";}s:33:\"wp-includes/js/hoverIntent.min.js\";a:2:{s:1:\"d\";i:1426108528;s:1:\"h\";s:32:\"ca500ade854c31417faf5762e31b9d00\";}s:46:\"wp-includes/js/imgareaselect/border-anim-h.gif\";a:2:{s:1:\"d\";i:1352328550;s:1:\"h\";s:32:\"5ac3c42cc86e745a5e36b67b4c70a134\";}s:46:\"wp-includes/js/imgareaselect/border-anim-v.gif\";a:2:{s:1:\"d\";i:1352328550;s:1:\"h\";s:32:\"20c97a21993cf137ead9fdbecbc42aa8\";}s:46:\"wp-includes/js/imgareaselect/imgareaselect.css\";a:2:{s:1:\"d\";i:1335404998;s:1:\"h\";s:32:\"7d28cad92829b3d633a087b5f3b595af\";}s:52:\"wp-includes/js/imgareaselect/jquery.imgareaselect.js\";a:2:{s:1:\"d\";i:1379774590;s:1:\"h\";s:32:\"55a6b7fb4b1b287497d3fc30910e97ce\";}s:56:\"wp-includes/js/imgareaselect/jquery.imgareaselect.min.js\";a:2:{s:1:\"d\";i:1379774590;s:1:\"h\";s:32:\"0030d4ba4c429d776d23c2e37775873a\";}s:30:\"wp-includes/js/jcrop/Jcrop.gif\";a:2:{s:1:\"d\";i:1352328550;s:1:\"h\";s:32:\"5a8bfd37651305bdafbcf2cd51b0254b\";}s:41:\"wp-includes/js/jcrop/jquery.Jcrop.min.css\";a:2:{s:1:\"d\";i:1379781970;s:1:\"h\";s:32:\"56cc9ea201dc2f4b910e78bfacac9211\";}s:40:\"wp-includes/js/jcrop/jquery.Jcrop.min.js\";a:2:{s:1:\"d\";i:1379781970;s:1:\"h\";s:32:\"2f61ab984c177275c71e34ff1a17c102\";}s:39:\"wp-includes/js/jquery/jquery-migrate.js\";a:2:{s:1:\"d\";i:1368566578;s:1:\"h\";s:32:\"90e237d5f01035b958feaf514ef27f7a\";}s:43:\"wp-includes/js/jquery/jquery-migrate.min.js\";a:2:{s:1:\"d\";i:1374607706;s:1:\"h\";s:32:\"512b871a2830e44259bc3ce3343afcd0\";}s:41:\"wp-includes/js/jquery/jquery.color.min.js\";a:2:{s:1:\"d\";i:1365629396;s:1:\"h\";s:32:\"ff2db8dbf145ce47f31781eef33e764a\";}s:36:\"wp-includes/js/jquery/jquery.form.js\";a:2:{s:1:\"d\";i:1379379970;s:1:\"h\";s:32:\"e5afd8e41d2ec22c19932b068cd90a71\";}s:40:\"wp-includes/js/jquery/jquery.form.min.js\";a:2:{s:1:\"d\";i:1379379970;s:1:\"h\";s:32:\"dbc3808473def00fce45fe564dc72dcb\";}s:39:\"wp-includes/js/jquery/jquery.hotkeys.js\";a:2:{s:1:\"d\";i:1388635874;s:1:\"h\";s:32:\"e29483a8ca26a0dd8b0d1146c6b0a6e9\";}s:43:\"wp-includes/js/jquery/jquery.hotkeys.min.js\";a:2:{s:1:\"d\";i:1345694658;s:1:\"h\";s:32:\"e353217d4555ab5c62b367be6889813d\";}s:31:\"wp-includes/js/jquery/jquery.js\";a:2:{s:1:\"d\";i:1425044488;s:1:\"h\";s:32:\"4e2a6874f8b028fa23591492284a1643\";}s:43:\"wp-includes/js/jquery/jquery.masonry.min.js\";a:2:{s:1:\"d\";i:1395919996;s:1:\"h\";s:32:\"928adcedcd52b828e51f9ec291655e01\";}s:37:\"wp-includes/js/jquery/jquery.query.js\";a:2:{s:1:\"d\";i:1359507152;s:1:\"h\";s:32:\"3bcc587af2c7b01fc6fbc9c077050143\";}s:40:\"wp-includes/js/jquery/jquery.schedule.js\";a:2:{s:1:\"d\";i:1200000948;s:1:\"h\";s:32:\"0426b39754aa6bc766d89ea4c41bbd06\";}s:48:\"wp-includes/js/jquery/jquery.serialize-object.js\";a:2:{s:1:\"d\";i:1295579378;s:1:\"h\";s:32:\"d15c29a18d9ffa8b9b4ae86c3c0cfa22\";}s:45:\"wp-includes/js/jquery/jquery.table-hotkeys.js\";a:2:{s:1:\"d\";i:1384506970;s:1:\"h\";s:32:\"a706ead694231e74fd6750b1670580a5\";}s:49:\"wp-includes/js/jquery/jquery.table-hotkeys.min.js\";a:2:{s:1:\"d\";i:1345694658;s:1:\"h\";s:32:\"e56f81676f199db7bf937e69a64909fa\";}s:46:\"wp-includes/js/jquery/jquery.ui.touch-punch.js\";a:2:{s:1:\"d\";i:1334127504;s:1:\"h\";s:32:\"4cc86d1003c45134d6838f13e3885db1\";}s:32:\"wp-includes/js/jquery/suggest.js\";a:2:{s:1:\"d\";i:1403813294;s:1:\"h\";s:32:\"bf55f3b46b05aa372a0bed97b848de9e\";}s:36:\"wp-includes/js/jquery/suggest.min.js\";a:2:{s:1:\"d\";i:1396479916;s:1:\"h\";s:32:\"21a79ede04fa5ee9017e6bdbdba5bfe9\";}s:41:\"wp-includes/js/jquery/ui/accordion.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"617307799c0ec636db3df228d57790da\";}s:44:\"wp-includes/js/jquery/ui/autocomplete.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"87848b50d8b543b6fe1a38a97a6aea5c\";}s:38:\"wp-includes/js/jquery/ui/button.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"cb7e87f8ae42aed3689546eaf9566d6c\";}s:36:\"wp-includes/js/jquery/ui/core.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"204d1573e5f9ad0d0c9b61bdffe4a37b\";}s:42:\"wp-includes/js/jquery/ui/datepicker.min.js\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"499a4efa077515f0e4025141e22b0290\";}s:38:\"wp-includes/js/jquery/ui/dialog.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"24036156f5137bd484089907f52c9530\";}s:41:\"wp-includes/js/jquery/ui/draggable.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"500b56f16499ad4010c6cb1159a00ef7\";}s:41:\"wp-includes/js/jquery/ui/droppable.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"1a4b2271fd48cc6494bc94967e41b150\";}s:44:\"wp-includes/js/jquery/ui/effect-blind.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"addbe09f173c4f1bd86d41ac5f3b4f4c\";}s:45:\"wp-includes/js/jquery/ui/effect-bounce.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"d8967fe0305451de35920fd4fbe18d53\";}s:43:\"wp-includes/js/jquery/ui/effect-clip.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"c7939457e8ab231b951713475a056173\";}s:43:\"wp-includes/js/jquery/ui/effect-drop.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"57fe560887cac7a5b2598188463290e8\";}s:46:\"wp-includes/js/jquery/ui/effect-explode.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"605955a2ff9bbd517d58d90651f730d8\";}s:43:\"wp-includes/js/jquery/ui/effect-fade.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"9f6fd64f4f5ff5893b7b72a235246d0c\";}s:43:\"wp-includes/js/jquery/ui/effect-fold.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"8d365ec1b3a7ee82f93c9afd441e456c\";}s:48:\"wp-includes/js/jquery/ui/effect-highlight.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"95e8ebe62adf187fb4c3b84eb5bef821\";}s:43:\"wp-includes/js/jquery/ui/effect-puff.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"fe496d6c9d63bc47854084c8b3fc20d6\";}s:46:\"wp-includes/js/jquery/ui/effect-pulsate.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"d31b2660850bd11ed7f4118ee166f1e9\";}s:44:\"wp-includes/js/jquery/ui/effect-scale.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"d57d0830652c29c3e0e301b02b6db754\";}s:44:\"wp-includes/js/jquery/ui/effect-shake.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"a0274a6716560eeaccaf0090400f7095\";}s:43:\"wp-includes/js/jquery/ui/effect-size.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"3a14499e6b9543cd2a85be995dab077f\";}s:44:\"wp-includes/js/jquery/ui/effect-slide.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"fa23475fb01c8f4d56da98ca0c1179b5\";}s:47:\"wp-includes/js/jquery/ui/effect-transfer.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"07e5b0dea800777dd2108788b56ef90b\";}s:38:\"wp-includes/js/jquery/ui/effect.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"1441d6a28c1e7069c1e21b757f2b6082\";}s:36:\"wp-includes/js/jquery/ui/menu.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"279b59ffd3e6ed2da1397cb06ce13ec0\";}s:37:\"wp-includes/js/jquery/ui/mouse.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"e4a138275da8ed21bf8e49d9b210b884\";}s:40:\"wp-includes/js/jquery/ui/position.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"7d94d07b3a1c9f704b76120cc16874fb\";}s:43:\"wp-includes/js/jquery/ui/progressbar.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"a5e9438e7bac8acb9a71ccf4741009cd\";}s:41:\"wp-includes/js/jquery/ui/resizable.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"3f04b22aeae2579369c558e39db6d5bf\";}s:42:\"wp-includes/js/jquery/ui/selectable.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"51f19c22fb1d7b1bbf428b4de4f01fce\";}s:42:\"wp-includes/js/jquery/ui/selectmenu.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"cb7db4cbaa328e395a680c78692236f0\";}s:38:\"wp-includes/js/jquery/ui/slider.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"7d09316c34df2686e1515795ef0f4cc8\";}s:40:\"wp-includes/js/jquery/ui/sortable.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"0ed316ce58771b0297b783130e6b5e94\";}s:39:\"wp-includes/js/jquery/ui/spinner.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"b2d7a9df2f6b0f264851faf33b6ac7d6\";}s:36:\"wp-includes/js/jquery/ui/tabs.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"fc67555a859a12b644ff9edaf7926a96\";}s:39:\"wp-includes/js/jquery/ui/tooltip.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"b75d47d283918bef01b8cdcc4045511e\";}s:38:\"wp-includes/js/jquery/ui/widget.min.js\";a:2:{s:1:\"d\";i:1426101148;s:1:\"h\";s:32:\"02e635faa37ecc25ee5d630d888cf53c\";}s:23:\"wp-includes/js/json2.js\";a:2:{s:1:\"d\";i:1345694658;s:1:\"h\";s:32:\"74d903049683e5bbea9ccb7544a42bca\";}s:27:\"wp-includes/js/json2.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"ef4188cb0b60a72017f4c8a1e840ab1e\";}s:29:\"wp-includes/js/masonry.min.js\";a:2:{s:1:\"d\";i:1428395906;s:1:\"h\";s:32:\"69717d4569676f401e97dcec54f10ebc\";}s:26:\"wp-includes/js/mce-view.js\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"20d3f2cf57d63060adbe47ccaae6919f\";}s:30:\"wp-includes/js/mce-view.min.js\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"924fa693f18b70b70c3f76ad13142bb2\";}s:34:\"wp-includes/js/media-audiovideo.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"197572f6fff30edee0fdc406462726d8\";}s:38:\"wp-includes/js/media-audiovideo.min.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"41ee8d23e04975b16e3fb8d8e949b958\";}s:30:\"wp-includes/js/media-editor.js\";a:2:{s:1:\"d\";i:1429641386;s:1:\"h\";s:32:\"20f9f27717e6b1fd22576cdffba06336\";}s:34:\"wp-includes/js/media-editor.min.js\";a:2:{s:1:\"d\";i:1429641386;s:1:\"h\";s:32:\"e284f524a66d2bd63a78dc948fc74416\";}s:28:\"wp-includes/js/media-grid.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"3c666ce2209e20ef9e7e5c8417b59fc8\";}s:32:\"wp-includes/js/media-grid.min.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"4cbc52e0ac47f37a70c89fc46eb69d4b\";}s:30:\"wp-includes/js/media-models.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"2e7864d513c82363a81c6eb0337bd5f2\";}s:34:\"wp-includes/js/media-models.min.js\";a:2:{s:1:\"d\";i:1429039888;s:1:\"h\";s:32:\"757f7c05171d7ab9fb8c6b4ed8a68aa0\";}s:29:\"wp-includes/js/media-views.js\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"1cdc4006b43c0e6434817af8a031bcdb\";}s:33:\"wp-includes/js/media-views.min.js\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"8582d4a37ee89cbf90edc967c4af02b6\";}s:39:\"wp-includes/js/mediaelement/bigplay.svg\";a:2:{s:1:\"d\";i:1407631458;s:1:\"h\";s:32:\"ea090d716dd05e4024c29283f3c88d0d\";}s:40:\"wp-includes/js/mediaelement/controls.svg\";a:2:{s:1:\"d\";i:1363425944;s:1:\"h\";s:32:\"40f56f5a736da4effeb790cedb8a52f0\";}s:49:\"wp-includes/js/mediaelement/flashmediaelement.swf\";a:2:{s:1:\"d\";i:1425588866;s:1:\"h\";s:32:\"a77bd46c3904a70f0e4ed6f3f714099a\";}s:45:\"wp-includes/js/mediaelement/froogaloop.min.js\";a:2:{s:1:\"d\";i:1420848264;s:1:\"h\";s:32:\"2a8742c0ac1cdbec23be44a7d4e9a3c9\";}s:39:\"wp-includes/js/mediaelement/loading.gif\";a:2:{s:1:\"d\";i:1363425944;s:1:\"h\";s:32:\"76b326f4d44222126fee21076595bef5\";}s:58:\"wp-includes/js/mediaelement/mediaelement-and-player.min.js\";a:2:{s:1:\"d\";i:1425671246;s:1:\"h\";s:32:\"a3a3353ab882870300207675fa6b1b83\";}s:54:\"wp-includes/js/mediaelement/mediaelementplayer.min.css\";a:2:{s:1:\"d\";i:1425588866;s:1:\"h\";s:32:\"2ca8d8977881d5e608aa01c45bac7dce\";}s:55:\"wp-includes/js/mediaelement/silverlightmediaelement.xap\";a:2:{s:1:\"d\";i:1425588866;s:1:\"h\";s:32:\"a83ab83a3d43222e4ba77cf96e0074aa\";}s:47:\"wp-includes/js/mediaelement/wp-mediaelement.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"94d8926ae846f335cf811cbf61635298\";}s:46:\"wp-includes/js/mediaelement/wp-mediaelement.js\";a:2:{s:1:\"d\";i:1414560084;s:1:\"h\";s:32:\"9f38d89f0e227bebd5ba84ac75e10f5a\";}s:42:\"wp-includes/js/mediaelement/wp-playlist.js\";a:2:{s:1:\"d\";i:1409615718;s:1:\"h\";s:32:\"0ec99859384076f01ce50727d9bf18b3\";}s:35:\"wp-includes/js/plupload/handlers.js\";a:2:{s:1:\"d\";i:1425944666;s:1:\"h\";s:32:\"c9d857501549cabf90a9c546f0556729\";}s:39:\"wp-includes/js/plupload/handlers.min.js\";a:2:{s:1:\"d\";i:1425944666;s:1:\"h\";s:32:\"813ceb60612a365924d271704d03d95c\";}s:35:\"wp-includes/js/plupload/license.txt\";a:2:{s:1:\"d\";i:1311944376;s:1:\"h\";s:32:\"751419260aa954499f7abaabaa882bbe\";}s:42:\"wp-includes/js/plupload/plupload.flash.swf\";a:2:{s:1:\"d\";i:1429524806;s:1:\"h\";s:32:\"aeb99cfd67b07d467f9c39c1228c7e53\";}s:44:\"wp-includes/js/plupload/plupload.full.min.js\";a:2:{s:1:\"d\";i:1393545676;s:1:\"h\";s:32:\"9349f636c747a5e983020a1cb7213a44\";}s:48:\"wp-includes/js/plupload/plupload.silverlight.xap\";a:2:{s:1:\"d\";i:1397448436;s:1:\"h\";s:32:\"3c524750546de1b3aab36ff60719aebb\";}s:38:\"wp-includes/js/plupload/wp-plupload.js\";a:2:{s:1:\"d\";i:1415230644;s:1:\"h\";s:32:\"659d8f1d3bfd32cf405f6591d0521e7c\";}s:42:\"wp-includes/js/plupload/wp-plupload.min.js\";a:2:{s:1:\"d\";i:1413453258;s:1:\"h\";s:32:\"1d8eb51f53f479c82c6c660f7f40ad40\";}s:27:\"wp-includes/js/quicktags.js\";a:2:{s:1:\"d\";i:1416984624;s:1:\"h\";s:32:\"f623cad23a3ce005fcd054d9e5adcaad\";}s:31:\"wp-includes/js/quicktags.min.js\";a:2:{s:1:\"d\";i:1416984624;s:1:\"h\";s:32:\"0d7a0005ba6a1fa29037258ddd1a2034\";}s:27:\"wp-includes/js/shortcode.js\";a:2:{s:1:\"d\";i:1417494682;s:1:\"h\";s:32:\"eb207a02d03e3196d9d14ad139327fb5\";}s:31:\"wp-includes/js/shortcode.min.js\";a:2:{s:1:\"d\";i:1398929834;s:1:\"h\";s:32:\"18ba5832006079f3bcbdeb4c38c92adf\";}s:27:\"wp-includes/js/swfobject.js\";a:2:{s:1:\"d\";i:1334718570;s:1:\"h\";s:32:\"9ffdba2cff497d701684657e329871f5\";}s:36:\"wp-includes/js/swfupload/handlers.js\";a:2:{s:1:\"d\";i:1393289354;s:1:\"h\";s:32:\"14b2d04fdb85bc1f171cf3dfb2987dca\";}s:40:\"wp-includes/js/swfupload/handlers.min.js\";a:2:{s:1:\"d\";i:1371813548;s:1:\"h\";s:32:\"96592c6b3fad580ce04e12bc3047ef3b\";}s:36:\"wp-includes/js/swfupload/license.txt\";a:2:{s:1:\"d\";i:1311981682;s:1:\"h\";s:32:\"cbe05bb060c85e07882dc06ff751577a\";}s:53:\"wp-includes/js/swfupload/plugins/swfupload.cookies.js\";a:2:{s:1:\"d\";i:1311981682;s:1:\"h\";s:32:\"7fa57ec00dda88dd6b5c2037ccb4d5cf\";}s:51:\"wp-includes/js/swfupload/plugins/swfupload.queue.js\";a:2:{s:1:\"d\";i:1311981682;s:1:\"h\";s:32:\"9953522fbd4a1b02bbf635a92d76cd8f\";}s:51:\"wp-includes/js/swfupload/plugins/swfupload.speed.js\";a:2:{s:1:\"d\";i:1311981682;s:1:\"h\";s:32:\"415a3787846bb6c2d745602c2afb73ac\";}s:55:\"wp-includes/js/swfupload/plugins/swfupload.swfobject.js\";a:2:{s:1:\"d\";i:1311981682;s:1:\"h\";s:32:\"ccb51571a75637db08545caaf2ed9e73\";}s:37:\"wp-includes/js/swfupload/swfupload.js\";a:2:{s:1:\"d\";i:1407916578;s:1:\"h\";s:32:\"ef3ae9014525cf81187afaa61bca737e\";}s:38:\"wp-includes/js/swfupload/swfupload.swf\";a:2:{s:1:\"d\";i:1375139700;s:1:\"h\";s:32:\"bd5a25f23589652ca472d41fe1484f0c\";}s:44:\"wp-includes/js/thickbox/loadingAnimation.gif\";a:2:{s:1:\"d\";i:1352163616;s:1:\"h\";s:32:\"ce2268030dd2151b63cdf4ffc2f626ba\";}s:36:\"wp-includes/js/thickbox/thickbox.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"255290108a1c6a8ad31f6fa1415978a7\";}s:35:\"wp-includes/js/thickbox/thickbox.js\";a:2:{s:1:\"d\";i:1416297324;s:1:\"h\";s:32:\"b4ba824311d86552ddc7fe7753ef8925\";}s:43:\"wp-includes/js/tinymce/langs/wp-langs-en.js\";a:2:{s:1:\"d\";i:1418738844;s:1:\"h\";s:32:\"08f8669f7453b17563a62e6bbb376137\";}s:34:\"wp-includes/js/tinymce/license.txt\";a:2:{s:1:\"d\";i:1302560632;s:1:\"h\";s:32:\"045d04e17422d99e338da75b9c749b7c\";}s:48:\"wp-includes/js/tinymce/plugins/charmap/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"61d3e5d077b1d76704eac85c63a148bc\";}s:52:\"wp-includes/js/tinymce/plugins/charmap/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"aeb8638d01b2c3c7fbf36e69893f4b25\";}s:52:\"wp-includes/js/tinymce/plugins/colorpicker/plugin.js\";a:2:{s:1:\"d\";i:1405648454;s:1:\"h\";s:32:\"66ed7befbb2773566ed188e1d3b97cc4\";}s:56:\"wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"1581bb02286f54b4fb0cce52d2ef61c7\";}s:54:\"wp-includes/js/tinymce/plugins/compat3x/css/dialog.css\";a:2:{s:1:\"d\";i:1393449794;s:1:\"h\";s:32:\"97ddcd95d500418cd2114974ff644812\";}s:49:\"wp-includes/js/tinymce/plugins/compat3x/plugin.js\";a:2:{s:1:\"d\";i:1407632176;s:1:\"h\";s:32:\"3db45ca97f2d1bccc5c7ec65abbf8b55\";}s:53:\"wp-includes/js/tinymce/plugins/compat3x/plugin.min.js\";a:2:{s:1:\"d\";i:1395218776;s:1:\"h\";s:32:\"5798e3d2fb0180a9179b8bd7cf728eae\";}s:55:\"wp-includes/js/tinymce/plugins/directionality/plugin.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"2a8fc756a0859acaac1b9d20481979f5\";}s:59:\"wp-includes/js/tinymce/plugins/directionality/plugin.min.js\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"60de57253ca9143a6f1e4aff10fc39d2\";}s:51:\"wp-includes/js/tinymce/plugins/fullscreen/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"b778c332bab095f15db744c1795a430e\";}s:55:\"wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"d47998057f5f31758add87f462076fe2\";}s:43:\"wp-includes/js/tinymce/plugins/hr/plugin.js\";a:2:{s:1:\"d\";i:1394081654;s:1:\"h\";s:32:\"b4853cda3c7b4c55371939381cecdb86\";}s:47:\"wp-includes/js/tinymce/plugins/hr/plugin.min.js\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"5c23255ad2d11db3f72c33b649f1389a\";}s:46:\"wp-includes/js/tinymce/plugins/image/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"3fdb72c74a1d00f833cd12985c8964a7\";}s:50:\"wp-includes/js/tinymce/plugins/image/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"4ece365f92b620c8d64ef003230fd75c\";}s:46:\"wp-includes/js/tinymce/plugins/lists/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"b19b342c0b7e49d869254590e4b0df5b\";}s:50:\"wp-includes/js/tinymce/plugins/lists/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"6bdcee3180998f7f8e13dc4917d8f9a9\";}s:52:\"wp-includes/js/tinymce/plugins/media/moxieplayer.swf\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"4e59d34efb2da0b9a033596a85e4b1ef\";}s:46:\"wp-includes/js/tinymce/plugins/media/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"117eed22aeeccaa7a85ad2c2a5760a01\";}s:50:\"wp-includes/js/tinymce/plugins/media/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"7ac22f7e2e534de4364c1de8351b175c\";}s:46:\"wp-includes/js/tinymce/plugins/paste/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"1e031c368742554084b13814a53c6261\";}s:50:\"wp-includes/js/tinymce/plugins/paste/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"f0293e817c1dae4b042a1a1d6248b007\";}s:49:\"wp-includes/js/tinymce/plugins/tabfocus/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"f26aeec9641346d082e288224578f806\";}s:53:\"wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"d810b096023695b38bf682f20774af98\";}s:50:\"wp-includes/js/tinymce/plugins/textcolor/plugin.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"f6f2de940de4a60ee25d7cff7a0ceab3\";}s:54:\"wp-includes/js/tinymce/plugins/textcolor/plugin.min.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"a5ca0a92e1bdf1fbf3f9a07db5573092\";}s:50:\"wp-includes/js/tinymce/plugins/wordpress/plugin.js\";a:2:{s:1:\"d\";i:1430893828;s:1:\"h\";s:32:\"ed367f421e178c90f4c3bbd81479d79d\";}s:54:\"wp-includes/js/tinymce/plugins/wordpress/plugin.min.js\";a:2:{s:1:\"d\";i:1430893828;s:1:\"h\";s:32:\"26da4266c11d1a0eea6ebf1360b815d4\";}s:53:\"wp-includes/js/tinymce/plugins/wpautoresize/plugin.js\";a:2:{s:1:\"d\";i:1428552688;s:1:\"h\";s:32:\"640cbc0058638c4fb0400370dbcf25a3\";}s:57:\"wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js\";a:2:{s:1:\"d\";i:1428552688;s:1:\"h\";s:32:\"564cd5d11909d4675327b6f71fa09269\";}s:50:\"wp-includes/js/tinymce/plugins/wpdialogs/plugin.js\";a:2:{s:1:\"d\";i:1396960154;s:1:\"h\";s:32:\"06f7aecb5bdfa28739eea0a498d15a81\";}s:54:\"wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js\";a:2:{s:1:\"d\";i:1396960154;s:1:\"h\";s:32:\"eafbb1478981e337981d287474e240b8\";}s:52:\"wp-includes/js/tinymce/plugins/wpeditimage/plugin.js\";a:2:{s:1:\"d\";i:1429408588;s:1:\"h\";s:32:\"f2633c807b88f1a99e21d313a4986f0f\";}s:56:\"wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js\";a:2:{s:1:\"d\";i:1429408588;s:1:\"h\";s:32:\"9f95f44ac2be559e61e0c16795bbc10e\";}s:48:\"wp-includes/js/tinymce/plugins/wpemoji/plugin.js\";a:2:{s:1:\"d\";i:1429414166;s:1:\"h\";s:32:\"1d793200d7b3e0f80818903ca5721bc7\";}s:52:\"wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js\";a:2:{s:1:\"d\";i:1429414166;s:1:\"h\";s:32:\"7ceb852c73b74dc1b5f5f015be95506d\";}s:53:\"wp-includes/js/tinymce/plugins/wpfullscreen/plugin.js\";a:2:{s:1:\"d\";i:1418738844;s:1:\"h\";s:32:\"dd83030fdd725c148b2b7a4aded9da13\";}s:57:\"wp-includes/js/tinymce/plugins/wpfullscreen/plugin.min.js\";a:2:{s:1:\"d\";i:1418738844;s:1:\"h\";s:32:\"76c195e5f157603feb495fe3fffbc33d\";}s:50:\"wp-includes/js/tinymce/plugins/wpgallery/plugin.js\";a:2:{s:1:\"d\";i:1413152000;s:1:\"h\";s:32:\"b10eadbf41e88b236ac764bd26e653f9\";}s:54:\"wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js\";a:2:{s:1:\"d\";i:1413152000;s:1:\"h\";s:32:\"b229462e6a542696fbf6bd4917c9074f\";}s:47:\"wp-includes/js/tinymce/plugins/wplink/plugin.js\";a:2:{s:1:\"d\";i:1428526766;s:1:\"h\";s:32:\"9bd4ce60a27b57efbabe5569270c770b\";}s:51:\"wp-includes/js/tinymce/plugins/wplink/plugin.min.js\";a:2:{s:1:\"d\";i:1428526766;s:1:\"h\";s:32:\"ba2e2243e1870cd1623ed1de4bf95ccb\";}s:47:\"wp-includes/js/tinymce/plugins/wpview/plugin.js\";a:2:{s:1:\"d\";i:1429666346;s:1:\"h\";s:32:\"71b5cb01bf11fbaea25876fb7226d560\";}s:51:\"wp-includes/js/tinymce/plugins/wpview/plugin.min.js\";a:2:{s:1:\"d\";i:1429666346;s:1:\"h\";s:32:\"8f66eb91bd871ee5a1b4e03ba3c18e84\";}s:61:\"wp-includes/js/tinymce/skins/lightgray/content.inline.min.css\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"5b10ce987c2e7a6ccb8f2e8e197dd5ac\";}s:54:\"wp-includes/js/tinymce/skins/lightgray/content.min.css\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"6f53d570185a3510ecd0c79b34be53d0\";}s:54:\"wp-includes/js/tinymce/skins/lightgray/fonts/readme.md\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"7a0f64800cf38b2be8d3dc4540ec31dd\";}s:62:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"e33420c71c1a5c429069874d1de98a8b\";}s:62:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"473611093dd8089b0ed33c199725a723\";}s:62:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"b86135446ecf06e0ac722d6d8f403550\";}s:63:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"d725b287d3d6816c20520a31924fde17\";}s:56:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"50b8dc1736855fc2b8d71d669b0eabf7\";}s:56:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"0d83661ec506e1571bee29a7cba9e2c2\";}s:56:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"04f99db6f827ff1f7c68d6bc6b38ca99\";}s:57:\"wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"90a61cfad08585040f6bebe2234d8aae\";}s:53:\"wp-includes/js/tinymce/skins/lightgray/img/anchor.gif\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"abd3613571800fdcc891181d5f34f840\";}s:53:\"wp-includes/js/tinymce/skins/lightgray/img/loader.gif\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"394bafc3cc4dfb3a0ee48c1f54669539\";}s:53:\"wp-includes/js/tinymce/skins/lightgray/img/object.gif\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"f3726450d7457d750a2f4d9441c7ee20\";}s:52:\"wp-includes/js/tinymce/skins/lightgray/img/trans.gif\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"12bf9e19374920de3146a64775f46a5e\";}s:55:\"wp-includes/js/tinymce/skins/lightgray/skin.ie7.min.css\";a:2:{s:1:\"d\";i:1416459024;s:1:\"h\";s:32:\"16b6170794ca6d5f7fd29073d4a5477f\";}s:51:\"wp-includes/js/tinymce/skins/lightgray/skin.min.css\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"c12daa75772a539d80c0bfffae2db05d\";}s:53:\"wp-includes/js/tinymce/skins/wordpress/wp-content.css\";a:2:{s:1:\"d\";i:1426730066;s:1:\"h\";s:32:\"1cd99e8652d4e846316f6af433bc58b6\";}s:45:\"wp-includes/js/tinymce/themes/modern/theme.js\";a:2:{s:1:\"d\";i:1426029628;s:1:\"h\";s:32:\"3cda8e27d12c73c9046250803b1153e0\";}s:49:\"wp-includes/js/tinymce/themes/modern/theme.min.js\";a:2:{s:1:\"d\";i:1414044500;s:1:\"h\";s:32:\"564c5df5e7f98ae88d546732251aeab2\";}s:40:\"wp-includes/js/tinymce/tiny_mce_popup.js\";a:2:{s:1:\"d\";i:1430903550;s:1:\"h\";s:32:\"d84233dd293717f0a07b558b2fe38f56\";}s:37:\"wp-includes/js/tinymce/tinymce.min.js\";a:2:{s:1:\"d\";i:1430903550;s:1:\"h\";s:32:\"df2f5a1e56af39b9ec1b4e2e7bf6d08b\";}s:48:\"wp-includes/js/tinymce/utils/editable_selects.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"79087fabcb00132181650bd80666c085\";}s:42:\"wp-includes/js/tinymce/utils/form_utils.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"a32d1bbc44057b7dd0d2776ba2826b7c\";}s:38:\"wp-includes/js/tinymce/utils/mctabs.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"9f78248e9e0a64aa17f3062ce25099cb\";}s:40:\"wp-includes/js/tinymce/utils/validate.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"681466e5980a5b99d9baeded56c67d34\";}s:38:\"wp-includes/js/tinymce/wp-mce-help.php\";a:2:{s:1:\"d\";i:1428526766;s:1:\"h\";s:32:\"58c3473b65b3f5b094ebfdbe4571de27\";}s:39:\"wp-includes/js/tinymce/wp-tinymce.js.gz\";a:2:{s:1:\"d\";i:1430903550;s:1:\"h\";s:32:\"937d1ec0bf894d9686332fc3f71e6d22\";}s:37:\"wp-includes/js/tinymce/wp-tinymce.php\";a:2:{s:1:\"d\";i:1420268242;s:1:\"h\";s:32:\"8a620ab81dc7307f7072b1d312924876\";}s:25:\"wp-includes/js/tw-sack.js\";a:2:{s:1:\"d\";i:1345694658;s:1:\"h\";s:32:\"b989a5bd84f6ebcbc1393ec003e6e991\";}s:29:\"wp-includes/js/tw-sack.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"a1c18227e6e93798c493aed96ee6cc84\";}s:25:\"wp-includes/js/twemoji.js\";a:2:{s:1:\"d\";i:1427870368;s:1:\"h\";s:32:\"fc199f3337f05b3a2e6920c4b47c74d1\";}s:29:\"wp-includes/js/twemoji.min.js\";a:2:{s:1:\"d\";i:1427870368;s:1:\"h\";s:32:\"b47c1841005ed6866cd72c7fc2b74d46\";}s:32:\"wp-includes/js/underscore.min.js\";a:2:{s:1:\"d\";i:1428395906;s:1:\"h\";s:32:\"929daff1019e5493c0486bfb7a642e2e\";}s:23:\"wp-includes/js/utils.js\";a:2:{s:1:\"d\";i:1407912436;s:1:\"h\";s:32:\"01b7f89601bfa36ffee09f056f2cc38a\";}s:27:\"wp-includes/js/utils.min.js\";a:2:{s:1:\"d\";i:1407912436;s:1:\"h\";s:32:\"41fa39bcefcede21b93beb099cfa78d7\";}s:25:\"wp-includes/js/wp-a11y.js\";a:2:{s:1:\"d\";i:1425251488;s:1:\"h\";s:32:\"9496a3e87aed4ca075c24a6710fadd6b\";}s:29:\"wp-includes/js/wp-a11y.min.js\";a:2:{s:1:\"d\";i:1425251488;s:1:\"h\";s:32:\"7fc4397387256fc4d513baf001563c34\";}s:34:\"wp-includes/js/wp-ajax-response.js\";a:2:{s:1:\"d\";i:1425944666;s:1:\"h\";s:32:\"cf231fd7fd235076995cd3ea70c31f92\";}s:38:\"wp-includes/js/wp-ajax-response.min.js\";a:2:{s:1:\"d\";i:1425944666;s:1:\"h\";s:32:\"6243173bbe7318aa7b1702a90c4b0ccb\";}s:31:\"wp-includes/js/wp-auth-check.js\";a:2:{s:1:\"d\";i:1427856926;s:1:\"h\";s:32:\"a28190f5ed5d6bfa0702e414b65a2156\";}s:35:\"wp-includes/js/wp-auth-check.min.js\";a:2:{s:1:\"d\";i:1427856926;s:1:\"h\";s:32:\"4584099c38e5ed5f6f44644a79b6e473\";}s:29:\"wp-includes/js/wp-backbone.js\";a:2:{s:1:\"d\";i:1392291374;s:1:\"h\";s:32:\"fdaba653baf259db7cb3d7a4d76a2970\";}s:33:\"wp-includes/js/wp-backbone.min.js\";a:2:{s:1:\"d\";i:1392291374;s:1:\"h\";s:32:\"b569e29ff8fd482e0ee75e1494085621\";}s:33:\"wp-includes/js/wp-emoji-loader.js\";a:2:{s:1:\"d\";i:1430890526;s:1:\"h\";s:32:\"d4a819f73ff1a4574a969c9e46d6f117\";}s:37:\"wp-includes/js/wp-emoji-loader.min.js\";a:2:{s:1:\"d\";i:1430890526;s:1:\"h\";s:32:\"26ce699f92d7bd2d7dee5ff0827b296c\";}s:38:\"wp-includes/js/wp-emoji-release.min.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"c2e58e292752044c979a4efe494e1299\";}s:26:\"wp-includes/js/wp-emoji.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"a1ee27ad90d9bd862c162080115b1890\";}s:30:\"wp-includes/js/wp-emoji.min.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"3a083b99f4d138b72547e42f77027320\";}s:35:\"wp-includes/js/wp-list-revisions.js\";a:2:{s:1:\"d\";i:1384511050;s:1:\"h\";s:32:\"47510d7560d22a974c8c0eec6e24bcbd\";}s:39:\"wp-includes/js/wp-list-revisions.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"b4031fcf4f4279be864d4bd82f7fc46c\";}s:26:\"wp-includes/js/wp-lists.js\";a:2:{s:1:\"d\";i:1395890056;s:1:\"h\";s:32:\"c54ced2e822b232f2ad8a5f34930386f\";}s:30:\"wp-includes/js/wp-lists.min.js\";a:2:{s:1:\"d\";i:1395890056;s:1:\"h\";s:32:\"98747c729c8e35d2d6781cc587d9d291\";}s:28:\"wp-includes/js/wp-pointer.js\";a:2:{s:1:\"d\";i:1384504930;s:1:\"h\";s:32:\"35cb8b380bbd1f2eaa723ac49ba5f3f0\";}s:32:\"wp-includes/js/wp-pointer.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"368f987c644d70580097e48066c99082\";}s:25:\"wp-includes/js/wp-util.js\";a:2:{s:1:\"d\";i:1415230762;s:1:\"h\";s:32:\"b1f5d3eba80a1f93e0253bc74991fbb1\";}s:29:\"wp-includes/js/wp-util.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"39ca66318ef66201510aebcaad263210\";}s:26:\"wp-includes/js/wpdialog.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"72e8395fd44d4039009c5396888fa6ba\";}s:30:\"wp-includes/js/wpdialog.min.js\";a:2:{s:1:\"d\";i:1388289196;s:1:\"h\";s:32:\"d22d9fa5bb00ba0667080da846c4a1be\";}s:24:\"wp-includes/js/wplink.js\";a:2:{s:1:\"d\";i:1429639170;s:1:\"h\";s:32:\"5c88246db88479ae6c91651d19eaedea\";}s:28:\"wp-includes/js/wplink.min.js\";a:2:{s:1:\"d\";i:1429639170;s:1:\"h\";s:32:\"ce9cca5e1367cd6f5d4471f5604a4d69\";}s:30:\"wp-includes/js/zxcvbn-async.js\";a:2:{s:1:\"d\";i:1384314190;s:1:\"h\";s:32:\"97a79e96a815b200139356055d752333\";}s:34:\"wp-includes/js/zxcvbn-async.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"3196e9b61f703909e139ce7e049a7ffd\";}s:28:\"wp-includes/js/zxcvbn.min.js\";a:2:{s:1:\"d\";i:1386201190;s:1:\"h\";s:32:\"a14cd5113bd0d57563c1a9b63cae05f8\";}s:20:\"wp-includes/kses.php\";a:2:{s:1:\"d\";i:1421438844;s:1:\"h\";s:32:\"fc2b0ef05c60060c011da5ed73b01d09\";}s:20:\"wp-includes/l10n.php\";a:2:{s:1:\"d\";i:1423841006;s:1:\"h\";s:32:\"6a19f8df214bb3d9f6c173381337145b\";}s:29:\"wp-includes/link-template.php\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"4b1e5c0301975cf669cf2fbe3ab8e149\";}s:20:\"wp-includes/load.php\";a:2:{s:1:\"d\";i:1423207464;s:1:\"h\";s:32:\"cc5403876675114a9b00cd478947300f\";}s:22:\"wp-includes/locale.php\";a:2:{s:1:\"d\";i:1420887264;s:1:\"h\";s:32:\"974e8b9c7e685d3ae754fc31eb078e51\";}s:30:\"wp-includes/media-template.php\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"e7c9e8c6f39984e84bbaf15910ba3f8a\";}s:21:\"wp-includes/media.php\";a:2:{s:1:\"d\";i:1428803368;s:1:\"h\";s:32:\"da126b266020a9c84338e05d3a9374d6\";}s:20:\"wp-includes/meta.php\";a:2:{s:1:\"d\";i:1428264688;s:1:\"h\";s:32:\"7d0f8ad88fe16f53b24279797db73b8f\";}s:24:\"wp-includes/ms-blogs.php\";a:2:{s:1:\"d\";i:1423207582;s:1:\"h\";s:32:\"2c09e2062db1557b8c25ae0cc009208b\";}s:36:\"wp-includes/ms-default-constants.php\";a:2:{s:1:\"d\";i:1405826056;s:1:\"h\";s:32:\"4e4d93eda2a8c01c8ad639f18862fc25\";}s:34:\"wp-includes/ms-default-filters.php\";a:2:{s:1:\"d\";i:1421095224;s:1:\"h\";s:32:\"8bf488d3b181958318657560e82e4037\";}s:29:\"wp-includes/ms-deprecated.php\";a:2:{s:1:\"d\";i:1421447844;s:1:\"h\";s:32:\"0e5f592bd357efbfe42bc596204c7095\";}s:24:\"wp-includes/ms-files.php\";a:2:{s:1:\"d\";i:1369095622;s:1:\"h\";s:32:\"5dbc79c3affe3cd17220d44ceb467c01\";}s:28:\"wp-includes/ms-functions.php\";a:2:{s:1:\"d\";i:1428394466;s:1:\"h\";s:32:\"0fabe77db37a6eacd8474e70dcafa207\";}s:23:\"wp-includes/ms-load.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"b6d38dfb1270eb3f6b2ce28648c7129d\";}s:27:\"wp-includes/ms-settings.php\";a:2:{s:1:\"d\";i:1404186616;s:1:\"h\";s:32:\"8a8d737615b5c982687aa82aca65f893\";}s:33:\"wp-includes/nav-menu-template.php\";a:2:{s:1:\"d\";i:1421095224;s:1:\"h\";s:32:\"8bdf7b7913f445e52deb328951887a83\";}s:24:\"wp-includes/nav-menu.php\";a:2:{s:1:\"d\";i:1426155328;s:1:\"h\";s:32:\"7f3768f396de9db53a16debfe92db937\";}s:22:\"wp-includes/option.php\";a:2:{s:1:\"d\";i:1425664646;s:1:\"h\";s:32:\"93f5212be90f9e312c0d949589b8bf07\";}s:36:\"wp-includes/pluggable-deprecated.php\";a:2:{s:1:\"d\";i:1417400366;s:1:\"h\";s:32:\"84dba0f9d4eb8476be216c22c8a4f32d\";}s:25:\"wp-includes/pluggable.php\";a:2:{s:1:\"d\";i:1430910390;s:1:\"h\";s:32:\"1d4ec059aa43e6c76546b1e54833fdfd\";}s:22:\"wp-includes/plugin.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4ef823bc14adc286ab699c19f588adb2\";}s:26:\"wp-includes/pomo/entry.php\";a:2:{s:1:\"d\";i:1351736032;s:1:\"h\";s:32:\"eb148c7d02db4c96c7bcc6a2d276c22e\";}s:23:\"wp-includes/pomo/mo.php\";a:2:{s:1:\"d\";i:1417398082;s:1:\"h\";s:32:\"7aea8668c85e32b92e91df74d6e9b261\";}s:23:\"wp-includes/pomo/po.php\";a:2:{s:1:\"d\";i:1417398082;s:1:\"h\";s:32:\"361d2b008f7fa66e15e45f48536cb5c4\";}s:28:\"wp-includes/pomo/streams.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"713bd07dad1799ee2ccaa09bf6911fa8\";}s:33:\"wp-includes/pomo/translations.php\";a:2:{s:1:\"d\";i:1417398082;s:1:\"h\";s:32:\"836657dba5cb229000024477660e9ddf\";}s:28:\"wp-includes/post-formats.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"e0034de9d2919356c894244c3b4364a7\";}s:29:\"wp-includes/post-template.php\";a:2:{s:1:\"d\";i:1428528566;s:1:\"h\";s:32:\"62fde70adc55279bc18b28ed7b9d6def\";}s:39:\"wp-includes/post-thumbnail-template.php\";a:2:{s:1:\"d\";i:1426895846;s:1:\"h\";s:32:\"65f5314c3552ba0d96bc59a91283b493\";}s:20:\"wp-includes/post.php\";a:2:{s:1:\"d\";i:1430943690;s:1:\"h\";s:32:\"7a2fbff334c1a12b5a636c63a069765b\";}s:21:\"wp-includes/query.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3b8e714e0f01cae90afcc81062acf39c\";}s:38:\"wp-includes/registration-functions.php\";a:2:{s:1:\"d\";i:1326056472;s:1:\"h\";s:32:\"5f3f3cb7c6d126548d7848dd5893434c\";}s:28:\"wp-includes/registration.php\";a:2:{s:1:\"d\";i:1326056472;s:1:\"h\";s:32:\"7198cf8d485e8ddcb2b3bb49a6d069da\";}s:24:\"wp-includes/revision.php\";a:2:{s:1:\"d\";i:1417402586;s:1:\"h\";s:32:\"807b2938032727aeeeaadc388c95f875\";}s:23:\"wp-includes/rewrite.php\";a:2:{s:1:\"d\";i:1427929590;s:1:\"h\";s:32:\"f9fb6acba8994419fa8b7e5ef68d548d\";}s:29:\"wp-includes/rss-functions.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"67b3b8bbb2d4166c5da5346a306c3d9d\";}s:19:\"wp-includes/rss.php\";a:2:{s:1:\"d\";i:1415009302;s:1:\"h\";s:32:\"565968c6a4b133fae4b81cd3cc750994\";}s:29:\"wp-includes/script-loader.php\";a:2:{s:1:\"d\";i:1429559066;s:1:\"h\";s:32:\"a7193c6c0ad49f0c577f3a4c23e390a2\";}s:23:\"wp-includes/session.php\";a:2:{s:1:\"d\";i:1421463082;s:1:\"h\";s:32:\"29137c6fd72e3b6558be0b2b7d4e17fd\";}s:26:\"wp-includes/shortcodes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"289d2b11c723316d8b1fd2abd6196fe4\";}s:32:\"wp-includes/SimplePie/Author.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"348071ed105ff0418b25964e771ba331\";}s:36:\"wp-includes/SimplePie/Cache/Base.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"9443eda189bbd9325d0c9c045d237c6a\";}s:34:\"wp-includes/SimplePie/Cache/DB.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"0659bf084f55a303f5922edc62bcfbf6\";}s:36:\"wp-includes/SimplePie/Cache/File.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"a33dbb0540ecc29cc6425b14100953d1\";}s:40:\"wp-includes/SimplePie/Cache/Memcache.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"f69d4a55b2a1168531535107ab843fb6\";}s:37:\"wp-includes/SimplePie/Cache/MySQL.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"e8911ece15df42ca43991a48d5785687\";}s:31:\"wp-includes/SimplePie/Cache.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"79fc9017a23a836f4d0f68f7764ca734\";}s:33:\"wp-includes/SimplePie/Caption.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"bdbabcdcca426a4dadf6675bc4c4ebe9\";}s:34:\"wp-includes/SimplePie/Category.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"ba7ec8cc3f13d4f27f2e0adcaf64bb2a\";}s:46:\"wp-includes/SimplePie/Content/Type/Sniffer.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"7c72c3f369855562d96c77ece1c7db33\";}s:35:\"wp-includes/SimplePie/Copyright.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"bd7fbf68b954a9d50955cc808db7cb6a\";}s:30:\"wp-includes/SimplePie/Core.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"a4ae19a923b890f2dcf7e2d415fd1ad2\";}s:32:\"wp-includes/SimplePie/Credit.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"0385e4a14de78c8b2a167f3e0aea197c\";}s:46:\"wp-includes/SimplePie/Decode/HTML/Entities.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"45975e2fcf0d428691a55a2394252f61\";}s:35:\"wp-includes/SimplePie/Enclosure.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"122e861f42eb6e01ce8d4b0f11fb735d\";}s:35:\"wp-includes/SimplePie/Exception.php\";a:2:{s:1:\"d\";i:1352416494;s:1:\"h\";s:32:\"094bfd76269c9fcc3c5cda8f05d05335\";}s:30:\"wp-includes/SimplePie/File.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"aeba08ad6b558736ea0aaf2beb2925b7\";}s:34:\"wp-includes/SimplePie/gzdecode.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"c538e2bc0e866197db616c17841134d4\";}s:37:\"wp-includes/SimplePie/HTTP/Parser.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"5725c7d0fb347f1c08df3690a58f3609\";}s:29:\"wp-includes/SimplePie/IRI.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"6e16ff20d3e68692cf3b617b875f36f5\";}s:30:\"wp-includes/SimplePie/Item.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"104510e221fa08437aec008e633cdca7\";}s:33:\"wp-includes/SimplePie/Locator.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"8073a4c6da1bb33b877576665ef5eab5\";}s:30:\"wp-includes/SimplePie/Misc.php\";a:2:{s:1:\"d\";i:1373317816;s:1:\"h\";s:32:\"cecde679c62dd50207d8d25ece1a4b89\";}s:34:\"wp-includes/SimplePie/Net/IPv6.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"a546790e216abdd9801795949fb6b40f\";}s:36:\"wp-includes/SimplePie/Parse/Date.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"9a0a326d308c1e48a0f89bd3ce6e2760\";}s:32:\"wp-includes/SimplePie/Parser.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"52bb2ee462e7e414a77efdc7ebf52bcc\";}s:32:\"wp-includes/SimplePie/Rating.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"3d7013a46d09c74b0ee3d8af617412fb\";}s:34:\"wp-includes/SimplePie/Registry.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"1cc8a2e6c0b5dd3176398d6400f0d9b8\";}s:37:\"wp-includes/SimplePie/Restriction.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"2a191e7168116418817388113bd57914\";}s:34:\"wp-includes/SimplePie/Sanitize.php\";a:2:{s:1:\"d\";i:1378886530;s:1:\"h\";s:32:\"42d8b8c0cf46b5d8a511e0ae48b88f75\";}s:32:\"wp-includes/SimplePie/Source.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"8e83bb1de3e018f0537bb32a8c9617ff\";}s:48:\"wp-includes/SimplePie/XML/Declaration/Parser.php\";a:2:{s:1:\"d\";i:1353551516;s:1:\"h\";s:32:\"8fb1da7028c385bb9d4203c9f6732362\";}s:24:\"wp-includes/taxonomy.php\";a:2:{s:1:\"d\";i:1430966968;s:1:\"h\";s:32:\"8ff69b032f99c10cdcd99080fc394a31\";}s:31:\"wp-includes/template-loader.php\";a:2:{s:1:\"d\";i:1383158350;s:1:\"h\";s:32:\"0573827ec7b9e08b5139c15a6ca23df4\";}s:24:\"wp-includes/template.php\";a:2:{s:1:\"d\";i:1421384784;s:1:\"h\";s:32:\"5ff61981f75197ad47e8f080e091ee1e\";}s:39:\"wp-includes/Text/Diff/Engine/native.php\";a:2:{s:1:\"d\";i:1369532306;s:1:\"h\";s:32:\"e5ad272a18821212bee3c3df2ae8780e\";}s:38:\"wp-includes/Text/Diff/Engine/shell.php\";a:2:{s:1:\"d\";i:1266557126;s:1:\"h\";s:32:\"75ab41dc91cd7e4aaa5e74a5f9e6eeba\";}s:39:\"wp-includes/Text/Diff/Engine/string.php\";a:2:{s:1:\"d\";i:1369532306;s:1:\"h\";s:32:\"5eee1f967840b952b502c6993dbbfad3\";}s:38:\"wp-includes/Text/Diff/Engine/xdiff.php\";a:2:{s:1:\"d\";i:1369532306;s:1:\"h\";s:32:\"d6b91fc8628a0c0474ad58389a475815\";}s:41:\"wp-includes/Text/Diff/Renderer/inline.php\";a:2:{s:1:\"d\";i:1266557126;s:1:\"h\";s:32:\"880ae56e35b150b4b2c7e9d94227e81e\";}s:34:\"wp-includes/Text/Diff/Renderer.php\";a:2:{s:1:\"d\";i:1369532306;s:1:\"h\";s:32:\"eb06befa8886e0c1858aa214e88fa829\";}s:25:\"wp-includes/Text/Diff.php\";a:2:{s:1:\"d\";i:1369534254;s:1:\"h\";s:32:\"25fe9d676b0c6a4062c025c6dfdc00d9\";}s:43:\"wp-includes/theme-compat/comments-popup.php\";a:2:{s:1:\"d\";i:1417915944;s:1:\"h\";s:32:\"5885552f89b4c18061da8c2e753c122e\";}s:37:\"wp-includes/theme-compat/comments.php\";a:2:{s:1:\"d\";i:1428531328;s:1:\"h\";s:32:\"e8816ffd51f74b3f4718f7bc7dbf3117\";}s:35:\"wp-includes/theme-compat/footer.php\";a:2:{s:1:\"d\";i:1393828468;s:1:\"h\";s:32:\"c6207e0b437e8e4d8f13dde9f8b5c93d\";}s:35:\"wp-includes/theme-compat/header.php\";a:2:{s:1:\"d\";i:1395782536;s:1:\"h\";s:32:\"b4788daaa2fc81887659a2b21d888c0b\";}s:36:\"wp-includes/theme-compat/sidebar.php\";a:2:{s:1:\"d\";i:1393828468;s:1:\"h\";s:32:\"3e1abfa5fc227d5775166faa86842e48\";}s:21:\"wp-includes/theme.php\";a:2:{s:1:\"d\";i:1428268288;s:1:\"h\";s:32:\"588c549575dcdeb7c3ec82fba23c234f\";}s:22:\"wp-includes/update.php\";a:2:{s:1:\"d\";i:1426730848;s:1:\"h\";s:32:\"aa5fa257f25c1e4610e544fb24e52c30\";}s:20:\"wp-includes/user.php\";a:2:{s:1:\"d\";i:1429557388;s:1:\"h\";s:32:\"0be29a51ba852adb3b2718fd65081770\";}s:20:\"wp-includes/vars.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"b38acf27be96e9387592b091c6b5383b\";}s:23:\"wp-includes/version.php\";a:2:{s:1:\"d\";i:1430964448;s:1:\"h\";s:32:\"2db0f9b1bb40f8b7f2eb9153e1abe905\";}s:23:\"wp-includes/widgets.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"a95a0636dbedc6fbcc9289ec24329a70\";}s:27:\"wp-includes/wlwmanifest.xml\";a:2:{s:1:\"d\";i:1386805752;s:1:\"h\";s:32:\"dfd490b6f383ea02a269031ff05e8896\";}s:21:\"wp-includes/wp-db.php\";a:2:{s:1:\"d\";i:1430910870;s:1:\"h\";s:32:\"ccc3c9fc31afd42091eace715ccb6ad5\";}s:23:\"wp-includes/wp-diff.php\";a:2:{s:1:\"d\";i:1422545782;s:1:\"h\";s:32:\"7a7b02df261fb505e0de51fbd0d2e822\";}}","no");
INSERT INTO `arc1542_options` VALUES("279","itsec_local_file_list_2","a:5:{s:20:\"arc-assets/.DS_Store\";a:2:{s:1:\"d\";i:1434415508;s:1:\"h\";s:32:\"14040730d326965b0bc93a9dd0c918bb\";}s:20:\"arc-assets/index.php\";a:2:{s:1:\"d\";i:1326056472;s:1:\"h\";s:32:\"67442c5615eba73d105c0715c6620850\";}s:29:\"arc-assets/wfcache/clear.lock\";a:2:{s:1:\"d\";i:1437026081;s:1:\"h\";s:32:\"d41d8cd98f00b204e9800998ecf8427e\";}s:46:\"arc-assets/wfcache/test.dev_/~~~~_wfcache.html\";a:2:{s:1:\"d\";i:1438100781;s:1:\"h\";s:32:\"b5f923f789cf1d6ef46611bd5917889c\";}s:51:\"arc-assets/wfcache/test.dev_/~~~~_wfcache.html_gzip\";a:2:{s:1:\"d\";i:1438100781;s:1:\"h\";s:32:\"4df85c72640743bbdf15699300dc3fda\";}}","no");
INSERT INTO `arc1542_options` VALUES("283","db_upgraded","","yes");
INSERT INTO `arc1542_options` VALUES("286","auto_core_update_notified","a:4:{s:4:\"type\";s:7:\"success\";s:5:\"email\";s:22:\"andre.hayter@gmail.com\";s:7:\"version\";s:5:\"4.2.4\";s:9:\"timestamp\";i:1438996043;}","yes");
INSERT INTO `arc1542_options` VALUES("293","_site_transient_timeout_itsec_random_version","1439082430","yes");
INSERT INTO `arc1542_options` VALUES("294","_site_transient_itsec_random_version","117","yes");
INSERT INTO `arc1542_options` VALUES("298","itsec_local_file_list_3","a:10:{s:45:\"arc-assets/uploads/ithemes-security/.htaccess\";a:2:{s:1:\"d\";i:1434397534;s:1:\"h\";s:32:\"209634bb0238704c4874c35d615ae59e\";}s:53:\"arc-assets/uploads/ithemes-security/backups/.htaccess\";a:2:{s:1:\"d\";i:1434397534;s:1:\"h\";s:32:\"209634bb0238704c4874c35d615ae59e\";}s:79:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1437011629-4oWTO52yS.zip\";a:2:{s:1:\"d\";i:1437026029;s:1:\"h\";s:32:\"6547dfb4630716481a6f5a4d5e3ab5f4\";}s:76:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1437011629-SpjxuO.zip\";a:2:{s:1:\"d\";i:1437026029;s:1:\"h\";s:32:\"aaae0d33af0c6455c633fe955f14d8d6\";}s:76:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1438086310-IvZBPb.zip\";a:2:{s:1:\"d\";i:1438100710;s:1:\"h\";s:32:\"9da0bbb667f7e58287b964974e39738b\";}s:75:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1438086311-amkbx.zip\";a:2:{s:1:\"d\";i:1438100711;s:1:\"h\";s:32:\"134f9769c18463f2e35391fe123b6841\";}s:76:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1438521472-DsMpZ2.zip\";a:2:{s:1:\"d\";i:1438535872;s:1:\"h\";s:32:\"d9fe869ee6f48a33f4f1f33c2dc2e006\";}s:79:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1438981631-nvf8ocpQ1.zip\";a:2:{s:1:\"d\";i:1438996031;s:1:\"h\";s:32:\"9395735eaf0b0ab9ffafdae400acfccb\";}s:79:\"arc-assets/uploads/ithemes-security/backups/backup-arc-1438981631-zT6YAobLi.zip\";a:2:{s:1:\"d\";i:1438996031;s:1:\"h\";s:32:\"2c1324ae17e2994939b580dc20f68d08\";}s:50:\"arc-assets/uploads/ithemes-security/logs/.htaccess\";a:2:{s:1:\"d\";i:1434397534;s:1:\"h\";s:32:\"209634bb0238704c4874c35d615ae59e\";}}","no");
INSERT INTO `arc1542_options` VALUES("300","_site_transient_timeout_theme_roots","1438997833","yes");
INSERT INTO `arc1542_options` VALUES("301","_site_transient_theme_roots","a:1:{s:10:\"ut-thehill\";s:7:\"/themes\";}","yes");
INSERT INTO `arc1542_options` VALUES("302","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.4\";s:7:\"version\";s:5:\"4.2.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1438996598;s:15:\"version_checked\";s:5:\"4.2.4\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("309","rewrite_rules","a:71:{s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `arc1542_options` VALUES("310","_site_transient_timeout_browser_5d477133650f1787e3f4e40cb87fb011","1439601397","yes");
INSERT INTO `arc1542_options` VALUES("311","_site_transient_browser_5d477133650f1787e3f4e40cb87fb011","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"44.0.2403.125\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("312","can_compress_scripts","1","yes");
INSERT INTO `arc1542_options` VALUES("313","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1439039800","no");
INSERT INTO `arc1542_options` VALUES("314","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2015 12:10:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"http://wordpress.org/?v=4.3-RC2-33594\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.4 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2015 12:10:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3827\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:397:\"WordPress 4.2.4 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by Marc-Alexandre Montpas of Sucuri, Helen Hou-Sandí [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2011:\"<p>WordPress 4.2.4 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by <a href=\"https://sucuri.net/\">Marc-Alexandre Montpas</a> of Sucuri, <a href=\"http://helenhousandi.com/\">Helen Hou-Sandí</a> of the WordPress security team, <a href=\"http://www.checkpoint.com/\">Netanel Rubin</a> of Check Point, and <a href=\"https://hackerone.com/reactors08\">Ivan Grigorov</a>. It also includes a fix for a potential timing side-channel attack, discovered by <a href=\"http://www.scrutinizer-ci.com/\">Johannes Schmitt</a> of Scrutinizer, and prevents an attacker from locking a post from being edited, discovered by <a href=\"https://www.linkedin.com/in/symbiansymoh\">Mohamed A. Baset</a>.</p>
<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.4 also fixes four bugs. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.4\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=33573&amp;stop_rev=33396\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.4</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.4.</p>
<p><em>Already testing WordPress 4.3? The second release candidate is now available (<a href=\"https://wordpress.org/wordpress-4.3-RC2.zip\">zip</a>) and it contains these fixes. For more on 4.3, see <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/\">the RC 1 announcement post</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 4.3 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 23:50:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3817\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:340:\"The release candidate for WordPress 4.3 is now available. We&#8217;ve made more than 100 changes since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on Tuesday, August 18, but we [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2256:\"<p>The release candidate for WordPress 4.3 is now available.</p>
<p>We&#8217;ve made more than <a href=\"https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33512&amp;stop_rev=33372&amp;limit=120\">100 changes</a> since releasing Beta 4 a week ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.3 on <strong>Tuesday, August 18</strong>, but we need your help to get there.</p>
<p>If you haven’t tested 4.3 yet, now is the time!</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href=\"https://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>To test WordPress 4.3 RC1, you can use the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin or you can <a href=\"https://wordpress.org/wordpress-4.3-RC1.zip\">download the release candidate here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\">Beta 3</a>, and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/\">Beta 4</a> blog posts.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.3 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.3 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href=\"https://make.wordpress.org/core/\">follow along the core development blog</a>, where we&#8217;ll continue to post <a href=\"https://make.wordpress.org/core/tag/dev-notes+4-3/\">notes for developers</a> for 4.3.</p>
<p><em>Drei Monate Arbeit</em><br />
<em>Endlich das Ziel vor Augen</em><br />
<em>Bald hab ich Urlaub!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2015/07/wordpress-4-3-release-candidate/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.3 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/07/wordpress-4-2-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/07/wordpress-4-2-3/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 11:21:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3807\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"WordPress 4.2.3 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by Jon Cave and [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2708:\"<p>WordPress 4.2.3 is now available. This is a<strong> security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was initially reported by <a href=\"https://profiles.wordpress.org/duck_\">Jon Cave</a> and fixed by <a href=\"http://www.miqrogroove.com/\">Robert Chapin</a>, both of the WordPress security team, and later reported by <a href=\"http://klikki.fi/\">Jouko Pynnönen</a>.</p>
<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft. Reported by Netanel Rubin from <a href=\"https://www.checkpoint.com/\">Check Point Software Technologies</a>.</p>
<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.3 also contains fixes for 20 bugs from 4.2. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.3\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=33382&amp;stop_rev=32430\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.3</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.3.</p>
<p>Thanks to everyone who contributed to 4.2.3:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/chriscct7\">Chris Christoff</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/gabrielperezs\">Gabriel Pérez</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, and <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-2-3/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 21:55:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3796\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2212:\"<p>WordPress 4.3 Beta 4 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta4.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a>, and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\">Beta 3</a> blog posts. Some of the changes in Beta 4 include:</p>
<ul>
<li><span class=\"s1\">Fixed several bugs and broken flows in the </span><span class=\"s1\"><strong>publish box </strong></span><span class=\"s1\">in the edit screen.</span></li>
<li>Addressed a number of edge cases for word count in the <strong>editor</strong>.</li>
<li><span class=\"s1\"><strong>Site icons</strong> </span><span class=\"s1\">can now be previewed within the customizer. The feature has been removed from general settings.</span></li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log/trunk?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33369&amp;stop_rev=33289\">more than 60 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a>.</p>
<p><em>Few Tickets Remain</em><br />
<em>Edge Cases Disappearing</em><br />
<em>You Must Test Today</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-4/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 21:49:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3787\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2529:\"<p>WordPress 4.3 Beta 3 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta3.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a> and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a> blog posts. Some of the changes in Beta 3 include:</p>
<ul>
<li>Performance improvements for <strong>Menus in the Customizer</strong>, as well as bug fixes and visual enhancements.</li>
<li>Added <strong>Site Icon</strong> to the Customizer. The feature is now complete and requires lots of testing. Please help us ensure the site icon feature works well in both Settings and the Customizer.</li>
<li>The improvements to <strong>Passwords</strong> have been added to the installation flow. When installing and setting up WordPress, a strong password will be suggested to site administrators. Please test and let us know if you encounter issues.</li>
<li>Improved <strong>accessibility of comments and media list tables</strong>. If you use a screen reader, please let us know if you encounter any issues.</li>
<li>Lots and lots of code documentation improvements.</li>
<li><strong>Various other bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33286&amp;stop_rev=33141&amp;limit=150\">more than 140 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a>.</p>
<p><em>Want to test new things?</em><br />
<em>Wonder how four three shapes up?</em><br />
<em>Answer: beta three</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 22:04:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3769\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2876:\"<p>WordPress 4.3 Beta 2 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta2.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Fixed an issue in beta 1 where an alert appeared when saving or publishing a new post/page for the first time.</li>
<li><strong><strong>Customizer</strong></strong> improvements including enhanced accessibility, smoother menu creation and location assignment, and the ability to handle nameless menus. Please help us test menus in the Customizer to fix any remaining edge cases!</li>
<li>More robust<strong> list tables</strong> with full content support on small screens and a fallback for the primary column for custom list tables. We&#8217;d love to know how these list tables, such as All Posts and Comments, work for you now on small screen devices.</li>
<li>The <strong>Site Icon</strong> feature has been improved so that cropping is skipped if the image is the exact size (512px square) and the media modal now suggests a minimum icon size. Please let us know how the flow feels and if you encounter any glitches!</li>
<li>The <strong>toolbar</strong> now has a direct link to the customizer, along with quick access to themes, widgets, and menus in the dashboard.</li>
<li>We enabled <strong>utf8mb4 for MySQL</strong> extension users, which was previously unintentionally limited to MySQLi users. Please let us know if you run into any issues.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33138&amp;stop_rev=33046\">almost 100 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.3&amp;group=component&amp;order=priority\">everything we’ve fixed</a>.</p>
<p><em>Edges polished up</em><br />
<em>Features meliorated</em><br />
<em>Beta Two: go test!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordCamps Update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/news/2015/07/wordcamps-update/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordcamps-update/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 16:13:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3758\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:311:\"Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year. There have been 39 WordCamps in 2015 so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9419:\"<p>Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year.</p>
<p>There have been <a href=\"https://central.wordcamp.org/schedule/past-wordcamps/\">39 WordCamps in 2015</a> so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for WordCamp tickets so far this year, isn&#8217;t that amazing?</p>
<p><a href=\"https://europe.wordcamp.org/2015/\">WordCamp Europe</a> was held in Seville, Spain just a few weeks ago, with close to 1,000 registered participants and over 500 live stream participants. You can watch  <a href=\"http://wordpress.tv/2015/07/04/matt-mullenweg-keynote-qanda-wordcamp-europe-2015/\">Matt Mullenweg’s keynote Q&amp;A</a> session from WordCamp Europe right now on WordPress.tv.</p>
<p>WordPress.tv has published 537 videos so far in 2015 from WordCamps around the world. Some of the more popular 2015 WordCamp talks on WordPress.tv include <a href=\"http://wordpress.tv/2015/03/13/tammie-lister-theme-dont-be-my-everything/\">Tammie Lister: Theme, Don’t Be My Everything </a>from WordCamp Maui, <a href=\"http://wordpress.tv/2015/04/17/jenny-munn-seo-for-2015-whats-in-whats-out-and-how-to-be-in-it-to-win-it-for-good/\">Jenny Munn: SEO for 2015 – What’s In, What’s Out and How to Be In It to Win It (For Good)</a> from WordCamp Atlanta, <a href=\"http://wordpress.tv/2015/02/27/fabrice-ducarme-les-constructeurs-de-page-pour-wordpress/\">Fabrice Ducarme: Les Constructeurs de Page pour WordPress</a> from WordCamp Paris, <a href=\"http://wordpress.tv/2015/06/02/ben-furfie-how-to-value-price-websites/\">Ben Furfie: How to Value Price Websites</a> from WordCamp London, and <a href=\"http://wordpress.tv/2015/06/09/morten-rand-hendriksen-building-themes-from-scratch-using-underscores-_s/\">Morten Rand-Hendriksen: Building Themes From Scratch Using Underscores (_S)</a> from WordCamp Seattle. Check them out!</p>
<h3>Lots of great WordCamps are still to come</h3>
<p><a href=\"http://ma.tt/2015/06/wordcamp-us-survey/\">WordCamp US</a> is currently in pre-planning, in the process of deciding on a host city. The following cities have proposed themselves as a great place to host the first WordCamp US: Chattanooga, Chicago, Detroit, Orlando, Philadelphia, and Phoenix. It&#8217;s possible the first WordCamp US will be held in 2016 so we can organize the best first WordCamp US imaginable.</p>
<p>At this time, there are 28 <a href=\"https://central.wordcamp.org/schedule/\">WordCamps</a>, in 9 different countries, that have announced their dates for the rest of 2015. Twelve of these have tickets on sale:</p>
<ul>
<li><a href=\"https://columbus.wordcamp.org/2015/\">WordCamp Columbus</a>, Columbus, Ohio: July 17-18</li>
<li><a href=\"https://scranton.wordcamp.org/2015/\">WordCamp Scranton</a>, Scranton, Pennsylvania: July 18</li>
<li><a href=\"https://boston.wordcamp.org/2015/\">WordCamp Boston</a>, Boston, Massachussetts: July 18-19</li>
<li><a href=\"https://milwaukee.wordcamp.org/2015/\">WordCamp Milwaukee</a>, Milwaukee, Wisconsin: July 24-26</li>
<li><a href=\"https://asheville.wordcamp.org/2015/\">WordCamp Asheville</a>, Asheville, North Carolina: July 24-26</li>
<li><a href=\"https://kansai.wordcamp.org/2015/\">WordCamp Kansai</a>, Kansai, Japan: July 25-26</li>
<li><a href=\"https://fayetteville.wordcamp.org/2015/\">WordCamp Fayetteville</a>, Fayetteville, Arkansas: July 31-August 2</li>
<li><a href=\"https://brighton.buddycamp.org/2015/\">BuddyCamp Brighton</a>,  Brighton, UK: August 8</li>
<li><a href=\"https://vancouver.wordcamp.org/2015/\">WordCamp Vancouver, BC,</a> Vancouver, BC, Canada: August 15-16</li>
<li><a href=\"https://russia.wordcamp.org/2015/\">WordCamp Russia</a>, Moscow, Russia: August 15</li>
<li><a href=\"https://norrkoping.wordcamp.org/2015/\">WordCamp Norrköping</a>, Norrköping, Sweden: August 28-29</li>
<li><a href=\"https://croatia.wordcamp.org/2015/\">WordCamp Croatia</a>, Rijeka, Croatia: September 5-6</li>
<li><a href=\"https://krakow.wordcamp.org/2015/\">WordCamp Krakow,</a>  Krakow, Poland: September 12-13</li>
<li><a href=\"https://nyc.wordcamp.org/2015/\">WordCamp NYC</a>, New York City, New York: October 30-November 1</li>
</ul>
<p>The other 16 events don’t have tickets on sale yet, but they’ve set their dates! Subscribe to the sites to find out when registration opens:</p>
<ul>
<li><a href=\"https://pune.wordcamp.org/2015/\">WordCamp Pune</a>, Pune, India: September 6</li>
<li><a href=\"https://capetown.wordcamp.org/2015/\">WordCamp Cape Town</a>, Cape Town, South Africa: September 10-11</li>
<li><a href=\"https://baltimore.wordcamp.org/2015/\">WordCamp Baltimore</a>, Baltimore, Maryland: September 12</li>
<li><a href=\"https://slc.wordcamp.org/2015/\">WordCamp Salt Lake City</a>, Salt Lake City, Utah: September 12</li>
<li><a href=\"https://lithuania.wordcamp.org/2015/\">WordCamp Lithuania</a>, Vilnius, Lithuania: September 19</li>
<li><a href=\"https://vegas.wordcamp.org/2015\">WordCamp Vegas</a>, Las Vegas, Nevada: September 19-20</li>
<li><a href=\"https://switzerland.wordcamp.org/2015/\">WordCamp Switzerland</a>, Zurich, Switzerland: September 19-20</li>
<li><a href=\"https://tampa.wordcamp.org/2015/\">WordCamp Tampa</a>, Tampa, Florida: September 25-27</li>
<li><a href=\"https://rhodeisland.wordcamp.org/2015/\">WordCamp Rhode Island</a>,  Providence, Rhode Island: September 25-26</li>
<li><a href=\"https://la.wordcamp.org/2015/\">WordCamp Los Angeles</a>, Los Angeles, California: September 26-27</li>
<li><a href=\"https://denmark.wordcamp.org/2015/\">WordCamp Denmark,</a>  Copenhagen, Denmark: October 3-4</li>
<li><a href=\"https://toronto.wordcamp.org/2015\">WordCamp Toronto</a>, Toronto, Ontario, Canada: October 3-4</li>
<li><a href=\"https://hamptonroads.wordcamp.org/2015/\">WordCamp Hampton Roads, </a>  Virginia Beach, VA, USA: October 17</li>
<li><a href=\"https://annarbor.wordcamp.org/2015\">WordCamp Ann Arbor</a>, Ann Arbor, Michigan: October 24</li>
<li><a href=\"https://portland.wordcamp.org/2015/\">WordCamp Portland</a>,  Portland, OR: October 24-25</li>
</ul>
<p>On top of all those exciting community events, there are 26 WordCamps in pre-planning as they look for the right event space.  If you have a great idea for a free or cheap WordCamp venue in any of the below locations, get in touch with the organizers through the WordCamp sites:</p>
<ul>
<li><a href=\"https://dfw.wordcamp.org/2015/\">WordCamp DFW</a>:  Dallas/Fort Worth, Texas</li>
<li><a href=\"https://riodejaneiro.wordcamp.org/2015/\">WordCamp Rio</a>: Rio de Janeiro, Brazil</li>
<li><a href=\"https://saratoga.wordcamp.org/2015/\">WordCamp Saratoga</a>:  Saratoga Springs, New York</li>
<li><a href=\"https://sofia.wordcamp.org/2015\">WordCamp Sofia</a>:  Sofia, Bulgaria</li>
<li><a href=\"https://austin.wordcamp.org/2015/\">WordCamp Austin</a>:  Austin, TX</li>
<li><a href=\"https://ottawa.wordcamp.org/2015/\">WordCamp Ottawa</a>:  Ottawa, Canada</li>
<li><a href=\"https://charleston.wordcamp.org/2015/\">WordCamp Charleston</a>:  Charleston, South Carolina</li>
<li><a href=\"https://chicago.wordcamp.org/2015/\">WordCamp Chicago</a>:  Chicago, Illinois</li>
<li><a href=\"https://albuquerque.wordcamp.org/2015/\">WordCamp Albuquerque</a>:  Albuquerque, New Mexico</li>
<li><a href=\"https://prague.wordcamp.org/2015/\">WordCamp Prague</a>:  Prague, Czech Republic</li>
<li><a href=\"https://seoul.wordcamp.org/2014/\">WordCamp Seoul: </a>Seoul, South Korea</li>
<li><a href=\"https://louisville.wordcamp.org/2014/\">WordCamp Louisville</a>: Louisville, Kentucky</li>
<li><a href=\"https://omaha.wordcamp.org/2015/\">WordCamp Omaha</a>:  Omaha, Nebraska</li>
<li><a href=\"https://grandrapids.wordcamp.org/2015/\">WordCamp Grand Rapids</a>:  Grand Rapids, Michigan</li>
<li><a href=\"https://easttroy.wordcamp.org/2015/\">WordCamp East Troy</a>:  East Troy, Wisconsin</li>
<li><a href=\"https://palmademallorca.wordcamp.org/2015\">WordCamp Mallorca</a>: Palma de Mallorca, Spain</li>
<li><a href=\"https://edinburgh.wordcamp.org/2015/\">WordCamp Edinburgh</a>:  Edinburgh, United Kingdom</li>
<li><a href=\"https://orlando.wordcamp.org/2015/\">WordCamp Orlando</a>:  Orlando, Florida</li>
<li><a href=\"https://mexico.wordcamp.org/2015/\">WordCamp Mexico City</a>:  Mexico City, Mexico</li>
<li><a href=\"https://netherlands.wordcamp.org/2015/\">WordCamp Netherlands</a>:  Utrecht, Netherlands</li>
<li><a href=\"https://phoenix.wordcamp.org/2016/\">WordCamp Phoenix</a>:  Phoenix, Arizona</li>
<li><a href=\"https://saopaulo.wordcamp.org/2015/\">WordCamp São Paulo</a>:  São Paulo, Brazil</li>
<li><a href=\"https://manchester.wordcamp.org/2015/\">WordCamp Manchester</a>:  Manchester, United Kingdom</li>
<li><a href=\"https://tokyo.wordcamp.org/2015/\">WordCamp Tokyo</a>:  Tokyo, Japan</li>
<li><a href=\"https://lima.wordcamp.org/2015/\">WordCamp Lima</a>:  Lima, Peru</li>
<li><a href=\"https://seattle.wordcamp.org/2015-beginner/\">WordCamp Seattle: Beginner</a>: Seattle, WA</li>
</ul>
<p>Don’t see your city on the list, but yearning for a local WordCamp? WordCamps are organized by local volunteers from the WordPress community, and we have a whole team of people to support new organizers setting up a first-time WordCamp. If you want to bring WordCamp to town, check out how you can <a href=\"https://central.wordcamp.org/become-an-organizer/\">become a WordCamp organizer</a>!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/news/2015/07/wordcamps-update/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 01:30:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3738\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.3 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4352:\"<p>WordPress 4.3 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta1.zip\">download the beta here</a> (zip).</p>
<p>4.3 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Menus</strong> can now be managed with the <strong>Customizer</strong>, which allows you to live preview changes you’re making without changing your site for visitors until you’re ready. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href=\"https://core.trac.wordpress.org/ticket/32576\">#32576</a>).</li>
<li>Take control of another piece of your site with the <strong>Site Icon</strong> feature. You can now manage your site’s favicon and app icon from the admin area (<a href=\"https://core.trac.wordpress.org/ticket/16434\">#16434</a>).</li>
<li>We put a lot of work into <strong>Better Passwords</strong> throughout WordPress. Now, WordPress will limit the life time of password resets, no longer send passwords via email, and generate and suggest secure passwords for you. Try it out and let us know what you think! (<a href=\"https://core.trac.wordpress.org/ticket/32589\">#32589</a>)</li>
<li>We’ve also added <strong>Editor Improvements</strong>. Certain text patterns are automatically transformed as you type, including <code>*</code> and <code>-</code> transforming into unordered lists, <code>1.</code> and <code>1)</code> for ordered lists, <code>&gt;</code> for blockquotes and two to six number signs (<code>#</code>) for headings (<a href=\"https://core.trac.wordpress.org/ticket/31441\">#31441</a>).</li>
<li>We’ve improved the <strong>list view</strong> across the admin dashboard. Now, when you view your posts and pages <strong>on small screen devices</strong>, columns are not truncated and can be toggled into view (<a href=\"https://core.trac.wordpress.org/ticket/32395\">#32395</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a few of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href=\"https://make.wordpress.org/core/2015/06/09/eliminating-shared-taxonomy-terms-in-wordpress-4-3/\">now be split</a> into separate terms on update to 4.3. Please let us know if you hit any snags (<a href=\"https://core.trac.wordpress.org/ticket/30261\">#30261</a>).</li>
<li>Added <code>singular.php</code> to the template hierarchy as a fallback for <code>single.php</code> and <code>page.php</code>. (<a href=\"https://core.trac.wordpress.org/ticket/22314\">#22314</a>).</li>
<li>The old Distraction Free Writing code was removed (<a href=\"https://core.trac.wordpress.org/ticket/30949\">#30949</a>).</li>
<li>List tables now can (and often should) have a primary column defined. We’re working on a fallback for existing custom list tables but right now they likely have some breakage in the aforementioned responsive view (<a href=\"https://core.trac.wordpress.org/ticket/25408\">#25408</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.3, <a href=\"https://make.wordpress.org/core/tag/4-3/\">check out all 4.3-tagged posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Site icons for all</em><br />
<em>Live preview menu changes</em><br />
<em>Four three beta now</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 May 2015 02:24:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3718\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:355:\"WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3213:\"<p>WordPress 4.2.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>Version 4.2.2 addresses two security issues:</p>
<ul>
<li>The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site scripting attack. All affected themes and plugins hosted on <a href=\"https://wordpress.org/\">WordPress.org</a> (including the Twenty Fifteen default theme) have been updated today by the WordPress security team to address this issue by removing this nonessential file. To help protect other Genericons usage, WordPress 4.2.2 proactively scans the wp-content directory for this HTML file and removes it. Reported by Robert Abela of <a href=\"http://netsparker.com\">Netsparker</a>.</li>
<li>WordPress versions 4.2 and earlier are affected by a <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\">critical cross-site scripting vulnerability</a>, which could enable anonymous users to compromise a site. WordPress 4.2.2 includes a comprehensive fix for this issue. Reported separately by Rice Adu and Tong Shi from Baidu[X-team].</li>
</ul>
<p>The release also includes hardening for a potential cross-site scripting vulnerability when using the visual editor. This issue was reported by Mahadev Subedi.</p>
<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.2 also contains fixes for 13 bugs from 4.2. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32418&amp;stop_rev=32324\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.2</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.2.</p>
<p>Thanks to everyone who contributed to 4.2.2:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, and <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 4.2.1 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Apr 2015 18:34:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:366:\"WordPress 4.2.1 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by Jouko Pynnönen. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1010:\"<p>WordPress 4.2.1 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by <a href=\"http://klikki.fi/\">Jouko Pynnönen</a>.</p>
<p>WordPress 4.2.1 has begun to roll out as an automatic background update, for sites that <a href=\"https://wordpress.org/plugins/background-update-tester/\">support</a> those.</p>
<p>For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.1\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 08 Aug 2015 01:16:40 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:10:\"x-pingback\";s:37:\"https://wordpress.org/news/xmlrpc.php\";s:13:\"last-modified\";s:29:\"Tue, 04 Aug 2015 12:10:40 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("315","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1439039800","no");
INSERT INTO `arc1542_options` VALUES("316","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1438996600","no");
INSERT INTO `arc1542_options` VALUES("317","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1439039801","no");
INSERT INTO `arc1542_options` VALUES("318","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: SkiPress a Week Long Excursion in the French Alps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47654\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"http://wptavern.com/skipress-a-week-long-excursion-in-the-french-alps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1333:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/SkiPressFeaturedImage.png\"><img class=\"aligncenter size-full wp-image-47658\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/08/SkiPressFeaturedImage.png?resize=852%2C269\" alt=\"SkiPress Featured Image\" /></a>If you enjoy skiing and WordPress, mark your calendars for <a href=\"http://skipressweek.com/\">SkiPress</a>, November 21-28, 2015. SkiPress is a week long excursion to Serre Chevalier, a ski resort in the French Alps. The cottage can hold up to 15 people where attendees can ski, discuss WordPress, develop code, or disconnect from technology.</p>
<p><a href=\"http://skipressweek.com/\">Bernard-Jacquet</a> who writes for <a href=\"http://wp-spread.com\" target=\"_blank\">WP-spread</a>, and helps organize the local WordPress meetup in Grenoble, France, is organizing the event.</p>
<p>Rooms at the cottage cost 350 euros. This amount covers the room for a week plus dinner at two restaurants. Prepare to bring some extra cash as the bus, skipass, and ski rental are additional costs.</p>
<p>There&#8217;s not an official deadline to book a room but the sooner you book the better. If you&#8217;re interested in booking a room, please <a href=\"http://skipressweek.com/\">contact Berard-Jacquet</a> as soon as possible so he can make arrangements.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Aug 2015 20:29:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Richard Best Publishes Human Readable Version of the GPLv2 License\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47645\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/richard-best-publishes-human-readable-version-of-the-gplv2-license\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2234:\"<p>WordPress is licensed under the <a href=\"https://wordpress.org/about/gpl/\">GPLv2</a> and the four freedoms it allows is considered to be its <a href=\"http://ma.tt/2014/01/four-freedoms/\">Bill of Rights</a>. The four freedoms are:</p>
<ol start=\"0\">
<li>The freedom to run the program, for any purpose.</li>
<li>The freedom to study how the program works, and change it so it does your computing as you wish.</li>
<li>The freedom to redistribute copies so you can help your neighbor.</li>
<li>The freedom to distribute copies of your modified versions, giving the community a chance to benefit from your changes.</li>
</ol>
<p>There is a lot more to the GPL than the four freedoms listed above however, the license details can be difficult to read and decipher. Richard Best, a qualified lawyer in New Zealand, England, and Wales, has published a <a href=\"http://wpandlegalstuff.com/a-human-readable-summary-of-the-gpl/\">human readable summary</a> of the GPL license.</p>
<p>Inspired by how Creative Commons offers a <a href=\"http://creativecommons.org/licenses/by/3.0/\">human readable version</a> of its licenses, the summary explains the core concepts of the GPL and outlines the position in relation to copying, distribution, fees, modifications/derivative works, distributing non-source forms, termination, and downstream licensing.</p>
<p>It&#8217;s important to note that the document is not endorsed by the Free Software Foundation nor a substitute for the full license text.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/GPLSummarySample2.png\"><img class=\"size-full wp-image-47647\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/08/GPLSummarySample2.png?resize=705%2C554\" alt=\"Sample of the human readable summary of the GPL\" /></a>Sample of the human readable summary of the GPL
<p>I encourage everyone participating in the WordPress ecosystem to read the <a href=\"https://wordpress.org/about/gpl/\">full license</a> text at least once. However, the summary does a good job explaining the core components of the GPL without having to dig into the license.</p>
<p>If you have questions concerning the GPL, I suggest seeking legal council with a lawyer familiar with software licensing.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Aug 2015 18:31:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: WPWeekly Episode 202 – Prestige is Serious Business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=47628&preview_id=47628\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"http://wptavern.com/wpweekly-episode-202-prestige-is-serious-business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2339:\"<p>On this week&#8217;s episode, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I talk about the news of the week, including the release of WordPress 4.2.4 which patches six security vulnerabilities.</p>
<p>I shared my experience attending Prestige last weekend while Marcus describes what it was like to watch the livestream. Marcus and I closed out the show with a candid conversation on the difficulty of achieving balance between work and life.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/wordpress-4-2-4-patches-six-security-vulnerabilities\">WordPress 4.2.4 Patches Six Security Vulnerabilities</a><br />
<a href=\"http://wptavern.com/recap-of-prestige-a-conference-geared-towards-growing-businesses\"> Recap of Prestige a Conference Geared Towards Growing Businesses</a><br />
<a href=\"http://nickhaskins.com/2015/07/on-life-and-family/\"> Aesop Interactive LLC For Sale</a><br />
<a href=\"http://wptavern.com/the-mantra-of-family-comes-first\"> The Mantra of Family Comes First</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/export-plugins-and-templates/\">Export Plugins and Templates</a> exports your plugins and templates to a Zip file directly from the WordPress dashboard.</p>
<p><a href=\"https://wordpress.org/plugins/expire-posts/\">Expire posts</a> automatically expires posts in WordPress and supports custom post types.</p>
<p><a href=\"https://wordpress.org/plugins/local-seo-and-business-listings/\">Local SEO and Business Listings</a> allows you to optimize your local business website through a step by step actionable Local SEO Guide and a host of tools proven to increase web rankings.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, August 12th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #202:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 07 Aug 2015 16:20:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: The WordPress Core Team Receives Praise for Their Efforts to Maintain Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47619\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"http://wptavern.com/the-wordpress-core-team-receives-praise-for-their-efforts-to-maintain-security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1832:\"<p>Netanel Rubin, a vulnerability researcher for <a href=\"http://www.checkpoint.com/\">Check Point Software</a> and <a href=\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\">credited</a> for properly disclosing a security vulnerability to WordPress, published the <a href=\"http://blog.checkpoint.com/2015/08/04/wordpress-vulnerabilities-1/\">first in a trilogy of posts</a> that explains how he discovered it.</p>
<p>The vulnerability was discovered during a full audit of WordPress&#8217; code base in which Rubin praised the efforts of the WordPress development team.</p>
<blockquote><p>In contrast to these frequent findings in 3rd party plug-ins’ code, barebones WordPress issues are rare, as WordPress core developers are well-trained to hold high security awareness for all released code.</p>
<p>We can confirm that during our audit of the source code, we witnessed the developers ‘leaving nothing to chance’, and implementing multiple layers of security protecting most attack vectors we could think of.</p>
<p>WordPress developers deserve praise for their efforts to maintain such complex software in this level of security, specifically considering the presence of the notoriously trigger-happy foot-gun called PHP.</p></blockquote>
<p>I recommend <a href=\"http://blog.checkpoint.com/2015/08/04/wordpress-vulnerabilities-1/\">reading the post</a> as it&#8217;s a brief look into the mind of a <a href=\"https://en.wikipedia.org/wiki/White_hat\">white hat</a> security researcher.</p>
<p>Although WordPress has <a href=\"http://wptavern.com/wordpress-4-2-4-patches-six-security-vulnerabilities\">seen its fair share</a> of security related releases this year, it&#8217;s reassuring to hear a third-party whose job it is to penetrate software security praise WordPress&#8217; codebase.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 06 Aug 2015 00:05:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"WPTavern: The Mantra of Family Comes First\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47609\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"http://wptavern.com/the-mantra-of-family-comes-first\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2219:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/FamilyFirstFeaturedImage.png\"><img class=\"size-full wp-image-47611\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/FamilyFirstFeaturedImage.png?resize=669%2C247\" alt=\"Family First Featured Image\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/63122283@N06/11867028263\">Mama&#8217;s </a>&#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>At <a href=\"http://wptavern.com/recap-of-prestige-a-conference-geared-towards-growing-businesses\">Prestige over the weekend</a>, I heard a presenter say that family comes first. This isn&#8217;t the first time I&#8217;ve heard this advice but it&#8217;s becoming more prevalent. I generally hear this advice from those who are living comfortably, have two kids or more, and/or have gone through the startup process more than once.</p>
<p>I&#8217;m a distributed worker who receives a check every two weeks. I&#8217;m married, have no kids, and write about WordPress for a living. Putting family first should be easy but it&#8217;s not. The last two years as a distributed worker, I&#8217;ve put work before family unless it&#8217;s an emergency.</p>
<p>Two weeks ago, my wife and I had a serious conversation about the way I work and how it has negatively impacted our marriage. I&#8217;m a late owl and on most nights, my wife sleeps alone. As a distributed worker, I get to make the rules and put myself in the best environment to get the job done.</p>
<p>The conversation with my wife involved words not fit for reproduction but everything she said was right. I&#8217;m spending too much time on digital devices and not enough with her. Our conversation was the wake up call I didn&#8217;t know I needed.</p>
<p>It&#8217;s not easy putting family first all the time. Some argue that you need to put yourself before family so that you can provide for them. Others find a critical balance between spending time with family and getting the job done.</p>
<p>How do you put family first when there are bills that need to be paid, sites to be built, and a constant deluge of work to be done? Please share your thoughts, experiences, and advice in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Aug 2015 01:43:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: WordPress 4.2.4 Patches Six Security Vulnerabilities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47605\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://wptavern.com/wordpress-4-2-4-patches-six-security-vulnerabilities\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2004:\"<p>WordPress <a href=\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\">4.2.4 is available</a> and patches six security vulnerabilities. The vulnerabilities were discovered by outside parties and members of the WordPress core security team. This release also fixes four bugs:</p>
<ul>
<ul>
<li>WPDB: When checking the encoding of strings against the database, make sure we&#8217;re only relying on the return value of strings that were sent to the database. <a class=\"external text\" href=\"https://core.trac.wordpress.org/ticket/32279\">#32279</a></li>
<li>Don&#8217;t blindly trust the output of <tt>glob()</tt> to be an array. <a class=\"external text\" href=\"https://core.trac.wordpress.org/ticket/33093\">#33093</a></li>
<li>Shortcodes: Handle <tt>do_shortcode(\'&lt;[shortcode]\')</tt> edge cases. <a class=\"external text\" href=\"https://core.trac.wordpress.org/ticket/33116\">#33116</a></li>
<li>Shortcodes: Protect newlines inside of <tt>CDATA</tt>. <a class=\"external text\" href=\"https://core.trac.wordpress.org/ticket/33106\">#33106</a></li>
</ul>
</ul>
<p>It&#8217;s been a busy year for the WordPress security team. Since the beginning of the year, there has been five security releases.</p>
<ul>
<ul>
<li><a href=\"https://wordpress.org/news/2015/04/wordpress-4-1-2/\">WordPress 4.1.2</a></li>
<li><a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\">WordPress 4.2.1</a></li>
<li><a href=\"https://wordpress.org/news/2015/05/wordpress-4-2-2/\">WordPress 4.2.2</a></li>
<li><a href=\"https://wordpress.org/news/2015/07/wordpress-4-2-3/\">WordPress 4.2.3</a></li>
<li><a href=\"https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\">WordPress 4.2.4</a></li>
</ul>
</ul>
<p>Users should check their sites to make sure they&#8217;re running 4.2.4. If your site hasn&#8217;t automatically updated yet, you should perform a full backup and manually update. Sites running WordPress RC 2 are safe since it fixes the same issues as 4.2.4.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2015 23:45:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Recap of Prestige a Conference Geared Towards Growing Businesses\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47580\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/recap-of-prestige-a-conference-geared-towards-growing-businesses\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4245:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/PrestigeconfFeaturedImage.png\"><img class=\"size-full wp-image-47595\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/08/PrestigeconfFeaturedImage.png?resize=677%2C268\" alt=\"Tony Perez of Sucuri\" /></a>Tony Perez of Sucuri Presenting on Security at Prestige
<p>Over the weekend, I attended <a href=\"http://prestigeconf.com/\">Prestige</a>, a conference geared towards freelancers, entrepreneurs, and small agencies looking to grow their businesses. Unlike WordCamps, plugins, themes, and WordPress in general were rarely mentioned. Instead, sessions included high level topics such as, how to land enterprise clients, knowing when to move on to the next big thing, and the benefits of partnerships.</p>
<p>The venue was perfect with plenty of space and the WiFi worked well. Lunch was an hour-long and provided on both days. The lunchroom can easily seat 300 people or more. Only a third of the space was used when attendees ate lunch providing a great environment to network with people.</p>
<h2>Nancy Lyons and Technology&#8217;s Dirty Little Secret</h2>
<p>Since I don&#8217;t deal with clients or own an agency, many of the sessions at Prestige are non-applicable to my day job. However, there is one session in particular that resonated with me. <a href=\"http://www.nancylyons.com/\">Nancy Lyons</a>, founder and CEO of <a href=\"http://www.clockwork.net/\">Clockwork</a>, shared her philosophies on hiring and getting employees engaged. Happy employees do good work but what makes them happy?</p>
<ul>
<li>Autonomy:  Control over time, technique, team, or task.</li>
<li>Mastery: Make progress and get better.</li>
<li>Purpose: Be part of something bigger.</li>
</ul>
<p>A lot of the tips shared by Lyons are geared towards employers but they&#8217;re just as applicable to employees. The biggest danger to agencies and freelancers is the inability to have conversations with clients about what is and isn&#8217;t possible. According to Lyons, you can love someone and still tell them what they need to hear. One of the best tips she shared is to find and have fun at work as there&#8217;s nothing wrong with having fun.</p>
<h2>Behind the Scenes of the Livestream</h2>
<p>Prestige is <a href=\"http://prestigeconf.com/free-livestream-minneapolis-2015/\">known for having</a> a high quality livestream where more than 1,000 people can watch the conference live. The livestream is produced by <a href=\"http://pixpromedia.com/\">PixProMedia</a>. The gentleman in charge uses a TriCaster to switch between speakers and slides during sessions. Here are a couple of photographs of his equipment.</p>
<a href=\"http://wptavern.com/recap-of-prestige-a-conference-geared-towards-growing-businesses#gallery-47580-1-slideshow\">Click to view slideshow.</a>
<p>According to some viewers, watching the livestream was like being at the conference but is not a substitute for face-to-face interactions.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">.<a href=\"https://twitter.com/jeffr0\">@jeffr0</a> The learning is like being there.  I miss the handshakes in the hallway, meeting people face-to-face.&#10;&#10;<a href=\"https://twitter.com/hashtag/prestigeconf?src=hash\">#prestigeconf</a></p>
<p>&mdash; Cate DeRosia (@mysweetcate) <a href=\"https://twitter.com/mysweetcate/status/627924263799009280\">August 2, 2015</a></p></blockquote>
<p></p>
<h2>Westwerk Is a Great Venue for After Parties</h2>
<p>The after party was held at <a href=\"http://westwerk.com/\">Westwerk</a>, a WordPress development agency and primary sponsor of the event. Their office was perfect for an after party as it includes, a foosball table, Nintendo Wii, shuffleboard, drinks, pool table, and small offices for private conversations. It&#8217;s one of the best after parties for a conference that I&#8217;ve attended.</p>
<h2>Prestige is Serious Business</h2>
<p>It may seem like a WordPress conference on the surface but Prestige is geared towards business minded people. It&#8217;s highly focused and filled with information you can apply to companies in and outside of WordPress. If you want to learn how to take your business to the next level, Prestige is an excellent value.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 04 Aug 2015 20:40:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"WPTavern: How to Avoid This Embarrassing Sharing Bug on WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47476\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/how-to-avoid-embarrassing-sharing-bug-on-wordpress-com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1804:\"<p>If you use the sharing feature on WordPress.com, you may have noticed an anomaly between your post title and what&#8217;s shared to social services. Since the post title is the first field to complete when writing a post, it makes sense to fill it in even if it&#8217;s a work in progress.</p>
<p>The sharing module on WordPress.com has a bug where the initial text in a post title is used when sharing the post to social networks. For the past several months, I&#8217;ve published many articles on WordPress.com where the text within social links does not match the text used in the post title leaving me feeling embarrassed.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/BuginAction.png\"><img class=\"size-full wp-image-47477\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/BuginAction.png?resize=728%2C482\" alt=\"WordPress.com Bug in Action\" /></a>WordPress.com Bug in Action
<p>To avoid this embarrassment, you&#8217;ll need to alter the text used in the sharing module before publishing each post. If you&#8217;re using the New Dash interface on WordPress.com, locate the Sharing metabox as seen in the screenshot above. When you&#8217;re ready to hit the publish button, change the text to match your title.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/TheCorrectPostTitle.png\"><img class=\"size-full wp-image-47478\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/TheCorrectPostTitle.png?resize=571%2C462\" alt=\"Post Title Matches the Sharing Text\" /></a>Post Title Matches the Sharing Text
<p>I&#8217;ve spoken to several Automattic employees at various WordPress events and they&#8217;re aware of the bug. Until it&#8217;s fixed, you&#8217;ll need to remember to change the sharing text before you publish a post.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 31 Jul 2015 21:52:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: WPWeekly Episode 201 – Interview With Paul Gibbs and John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=47469&preview_id=47469\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://wptavern.com/wpweekly-episode-201-interview-with-paul-gibbs-and-john-james-jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2500:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I are joined by <a href=\"http://byotos.com/\">Paul Gibbs</a> and <a href=\"http://jjj.me/\">John James Jacoby</a>. Jacoby shares what he learned and accomplished <a href=\"http://wptavern.com/buddypress-bbpress-and-glotpress-development-campaign-is-now-fully-funded\">working on bbPress and BuddyPress</a> full-time for six months.</p>
<p>Gibbs explains his motivation to organize the first ever <a href=\"https://brighton.buddycamp.org/2015/\">BuddyCamp Brighton, UK</a>, that takes place on August 8th. We also discuss a new working group dedicated to possibly bringing back <a href=\"http://backpress.org/\">BackPress</a>. Last but not least, Gibbs and Jacoby offer their opinions on <a href=\"http://wptavern.com/meet-peepso-buddypress-newest-competitor-in-open-source-social-networking-for-wordpress\">PeepSo</a>, a new social networking plugin for WordPress.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/philadelphia-pa-to-host-wordcamp-us-december-4th-6th\">Philadelphia, PA to Host WordCamp US December 4th–6th</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/gallery-for-instagram/\">Instagram Gallery</a> displays a gallery from one or more Instagram accounts.</p>
<p><a href=\"https://wordpress.org/plugins/backup-amazon-s3/\">Amazon S3 Backup and Restore</a> enables you to create full backups to Amazon S3 and restore, duplicate, clone, or migrate your site.</p>
<p><a href=\"https://wordpress.org/plugins/responsivevoice-text-to-speech/\">ResponsiveVoice Text To Speech</a> is a HTML5 based text-to-speech library designed to add voice features to WordPress across all smart phone, tablet, and desktop devices. It supports 51 languages through 168 voices and has no dependencies.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, August 5th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #201:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 31 Jul 2015 19:45:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Hong Kong Morning\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45280\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/07/hong-kong-morning/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:381:\"<p><span class=\"embed-youtube\"></span></p>
<p>The upside of jet lag, like <a href=\"http://om.co/2015/07/10/paris-je-laime/\">Om discovering the streets of Paris</a>, are enjoying parts of the day you might not normally be awake for, like a beautiful sun rise. Here&#8217;s a time lapse I made of the Victoria Harbor in Hong Kong taken from the incredible view I have in my room.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Jul 2015 23:40:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Postmatic Brings 100% Realtime Commenting to WordPress with Epoch Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44317\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/postmatic-brings-100-realtime-commenting-to-wordpress-with-epoch-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7876:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch.jpg?resize=919%2C443\" alt=\"epoch\" class=\"aligncenter size-full wp-image-47416\" /></a></p>
<p>The team behind <a href=\"https://gopostmatic.com/\" target=\"_blank\">Postmatic</a> is aiming to breathe new life into WordPress native comments with the 1.0 release of <a href=\"https://wordpress.org/plugins/epoch/\" target=\"_blank\">Epoch</a> today. The plugin was created to provide a Disqus alternative with faster loading and submitting for comments.</p>
<p>Epoch&#8217;s creators set an ambitious goal for themselves on the plugin&#8217;s description page:</p>
<blockquote><p>The goal: To provide a realtime commenting/chat experience using fully native comments while being compatible with page caching, CDNs, mobile, other comment plugins, and SEO best practices.</p></blockquote>
<p>The plugin submits comments via AJAX, which means that comments appear instantly within the conversation without refreshing the page. The experience is designed to be so fast that it blurs the line between commenting and chatting, as comments from other readers also show up automatically with the same speed. The video below shows the plugin in action and a <a href=\"https://gopostmatic.com/epoch/#reply-title\" target=\"_blank\">live demo of Epoch</a> is available on the Postmatic website.</p>
<p></p>
<p></p>
<p>Epoch <a href=\"https://wordpress.org/plugins/epoch/changelog/\" target=\"_blank\">version 1.0</a> boasts compatibility with virtually any WordPress theme. The plugin will attempt to integrate with your theme via one of three ways:</p>
<ul>
<li>The first tries to continue using your existing comment template while still offering all the performance gains</li>
<li>The second overrides your comment template but inherits typography and colors from your theme</li>
<li>The third totally replaces your comment template à la Disqus or Jetpack Comments</li>
</ul>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch-theme-integration.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch-theme-integration.png?resize=1025%2C839\" alt=\"epoch-theme-integration\" class=\"aligncenter size-full wp-image-47442\" /></a></p>
<p>Unlike Postmatic, which has a <a href=\"https://gopostmatic.com/premium/\" target=\"_blank\">commercial option</a> for additional features, founder Jason Lemieux says Epoch will not be directly monetized.</p>
<p>&#8220;We do not have any plans to create a commercial version,&#8221; he said. &#8220;Postmatic is our primary product, Epoch exists only to make it easier for people to move back to native commenting, and in turn to use Postmatic. Epoch will be free forever.&#8221;</p>
<h3>Compatibility with Other Comment Plugins</h3>
<p>Epoch works seamlessly with Postmatic, i.e. it will pop up an opt-in modal allowing the commenter to subscribe to new post notifications. Using Postmatic in combination with Epoch is not required, because the plugin was created to work well on its own. It&#8217;s also compatible with many other plugins that extend comments.</p>
<p>&#8220;Other third party native commenting plugins have taken a heavy-handed approach and do not support the comment template hooks built into WordPress,&#8221; Lemieux said. &#8220;This creates a walled garden in which the innovation and hard work present in existing and future comment plugins is left out.</p>
<p>&#8220;We decided to take a different approach. We built Epoch to be compatible with other comment plugins as much as possible. Not all are, but with little tweaks here and there they work just fine.&#8221;</p>
<p>Version 1.0 integrates perfectly out of the box with Postmatic, WordPress Zero Spam, Akismet, WP Markdown, and WordPress Social Login.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch-plugin-compatibility.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/epoch-plugin-compatibility.png?resize=1025%2C583\" alt=\"epoch-plugin-compatibility\" class=\"aligncenter size-full wp-image-47447\" /></a></p>
<p>&#8220;In our testing most anything that does not use a lot of JavaScript works just fine,&#8221; Lemieux said. &#8220;Things I haven&#8217;t tested but I assume would work would be anything that modifies or adds fields to the comment form (Subscribe to Comments, CommentLuv, various captchas).</p>
<p>&#8220;Fancier plugins that allow for comment editing or sorting the comment order based on voting would probably not be happy. We will have to make that functionality ourselves.&#8221;</p>
<h3>Epoch is a Disqus Alternative with an Emphasis on Privacy</h3>
<p>When Lemieux and his team created Epoch, the strategy was to address problems with native commenting in order to pave the way for more users to get on board with Postmatic.</p>
<p>&#8220;We didn&#8217;t set out with intentions of competing with Disqus,&#8221; he said. &#8220;However, a few months in it became clear that there are usually two reasons people were not using native comments, and we would need to address both if we wanted widespread adoption of Postmatic.</p>
<p>&#8220;The first is that the comment templates that come with a huge majority of themes just plain stink. Theme developers hate dealing with them. It&#8217;s usually an afterthought. So the commenting experience suffers. It is slow, ugly, and not at all fun.</p>
<p>&#8220;The second reason is that native commenting is extremely hard on the server. You can&#8217;t run native comments on a high traffic site. The server would buckle. A CDN won&#8217;t save you because the page content is constantly changing. For larger sites, native commenting is not even an option.</p>
<p>&#8220;Both of these problems are solved easily with solutions like Livefyre or Disqus, so they get installed. But it&#8217;s just selling your users down the river. Your data is not yours, ads start showing up on your site. Privacy is out the window. And really, the performance gains are minimal when the embedded comments still take 10 second to load because there is so much tracking JavaScript being queued up in the background.&#8221;</p>
<p>In contrast, Epoch loads faster than third party solutions and is completely private. Your commenters&#8217; data is not farmed out and comments stay on your server.</p>
<p>&#8220;For the first time someone can say this: running native WordPress commenting will actually increase your site performance,&#8221; Lemieux said.</p>
<h3>What&#8217;s on the roadmap for the future of Epoch?</h3>
<p>Lemieux and his team hope to attract a larger community around the project, which is <a href=\"https://github.com/postmatic/epoch\" target=\"_blank\">open to contribution on GitHub</a>.</p>
<p>&#8220;We plan on aggressively recruiting others to join the project and we hope other developers will be inspired by what we have started,&#8221; he said.</p>
<p>&#8220;We are going to build out a small API to make it easier for other plugins to hook into some of the advanced functionality.</p>
<p>&#8220;And there are a few things that feel like they may be necessary: comment voting and a simple little like button which would be handy as a way to say, &#8216;I appreciate what you said, I do not have anything else to add.&#8217; I would love to integrate that with Postmatic. I often will get a comment in my inbox and I want to recognize the thought that went into it, but don&#8217;t feel like I have anything to add. A simple little +1 would do it nicely,&#8221; Lemieux said.</p>
<p>The 1.0 release of Epoch is exciting news for those who have been dissatisfied with WordPress native comments but are hoping for a reason to return. The plugin is open source and <a href=\"https://wordpress.org/plugins/epoch/\" target=\"_blank\">available for free on WordPress.org</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Jul 2015 17:45:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WPTavern: Yuuta: A Free Visual Diary Theme for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47303\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"http://wptavern.com/yuuta-a-free-visual-diary-theme-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4045:\"<p>Earlier this month, <a href=\"http://wptavern.com/new-proposal-on-trac-to-remove-post-formats-from-wordpress-core\" target=\"_blank\">a new proposal landed on trac</a>, advocating the removal of <a href=\"http://codex.wordpress.org/Post_Formats\" target=\"_blank\">post formats</a> from core. Many believe that this feature would be better as a plugin, since it has received little improvement over the years and is not used by the majority of WordPress users.</p>
<p>If the UI can be improved to be less confusing and theme support is standardized, post formats may have a chance at more widespread adoption. The feature is entirely dependent on theme support, as post formats are not enabled by default unless the theme author opts to include them. Many still do, which is why ripping them out of core in favor of a plugin would be a major undertaking.</p>
<p>One of the most common use cases for post formats is a diary style WordPress theme. <a href=\"https://wordpress.org/themes/yuuta/\" target=\"_blank\">Yuuta</a> is a relatively popular theme on WordPress.org that revolves entirely around post formats. In the past four months, it has been downloaded more than 7,000 times. Yuuta was created to serve as a visual diary and includes support for all nine of WordPress&#8217; post formats.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta.png?resize=880%2C660\" alt=\"yuuta\" class=\"aligncenter size-full wp-image-47392\" /></a></p>
<p>The theme was designed by Felix Dorner, owner of <a href=\"http://drnr.co/\" target=\"_blank\">Studio DRNR</a>, a Berlin-based web development company. According to its description page, Yuuta was selected as the the theme&#8217;s name based on its Japanese meaning:</p>
<blockquote><p>Yuuta is a Japanese name and is made up of 優 (yuu) “gentleness, superiority”, 悠 (yuu) “distant, leisurely” or 勇 (yuu) “brave” combined with 太 (ta) “thick, big”.</p></blockquote>
<p>Each post format has its own distinguishing icon and unique display. Dorner opted to use Roboto, Roboto Slab, and a sprinkling of Courier as the theme&#8217;s primary fonts. The typography choices were selected for optimal readability on all screen sizes.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta-chat-format.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta-chat-format.jpg?resize=961%2C526\" alt=\"yuuta-chat-format\" class=\"aligncenter size-full wp-image-47405\" /></a></p>
<p>Yuuta also includes specific styles for both standard and Jetpack-enabled galleries.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta-jetpack-enabled-gallery.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/yuuta-jetpack-enabled-gallery.jpg?resize=652%2C572\" alt=\"yuuta-jetpack-enabled-gallery\" class=\"aligncenter size-full wp-image-47407\" /></a></p>
<p>The theme&#8217;s design is fairly set, unless you opt to create a child theme. There are zero options in the Customizer. Much of the design customization is done on a post-by-post basis, as the featured image serves as a unique background for the post. Yuuta also includes editor styles to match the editing experience to the theme&#8217;s frontend appearance.</p>
<p>The primary navigation menu is hidden until toggled into view by the icon in the header, which keeps the reader focused on the content. There are no sidebars to contend with but widgets can be added to the footer.</p>
<p>If you&#8217;re a fan of post formats, the Yuuta theme really makes them shine. It responds to display beautifully on all devices from desktop to tablet to smartphone. Check out a <a href=\"http://demo.felixdorner.com/yuuta/\" target=\"_blank\">live demo</a> on Dorner&#8217;s website to see each post format in action. You can download <a href=\"https://wordpress.org/themes/yuuta/\" target=\"_blank\">Yuuta</a> for free from WordPress.org or install it via your admin themes browser.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 30 Jul 2015 04:06:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Awesome Geek Podcasts: A Curated List of Tech Podcasts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46562\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/awesome-geek-podcasts-a-curated-list-of-tech-podcasts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2834:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/headphones.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/headphones.jpg?resize=960%2C482\" alt=\"photo credit: Jan Vašek\" class=\"size-full wp-image-47389\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/3YOVALG5DX\">Jan Vašek</a>
<p>The WordPress community produces a couple dozen high quality podcasts covering diverse topics, such as weekly news, business/entrepreneurship, education, and development. Every year the best WordPress-related podcasts are featured in <a href=\"http://iamdavidgray.com/best-wordpress-podcasts/\" target=\"_blank\">roundup posts</a> highlighting shows that are publishing new episodes regularly.</p>
<p>One way to venture outside the WordPress world is to expand your horizons when it comes to podcast subscriptions. <a href=\"https://github.com/cv/awesome-geek-podcasts\" target=\"_blank\">Awesome Geek Podcasts</a> is a curated list of tech podcasts that was first published in May of this year on GitHub. Since that time the repository has received 121 commits from 34 contributors.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/awesome-geek-podcasts.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/awesome-geek-podcasts.png?resize=1025%2C551\" alt=\"awesome-geek-podcasts\" class=\"aligncenter size-full wp-image-47382\" /></a></p>
<p>None of the podcasts listed in the repo are directly related to WordPress, but many cover topics related to the various technologies that work in and with WordPress. The list includes approximately seven PHP-related podcasts in English (and more in other languages), along with shows focused on JavaScript, Sass, Git, and other technologies.</p>
<p>Other topics included in the Awesome Geek Podcasts list that might be of interest to WordPress developers include:</p>
<ul>
<li>Running software companies</li>
<li>Software design, creation, and delivery</li>
<li>Front end web design, development, and UX</li>
<li>Typography, design, prototyping</li>
<li>Open source software</li>
<li>Family and life/work balance</li>
</ul>
<p>Several of those listed follow a short format of 5 and 10-minute episodes for developers who are short on time. No matter where your interests lie in the various aspects of &#8220;geek life,&#8221; the Awesome Geek Podcast list has something for everyone.</p>
<p>Currently the list has separate sections for shows in English, Portuguese, Spanish, Russian, Persian, and Swedish, but it is open to contribution. Although it doesn&#8217;t seem to include many podcasts that focus on specific CMS platforms, you can try <a href=\"https://github.com/cv/awesome-geek-podcasts/blob/master/CONTRIBUTING.md\" target=\"_blank\">submitting a pull request</a> for the inclusion of your WordPress-related podcast.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 20:58:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: Behind the Scenes of WordPress 4.2.3 With Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47354\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/behind-the-scenes-of-wordpress-4-2-3-with-gary-pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2253:\"<p>When <a href=\"http://wptavern.com/wordpress-4-2-3-is-a-critical-security-release-fixes-an-xss-vulnerability\">WordPress 4.2.3 was released</a> last week, not only did it patch a critical security vulnerability, but also <a href=\"http://wptavern.com/plugin-developers-demand-a-better-security-release-process-after-wordpress-4-2-3-breaks-thousands-of-websites\">adversely impacted</a> a number of sites. Changes to the Shortcode API which were necessary as part of the patch caused some plugins that rely on the API to break. These changes were not immediately communicated to plugin developers. Nearly eight hours after its release, a <a href=\"https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/\">post published</a> on the Make WordPress Core blog explained the changes.</p>
<p>The release process of WordPress 4.2.3 left <a href=\"http://wptavern.com/plugin-developers-demand-a-better-security-release-process-after-wordpress-4-2-3-breaks-thousands-of-websites#comments\">plugin authors and users</a> scratching their heads. On one hand, point releases are not supposed to break anything. On the other, affected plugin authors were left in the dark for nearly eight hours wondering why a point release broke their plugins.</p>
<p><a href=\"http://pento.net/\">Gary Pendergast</a> who works for Automattic, is a WordPress core contributor, and a member of the WordPress core security team, reached out to me for an interview. In the following conversation, we discuss what happened behind the scenes before 4.2.3 was released.</p>
<p>He clears up some confusion on when the changes to the Shortcode API were implemented. He also admits the team made some mistakes and has already implemented changes to improve the release process. One of those changes includes publishing a post on the Make WordPress Core blog as soon as the update is pushed out to sites.</p>
<p>I appreciate and thank Pendergast for reaching out to me to have this conversation. I look forward to similar collaborations with members of the core team in the future. A transcription of this interview is not available but if you have it transcribed and would like to make it available to the public, please <a href=\"http://wptavern.com/contact-me\">contact me</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 19:02:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: WordPress Theme Review Team Votes to Allow Themes to Use the REST API Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47342\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"http://wptavern.com/wordpress-theme-review-team-votes-to-allow-themes-to-use-the-rest-api-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3363:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/colored-pencils.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/colored-pencils.jpg?resize=960%2C470\" alt=\"colored-pencils\" class=\"aligncenter size-full wp-image-42610\" /></a></p>
<p>During this week&#8217;s WordPress Theme Review Team meeting, members considered the possibility of allowing themes hosted in the directory to make use of the <a href=\"https://wordpress.org/plugins/rest-api/\" target=\"_blank\">WP REST API plugin</a>. Since the API is not yet included in core, any theme or plugin author who wants to use it must have the feature plugin installed.</p>
<p>Ordinarily, WordPress.org themes are not allowed to require a plugin on installation (although they can suggest one). As per the <a href=\"https://make.wordpress.org/themes/handbook/review/required/#plugins\" target=\"_blank\">Theme Review Handbook on plugins</a>: <em>A theme can recommend plugins but not include those plugins in the theme code.</em></p>
<p>&#8220;The core team has asked us to consider temporarily allowing the requirement of the REST API for themes that may take advantage of it,&#8221; Tammie Lister said before calling for a vote. She also noted that waiving the rule would be temporary, as the API will soon be going into core.</p>
<p>&#8220;This does not open up the way for others as an exception because it&#8217;s a core feature,&#8221; she said.</p>
<p>The team took a quick vote and all present unanimously agreed to allow themes to require the REST API plugin as a temporary measure until it is available in core. Check out the <a href=\"https://make.wordpress.org/themes/2015/07/28/theme-review-team-weekly-meeting-notes-the-logs-7/\" target=\"_blank\">meeting logs</a> for the full discussion.</p>
<p>The WP REST API is already being used in production in many different ways around the web, as revealed in the comments on project leader Ryan McCue&#8217;s recent <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/\" target=\"_blank\">post</a> calling for examples. If the Theme Review Team wants to keep pace with where WordPress is headed, it must offer the flexibility to allow for more innovative themes. Temporarily waiving the guideline against plugin requirements is a smart move.</p>
<p>As WordPress.org accrues more examples of themes that use the REST API in a way that complies with the review team&#8217;s high standards, developers who are just getting started will have strong examples for creating their own. Jack Lenox&#8217;s presentation at WordCamp London this year highlighted a few of the benefits of theming with the REST API:</p>
<ul>
<li>Provides a way to retrieve pure data (usually in JSON or XML format) over HTTP</li>
<li>No loops necessary</li>
<li>Good for mobile apps and environments where you don’t want a full webpage to render but want content from a blog or site</li>
</ul>
<p>With the official directory now welcoming these types of themes, it won&#8217;t be long before the entire landscape of WordPress theme development changes to support more modern ways of presenting content. Check out Jack Lenox&#8217;s presentation on <a href=\"http://wptavern.com/jack-lenox-on-building-themes-with-the-wp-rest-api\" target=\"_blank\">Building themes with the WP REST API</a> for information on how to get started.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 17:30:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"Post Status: Don’t make enemies, invest in friendships\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=13860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://poststatus.com/invest-in-friendships/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4756:\"<p><em>Editor&#8217;s note: The following is a guest post by <a href=\"http://corymiller.com/about/\">Cory Miller</a>, the CEO of <a href=\"https://ithemes.com\">iThemes</a>. Cory describes his approach to making friends and avoiding making enemies. You should also check out his recent <a href=\"http://corymiller.com/my-talk-on-mental-health-and-entrepreneurship-is-now-online/\">talk on mental health and entrepreneurship</a>, which is terrific.</em></p>
<p>I’d rather wave a white flag and compromise than make an enemy. Every. Single. Day.</p>
<p>I’ve purposefully and intentionally, throughout my life (and business), sought to <em>not</em> make enemies, but rather build friendships.</p>
<ul>
<li>Enemies are only trouble.</li>
<li>Enemies are distractions.</li>
<li>Enemies eat my time and energy and focus.</li>
<li>Enemies seek your destruction.</li>
<li>Enemies oppose you.</li>
<li>Enemies seek to “harm or weaken” you.</li>
</ul>
<p>Friends do the opposite.</p>
<p>My best example of this is my wife, Lindsey. I think of her as my greatest ally and my best friend. She’s the opposite of an enemy.</p>
<p>The words I use to describe her are “caring,” “supportive,” “loving,” and “wants my best.”</p>
<p>So why would I spend my time seeking to <em>create</em> enemies, instead of friendships?</p>
<ul>
<li>You can have opinions.</li>
<li>You can take stands.</li>
<li>You can and should draw boundary lines.</li>
<li>You can have your principles and <em>never</em> budge on them.</li>
</ul>
<p><em>But,</em> you can also, simultaneously, choose to make and focus on friendships.</p>
<p>Some of my best friendships have come through business, and some of them would be considered “competitors.”</p>
<p>But I’ve cherished those friendships.</p>
<p>Additionally, I sleep better at night knowing we only want each other’s best and that there is plenty of room for each other instead of someone actively, purposefully seeking my destruction.</p>
<p>But instead of seeking to fester anger and hate and competition, I’ve sought the opposite, asking, &#8220;Where can we find ways to help each other do better for each other?&#8221;</p>
<p>So what if we approached life and business like this:</p>
<p>Instead of using that anger, bile, jerk-ness, and negative energy in telling the world who you hate and how big of a jerk you can be, and how you don’t want to be an enemy of &#8212; why not seek to build true, lasting, deep friendships?</p>
<p>The old quote, “Keep your friends close, and your enemies closer,” is pure B.S.</p>
<p>Why not create a friend instead of nurture an enemy?</p>
<p>Why not tell the world that you can be the <em>best</em> friend they ever made? And prove it by your actions.</p>
<p>Friendships do take an investment. They take consistency. They take time. They take compromise sometimes. It means showing up for them when they most need it.</p>
<p>But those relationships have been some of the richest relationships I’ve ever had. And totally worth the investment (multiple times over and over in fact).</p>
<p>And yes, I have made enemies in my life. Purposefully and sometimes not. In fact, someone recently asked me jokingly on Twitter who didn’t like me. I responded with:</p>
<p>“I can think of 1 or 2 a-holes but I don’t like thinking about them. <img src=\"https://poststatus.com/wp-includes/images/smilies/simple-smile.png\" alt=\":)\" class=\"wp-smiley\" /> hahahahaha”</p>
<p>And although that’s sadly true, I’ve sought to minimize the enemies I’ve made in my life and business.</p>
<p>My perspective on making necessary enemies is that <em>if</em> you <em>have</em> to make an enemy &#8212; and when I say that, I don’t mean because your personality defaults to that of a jerk and you sadistically like being labeled one), but you <em>have</em> to make an enemy because you have to set a boundary and tell someone no, or take a legal action &#8212; make dang sure it’s either for a <em>very</em> good purpose, value or strategic reason.</p>
<p>And even then, question yourself about why.</p>
<p>As my attorney told me recently: “You catch more flies with honey.”</p>
<p>So don’t be a jerk while making enemies. You’ll make <em>more</em> enemies in the process.</p>
<p>Simple, lip-biting kindness in the face of anger and hate and bile helps deflate a situation rather than pour lighter fluid on it.</p>
<p>I tell people often: it doesn’t cost me anything to be nice and kind. (In fact most of the time it makes me happier.) And I seek out different avenues to vent my frustration and relieve my stress.</p>
<p>So I say: Don’t make enemies. Invest in friendships.</p>
<p>It should be common sense, but sometimes I (and maybe you) need a reminder.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 05:13:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Cory Miller\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: Adler: A Unique Personal Blogging Theme for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47272\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://wptavern.com/adler-a-unique-personal-blogging-theme-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3395:\"<p>If you&#8217;re on the hunt for a new WordPress blogging theme but the designs are all starting to look too similar, you may want to check out <a href=\"https://wordpress.org/themes/adler/\" target=\"_blank\">Adler</a>. It is one of the more unique themes to land in the WordPress.org directory in recent months with its uncommon typography choices and bright bursts of color.</p>
<p>Adler was created by Romanian theme designer <a href=\"https://twitter.com/BabBarDeL\" target=\"_blank\">George Olaru</a> of <a href=\"https://pixelgrade.com/\" target=\"_blank\">Pixelgrade</a>. Olaru takes a unique approach to the popular fullscreen splash page style that many themes have adopted for a homepage layout, overlaying it with a serif font title paired with a hand-script style subtitle.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/adler.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/adler.png?resize=880%2C660\" alt=\"adler\" class=\"aligncenter size-full wp-image-47315\" /></a></p>
<p>Styling for single posts is similar to the home page with the featured image serving as a fullscreen background for the title. Scroll further down and the post content is centered with no distracting sidebar widgets.</p>
<p>Adler combines two unusual Google font choices in the design: Droid Sans Mono for paragraph text and Permanent Marker for blockquotes and subtitles. Images in posts overhang the text column to create a strong visual impact.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/adler-images-blockquotes.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/adler-images-blockquotes.jpg?resize=810%2C812\" alt=\"adler-images-blockquotes\" class=\"aligncenter size-full wp-image-47318\" /></a></p>
<p>Adler&#8217;s files include a tiny leaf icon that is tastefully applied on the home and archive templates to separate posts. The effect is minimalist without appearing to be stark. The theme also includes support for Font Awesome icons.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/font-awesome.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/font-awesome.jpg?resize=656%2C534\" alt=\"font-awesome\" class=\"aligncenter size-full wp-image-47320\" /></a></p>
<p>The necessity for large featured images can sometimes be a drawback for users when selecting a blogging theme. After testing Adler, I found that the design doesn&#8217;t break if you don&#8217;t have a large featured image assigned to a post. In fact, posts lacking a featured image look just as nice as those that include one, so you&#8217;re not tied down to hunting for one every time you publish.</p>
<p>Adler supports three menu locations for a primary, footer, and social menu. It includes support for one footer widget area, which spans three columns. There are just two options available in the native customizer that allow you to change the background color or add a background image.</p>
<p>Adler was created to be a personal blogging theme and the design instantly communicates: &#8220;I have something to say.&#8221; Check out the <a href=\"https://pixelgrade.com/demos/adler/\" target=\"_blank\">live demo</a> on Pixelgrade.com to see it in action. If you like what you see, you can <a href=\"https://wordpress.org/themes/adler/\" target=\"_blank\">download Adler</a> for free from WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2015 01:09:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: New WordPress Plugin Automates Slack Team Invitations\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47267\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/new-wordpress-plugin-automates-slack-team-invitations\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4403:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/11/slack-logo.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/11/slack-logo.jpg?resize=700%2C314\" alt=\"slack-logo\" class=\"aligncenter size-full wp-image-33466\" /></a></p>
<p>Generating Slack team invitations can become rather tedious when you&#8217;re managing a large group of people &#8211; particularly when the team is open to almost anyone. In the case of a company or organization, a Slack admin can use the feature that permits anyone with an email from a specified domain to be accepted on signup. However, this feature isn&#8217;t applicable to teams that are made up of people with diverse email domains and associations.</p>
<p><a href=\"http://boiteaweb.fr/\" target=\"_blank\">Julio Potier</a>, a French security consultant and prolific <a href=\"https://profiles.wordpress.org/juliobox/\" target=\"_blank\">plugin developer</a>, created a solution for this particular scenario. As an admin on the <a href=\"https://wordpressfr.slack.com/\" target=\"_blank\">WordPressFR.slack.com</a> team, which is open to all French WordPress users, he needed a more convenient way to allow new signups. The team has 27 channels and 250+ members with 200 added in the first week.</p>
<p>Julio decided to create a plugin to make the invitation process easier in the future. The new <a href=\"https://wordpress.org/plugins/lazy-invitation/\" target=\"_blank\">Slack Lazy Invitation</a> plugin automates the sending of Slack team invitations by adding a frontend signup on your WordPress site.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/join-slack-team.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/join-slack-team.png?resize=404%2C405\" alt=\"join-slack-team\" class=\"aligncenter size-full wp-image-47285\" /></a></p>
<p>The user simply enters an email address and the invitation is sent. A Slackbot confirmation will appear on the page.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/slack-team-invite-sent.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/slack-team-invite-sent.png?resize=365%2C253\" alt=\"slack-team-invite-sent\" class=\"aligncenter size-full wp-image-47286\" /></a></p>
<p>To configure the plugin for your Slack team all you need to do is enter the group name and the security token for your Slack invitations. As this token is not easy to find, Julio wrote a bookmarklet that will automatically capture it for you. From the plugin&#8217;s settings page you can drag and drop the bookmarklet into your browser toolbar on the invitation page found at: <code>https://YOURGROUP.slack.com/admin/invites</code>.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/lazy-slack-settings.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/lazy-slack-settings.png?resize=782%2C439\" alt=\"lazy-slack-settings\" class=\"aligncenter size-full wp-image-47295\" /></a></p>
<p>Once the plugin is configured, the invitation signup page will be available at <code>example.com/wp-login.php?action=slack-invitation</code>. If you&#8217;re using either the <a href=\"https://wordpress.org/plugins/wp-recaptcha/\" target=\"_blank\">wp-reCaptcha</a> or <a href=\"https://wordpress.org/plugins/google-captcha/\" target=\"_blank\">google-captcha</a> plugins, Slack Lazy Invitation will automatically add protection to the form.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/slack-invite-recaptcha.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/slack-invite-recaptcha.jpg?resize=350%2C481\" alt=\"slack-invite-recaptcha\" class=\"aligncenter size-full wp-image-47292\" /></a></p>
<p>The plugin also includes support for the <a href=\"https://wordpress.org/plugins/sf-move-login/\" target=\"_blank\">SF Move Login</a> plugin, so that the invitation form is available at /slack-invitation instead of the much longer URL. This slug can be changed in the SF Move Login settings panel.</p>
<p>In the future Julio plans to add support for adding invite pages for multiple groups. I tested <a href=\"https://wordpress.org/plugins/lazy-invitation/\" target=\"_blank\">Slack Lazy Invitation</a> and found that it works exactly as advertised. If you have a large Slack team with open invites, this plugin will save you quite a bit of time. Download it for free from WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 28 Jul 2015 22:30:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: Meet PeepSo: BuddyPress’ Newest Competitor in Open Source Social Networking for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46711\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"http://wptavern.com/meet-peepso-buddypress-newest-competitor-in-open-source-social-networking-for-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10255:\"<p>When the first <a href=\"https://buddypress.org/2008/12/buddypress-10b1-components/\" target=\"_blank\">BuddyPress beta</a> arrived on the scene in 2008, there was nothing like it for WordPress. Facebook was still relatively new to the public and Twitter was just a couple years old. A plugin that transformed WordPress into a social network was an exciting prospect.</p>
<p>After seven years of virtually unchallenged dominance among WordPress social networking plugins, BuddyPress has a new competitor. <a href=\"http://www.peepso.com/\" target=\"_blank\">PeepSo</a>, trademarked <em>&#8220;Your people. Your community. Your way,&#8221;</em> is the newest contender in WordPress&#8217; open source social networking plugin niche.</p>
<p>Unlike <a href=\"https://buddypress.org/\" target=\"_blank\">BuddyPress</a>, which for the most part has improved slowly through community contribution, the <a href=\"http://www.peepso.com/\" target=\"_blank\">PeepSo</a> project is run more like a startup and is 100% self-funded. It is currently being marketed as an alternative to BuddyPress.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">You\'ve been asking for it. An alternative to BuddyPress. It\'s here! <a href=\"http://t.co/Uxd7AQcnCL\">http://t.co/Uxd7AQcnCL</a> <a href=\"https://twitter.com/hashtag/wordpress?src=hash\">#wordpress</a> <a href=\"https://twitter.com/hashtag/buddypress?src=hash\">#buddypress</a> <a href=\"http://t.co/yYRI5pnXJR\">pic.twitter.com/yYRI5pnXJR</a></p>
<p>&mdash; peepso (@peepsowp) <a href=\"https://twitter.com/peepsowp/status/623768949943984128\">July 22, 2015</a></p></blockquote>
<p></p>
<p>The <a href=\"https://wordpress.org/plugins/peepso-core/\" target=\"_blank\">PeepSo plugin</a>, available on WordPress.org, offers many of the same <a href=\"http://www.peepso.com/pricing/\" target=\"_blank\">core features</a> as BuddyPress but was launched with a collection of commercial add-on plugins for things like photos, videos, moods, tagging, locations, friends, and messages. A groups feature is noticeably absent from Peepso but <a href=\"http://www.peepso.com/roadmap/\" target=\"_blank\">planned for version 1.4</a>. Current extensions seem to focus primarily on adding multimedia features to the activity stream.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/peepso-profile.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/peepso-profile.png?resize=1025%2C769\" alt=\"peepso-profile\" class=\"aligncenter size-full wp-image-47235\" /></a></p>
<h3>Who is Behind PeepSo?</h3>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/merav-peepso.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/merav-peepso.jpg?resize=225%2C300\" alt=\"merav-peepso\" class=\"alignright size-medium wp-image-47241\" /></a>PeepSo was founded by <a href=\"https://about.me/meravknafo\" target=\"_blank\">Merav Knafo</a>, owner of <a href=\"http://www.jomsocial.com/\" target=\"_blank\">JomSocial</a>, Joomla&#8217;s most popular social networking solution. Knafo, a veteran in the Joomla community, brings a unique perspective on the differences between the Joomla and WordPress markets for social networking software. As <a href=\"http://w3techs.com/technologies/overview/content_management/all\" target=\"_blank\">Joomla captures roughly 7% to WordPress&#8217; 60% of the CMS market share</a>, Knafo saw an opportunity to break into a larger market.</p>
<p>&#8220;As a business owner, it’s my job to pay attention to trends in my industry and unfortunately, Joomla has been on a downward trend since 2009,&#8221; Knafo said.</p>
<p>&#8220;Many of our JomSocial customers have asked us to &#8216;make JomSocial for WordPress,&#8217; because they wanted to switch to WordPress but there was nothing like JomSocial for WordPress. Finally, I could not ignore the trend nor the requests and decided to get into the WordPress market as well.&#8221;</p>
<p>Knafo hopes to parlay her experience with JomSocial into her new venture with PeepSo.</p>
<p>&#8220;We stuck with Joomla for almost 10 years now and took JomSocial to a whole new level when we took over in 2013,&#8221; she said. &#8220;I am very proud of what we’ve accomplished with JomSocial and super excited to implement all this experience and knowledge into PeepSo.&#8221;</p>
<h3>How PeepSo Got Started</h3>
<p>The idea for PeepSo was incubating for a few years before Knafo had the opportunity to execute it.</p>
<p>&#8220;Brad Bihun used to be a customer of ours at <a href=\"http://www.ijoomla.com/\" target=\"_blank\">iJoomla</a>, and then he switched to WordPress,&#8221; she said. &#8220;We happened to live very close to each other in Encinitas, California, so we met up and suggested I’d created &#8216;JomSocial for WordPress.&#8217;</p>
<p>&#8220;At that time, I didn’t even own JomSocial and I was too busy with all the iJoomla products. Then a couple of years later, I acquired JomSocial and he approached me again, but once again, I was just too busy. A year and a half into JomSocial acquisition, when things got a lot smoother, I finally said yes, he introduced me to the <a href=\"http://spectromtech.com/\" target=\"_blank\">SpectrOM</a> team, and we got started.&#8221;</p>
<p>Although the plugin appears to be marketed as a direct competitor to BuddyPress, Knafo said that it wasn&#8217;t created specifically for that purpose but rather to give WordPress users a more robust array of options for building networks.</p>
<p>&#8220;Obviously we felt there was a need for another product as an alternative to BuddyPress,&#8221; she said. &#8220;Leaving users with just one option is rarely a good idea, people like options.</p>
<p>&#8220;We don’t necessarily plan to take on BuddyPress, we just want to offer those who want an alternative, a product that is of high quality and that is being continuously developed. Ultimately, people will choose the solution that serves them best. We are just getting started, but we have big plans and an excellent track record doing this successfully with Joomla.&#8221;</p>
<h3>The Differences Between PeepSo and BuddyPress</h3>
<p>I asked Knafo what her team perceives to be the most notable differences between PeepSo and its more established competitor, based on what they found to be lacking in BuddyPress.</p>
<p>&#8220;I’d say the look and feel is a lot more modern in PeepSo right off the bat with no special themes needed,&#8221; she said. &#8220;The features are more up-to-date with the latest and greatest features of big social networks, such as Facebook &#8211; from cover photos to &#8216;likes&#8217; and so on.&#8221;</p>
<p>BuddyPress core developers have opted to leave the aforementioned features to separate third-party plugins as opposed to packing them into core. With certain features, i.e. photos and videos, PeepSo does the same, except the add-ons are supported by PeepSo core developers.</p>
<p>&#8220;PeepSo is lightweight and allows you to only add features that you need, to keep it lightweight,&#8221; Knafo said. &#8220;PeepSo’s code is so beautiful it made our developers shed tears of joy when they first saw it &#8211; that said, I never looked at BuddyPress’s code, nor would I be able to tell whether it’s beautiful or not.&#8221;</p>
<p>In terms of code differences, PeepSo&#8217;s development team cited what they believe to be a few major differences between their <a href=\"https://github.com/wp-plugins/peepso-core\" target=\"_blank\">codebase</a> and BuddyPress:</p>
<ul>
<li>All object oriented &#8211; from the PHP to the Javascript</li>
<li>Built with a templating engine similar to what you see in shopping cart systems. This allows use with virtually any theme.</li>
<li>The JavaScript uses an extension mechanism, allowing add-ons to extend the abilities of the postbox.</li>
<li>We made the database queries as optimized as possible to allow for greater scalability.</li>
</ul>
<p>&#8220;We have a track record creating and supporting a very large social networking application (JomSocial),&#8221; Knafo told the Tavern. &#8220;We know the ins and out of this business. We may be new to WordPress, but we are veterans when it comes to social networking applications.&#8221;</p>
<h3>Where is PeepSo Headed?</h3>
<p>The PeepSo development team, guided by lead architect <a href=\"https://twitter.com/davejesch\" target=\"_blank\">Dave Jesch</a> of <a href=\"http://spectromtech.com/\" target=\"_blank\">SpectrOM</a>, has an aggressive <a href=\"http://www.peepso.com/roadmap/\" target=\"_blank\">roadmap</a> for improving the plugin&#8217;s core and adding more features via commercial plugins.</p>
<p>&#8220;Our main goal is to add more plugins to PeepSo, you can see our road map here. We’ll start with a chat plugin, custom profile fields and then groups, events, pages and so forth,&#8221; Knafo said. The team also hopes to partner with other developers who want to create PeepSo plugins.</p>
<p>I asked her if the team plans to create a hosted PeepSo platform for community managers. Knafo said it isn&#8217;t totally out of the question but isn&#8217;t high on the priority list at the moment.</p>
<p>&#8220;We tried to do this with JomSocial but we had a hard time finding the right hosting solution for it,&#8221; she said. &#8220;That said, we are open to the idea, a bit down the road.&#8221;</p>
<p>PeepSo is just getting started and has not yet attracted many customers. However, Knafo&#8217;s experience of successfully running an open source project for the past 10 years has given her the determination to break into a new and unfamiliar market.</p>
<p>&#8220;The sales have been as can be expected this early after the initial release, not too shabby to start with but we expect whole lot more sales as the WordPress users become aware of PeepSo, download the free version and give it a try,&#8221; she said.</p>
<p>&#8220;We’re here for the long haul and we take no shortcuts in doing this right. We know it’s a huge undertaking; there is so much more to do. I am confident that investing in WordPress was the right move, I’ve been very pleased by the feedback and the community. My hope is that WordPress developers will join us and create awesome plugins to take PeepSo to the next level.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 22:50:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Only 70 Tickets Remain to Livestream Prestige for Free August 1-2, 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47208\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/only-70-tickets-remain-to-livestream-prestige-for-free-august-1-2-2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4855:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png\"><img class=\"alignright size-full wp-image-27630\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/08/PrestigeConfLogo.png?resize=275%2C233\" alt=\"Prestige Conference Logo\" /></a>With just a few days remaining before <a href=\"http://prestigeconf.com/\">Prestige takes place</a>, there are only 70 tickets left to watch the event for free. Courtesy of <a href=\"http://www.rocketgenius.com/\">Rocketgenius</a>, the event&#8217;s primary sponsor, more than 500 people will be watching the event for free this weekend. To watch the event for <del>free, use the code <strong>GravityFormsLS </strong></del>when <a href=\"http://prestigeconf.com/tickets/\">purchasing a streaming ticket</a>.</p>
<p>Free tickets are sold out. However, entering the code <strong>PrestigeStream</strong> when <a href=\"http://prestigeconf.com/tickets/\">purchasing a streaming ticket</a>, will take 50% off the price</p>
<p>Prestige is a conference founded by Kiko Doran and Josh Broton in 2014 that focuses on the business aspects of WordPress. The first event was held in Minneapolis, MN, in October of 2014. Earlier this year, Prestige was held in Las Vegas, NV. This weekend marks the third time the conference will be held.</p>
<h2>The Future of Prestige</h2>
<p>The first and second conference had approximately 100 attendees and Doran expects the same amount this weekend. However, future iterations of Prestige will have lower attendance. &#8220;We are transitioning to more of an online event. We’re actually going to make the in-person events smaller moving forward.&#8221; Doran told the Tavern.</p>
<p>There&#8217;s also a chance the conference could morph into something completely different. &#8220;After organizing two WordCamps, I figured out some of the things I loved about them and some of the things I don&#8217;t. Prestige has given me the freedom to try new things and see what people like and what they don’t like,&#8221; Doran said.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/PrestigeinVegas.jpg\"><img class=\"wp-image-47216 size-full\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/PrestigeinVegas.jpg?resize=1025%2C576\" alt=\"Prestige in Las Vegas Nevada\" /></a>Prestige in Las Vegas, NV Image courtesy of <a href=\"https://www.happyjoe.org/prestige-conference-las-vegas-2015/\">James Dalman</a>
<p>Although the conference has been held twice this year and in different cities, the organizing team plans to host at least one Prestige conference in Minneapolis every year. Talks are underway for the next event but details are not locked down.</p>
<p>&#8220;We plan to do one in Minneapolis every year because we love the community there. We’d like to do Minneapolis in the summer time, due to weather, then we’d like to do any winter events in a warm place,&#8221; Doran said.</p>
<p>Organizing a conference is a challenging experience that benefits from having motivated organizers. Doran explains what motivates him to organize Prestige, sometimes twice a year.</p>
<p>&#8220;I have a small awesome team of organizers that love putting this event on. That and the people who come and share their knowledge. It’s a smaller event but to me, that&#8217;s the appeal of it. Everyone is far more approachable in this environment,&#8221; he said.</p>
<h2>A First for Prestige</h2>
<p>This weekend&#8217;s event features a hands-on workshop by Jennifer Bourn of <a href=\"http://www.bourncreative.com/\">Bourn Creative</a>. It&#8217;s the first session in Prestige&#8217;s young history to involve hands-on exercises. The session is uncharted territory for the conference which has mostly focused on people sharing their experiences building  businesses.</p>
<h2>How Long Will Doran Organize Prestige?</h2>
<p>With this being his third conference, I asked Doran how long does he plan to continue organizing Prestige, &#8220;I’ll organize the conference as long as there is a demand for the content. People often say to scratch your own itch. This conference started off as a little self-serving in that I wanted to ask people all of these questions. Then I thought, couldn’t others benefit from this information as well?&#8221; he replied.</p>
<h2>I&#8217;ll Be at Prestige Conference</h2>
<p>I&#8217;ll be among the 100 expected attendees at this weekends conference. If you&#8217;re attending the event, please stop me and say hi. If not, make sure you grab one of the <a href=\"http://prestigeconf.com/tickets/\">70 tickets left</a> to watch a livestream of the event. You can also monitor the <a href=\"https://twitter.com/search?q=prestigeconf&src=typd\">#Prestigeconf</a> hashtag on Twitter. If you&#8217;ve previously attended Prestige or watched the livestream, please share your experiences in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 21:13:13 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: WordPress Users Association Under New Ownership\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46317\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://wptavern.com/wordpress-users-association-under-new-ownership\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5827:\"<p>The <a href=\"http://wpua.org/\">WordPress Users Association</a> (WPUA) is breathing new life after it was acquired by Paul DeMott earlier this year <a href=\"https://flippa.com/4377398-pr-2-2-405-last-12-mos-wordpress-training-membership-site-3500-members\">on Flippa</a> for $797. WPUA originally launched in December 2010, with the goal of providing a central place for WordPress users to swap war stories, learn how to get the most out of WordPress, and take part in getting special discounts on themes and plugins.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/WPUAFrontPage.png\"><img class=\"size-full wp-image-47197\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/WPUAFrontPage.png?resize=1025%2C489\" alt=\"Redesigned Front Page\" /></a>Redesigned Front Page
<p>Three years after its launch, the site appeared to be dead. In 2013, <a href=\"http://wptavern.com/psa-dont-give-your-money-to-the-wpua\">I paid to become a member</a> to confirm my suspicions and to see if the site still accepted payments. Free themes and plugins offered to members were not impressive and there wasn&#8217;t much to choose from. All of the videos used for WordPress training were broken. Despite these setbacks, I was able to successfully complete the refund process.</p>
<h2>Financial Details</h2>
<p>Earlier this year, WPUA.org was listed on <a href=\"https://flippa.com/\">Flippa.com</a>, a domain auctioning site. As part of the auction financial details of WPUA.org were made public. According to <a href=\"https://flippa.com/users/217895\">the seller</a>, the site made $20K when it launched. The previous owners spent between $500-$1,000 on ads and answering WordPress questions through the Ask a WordPress Expert section of the site.</p>
<p>The following shows revenue, costs, and profit between October 2014 and March 2015. WPUA earned revenue primarily with product or service sales and affiliate income.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WPUARevenue.png\"><img class=\"size-full wp-image-47198\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WPUARevenue.png?resize=580%2C273\" alt=\"WPUA Revenue\" /></a>WPUA Revenue
<p>At the time the site was listed for auction, it had 3,500+ total members made up of free and paid subscriptions. The site today boasts more than 5,600 members.</p>
<h2>Previous Owner Explains Why He Sold The Site</h2>
<p>Wesley Williams is the former owner of WPUA.org and helped launch the site in 2010. Williams transitioned away from the domain because his web development business used the majority of his time. &#8220;We felt with our limited time to invest in it that it was best to transition it to someone who shared our passion but had a little more time to invest in growing the community and serving the members. We completed this transition back in April,&#8221; Williams told the Tavern.</p>
<p>From my perspective, the WPUA was not a successful venture but Williams says otherwise.</p>
<p>&#8220;I wouldn&#8217;t say it wasn&#8217;t a success. There are thousands of members and we provided a lot of help to a lot of new and experienced WordPress users. As my main core business grew and as the time requirements of our projects increased, we couldn&#8217;t devote the time required to answer questions and give the help needed.</p>
<p>&#8220;Actually, WPUA was a big success in my mind. Just from a number of members point of view it was a success. From the amount and number of questions and people we helped it was a success and from a financial standpoint it was a success,&#8221; he said.</p>
<p>Williams explains his goal with WPUA and why some members of the community may not be aware of the growth it had. &#8220;My goal was to help the under-served, those just getting started and without the technical know how to make what is actually simple fixes or changes to their WordPress site.</p>
<p>&#8220;I didn&#8217;t run the WPUA in the circles of all the established WordPress technical crowd, even though a large number of them became members of the WPUA. I ran it focused on users new to the platform and so because of that, some members of the WordPress community might not be aware of the growth and success it had,&#8221; he said.</p>
<p>Through the course of time, Williams and his team adjusted membership levels and access points which helped increase registrations. Williams also learned that what members wanted was a direct way to ask questions and receive expert answers.</p>
<p>&#8220;A person new to the platform didn&#8217;t want to post their question in a forum and they weren&#8217;t really sure what the real question was. Thus, we removed the forum and went to an &#8216;Ask an Expert&#8217; system where they could email their questions. This seemed to work better for everyone,&#8221; he said.</p>
<p>Overall, Williams is happy with how WPUA progressed and feels fortunate to have played a role in its growth and success.</p>
<h2><strong>Who is Paul DeMott?</strong></h2>
<p>In the <a href=\"https://vimeo.com/129324627\">following video,</a> DeMott explains how to build a eCommerce site with WooCommerce and calls himself the new president of recruitment for the WPUA. According to <a href=\"https://www.linkedin.com/pub/paul-demott/79/300/727\">his LinkedIn profile</a>, he lives in Cincinnati, OH and is the owner of Paul&#8217;s SEO and Web Expertise which works with companies to develop websites that bring in internet traffic and sales.</p>
<p>Not much is known about DeMott and multiple requests for comment have gone unanswered. It&#8217;s unclear what his plans are for WPUA.org but so far, it&#8217;s remained as a paid subscription membership site. If you are a past or current member of the WordPress Users Association, please tell us about your experience in the comments.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 20:39:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: MPAA Smoking Gun\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45270\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/07/mpaa-smoking-gun/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:319:\"<p>Sometimes truth is worse than what you would imagine: <a href=\"https://www.techdirt.com/articles/20150724/15501631756/smoking-gun-mpaa-emails-reveal-plan-to-run-anti-google-smear-campaign-via-today-show-wsj.shtml\">Smoking Gun: MPAA Emails Reveal Plan To Run Anti-Google Smear Campaign Via Today Show And WSJ</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jul 2015 15:34:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:119:\"WPTavern: Plugin Developers Demand a Better Security Release Process After WordPress 4.2.3 Breaks Thousands of Websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47146\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:129:\"http://wptavern.com/plugin-developers-demand-a-better-security-release-process-after-wordpress-4-2-3-breaks-thousands-of-websites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6880:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/security.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/07/security.jpg?resize=1024%2C487\" alt=\"photo credit: Ravages - cc\" class=\"size-full wp-image-27206\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/ravages/6731739485/\">Ravages</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p><a href=\"http://wptavern.com/wordpress-4-2-3-is-a-critical-security-release-fixes-an-xss-vulnerability\" target=\"_blank\"> WordPress 4.2.3</a>, a critical security release, was automatically pushed out to users yesterday to fix an XSS vulnerability. Shortly afterwards, the <a href=\"https://wordpress.org/search/4.2.3?forums=1\" target=\"_blank\">WordPress.org support forums</a> were flooded with reports of websites broken by the update.</p>
<p>Roughly eight hours later Robert Chapin (@<a href=\"https://profiles.wordpress.org/miqrogroove/\" target=\"_blank\">miqrogroove</a>) published a post to the Make.WordPress.org/Core blog, detailing <a href=\"https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/\" target=\"_blank\">changes to the Shortcode API</a> that were included in the release. According to Chapin, these changes were necessary as part of the security fix:</p>
<blockquote><p>Due to the nature of the fix – as is often the case with security fixes – we were unable to alert plugin authors ahead of time, however we did make efforts to scan the plugin directory for plugins that may have been affected.</p>
<p>With this change, every effort has been made to preserve all of the core features of the Shortcode API. That said, there are some new limitations that affect some rare uses of shortcodes.</p></blockquote>
<p>The security team had no reasonable way of accounting for every single edge case, but the negative impact of these changes were far more wide-reaching than they had anticipated. This particular use case likely wasn&#8217;t covered in their testing. Unfortunately, plugin developers found out about the breaking changes only after the security release had already left a slew of broken websites in its wake.</p>
<p>&#8220;I fully understand this is an issue, but isn’t this a weird way of updating &#8211; almost all our clients are calling / e-mailing us at the moment as their sites seem to be broken,&#8221; one developer <a href=\"https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/#comment-26449\" target=\"_blank\">commented</a> on the Shortcode API post. &#8220;Normally it would be better to announce such huge impact changes to the plugin and theme developers. This means I need to fully reschedule my agenda, which already is full during holiday season.&#8221;</p></blockquote>
<p>Comments on the WordPress.org post are full of developers scrambling to find a way to fix client websites. Many were disappointed that the total secrecy of the security team, which is necessary in situations like this, was not immediately followed up with a public post on the important changes to the Shortcode API. Meanwhile, the email inboxes of agencies and plugin developers are filling up with urgent messages from outraged clients.</p>
<p>Developers want better communication from the those who are managing security releases. <a href=\"https://twitter.com/helzer\" target=\"_blank\">Amir Helzer</a>, author of <a href=\"https://wordpress.org/plugins/types/\" target=\"_blank\">Types</a> and <a href=\"http://wp-types.com/home/views-create-elegant-displays-for-your-content/\" target=\"_blank\">Views</a>, two plugins majorly affected by the release, <a href=\"https://make.wordpress.org/core/2015/07/23/changes-to-the-shortcode-api/#comment-26447\" target=\"_blank\">sums up the thoughts of many other commenters</a> on the Make/WordPress.org/Core post:</p>
<blockquote><p>We are updating the Views plugin today, so that we resolve all shortcodes before passing to WordPress to process content.</p>
<p>This is a straightforward change, which takes us one day to complete.</p>
<p>Would have been great to receive a heads-up about an upcoming change in WordPress, so we could do this change on time.</p>
<p>We received a huge amount of support requests due to this, but this isn’t the issue. We can deal with a wave a support issues. This time it wasn’t “our fault”, but sometimes it is.</p>
<p>What worries us, as mentioned above, is seeing our clients (folks who build WordPress sites for a living), losing their faith in the system. They feel like the system sees them as little ants and not as humans. People don’t like seeing their problems being dismissed.</p>
<p>Many of them run hundreds of sites. They cannot afford to stop everything and fix content on so many sites. Especially not if they are currently away for their family vacation.</p>
<p>What others have asked here, and I would like to ask, too, is to setup a mechanism that allows WordPress core developers to privately communicate such upcoming issues with plugins developers.</p>
<p>We are your partners.</p>
<p>Without WordPress (secure, stable and reliable), we would not exist.</p>
<p>Without great themes and plugins, WordPress would not power 24% of the Web.</p>
<p>WordPress core members already volunteer a lot of their time. I’m not asking for anyone to volunteer more time. Need help? Ask us. There is a huge community of developers who rely on WordPress. We would be happy to get involved and set up whatever is needed.</p></blockquote>
<p>User confidence in WordPress&#8217; automatic background updates took a dent with the 4.2.3 release. Waking up to broken websites causes users to second guess automatic updates after being assured that maintenance and security releases would not include breaking changes.</p>
<p>When users get burned by automatic updates, in the end it doesn&#8217;t matter which party is at fault &#8211; whether it&#8217;s the core team or a theme or plugin. They simply expect updates to work and not break anything. Even in instances where a poorly coded extension may be at fault, the average user has no way of determining whether or not their active plugins follow WordPress best practices.</p>
<p>The aftermath of the most recent security release is one reason why many developers and users are still wary of automatic updates. Amir Helzer represents many other plugin developers who are eager to find better ways to work together with the core team to provide a better update experience for users. This is especially important for releases like this one where the Shortcode API changes directly affected users&#8217; content. Hezler&#8217;s comment reaffirms the fact that development agencies, plugin developers, and core developers are all partners on the same team. It&#8217;s time to find better ways of working together to provide the best update experience possible for WordPress users.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 25 Jul 2015 02:46:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"WPTavern: FooPlugin’s Digital License Key Management Plugin is Now Open Source for Developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47117\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"http://wptavern.com/fooplugins-digital-license-key-management-plugin-is-now-open-source-for-developers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5296:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/open-source.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/open-source.jpg?resize=1024%2C514\" alt=\"photo credit: 16th st - (license)\" class=\"size-full wp-image-45884\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/79777096@N00/6866996865\">16th st</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-nd/2.0/\">(license)</a>
<p>Three years ago, <a href=\"http://fooplugins.com/\" target=\"_blank\">FooPlugins</a> built <a href=\"https://bitbucket.org/fooplugins/foolicensing\" target=\"_blank\">FooLicensing</a>, a digital license key management tool that enabled them to manage customers of their <a href=\"https://easydigitaldownloads.com/\" target=\"_blank\">EDD</a>-powered commercial plugins store. Although EDD already offered a license creation and management extension, FooPlugins required more features than it had at that time and opted to build their own.</p>
<p>As of today, FooLicensing is now open source and free for anyone to use, along with the associated EDD connector plugin.</p>
<p>&#8220;We love the community and wanted to give back,&#8221; FooPlugins co-founder Adam Warner said.</p>
<p>&#8220;We know FooLicensing could be so much more but we just don&#8217;t have the time to dedicate to it alone. We are a small team and because of that we find ourselves with dozens of projects that could be so much more if only we had more time and people.&#8221;</p>
<p>Open sourcing a project can change its trajectory if there&#8217;s enough interest and developers willing to contribute to improve it. Warner isn&#8217;t counting on that, however, and simply hopes other developers will find it useful.</p>
<p>&#8220;It&#8217;s a bit of a leap of faith, but if it helps someone else get involved to help create an even more robust system, then great,&#8221; he said. &#8220;Bonus if it helps someone build additional extensions to help others.&#8221;</p>
<p>FooLicensing&#8217;s main features include:</p>
<ul>
<li>View and manage the validated domains for your EDD license level</li>
<li>One click EDD license upgrade/add to cart</li>
<li>One click EDD license renewal (with associated discount) /add to cart</li>
</ul>
<p>A logged-in user who has entered a license key will see all the relevant account information detailing status, activations, expirations, etc.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-user-admin.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-user-admin.png?resize=580%2C332\" alt=\"foolicensing-user-admin\" class=\"aligncenter size-full wp-image-47135\" /></a></p>
<p>Administrators who are using the plugin together with its <a href=\"https://bitbucket.org/fooplugins/edd-foolicensing\" target=\"_blank\">EDD Connector</a> will see a menu with various license creation and management tools.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-admin-view.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/foolicensing-admin-view.png?resize=160%2C264\" alt=\"foolicensing-admin-view\" class=\"aligncenter size-full wp-image-47137\" /></a></p>
<p>The <a href=\"https://bitbucket.org/fooplugins/edd-foolicensing\" target=\"_blank\">EDD Connector</a>, also now open source, enables the following:</p>
<ul>
<li>Add new licenses to attach to an EDD product</li>
<li>A searchable list of all license keys that have been created and assigned, complete with attached domains</li>
<li>A list of licenses that have been renewed</li>
<li>Testing for license validation and update checks in the API Sandbox</li>
<li>A management area for various messages (domain attach, detach) and for license renewal discount amount and emails</li>
</ul>
<h3>Foo Licensing is Extensible for Other Platforms</h3>
<p>FooLicensing was built from the beginning to be extensible for use with other platforms beyond EDD. The team at FooPlugins had plans to expand their library of connectors but didn&#8217;t have the time to execute them.</p>
<p>&#8220;Our goal for FooLicensing was to build additional integrations for other eCommerce plugins and digital sales platforms but it quickly took a back seat as our <a href=\"https://fooplugins.com/plugins/foobox/\" target=\"_blank\">FooBox</a> and other plugins like <a href=\"https://fooplugins.com/plugins/foogallery/\" target=\"_blank\">FooGallery</a> gained popularity,&#8221; Warner said.</p>
<p>&#8220;Documentation is non-existent at this point, but we welcome you to step through the code and consider getting involved with the core plugin or with extensions for other eCommerce platforms.&#8221;</p>
<p>Warner said the team is considering a full-fledged site dedicated to FooLicensing if enough developers become interested and would consider the possibility of a marketplace to host any extension built. FooPlugins does not currently have plans to create additional extensions in house.</p>
<p>&#8220;We&#8217;ll see what the future holds, but for now we need to move forward with some other things rather than holding this tight to our chests,&#8221; Warner said. &#8220;Open sourcing the plugins just fits in with what we believe is the right thing to do to make the web (and the WP community) a better place.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 24 Jul 2015 20:17:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"Post Status: Thesis, Automattic, and WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=13692\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://poststatus.com/thesis-automattic-and-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:70425:\"<p>Chris Pearson and Matt Mullenweg have hardly communicated with one another in the last five years, but they are ideological enemies. They are both wealthy individuals (though of different magnitudes) thanks to their online endeavors, with very strong personalities and unshakable beliefs on business and software. This is a story of their dispute, their idealism, and the implications it will have on the WordPress project.</p>
<p><a href=\"http://ma.tt/\">Matt Mullenweg</a> co-founded WordPress, founded <a href=\"https://automattic.com\">Automattic</a>, and is one of the most successful entrepreneurs of his generation. He runs a billion dollar &#8220;unicorn&#8221; startup centered on a culture of embracing open source technology and has achieved incredible success embracing principles counterintuitive to either Silicon Valley or big corporate culture. He&#8217;s paving a new path for how to create a valuable software company while religiously defending and promoting open source software.</p>
<p><a href=\"http://www.pearsonified.com/\">Chris Pearson</a> founded <a href=\"http://diythemes.com/\">DIYthemes</a> and helped pioneer the early WordPress commercial theme industry. He has run his business successfully for over seven years, despite unique hurdles that result from a very public dispute with Mullenweg in 2010. He vehemently defends his work as his own non-derivative achievement and rejects the religiosity and cult mentality that he believes exists in the WordPress ecosystem. He views WordPress as a huge chunk of the web, available to be monetized &#8212; which he has done so to the tune of millions of dollars &#8212; but he does not believe he must adopt Matt Mullenweg&#8217;s principles in order to meet customer demand, run his own business, and protect his own inventions.</p>
<p>By all normal definitions, Mullenweg and Pearson have done incredibly well for themselves. However, from a pure size perspective and principles aside, Mullenweg is the big nation army and Pearson is the small revolutionary militia. Mullenweg views Pearson as a threat to everything he stands for and has worked to accomplish, and Pearson views Mullenweg as an overbearing figure with no true authority over his decisions.</p>
<p>Mullenweg has the motivation, resources, and ability to squash Pearson &#8212; and indeed most thought he&#8217;d done so already. While he has far fewer resources, Pearson has some tools available to protect his business or to potentially even disrupt the entire WordPress ecosystem as we know it today.</p>
<p>During their first conflict in 2010, and in the resurgent one going on now, Mullenweg and Pearson have both at times made mistakes, acted childishly, or been in the wrong. Both also have merit in various aspects of their positions. Neither conflict, so publicly debated, reflects well on the WordPress ecosystem as a whole &#8212; even though I believe it is right that each conflict is best observed under a public eye, as the results can affect so many other businesses and potentially even WordPress itself.</p>
<p>With this post, I aim to outline the entire conflict; to describe the implications past, present and future; to highlight non-WordPress comparisons for precedent and potential implications; and to share my own thoughts on who is in the right and who is in the wrong, as viewed for the good of the global WordPress community.</p>
<h2>A history of conflict</h2>
<p>The commercial theme movement started in 2007 and took off in 2008. Thesis was one of the pioneers of commercial WordPress themes. The theme industry was young and evolving rapidly, and many sellers hardly considered or understood licensing issues at all.</p>
<p>Many of the sources for this period are from Siobhan McKeown&#8217;s excellent account in the book, <a href=\"https://github.com/WordPress/book\"><em>Milestones: The Story of WordPress</em></a> (which I&#8217;ll refer to as <em>Milestones</em>).</p>
<h3>Themes as derivative works of WordPress</h3>
<p>WordPress is licensed by the GNU General Public License (GPL), version 2 or later. The GPL ensures certain freedoms that protect both WordPress and those that utilize it. The &#8220;four freedoms&#8221; that are the heart of the GPL are as follows:</p>
<blockquote>
<ul>
<li>The freedom to run the program as you wish, for any purpose (freedom 0).</li>
<li>The freedom to study how the program works, and change it so it does your computing as you wish (freedom 1). Access to the source code is a precondition for this.</li>
<li>The freedom to redistribute copies so you can help your neighbor (freedom 2).</li>
<li>The freedom to distribute copies of your modified versions to others (freedom 3). By doing this you can give the whole community a chance to benefit from your changes. Access to the source code is a precondition for this.</li>
</ul>
</blockquote>
<p>As WordPress co-founder Mike Little phrased it in the Post Status Slack, &#8220;The GPL is meant to be restrictive for developers and permissive for users.&#8221; The <a href=\"https://gnu.org/philosophy/philosophy.html\">GNU philosophy page</a> and subsequent articles are a good resource for understanding the nature of the license.</p>
<p>The GPL is a <a href=\"https://en.wikipedia.org/wiki/Copyleft\">Copyleft</a> license, which creates the &#8220;stipulation that the same rights be preserved in derivative works down the line.&#8221; In an immature theme market, licensing was given relatively little notice, and many theme authors provided their themes with no license or proprietary licenses.</p>
<p>Matt Mullenweg, to many, would be considered <a href=\"https://en.wikipedia.org/wiki/Benevolent_dictator_for_life\">BDFL</a>, or Benevolent Dictator for Life, of WordPress. It&#8217;s a common term for folks that lead open source projects and have final say on project decisions. In his role as WordPress BDFL, he now has a reputation &#8212; at least within certain circles of folks that pay close attention &#8212; for making large, impactful decisions with little description of why he has done so.</p>
<p>In late 2008, more than 200 free WordPress themes were removed from the WordPress.org theme repository. While many of the themes were removed due to spammy links, some were pulled due to GPL violations within the themes or within the theme upsells that were linked from the theme listings.</p>
<p>The move, which was made without announcement, shocked many theme providers that felt they were unfairly included in the group of removed themes. The situation created a spark and initiated a serious debate about theme licensing.</p>
<p>Authors were concerned that GPL licensed themes would mean that their themes would be bought and freely distributed, removing their ability to make money from their works. A few, such as Brian Gardner with his Revolution theme, <a href=\"http://www.blogherald.com/2008/10/01/brian-gardners-revolution-theme-goes-open-source/\">changed their licensing</a> as a result of conversations with Mullenweg and Toni Schneider, Automattic&#8217;s CEO at the time. In Brian&#8217;s case, he made his theme free and offered paid support services.</p>
<p>Eventually though, most authors &#8220;selling&#8221; themes started actually selling support, access to download, and updates for their themes. This model was both GPL compatible, as well as workable for authors to get paid.</p>
<p>In mid-2009, Matt Mullenweg also posted <a href=\"https://wordpress.org/news/2009/07/themes-are-gpl-too/\">on the official</a> WordPress blog that he was introducing a new <a href=\"https://wordpress.org/themes/commercial/\">commercial theme listing page</a> on WordPress.org, and he shared an opinion he requested from the Software Freedom Law Center (SFLC), where they determined that the two themes packaged with WordPress were derivative works.</p>
<p>The SFLC opinion did leave room for a &#8220;split license&#8221; where the WordPress and PHP code must inherit the GPL, and the CSS, Javascript, and images could be under a proprietary license:</p>
<blockquote><p>In conclusion, the WordPress themes supplied contain elements that are derivative of WordPress’s copyrighted code. These themes, being collections of distinct works (images, CSS files, PHP files), need not be GPL-licensed as a whole. Rather, the PHP files are subject to the requirements of the GPL while the images and CSS are not. Third-party developers of such themes may apply restrictive copyrights to these elements if they wish.</p>
<p>Finally, we note that it might be possible to design a valid WordPress theme that avoids the factors that subject it to WordPress’s copyright, but such a theme would have to forgo almost all the WordPress functionality that makes the software useful.</p></blockquote>
<p>&#8220;Split license&#8221; is the colloquial term the community has assigned to this statement, but in fact the actual splitting of which parts are GPL and which parts are not matters, so it may not do the reality of the situation justice. Perhaps it should be termed &#8220;PHPGPL&#8221; or &#8220;Non-Assets GPL&#8221;.</p>
<p>A number of prominent theme sellers were unhappy with Mullenweg&#8217;s insistence that their themes maintain a 100% GPL license, but they were not willing to shake the boat over it. At this point, themes were becoming big businesses and making new millionaires (or close to it) of some of these shop owners. This settled the issue for nearly all theme sellers, and most moved to either 100% GPL or a PHPGPL license, and the doomsday scenarios never came; the theme industry continues to thrive.</p>
<h3>Thesis holds out</h3>
<p>But not everyone agreed to go either 100% GPL or PHPGPL license. Chris Pearson kept his Thesis theme under a proprietary license.</p>
<p>Thesis was one of the most popular and flexible themes in the world, and Pearson <a href=\"https://github.com/WordPress/book/blob/925d7dc6293b1662a7e6839a2703e8a858c730ad/Content/Part%205/39-thesis.md\">boasted on Andrew Warner&#8217;s Mixergy podcast</a> of revenues of $1.2 million+ over the 12-18 month period prior to the interview. Mullenweg and Pearson criticized one another publicly, and Warner invited them both to Mixergy where they debated the merits of GPL licensing.</p>
<p>By most accounts, Mullenweg had the better argument on the Mixergy episode, and also came off as a calmer and more collected personality &#8212; in contrast to Pearson&#8217;s often heated, and sometimes very strange, statements.</p>
<p>The debate continued between Mullenweg, Pearson, and a variety of WordPress community members and their blogs. Mullenweg was extremely aggressive, to the extent that he <a href=\"https://twitter.com/photomatt/status/18548422506\">offered to buy</a> alternative commercial themes for users of Thesis that agreed to switch. Mullenweg tells me that many took him up on his offer, but it was, &#8220;less than a thousand.&#8221; In my opinion, this was a step too far by Mullenweg, though for him the issue was already personal.</p>
<p>Pearson held his ground over the following days until an admission by one of his own team members of wholesale copying of code in Thesis from WordPress code, which violates the WordPress copyright.</p>
<p>At this point, Pearson finally capitulated and announced that Thesis would be a split license GPL compatible theme, and the debate died down. Pearson put his head down and started working on Thesis 2.</p>
<p>He released Thesis 2 in late 2012, and by this time the debate was cool &#8212; the community had moved on to other drama (yes, even more GPL drama) &#8212; and the release of Thesis 2 was largely ignored outside of DIYthemes&#8217; audience, which was quite large but also largely isolated from the WordPress &#8220;community&#8221; that cares about stuff like licensing.</p>
<p>Therefore, not many people paid attention to the new Thesis or the licensing it contained. Mullenweg, however, was still paying attention.</p>
<h2>The battle over thesis.com</h2>
<p>If you consider the word <em>thesis</em>, what do you think of?</p>
<p>If you are a regular person walking down the street, you probably think of the general concept for stating a theory, or perhaps you think of the long papers that university students write as part of their programs.</p>
<p>If you are in the WordPress world, you may also consider the Thesis WordPress theme by DIYthemes.</p>
<p>Good, single word domain names are hard to come by. Thesis.com, if you visit it now, redirects to the <a href=\"http://themeshaper.com\">ThemeShaper blog</a>. ThemeShaper is owned and operated by Automattic, and frequently posts articles about WordPress themes.</p>
<p>ThemeShaper is not a dedicated commercial property, but it does link to Automattic&#8217;s primary website, and Automattic does make and sell WordPress themes.</p>
<h3>Automattic buys thesis.com</h3>
<p>Automattic hasn&#8217;t always owned <a href=\"http://thesis.com\">thesis.com</a>. Matt Mullenweg met a third party owner of the domain at a conference &#8212; a guy named Larry &#8212; and inquired about the domain by email in January of 2014. Chris Pearson had already attempted to purchase the domain from Larry, and did not agree to pay the $150,000 that Larry requested.</p>
<p><a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php\">According to Pearson&#8217;s accounts</a>, he and Larry had a few exchanges that stalled with Pearson unwilling to bid beyond $37,500 for the domain, and Larry sticking to $150,000. With a $100,000 offer on the table from Mullenweg, Larry gave Pearson an opportunity to buy the domain for $115,000, which he didn&#8217;t do &#8212; in part because he thought it too expensive, but also because he suspected Larry didn&#8217;t really have the offer from Mullenweg.</p>
<p>As we now know, Larry did have the offer and Automattic became the owner of the thesis.com domain name.</p>
<p>Pearson didn&#8217;t know that Mullenweg actually bought the domain until November of 2014, when he was notified by a friend that Mullenweg&#8217;s WordCamp San Francisco State of the Word Q&amp;A session included a section where Mullenweg noted that he owned the domain (more on that later).</p>
<h3>Pearson attempts to force domain transfer</h3>
<p>On April 9th, 2015, Pearson and his lawyers filed a UDRP (Uniform Domain-Name Dispute Resolution Policy) complaint, which is a formal method for resolving domain disputes, recognized by ICANN. UDRP isn&#8217;t a formal government court, but serves as arbitration for domains due to the recognition by ICANN.</p>
<p>There are many, many examples of UDRP complaints in regard to trademark infringement. There are a <a href=\"https://www.icann.org/resources/pages/policy-2012-02-25-en?routing_type=path\">number of criteria</a> that come into play that guide the UDRP panel&#8217;s decision making process.</p>
<p>The three basic tenets that must be met are as follows:</p>
<blockquote><p>(i) your domain name is identical or confusingly similar to a trademark or service mark in which the complainant has rights; and</p>
<p>(ii) you have no rights or legitimate interests in respect of the domain name; and</p>
<p>(iii) your domain name has been registered and is being used in bad faith.</p></blockquote>
<p>The panel reviews the initial complaint (in this case, by Pearson) and gives the respondent (Automattic) an opportunity to respond. All correspondence is in writing and not in person. The panel has two weeks after everything has been submitted to reach a decision.</p>
<p>In this case, which <a href=\"http://www.adrforum.com/domaindecisions/1613723.htm\">is available publicly</a>, the panel denied Pearson&#8217;s complaint.</p>
<p>Pearson&#8217;s complaint cited that he fulfilled each of the three criteria:</p>
<ul>
<li>By noting his trademark of the word &#8220;thesis&#8221;.</li>
<li>By noting that Automattic was using the domain with a commercial interest (by redirecting it to ThemeShaper).</li>
<li>By noting the bad faith clause by citing that Automattic, &#8220;purchased the disputed domain name to confuse and redirect customers and potential customers to Respondent’s competing webpage.&#8221;</li>
</ul>
<p>In the response, Automattic did not contest Pearson&#8217;s trademark on the word <em>thesis</em>. However, Automattic also noted that the word is very generic, and also that ThemeShaper was not a commercial part of Automattic, but a &#8220;blogging site.&#8221;</p>
<p>For the bad faith argument, Automattic claimed that the redirect to ThemeShaper furthers their, &#8220;purpose in providing a blogging site,&#8221; and highlights that the intention for the domain is not as a commercial entity or one to be confused with Pearson&#8217;s trademark.</p>
<h3>Automattic wins dispute</h3>
<p>Automattic won the dispute against Pearson. As noted, the panel had two weeks to deliver the decision, and Automattic proposed a settlement with Pearson before the decision was handed down.</p>
<p>Pearson was considering the settlement when the decision came a day before the two week deadline, which is apparently not a common occurrence. Had the decision not come early, Pearson may have saved himself some trouble, especially in regard to eliminating the <a href=\"http://ttabvue.uspto.gov/ttabvue/v?qs=85115266\">trademark cancellation requests</a> by Automattic on <em>thesis</em> and related terms.</p>
<p>In Pearson&#8217;s blog post, <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php\">The Truth about Thesis.com</a>, he notes the general terms of the proposed settlement:</p>
<blockquote><p>Automattic’s attorneys drafted the original settlement, which included the following terms:</p>
<ul>
<li>Automattic would keep thesis.com</li>
<li>Automattic would withdraw the federal trademark cancellation request</li>
<li>I would withdraw the UDRP</li>
<li>Both parties would mutually release one another (agree not to sue over this issue in the future)</li>
</ul>
<p>Nothing in the original settlement addressed the trademark infringement, and since this was the reason I took action in the first place, I added a requirement that Automattic no longer infringe upon my mark (which would mean they stop forwarding the domain).</p>
<p>At this point in the proceedings, I agreed to the settlement.</p></blockquote>
<p>However, since the decision came early, the settlement was never binding. It&#8217;s also worth noting that Mullenweg commented to me that Pearson&#8217;s stated terms are actually not the terms of the settlement:</p>
<blockquote><p>In the settlement Automattic offered Chris we agreed not to infringe his trademarks (which is the law, regardless of what the settlement said). He never asked us to change the redirect of thesis.com in the settlement, and if he asked after, we would have said no. There were no restrictions on thesis.com in the settlement.</p></blockquote>
<p>He also said, &#8220;I wish he had reached out before litigating,&#8221; and noted that it would have &#8220;definitely&#8221; changed the outcome of the entire situation. Whether it truly would have is neither here nor there.</p>
<h3>Possibility for appeal</h3>
<p>The UDRP doesn&#8217;t have an official appeals process. Instead, they are willing to not make the changes that a ruling states, if indeed a domain transfer or other action is ordered, if the affected party files a suit in court within ten days of the ruling.</p>
<p>In this case, Pearson did not file in a court within the given timeline, and since the ruling did not require a change in domain ownership, there is no further recourse with the UDRP. However, there is no time limit if Pearson wishes to file in court &#8212; but that is the only path remaining if he truly wants to go after the domain.</p>
<h3>Legitimacy of the trademark dispute</h3>
<p>Trademark law has a long history. Trademarks follow a categorical system, meaning words and terms must be trademarked within a particular category to be applied to.</p>
<p>Pearson has three trademarks for the Thesis and DIYthemes brands, all under <a href=\"http://www.oppedahl.com/trademarks/tmclasses.htm\">international trademark class</a> 42, for computer, scientific, and legal purposes:</p>
<ul>
<li>THESIS</li>
<li>THESIS THEME</li>
<li>DIYTHEMES</li>
</ul>
<p>The applications were filed in 2010 and registered in 2011. On June 16th, 2015, Automattic filed <a href=\"http://ttabvue.uspto.gov/ttabvue/v?qs=85115266\">cancellation requests</a> for all three trademarks, which were instituted June 25th. Pearson has 40 days from the date the application was instituted (which would be August 4th) to file a response to the cancellation requests. His answers, &#8220;must contain admissions or denials of the allegations in the petition for cancellation, and may include available defenses and counterclaims.&#8221; It is his burden as the defendant to establish his defense, and, &#8220;Failure to file a timely answer may result in entry of default judgment and the cancellation of the registration.&#8221;</p>
<p>Basically, Automattic is holding his feet to the fire to defend the trademarks, which their counsel feels should not apply for two primary reasons, as listed in their <a href=\"http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1\">formal filing</a>.</p>
<ul>
<li>The trademarks were registered in Pearson&#8217;s own name, but are used by DIYthemes, and Automattic claims that, &#8220;The Pearson Applications were improperly filed in the name of an individual, who did not have the requisite intent-to-use the marks as of the filing date, and the underlying applications are void ab initio.&#8221; Their claim notes that US Code section <a href=\"https://www.law.cornell.edu/uscode/text/15/1051\">1051(b)</a> offers this justification.</li>
<li>Furthermore, section <a href=\"https://www.law.cornell.edu/uscode/text/15/1052\">1052(e)(1)</a> requires that a trademark not be &#8220;merely descriptive,&#8221; as Automattic claims his trademarks are.</li>
</ul>
<p>If upheld, the trademarks will be deregistered by the US Patent Office, further limiting Pearson&#8217;s options to defend his claims to the thesis.com domain name in a formal court suit.</p>
<p>I don&#8217;t know how good of a case Automattic has, but purely on the surface it looks pretty good. I spent time reviewing the application and the US Code and the arguments appear fairly sound &#8212; especially the argument that Pearson applied for the trademarks as an individual and utilizes them as DIYthemes, despite DIYthemes already having been registered as an LLC.</p>
<h3>Automattic&#8217;s justification for the domain</h3>
<p>During the <a href=\"https://videopress.com/v/WmCl2kwS\">WordCamp San Francisco Q&amp;A</a>, Mullenweg noted the existence of the redirect of the domain name with a sense of pride, and a bit of a side-eyed smirk. In response to a question about relationships with commercial theme sellers and marketplaces, he states:</p>
<blockquote><p>With the premium theme and plugin folks? &#8230; We have had some ups and downs, particularly with marketplaces that didn&#8217;t follow the GPL, for example, or violated WordPress&#8217;s license &#8212; themes that violated WordPress&#8217;s license. Um, you can go to thesis.com to learn more about that. Type it in, seriously.</p></blockquote>
<p>I was at this Q&amp;A in person, and don&#8217;t remember him saying this, as it was so buried in a much larger conversation, and I was simultaneously writing a wrap-up post about the State of the Word. However, once the UDRP ruling surfaced publicly, a number of WordPress community members recalled Matt&#8217;s statement and it brought a new dimension to the ruling and Mullenweg&#8217;s motivation for the domain.</p>
<p>While Automattic bought the domain, Matt Mullenweg was clearly the driving force behind the decision. When <a href=\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks\">WP Tavern prompted Automattic</a> for a comment on their motivation for purchasing the domain, they responded with the following:</p>
<blockquote><p>We’re happy the panel ruled in our favor. We think Thesis.com is a cool, generic .com that could be used for a variety of things. Just because you have a small WordPress theme doesn’t mean you have a right to seize generic English word .com domains.</p></blockquote>
<p>We can accept Automattic&#8217;s case that they had a general interest in a generic .com domain, but in reality we know better. Mullenweg was clearly presented with an opportunity by this Larry character that checked all of the right boxes for him.</p>
<p>He could get a domain he obviously knew Pearson would want, and deny him.</p>
<p>It has a side benefit that it <em>is</em> a high quality generic domain that will likely maintain or increase its value. And he probably thought it was funny.</p>
<p>I doubt Mullenweg even knew what kind of trademarks Pearson held, but despite Pearson holding the trademarks, it seems Automattic&#8217;s attorneys now have the upper hand, and it is highly unlikely Pearson will ever own the domain now.</p>
<p>Mullenweg <a href=\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks#comment-70849\">commented</a> on his refusal to give up the domain to Pearson on WP Tavern:</p>
<blockquote><p>I’m not going to give a domain worth several hundred thousand dollars to the worst actor in the entire WP ecosystem, someone who keeps repeatedly violating the GPL and now has gone beyond that into patents. Why reward that? I wouldn’t sell it if he offered a million dollars.</p>
<p>There are so many people doing amazing things in the WP community, and 100% GPL! I can and have supported them almost every opportunity I can, and one of the things I’m most proud of in the world is how many fantastic open source businesses have been built on top of WordPress.</p>
<p>And it’s just the beginning — if you remembered in 2010 Chris said that going GPL would destroy businesses and sticking to the principles of our license would destroy investment in WordPress — we all know how that’s worked out since then.</p></blockquote>
<p>Such a statement, combined with the WCSF video, highlights that the issue is about far more than the domain and its investment potential &#8212; a 10x return in less than a year would make for an excellent investment, in the near impossible situation Pearson would offer that.</p>
<p>No, the move was quite clearly a personal one &#8212; if also convenient &#8212; for Mullenweg, and that&#8217;s why terms like &#8220;bully&#8221;, &#8220;petty&#8221;, and &#8220;spiteful&#8221; have been used by many WordPress community members surprised by his actions. They expected more. They expected better, even when directed toward someone as controversial as Chris Pearson.</p>
<h2>Pearson&#8217;s patent</h2>
<p>While a tantalizing story, the battle over thesis.com is not <em>the</em> story here. It has simply been the spark to reignite old disputes with new fervor with potentially much bigger consequences than the 2010 affair ever reached.</p>
<p>One of two additional large components of this story is an active patent application by Pearson that was submitted in 2012 and published in 2014. Keep in mind &#8212; and Chris Pearson reiterated this to me many times &#8212; it is an application for a patent, not a published patent.</p>
<h3>A patent on Thesis 2, or all web templates?</h3>
<p>The main patent is titled, <a href=\"https://patents.google.com/patent/US20140095982A1/en?q=thesis&q=diythemes\"><em>Systems, Servers, and Methods for Managing Websites</em></a>. Chris Pearson is listed as the inventor and DIYthemes the assignee.</p>
<p>The patent never mentions WordPress or WordPress themes, however both in the abstract and in the text, it does have many similarities to what one may expect as a description of a general template mechanism for a website, versus a specific description of the Thesis 2 technology.</p>
<p>Here is the abstract in full (and here is the <a href=\"https://poststatus.com/wp-content/uploads/2015/07/US20140095982-thesis-patent-app.pdf\">full patent application PDF</a>, including art):</p>
<blockquote><p>Systems, servers, and methods for managing websites. Some embodiments provide methods which include, according to a user selection of a website skin, activating the selected skin. The skin comprises at least one structural box further comprising structural code for the website. The method also includes receiving a request (for instance a call to a hook) to serve the website. Further, the method includes, responsive to the request, outputting (by echoing PHP code if desired) the structural code with style related code applied thereto according to a reference between the box and a style package (which comprises the stylistic code). The outputting can occur in an order associated with the boxes. In some situations, another skin can be activated. Moreover, a change (or, perhaps, an edit) can be made to another skin and displayed without affecting the website. Moreover, another skin can be selected and associated with the website.</p></blockquote>
<p>I discussed the patent at length with Chris Pearson, and while much of that conversation is off the record, I can share what I believe his motivations are with the patent application, and what I think the potential implications for this new chapter of Pearson versus Mullenweg are.</p>
<h3>Discovery and publicity of the patent</h3>
<p>This patent and another that&#8217;s since been rescinded were discovered by Automattic&#8217;s lawyers during the UDRP proceedings. There is debate as to how members of the WordPress community discovered the patents&#8217; existence &#8212; Jeff Chandler of WP Tavern and Carl Hancock of Gravity Forms were two of the first to discuss it publicly &#8212; but there is speculation from Chris Pearson and others that the community discovery of these patents was leaked by Mullenweg himself in order to deflect the attention at the time away from the domain issue and onto the patents and their potential implications.</p>
<p>I honestly don&#8217;t care how they came up, though Pearson&#8217;s questioning of Jeff Chandler&#8217;s journalistic integrity were uncalled for. It is anyone&#8217;s right and ability to tip someone off to legitimate news &#8212; and these patent applications are legitimate news &#8212; and I don&#8217;t believe for a second that Chandler has played puppet to his boss&#8217;s wishes. He has dutifully and to the best of his ability written about whatever news matters to the community, and I respect him for it.</p>
<p>Nevertheless, this patent does potentially have significantly more newsworthiness, depending on if it is approved and how it is defended by Pearson if it is approved.</p>
<h3>Patent law and litigation</h3>
<p>Patents often get a bad reputation, and their role in the software world is quite murky. I apologize in advance for this long sidebar on the wild world of patents.</p>
<h4>Patent trolls</h4>
<p>Most folks have heard of &#8220;patent trolls&#8221; that prey on companies using vague or overly generic patents, demanding big payouts.</p>
<p>Patent law is weird, and the lawsuits that result are infamously unpredictable and cause a scenario ripe for abuse. For example, filing patent lawsuits in one district over another can have enormous impact, like <a href=\"http://www.nytimes.com/2006/09/24/business/24ward.html?pagewanted=all&_r=0\">the case of Marshall, Texas</a>, which is a hotbed for patent trolls:</p>
<blockquote><p>Patent litigation is a growing business across the country; Marshall is just the most visible example. Among the weightier issues behind the mushrooming of its patent docket is whether the elements that have made it expand — hungry plaintiffs’ lawyers, speedy judges and plaintiff-friendly juries — are encouraging an excess of expensive litigation that is actually stifling innovation.</p>
<p>Some say yes. “A lot of the cases being filed in Marshall are by patent holding companies, or patent trolls, as they’re called, whose primary and only assets are patents,” Mr. Tyler said.</p></blockquote>
<p>Companies that deal in patents but do not utilize the patented technology are <a href=\"https://www.patentfreedom.com/about-npes/background/\">called non-practicing entities (NPEs)</a>.</p>
<p>One of the concerns with Pearson&#8217;s patent would be if it were approved and he sold it to an NPE. It&#8217;s not uncommon for NPEs to acquire patents with the express purpose to enforce them:</p>
<blockquote><p>Finally, of course, some entities buy patents with the express purpose of licensing them aggressively. For instance, about 25% of “parent” NPEs tracked by PatentFreedom are enforcing only patents that they had acquired. Another 60% are asserting patents originally assigned to them, and the remaining 15% are asserting a blend of originally assigned and acquired patents. However, if we add in the more than 2,100 subsidiaries and affiliates of these entities and treat them all as standalone entities, we find that 19% of them are originally assignees, and 69% are acquirers, and 12% are blends.</p>
<p>Regardless of the important variations in their origin and behavior, NPEs present a fundamentally different challenge than operating company patent assertions.</p></blockquote>
<h4>Software patents unpredictability and &#8220;obviousness&#8221;</h4>
<p>The concept of software patents <em>at all</em> has been in dispute for a long time. Thousands have been awarded, but there are a handful of past court rulings that seem to <a href=\"https://www.law.cornell.edu/uscode/text/35/part-II/chapter-10\">govern the US Patent and Trademark office&#8217;s interpretations</a> for making decisions when reviewing software patents.</p>
<p><a href=\"http://www.ipwatchdog.com/2014/02/01/when-is-an-invention-obvious/id=47709/\">Obviousness</a> is a key term in the patent world. Patent applicants aim to create &#8220;meaningful&#8221; patents, but &#8220;at a minimum you must have claims that embody patent eligible subject matter, demonstrate a useful invention, cover a novel invention and which are non-obvious in light of the prior art. Obviousness is typically the real hurdle to patentability, and unfortunately the law of obviousness can be quite subjective and difficult to understand. At times obviousness determinations almost seems arbitrary.&#8221;</p>
<p>&#8220;Art&#8221; is the outlay of the invention by the applicant, and the invention&#8217;s ability to be patented depends on &#8220;prior art&#8221; not deeming the invention as obvious. Establishing non-obviousness for software has a contentious history. If it can be shown that, &#8220;any combination of prior art references that when put together would be the invention in question,&#8221; then the applicant is in trouble.</p>
<p>But there is a great deal of potential for subjectivity from thousands of patent examiners:</p>
<blockquote><p>Still, ever since the Supreme Court’s decision in KSR [<a href=\"http://www.ipwatchdog.com/2012/04/29/ksr-the-5th-anniversary-one-supremely-obvious-mess/id=24456/\">reference</a>] there has been a great deal of subjectivity in the application of the law of obviousness, which is apparent if you look at the patents that issue, patents that are finally rejected and ultimately abandoned, and the patents the Federal Circuit ultimately finds to include obvious patent claims. There is little to no predictability at the edges.</p></blockquote>
<h4>The Alice case</h4>
<p>In my research, the <em>Alice case</em> came up many times as a pivotal case for helping to define the legitamacy of software patents. Martin Goetz is the holder of the first ever software patent, and has <a href=\"http://www.ipwatchdog.com/2015/02/06/alice-v-cls-bank-is-a-victory-for-software-patents/id=54489/\">an excellent write-up on the importance of the Alice case</a>.</p>
<blockquote><p>I have been asked for my opinion based my long history in the software industry and from my perspective as someone that has followed that controversial question “Is Software patentable”? That question first began to be publicly debated when I received the first software patent in 1968 for an invention on a new way of sorting data on a computer. Shortly thereafter a publication printed a page one headline “First Patent is Issued for Software, Full Implications Are Not Yet Known.”</p>
<p>Forty five years later a variation of that question was again before the Supreme Court when it agreed to hear the appeal of the Alice v. CLS Bank case.</p></blockquote>
<p>Goetz argues that the Alice case is a victory for software patents on both sides: that it helps true inventions gain patents (he and others assign a high standard to define &#8220;invention&#8221;), and it also helps prevent abuse of overly vague or non-inventive &#8220;obvious&#8221; patents to be denied:</p>
<blockquote><p>The Alice v CLS Bank Supreme Court decision in June 2014 was a great victory for those that believe that inventors that use a digital computer to innovate can get a patent on their invention. It is also a victory for those people and organizations that recognize how the patent System has been abused for many years by trolls and others where there was no invention. Since the Supreme Court decision in June, thousands of patents that should never have been issued are now being deemed invalid by the US Courts and by the Patent Office.</p></blockquote>
<h4>Obviousness and invention for Pearson&#8217;s patent</h4>
<p>This long and boring description of patents is necessary because Pearson&#8217;s patent application is still just an application, and it can be challenged, both by the patent reviewer, but also by third parties.</p>
<p>As patent obviousness is &#8220;so unevenly applied,&#8221; there is some risk in not challenging Pearson&#8217;s patent, if a third party like Automattic (or a myriad of other web template providers) is worried about the potential implications of the patent. Although, the Alice case does seem &#8212; in my very amateur opinion &#8212; to offer better guidance to reject the patent based on a lack of true invention.</p>
<h3>Pearson&#8217;s reasoning for a patent, and its likelihood for success</h3>
<p>Patents are not cheap to apply for. The patent application Pearson submitted is 34 pages of art diagrams and text describing the inventiveness of Thesis 2, though Thesis 2 is not specifically named.</p>
<p>I asked Pearson why he applied for the patent, which he did not want to share the specifics of his position due to the open nature of the application. I&#8217;ve racked my brain to try and determine the potential causes as well.</p>
<p>There are only a couple of decent outcomes for Pearson with this patent application. The most likely, and not good outcome for him, is that he is denied the patent; and in this case he would have spent a great deal of money for nothing.</p>
<p>In the event he does get the patent &#8212; or perhaps even before it is fully reviewed for approval &#8212; he could face a challenge from Automattic or other parties that may be concerned his invention&#8217;s description could apply more broadly than Thesis 2.</p>
<p>If he gets the patent, and he survives a challenge, I see three ways he could theoretically use it:</p>
<ul>
<li>He can do nothing.</li>
<li>He can sell it to the highest bidding NPE, which would be a dreadful outcome for any web entities that sell templates.</li>
<li>He can keep it in his back pocket, in case someone threatens his business or his software license, wherein he can initiate a lawsuit.</li>
</ul>
<p>Honestly, the whole patent route seems odd. I don&#8217;t love the idea of this patent being approved, because the application does seem overly broad toward all web templates to me, from the title to the meat of the application&#8217;s art. However, there are loads of patents in the world for incredibly silly things that have never really impacted a lot of folks&#8217; life; it&#8217;s just that it doesn&#8217;t mean a silly patent <em>couldn&#8217;t</em> become a problem. The Electronic Frontier Foundation has <a href=\"https://www.eff.org/patent\">mountains of evidence</a> of patent holders causing havoc.</p>
<p>I&#8217;m not much of a gambler, but if I had to gamble on this I&#8217;d put my money on this patent never being approved, and definitely never truly impacting the web or WordPress industry at scale.</p>
<p>I don&#8217;t think Pearson is a bad guy for wanting to patent his work. When I requested comment about the patents, he told me, &#8220;If I were ever to consider selling my business, things like trademarks and patents show up on the balance sheet and add to the bottom line,&#8221; but that he views them as, &#8220;one of many expensive, ridiculous options for bolstering one&#8217;s business,&#8221; versus a way to celebrate and protect his achievements as I previously characterized his intentions.</p>
<h2>The GPL</h2>
<p>Most agree that the GPL has not been well tested in court, though a <a href=\"https://en.wikipedia.org/wiki/Software_license\">software license</a> is a &#8220;legal instrument.&#8221; There is often confusion over whether a license is a contract or not.</p>
<h3>License versus contract</h3>
<p>One of my favorite <a href=\"http://softwarelawyer.blogspot.com/2008/01/jacobsen-v-katzer.html\">things I&#8217;ve read on this</a> is by former Adobe Associate General Counsel Robert Pierce:</p>
<blockquote><p>A license is not a contract. This much I know.</p>
<p>Rather, a license is a permission granted by one party to another allowing use of a property without fear of lawsuit brought by the granting party. A license does not include a return promise (i.e., consideration) from the licensee. So, as we all learned in law school, a license cannot be a contract under law. This is not to say that a license cannot be an element of a contract under which two parties trade promises, one of such promises being a license. This is commonly known as a &#8220;license agreement.&#8221; But a bald license, a one-way promise, is enforceable outside of contract law. It is something apart. It exists and is enforceable under property law doctrine.</p>
<p>What makes things difficult is that the scope of a license&#8217;s grant, and the conditions and restrictions on the license (or all of them together) can make what is intended to be a one-way license look a lot like a contract. The precise wording used becomes critical.</p></blockquote>
<p>The distinction can be significant because, &#8220;contracts are enforceable by contract law, whereas licenses are enforced under copyright law,&#8221; though even this rule depends on the jurisdiction where the matter is being discussed. His larger point is that a license is a one-way street, whereas a contract is agreed upon by both sides.</p>
<h3>Spirit of the GPL</h3>
<p>There is little debate that a &#8220;Split GPL&#8221; or &#8220;PHP GPL&#8221; license is perfectly GPL compatible, though Mullenweg doesn&#8217;t consider that the &#8220;<a href=\"https://github.com/WordPress/book/blob/e55a93f1056ffac8466944086b2c5104becab9c4/Content/Part%206/42-spirit-of-the-gpl.md\">spirit of the GPL</a>,&#8221; and companies like Envato&#8217;s ThemeForest and others have felt the consequences of not adopting 100% GPL licenses.</p>
<p>From <em>Milestones</em>:</p>
<blockquote><p>While not everyone liked the fact that the WordPress project would only support 100% GPL products, most people had accepted it. Many, however, were taken by surprise, by a sudden flare-up around not just the legalities of the GPL, but the “spirit” of the license. In a 2008 interview, Jeff Chandler asks Matt about the spirit of the GPL. Matt says that the spirit of the GPL is about user empowerment, about the four freedoms: to use, distribute, modify, and distribute modifications of the software. Software distributed with these four freedoms is in the spirit of the GPL. WordPress was created and distributed in this spirit, giving users full freedom with regard to the software.</p>
<p>The Software Freedom Law Center&#8217;s opinion &#8212; with regards to WordPress themes, however &#8212; gives developers a loophole, one that helps them achieve GPL compliance, but denies the same freedoms as WordPress. PHP in themes must be GPL, but the CSS, images, and JavaScript do not have to be GPL. This is how Thesis released with a split license &#8212; the PHP was GPL, while the rest of the code and files were proprietary. This split license ensures that the theme is GPL compliant yet it isn&#8217;t released under the same spirit as the GPL&#8217;s driving user-freedom ethos.</p>
<p>The loophole may have kept theme sellers in line with the GPL, but WordPress.org didn&#8217;t support that approach. In a 2010 interview, Matt says “in the philosophy there are no loopholes: you’re either following the principles of it or you’re not, regardless of what the specific license of the language is.&#8221; Theme sellers that sell their themes with a 100% GPL license are supported by WordPress. Those that aren’t don’t get any support or promotion on WordPress.org or on official resources. This is also one of the WordCamp guidelines, introduced in 2010; that WordCamps should promote WordPress’ philosophies. If a speaker, volunteer, or organizer is distributing a WordPress product it needs to be 100% GPL, i.e., the CSS, JavaScript, and other assets need to be GPL, just like the PHP.</p></blockquote>
<p>Mullenweg believes that Thesis 2 is not only not in the spirit of the GPL, but flagrantly operates in total violation of it, as Thesis 2 carries a 100% proprietary license. Considering the implications for folks that make stuff compatible with the GPL, it&#8217;s little surprise that Mullenweg has taken the stance and actions he has toward Pearson.</p>
<h3>Thesis 2 carries a proprietary license</h3>
<p>Chris Pearson&#8217;s <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962\">comment on his blog post</a> describes that the theme has always been a proprietary license, and he describes why it is okay to be such:</p>
<blockquote><p>In October 2012, I released an all-new version of Thesis that carried the same name as the original (which had a split-GPL license), but that’s where the similarities stopped.</p>
<p>The new Thesis is not a Theme—it is an operating system for templates and design. This system runs Skins and Boxes, which are similar to Themes and Plugins, but with a boatload of built-in efficiencies that Themes and Plugins cannot provide.</p></blockquote>
<p>It is worth noting the final paragraph of the SFLC&#8217;s opinion that Mullenweg has cited numerous times as justification against proprietary licenses <em>does</em> have a provision for avoiding WordPress&#8217;s copyright:</p>
<blockquote><p>Finally, we note that it might be possible to design a valid WordPress theme that avoids the factors that subject it to WordPress’s copyright, but such a theme would have to forgo almost all the WordPress functionality that makes the software useful.</p></blockquote>
<p>That&#8217;s exactly what Pearson believes Thesis 2 is. But the GPL has rarely been tested in a proper court, and never from a WordPress perspective. The SFLC&#8217;s opinion is just that, for now, whether Mullenweg likes it or not.</p>
<h3>The GPL in court</h3>
<p>The Free Software Foundation maintains the copyright on the text of the GPL itself, and between the FSF and the SFLC, a <a href=\"https://en.wikipedia.org/wiki/GNU_General_Public_License#Legal_status\">small number of lawsuits</a> have occurred, and a German court upheld the GPL as a &#8220;valid, legally binding&#8221; license, but most of these tests have occurred outside of the United States. From what I can tell, cases involving the GPL have largely settled outside of court when based in the United States, or were argued on whether the GPL was legally applied, like in the case of <a href=\"https://en.wikipedia.org/wiki/SCO_Group,_Inc._v._International_Business_Machines_Corp.#The_GPL_issue\">SCO vs IBM</a>, rather than whether the GPL was legally binding itself.</p>
<p>In another case, <a href=\"https://en.wikipedia.org/wiki/Wallace_v._International_Business_Machines_Corp.\">Wallace vs FSF</a>, Daniel Wallace compared the GPL to price fixing, as it required software to be free. The FSF won the case, as the judge cited, &#8220;The GPL encourages, rather than discourages, free competition and the distribution of computer operating systems, the benefits of which directly pass to consumers. These benefits include lower prices, better access and more innovation.&#8221;</p>
<p>A much <a href=\"http://www.infoworld.com/article/2893695/open-source-software/vmware-heading-to-court-over-gpl-violations.html\">newer case involving VMware</a> again tests the GPL. The Software Freedom Conservancy, &#8220;claims VMware is using the Linux kernel without respecting the terms of its copyright license, the GPL.&#8221; This case may offer a better precedent for WordPress and its derivative works, as it is centered on &#8220;module loading&#8221; in VMware, &#8220;with an insulating layer to allow its kernel to use unmodified Linux drivers.&#8221; The case gets murkier than that, as it may not have been as isolated as it was attempted, but the result could be decent precedent for similarly loading WordPress themes and plugins, in my opinion.</p>
<h3>Limited guidance</h3>
<p>Few lawyers want to be the first to test something in court. It&#8217;s easier to make a case when there are many cases before you to provide guidance. With the GPL, there is what&#8217;s called &#8220;limited guidance,&#8221; meaning that it&#8217;s untested, and therefore the outcome of a GPL case in the US could be very difficult to predict.</p>
<p>If a lawsuit does occur, it could prove costly to all parties involved, and I think it&#8217;s clear that Pearson and Mullenweg both wish that litigation was not happening, though both of them maintain a bit of a &#8220;you started it&#8221; attitude.</p>
<p>Without a formal court proceeding, which could last years, it&#8217;s going to be near impossible for Matt Mullenweg to fully prevent non-GPL compatible licenses to exist for WordPress themes and plugins. His best method to prevent it is to do what he&#8217;s done so far: make an example of bad offenders and cause anyone thinking of using a non-GPL compatible license to reconsider.</p>
<h2>Are all WordPress themes derivative works?</h2>
<p>A key question to whether themes and plugins must be GPL compatible licensed is whether the theme or plugin is a derivative of WordPress itself. If it is derivative, then it is under the umbrella of the GPL&#8217;s Copyleft nature.</p>
<p>Folks disagree a good bit on how themes and plugins should be considered as derivative works, though most either agree with Mullenweg&#8217;s strict &#8220;spirit of the GPL&#8221; view, or at least have molded to avoid being an outcast.</p>
<p>The strongest argument I&#8217;ve seen in favor of all themes being derivative of WordPress &#8212; no matter how much or little they rely on WordPress functionality &#8212; is from WordPress lead developer Mark Jaquith:</p>
<blockquote><p>There is a tendency to think that there are two things: WordPress, and the active theme. But they do not run separately. They run as one cohesive unit. They don’t even run in a sequential order. WordPress starts up, WordPress tells the theme to run its functions and register its hooks and filters, then WordPress runs some queries, then WordPress calls the appropriate theme PHP file, and then the theme hooks into the queried WordPress data and uses WordPress functions to display it, and then WordPress shuts down and finishes the request. On that simple view, it looks like a multi-layered sandwich. But the integration is even more amalgamated than the sandwich analogy suggests.</p>
<p>Here is one important takeaway: <em>themes interact with WordPress (and WordPress with themes) the exact same way that WordPress interacts with itself</em>. Give that a second read, and then we’ll digest.</p>
<p>The same core WordPress functions that themes use are used by WordPress itself. The same action/filter hook system that themes use is used by WordPress itself. Themes can thus disable core WordPress functionality, or modify WordPress core data. Not just take WordPress’ ultimate output and change it, but actually reach into the internals of WordPress and change those values before WordPress is finished working with them. If you were thinking that theme code is a separate work because it is contained in a separate file, also consider that many core WordPress files work the same way. They define functions, they use the WordPress hook system to insert themselves at various places in the code, they perform various functions on their own but also interact with the rest of WordPress, etc. No one would argue that these core files don’t have to be licensed under the GPL — but they operate in the same way that themes do!</p>
<p>It isn’t correct to think of WordPress and a theme as separate entities. As far as the code is concerned, they form one functional unit. The theme code doesn’t sit “on top of” WordPress. It is within it, in multiple different places, with multiple interdependencies. This forms a web of shared data structures and code all contained within a shared memory space. If you followed the code execution for Thesis as it jumped between WordPress core code and Thesis-specific code, you’d get a headache, because you’d be jumping back and forth literally hundreds of times. But that is an artificial distinction that you’d only be aware of based on which file contained a particular function. To the PHP parser, it is all one and the same. There isn’t WordPress core code and theme code. There is merely the resulting product, which parses as one code entity.</p></blockquote>
<p>Jaquith&#8217;s argument that the theme and WordPress execute together to form a joint &#8220;modified work&#8221; is the key phrase, I believe. As he states, and I tend to agree, it does not matter that the files are separate or that they can be distributed independently; together, when executed, they are so intertwined that they become a single work.</p>
<p>That said, the theme is clearly dependent on WordPress itself, which is another common justification that themes are derivative. Explaining this concept is simple: WordPress can be distributed without any theme but those that ship with it by default. But a distributed theme, like Thesis, must be <em>installed and activated using WordPress&#8217;s own schema for loading a template</em>, and cannot operate independently of WordPress.</p>
<h3>What about the WordPress REST API?</h3>
<p>Thus far, we&#8217;ve discussed the derivative nature of WordPress themes and plugins, which require they operate within the WordPress install. It is a different matter if we consider applications that consume data or interact with WordPress as an outside application.</p>
<p>The WordPress REST API enables one to interact with or consume data from WordPress, while being wholly independent of the WordPress install. Jaquith makes a clear exception for a scenario like this (and also applies it to technologies like RSS and XML-RPC):</p>
<blockquote><p>Something that interacts with these APIs sits entirely outside of WordPress. Google Reader doesn’t become part of WordPress by accessing your feed, and MarsEdit doesn’t become part of WordPress when you use it to publish a post on your WordPress blog. These are separate applications, running separately, on separate codebases. All they are doing is communicating. Applications that interact with WordPress this way are separate works, and the author can license them in any way they have authority to do so.</p></blockquote>
<h3>The GNU&#8217;s take</h3>
<p>The GNU agrees with Jaquith&#8217;s take. They provide <a>an FAQ</a> to answer, &#8220;&#8221;What is the difference between an &#8216;aggregate&#8217; and other kinds of &#8216;modified versions&#8217;?&#8221; The emphasis provided is my own:</p>
<blockquote><p>An “aggregate” consists of a number of separate programs, distributed together on the same CD-ROM or other media. The GPL permits you to create and distribute an aggregate, even when the licenses of the other software are non-free or GPL-incompatible. The only condition is that you cannot release the aggregate under a license that prohibits users from exercising rights that each program&#8217;s individual license would grant them.</p>
<p><em>Where&#8217;s the line between two separate programs, and one program with two parts? This is a legal question, which ultimately judges will decide</em>. We believe that a proper criterion depends both on the mechanism of communication (exec, pipes, rpc, function calls within a shared address space, etc.) and the semantics of the communication (what kinds of information are interchanged).</p>
<p><em>If the modules are included in the same executable file, they are definitely combined in one program. If modules are designed to run linked together in a shared address space, that almost surely means combining them into one program</em>.</p>
<p>By contrast, pipes, sockets and command-line arguments are communication mechanisms normally used between two separate programs. So when they are used for communication, the modules normally are separate programs. But if the semantics of the communication are intimate enough, exchanging complex internal data structures, that too could be a basis to consider the two parts as combined into a larger program.</p></blockquote>
<p>The GNU argument falls very much in line with Jaquith&#8217;s, though admits itself that judges must decide whether it&#8217;s the case, in the end.</p>
<h3>The case against The GNU position on derivative works</h3>
<p>The University of Washington School of Law has a <a href=\"http://www.law.washington.edu/lta/swp/index.html\">section of their website</a> devoted to the, &#8220;business, legal and technical consequences of choosing Open Source Software (OSS) or proprietary software.&#8221; They cover many of the topics I&#8217;ve outlined in this post so far, and <a href=\"http://www.law.washington.edu/lta/swp/Law/derivative.html\">in the case of the GPL and derivative works</a>, they believe the GNU is overstepping with an &#8220;expansive definition&#8221; of derivative works with consequences, &#8220;counter to the goals of the proponents of Free Software.&#8221;</p>
<p>The most compelling of multiple derivative works examples they provide is that of subclasses. For example, imagine a class, <code>Some_Theme_Class</code> that extends <code>Some_Core_WordPress_Class</code>. The GPL FAQ is very hardline on the topic (and for what it&#8217;s worth, Thesis 2 does extend some WordPress core classes). Washington believes the GNU stance on inheritance is too over-reaching:</p>
<blockquote><p>Example 5: Programmer X wishes to write a class D, that is a subclass of existing class B. Class B is subject to the terms of the GPL. If X distributes D, does it have to be licensed under the terms of the GPL?</p>
<p>The answer given in the GPL FAQ is short and to the point: &#8220;Subclassing is creating a derivative work.&#8221; In our example, this makes D a work derived from B, and thereby makes D subject to the terms of the GPL upon distribution. This approach attempts to further broaden the reach of the GPL, but it again leads to counter-intuitive results.</p>
<p>Typical object oriented programming languages include a standard class hierarchy. This hierarchy provides a framework within which application developers can build their programs. The standard classes typically provide useful classes that represent user interface elements (e.g. windows, buttons, etc.), collection classes (for handling collections of data), and input-output abstractions (e.g. files and networking connections). In many object oriented languages, each class must be a subclass of exactly one superclass. And for this reason, the class hierarchies are rooted by a highly generic, standard class called Object. (The question of the superclass of Object is beyond the scope of this article.) The class Object describes only the most general properties and behaviors. For instance, in Java, the class Object only performs a handful of functions. In Java, every class is a subclass (directly or indirectly) of the Object class. Under the GPL approach, then, every program written in Java is a derived work of Object, because every program written in Java by definition consists of classes that inherit from the Object class.</p></blockquote>
<p>Whether this argument or any of the others Washington outlines would apply to WordPress themes and/or plugins would, again, need to be settled in court. But Washington does give a compelling argument.</p>
<p>They conclude with the following:</p>
<blockquote><p>In some ways, the apparent weaknesses in the GPL should come as no surprise, as the GPL was born of an era in which the central artifact of software development and distribution was the monolithic executable. In such a universe, software development proceeded principally by modifying the existing source text of programs, compiling source modules, linking the corresponding object files, and distributing the resulting executable. This model of software development and distribution has become increasingly fractured in an era characterized by highly dynamic, late binding, object- and network-based systems. The GPL, consequently, strains to cover these newly arising scenarios.</p>
<p>To effectuate the goals of the free software movement, the drafters of the GPL urge a generally expansive definition of derivative work. The great irony is, of course, that such an expansive definition would have second order consequences that are exactly counter to the goals of the proponents of Free Software. A broad definition of derivative would give code authors less freedom to create software that they can truly call their own and do with as they please. And if naive analytic approaches such as &#8220;subclassing equals derivation&#8221; reign, then proprietary vendors such as Microsoft could arguably stake claim to every program ever written in C#, because they authored the original class hierarchy. And since it seems unlikely that courts would employ different standards depending on the goals or ideological motivations of licensors, proponents of free software might want to be careful what they wish for: what&#8217;s good for the GNU might not be good for the gander.</p></blockquote>
<h3>Aggressive license agreements</h3>
<p>Both the GPL and DIYthemes&#8217; proprietary license could be appropriately identified as aggressive. The Copyleft nature of the GPL annoys many open source advocates, who would prefer a less restrictive license for developers, like the MIT or BSD licenses. The GPL is absolutely an opinionated license.</p>
<p>Pearson&#8217;s proprietary license is also aggressive, in the other direction. I&#8217;ve never purchased a WordPress-centric product that so strongly forced me to accept a license. Usually, you have to look in the source code or a page on the website for a license; DIYthemes forces you to accept the <a href=\"http://diythemes.com/thesis/rtfm/software-extensions-license-agreement/\">terms of the proprietary license</a> before you can download the product at all.</p>
<h3>Derivative works are not a bright line</h3>
<p>The GNU attempts to offer a &#8220;bright line&#8221; distinction for derivative works. A bright line, in much of the legal analysis I&#8217;ve read, is where <em>thing x</em> is so because of <em>thing y</em>, and can be applied across the board. You can clearly see the bright line, and when it has been crossed.</p>
<p>Washington proves the point quite well that the GNU&#8217;s bright line approach to derivation is quite challengeable. But I don&#8217;t think their arguments prove that WordPress themes in particular are not derivative. I believe, from a legal perspective, it&#8217;s fuzzier than a bright line approach, and if I were Mullenweg or anyone defending GPL software, I would not be excited to take the issue to court.</p>
<p>The &#8220;spirit of the GPL&#8221; is to offer users liberal freedoms, even while restricting developers building on a GPL licensed application. And I believe there is merit in the fact that WordPress, its co-founders, its lead developers, and the vast majority of its copyright holders (contributors) wish to defend the spirit of the license, even if it&#8217;s not been tested in court.</p>
<p>Pearson is not in the majority opinion by using a proprietary license, but he is also not definitively in a position of legal wrongdoing. His desire to protect his works from user freedoms with a proprietary license may well be tested all the way to the courts, and he must be prepared to deal with that, but I don&#8217;t believe there is clear wrongdoing, legally, with his license.</p>
<h2>A tale of idealism</h2>
<p>Matt Mullenweg and Chris Pearson are two of the most idealistic people I&#8217;ve ever observed. They are near polar opposites, from their business belief systems and even their general world views.</p>
<p>One of the most depressing components of my research was something Pearson told me. I asked him why he doesn&#8217;t just get out of it all and do something else. He&#8217;s not married to the culture of WordPress bestowed on it by its leaders. He called it, the &#8220;zeitgeist of western culture,&#8221; with its openness, zen attitude, and more that he feels no need to embrace if he doesn&#8217;t want to.</p>
<p>But he admits that WordPress, &#8220;is the most used piece of software to build a website in the world. WordPress was the beneficiary of impeccable timing.&#8221; And it&#8217;s a tool for him to make his living; it&#8217;s his job, and he doesn&#8217;t see a need to be in love with every aspect of his job. This is what made me sad, because for most of us that make our living within this space, we were able to escape the &#8220;it&#8217;s just a job&#8221; mentality and be emotionally enriched by what is possible on the open web.</p>
<p>Matt could probably drop his various issues with Pearson and life would go on. The vast majority of WordPress businesses could understand the status quo and live by it, and those that don&#8217;t can keep living their lives outside of the approval of Mullenweg, and for that matter, the official WordPress project and website. But he too insists to stand up for his ideals and the web he believes in. He sees himself as a defender of the user, and his defense of the GPL is an extension of his core beliefs on software.</p>
<p>They will never agree on licensing, that much is clear. The question of what&#8217;s next is multi-layered.</p>
<h3>Will litigation continue?</h3>
<p>Undoubtedly, yes, litigation will continue. But the litigation should be viewed as three distinct parts:</p>
<ul>
<li>In regard to the thesis.com domain, it&#8217;s really a sideline issue that resulted from more deep-rooted differences in ideals that turned into a personal spat. Pearson may continue in court to try and get the domain back, but I doubt it. I don&#8217;t know if Automattic will relent on the trademark cancellation requests, but I wouldn&#8217;t be surprised if they dropped it in some form of settlement.</li>
<li>The patent issue is not over. I believe Automattic and potentially other organizations will challenge Pearson&#8217;s patent application using a variety of legal options available. The chances the patent gets approved or holds up long term are unlikely (but yes, it is possible), and I don&#8217;t believe there is a significant chance it will have longstanding implications on the WordPress project.</li>
<li>I believe the GPL will continue to be tested in court, and eventually we may have a proper precedent set to put current questions aside. I won&#8217;t pretend a guess how it will turn out, because I think it truly depends on many, many factors. I do think that if Matt Mullenweg pursues a case himself, he will be joined by a number of interested organizations, including the Free Software Foundation; or the GPL debate could be settled in court in a completely different dispute, unrelated to WordPress &#8212; but have a longstanding impact on products made for WordPress.</li>
</ul>
<h3>Is this debate bad for WordPress?</h3>
<p>The <em>way</em> this debate has occurred is bad for WordPress. Neither Matt Mullenweg nor Chris Pearson looks like a saint right now. And parts of the whole thing don&#8217;t do a whole lot to further the conversation.</p>
<p>At the root of the debate is licensing, and that debate is worth having.</p>
<p>It is important that we separate the intent and the legal interpretation of the GPL. It is also important that we separate one&#8217;s legal ability to not license distributed WordPress products as GPL compatible, versus the business and community consequences that may result from such a decision.</p>
<h2>Endmatter</h2>
<p>This post would not be possible without the Post Status <a href=\"https://poststatus.com/partners\">Partners</a> and <a href=\"https://poststatus.com/profiles\">Members</a> that fund the website, and my ability to write about WordPress full time. If you enjoyed this post, please consider becoming a <a href=\"https://poststatus.com/club\">Post Status member</a> to fund more free content, plus loads of great members-only benefits, including a daily-ish newsletter that keeps you covered on the happenings of the WordPress world.</p>
<p>I would also like to thank Matt Mullenweg and Chris Pearson for the interviews they provided me in preparation of this post.</p>
<p>And I&#8217;d like to thank my lawyer, <a href=\"http://associatesmind.com\">Keith Lee</a> (a WordPress fan and blogger himself!) for helping me think through some of the legal matters discussed &#8212; though the opinions themselves are my own.</p>
<p>Finally, I&#8217;d like to thank the folks that helped me review the post, consider my positions, and organize my thoughts. You know who you are.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 24 Jul 2015 01:42:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: Who’s Using the WordPress REST API?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47039\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"http://wptavern.com/whos-using-the-wordpress-rest-api\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4659:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg?resize=1025%2C469\" alt=\"wp-rest-api\" class=\"aligncenter size-full wp-image-43000\" /></a></p>
<p>Ryan McCue and the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">WP REST API</a> team are <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/\" target=\"_blank\">seeking feedback</a> on the project ahead of the API merging into core. McCue invited comments on the post to find out how and where it&#8217;s currently being used, in hopes of identifying any roadblocks developers may be facing.</p>
<p>&#8220;We’d love to hear feedback from everyone using this, from JS-only developers coming to WP for the first time, through WordPress plugin and theme developers, all the way through to PHP developers not involved with WordPress,&#8221; he said.</p>
<p>Comments on the post provide a nice overview of places where the API is already in use in production all over the WordPress development community. A few examples include:</p>
<ul>
<li><a href=\"https://hmn.md/\" target=\"_blank\">Human Made</a> uses the API with client projects, i.e. to create a Node-powered frontend and maintain the familiar WordPress admin.</li>
<li><a href=\"http://reactor.apppresser.com/\" target=\"_blank\">Reactor</a> uses the API to create mobile apps that digest the API themselves.</li>
<li><a href=\"http://aesopstoryengine.com/\" target=\"_blank\">Aesop Interactive</a> uses the API with <a href=\"http://wptavern.com/lasso-frontend-editing-plugin-for-wordpress-now-available-on-github\" target=\"_blank\">Lasso</a> and also to power the <a href=\"http://wptavern.com/new-wp-live-search-plugin-utilizes-the-wp-rest-api\" target=\"_blank\">WP Live Search</a> plugin.</li>
<li>A large industrial real estate firm manages its properties via an internal proprietary .NET app with a public-facing site powered by WP. It uses the API to sync property data (in real time) between the internal app and the website so the real estate listings will always be current.</li>
<li><a href=\"https://www.joininuk.org/\" target=\"_blank\">Join In</a>, a site organizing volunteers in the UK, used the API to create <a href=\"https://www.joininuk.org/widget/\" target=\"_blank\">an embeddable JS widget</a>.</li>
<li><a href=\"https://profiles.wordpress.org/pers/\" target=\"_blank\">Per Soderlind</a> used the WP REST API as <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26372\" target=\"_blank\">a backend for an iOS application</a> for the Norwegian Ministry of Petroleum and Energy.</li>
<li><a href=\"http://tri.be/about/\" target=\"_blank\">Modern Tribe</a> is building sites that use the REST API to power both Handlebars and full page React templates in themes.</li>
</ul>
<p>Those are just a small sampling of places where the API is being used to make WordPress more flexible for creating custom solutions. For many who are using the API or hoping to use it, the main hindrance is that it&#8217;s not yet in core.</p>
<p>&#8220;The biggest issue right now is that the REST API isn’t included in core,&#8221; a representative from Ashworth Creative <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26390\" target=\"_blank\">commented</a>. &#8220;If we build plugins or a theme that needs to consume data asynchronously, we’d either have to bundle the API and have to maintain it in our repositories as a dependency, or have clients install and maintain it on their own.&#8221;</p>
<p>WordPress developer Nate Wright echoed that opinion and is eager to be able to extend it for use in his products, without having to include it as a plugin.</p>
<p>&#8220;Put it in core, so that as a plugin developer I can make use of it in my products,&#8221; he <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/#comment-26367\" target=\"_blank\">said</a>. &#8220;I built the most popular Restaurant Reservations plugin in the .org repo, and I am eager to add a robust capacity/table management component for it using the REST API and a jQuery/Underscore/Backbone stack.&#8221;</p>
<p>Early adopters have the unique opportunity to provide feedback on the REST API and help shape priorities for development. If you are using the API somewhere in the wild, make sure to <a href=\"https://make.wordpress.org/core/2015/07/23/rest-api-whos-using-this-thing/\" target=\"_blank\">leave your feedback on McCue&#8217;s post</a> to help the team make any necessary changes required before it&#8217;s merged into core.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 21:15:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"WPTavern: WPWeekly Episode 200 – The Big Two Oh Oh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=47083&preview_id=47083\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wptavern.com/wpweekly-episode-200-the-big-two-oh-oh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3495:\"<p>In this special 200th episode of WordPress Weekly, I&#8217;m joined by <a href=\"http://marcuscouch.com/\">Marcus Couch</a>, <a href=\"http://strangework.com/\">Brad Williams</a>, <a href=\"http://www.ronalfy.com/\">Ronald Huereca</a>, and <a href=\"http://piratedunbar.com/\">Ptah Dunbar</a>. Brad, Ronald, and Ptah were among the first to support WordPress Weekly. They helped get the show off the ground and provided momentum.</p>
<p>Seven years have passed since I started WordPress Weekly. In those seven years, each one of my guests have gone on to do great things with WordPress. We find out what they&#8217;re up to these days and recall memorable moments of the show. Near the beginning of the show, we held a moment of silence in Kim&#8217;s memory.</p>
<p>I had a great time hosting episode 200, but I&#8217;m sad that the <a href=\"http://wptavern.com/kim-parsell-affectionately-known-as-wpmom-passes-away\">late Kim Parsell</a> couldn&#8217;t celebrate with us. When I started WordPress Weekly in 2008, Kim would often join me on each episode to provide a countdown before I pressed the record button.</p>
<p>She was occasionally a <a href=\"http://wptavern.com/wpweekly-episode-87-%E2%80%93-the-lost-episode\">guest on the show</a>. After the show, she would stick around for a half hour to an hour to talk about whatever was on her mind. In many ways, the show offered her an opportunity to connect and speak to WordPress people every week. It was the closest thing to a meetup she could regularly attend.</p>
<p>Thanks to everyone who listens to the show and provides us with valuable feedback. Join us next Wednesday, as we begin the journey to episode 300.</p>
<h2>History of WordPress Weekly:</h2>
<ul>
<li>My first show on Talkshoe.com was 7 years ago on January 11th, 2008.</li>
<li>WordPress 2.3.2 was released.</li>
<li>WordPress 2.5 took the place of 2.4.</li>
<li>Episode 100 was on June 5th 2010.</li>
<li>I took a two year break after episode 117 October 28th, 2011.</li>
<li>I resumed the show on August 16th 2013 which was also my last show on Talkshoe.</li>
<li>Marcus became a co-host January 18th, 2014, on Episode 134.</li>
</ul>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/flow-flow-social-streams/\">Flow-Flow Social Streams</a> lets you display your Facebook, Twitter, and Instagram messages in a responsive grid.</p>
<p><a href=\"https://wordpress.org/plugins/test-gateway-for-woocommerce/\">Test Payment Module for Woocommerce</a> gives you the option to test payments in WooCommerce locally without using services such as Paypal or Authorize.net.</p>
<p><a href=\"https://wordpress.org/plugins/easy-backup-by-supsystic/\">DropBox Backup by Supsystic</a> allows you to backup to Dropbox and FTP with one click. You can also restore full or partial backups from DropBox.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 29th 4 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #200:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 20:30:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: Philadelphia, PA to Host WordCamp US December 4th–6th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://wptavern.com/philadelphia-pa-to-host-wordcamp-us-december-4th-6th\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1943:\"<p>Matt Mullenweg <a href=\"http://ma.tt/2015/07/wcus-philadelphia/\">announced</a> that Philadelphia, PA, will host WordCamp US December 4th–6th at the <a href=\"http://www.paconvention.com/Pages/default.aspx\">Pennsylvania Convention</a> center. Philadelphia will also host WordCamp US in 2016, although no dates have been chosen yet.</p>
<p>According to Mullenweg, &#8220;Having it the same place two years in a row allows us to keep logistics a set variable and really focus on the rest of the event in the second year.&#8221; The 2017 and 2018 host cities will be chosen in between the first and second event. This allows the team in the host city to volunteer and gain on-the-ground experience in Philadelphia.</p>
<p>Out of six cities chosen to possibly host WordCamp US and 1,390 total voters, Tavern <a href=\"http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us\">readers voted</a> to have it in Phoenix, AZ, citing <a href=\"http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us#comment-70157\">its warm weather</a> during winter months. Philadelphia, home of the cheesesteak, was a close second.</p>
<p>The event is inspired by WordCamp Europe, where organizers take an entire year to <a href=\"http://wptavern.com/vienna-austria-to-host-wordcamp-europe-2016\">plan and coordinate</a> the event. Some <a href=\"http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us#comment-70055\">readers questioned</a> whether the event would be held this year considering <a href=\"http://wptavern.com/wordcamp-us-2015-now-accepting-applications-for-host-city\">applications to be the host city </a>weren&#8217;t accepted until June.</p>
<p>With only half a year to plan and organize WordCamp US, it will be interesting to see how the first one goes. Let us know if you plan on attending the event and if you&#8217;re going to bring ear muffs as Philadelphia during that time of year is cold.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 17:31:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"Matt: WordCamp US to be in Philadelphia\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45259\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/07/wcus-philadelphia/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1188:\"<p><img class=\" wp-image-45261 alignright\" src=\"http://i1.wp.com/ma.tt/files/2015/07/wordcamp1-e1437663434378.png?resize=303%2C309\" alt=\"WordCamp US\" />There were <a href=\"http://ma.tt/2015/06/wordcamp-us-survey/\">amazing applications</a> for teams and cities to host the inaugural WordCamp US, a concept originally floated at <a href=\"http://wordpress.tv/2014/10/26/matt-mullenweg-the-state-of-the-word-2014/\">the State of the Word last year</a>. It was very hard to make a choice, but can now announce that the birthplace of the United States, <strong>Philadelphia, will host the first WCUS on December 4th&#8211;6th</strong>. They will also host it in 2016, but no dates have been chosen yet.</p>
<p>Having it the same place two years in a row allows us to keep logistics a set variable and really focus on the rest of the event in the second year. I also want to use it to facilitate experience transfer: We&#8217;ll choose the 2017 + 2018 host city in between the first and second event, so that team can volunteer on the ground the second year Philadelphia hosts it to learn from their experience. Hat tip: Cool graphic by <a href=\"http://visualrhythm.com/\">Andrew Bergeron</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 16:38:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"WPTavern: WordPress 4.2.3 is a Critical Security Release, Fixes an XSS Vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=47045\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:93:\"http://wptavern.com/wordpress-4-2-3-is-a-critical-security-release-fixes-an-xss-vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3025:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/03/security.jpg?resize=1024%2C514\" alt=\"photo credit: Lock - (license)\" class=\"size-full wp-image-40187\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/58441544@N00/2660230441\">Lock</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>WordPress users in the Americas woke this morning to find update notices in their inboxes due to a critical security vulnerability. <a href=\"https://wordpress.org/news/2015/07/wordpress-4-2-3/\" target=\"_blank\">WordPress 4.2.3</a> was released today and automatically pushed out to sites that have auto-updates enabled.</p>
<p>Because this is a security release for all previous versions of WordPress, those who do not have automatic update enabled will need to manually update their sites immediately. Core contributor Gary Pendergast explained the severity of the bug in the release post:</p>
<blockquote><p>WordPress versions 4.2.2 and earlier are affected by a cross-site scripting vulnerability, which could allow users with the Contributor or Author role to compromise a site. This was reported by <a href=\"https://profiles.wordpress.org/duck_\" target=\"_blank\">Jon Cave</a> and fixed by <a href=\"http://www.miqrogroove.com/\" target=\"_blank\">Robert Chapin</a>, both of the WordPress security team.</p>
<p>We also fixed an issue where it was possible for a user with Subscriber permissions to create a draft through Quick Draft.</p></blockquote>
<p>Pendergast thanked all parties reporting vulnerabilities for <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\" target=\"_blank\">responsibly disclosing them </a> to the WordPress security team.</p>
<p>This release also contains fixes for 20 bugs from 4.2, including one that might require you to update your database before being allowed back into the admin.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-update-db.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-update-db.jpg?resize=773%2C370\" alt=\"wp-update-db\" class=\"aligncenter size-full wp-image-47047\" /></a></p>
<p>Not all WordPress users who are updating will be greeted with this message, but if you see it, don&#8217;t panic. It&#8217;s related to one of the bug fixes included in the release.</p>
<p>&#8220;It was a bug fix in 4.2.3, not backported &#8211; some versions of PHP didn&#8217;t run the utf8mb4 update correctly,&#8221; Pendergast said when asked about the required database update.</p>
<p>Unfortunately, in some instances, clicking the &#8220;Update WordPress Database&#8221; button may require multiple attempts. This is unusual but Pendergast said that improving database upgrades is high on the team&#8217;s list of priorities.</p>
<p>A list of all the files revised is available on the <a href=\"https://codex.wordpress.org/Version_4.2.3\" target=\"_blank\">4.2.3 release page</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 14:06:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: WordPress Custom Post Type UI Plugin Passes 1 Million Downloads\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46940\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/wordpress-custom-post-type-ui-plugin-passes-1-million-downloads\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5094:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/celebration.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/celebration.jpg?resize=960%2C482\" alt=\"photo credit: Stephanie McCabe\" class=\"size-full wp-image-47036\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/6V12NODFVM\">Stephanie McCabe</a>
<p>In June of 2010, <a href=\"http://codex.wordpress.org/Version_3.0\" target=\"_blank\">WordPress 3.0</a> Thelonious was released with the historic merge of WordPress MU into core and the debut of the brand new Twenty Ten default theme. This pivotal release also gave developers the ability to register their own <a href=\"http://codex.wordpress.org/Custom_Post_Types\" target=\"_blank\">custom post types</a>. Expanding WordPress&#8217; custom content capabilities beyond simple posts and pages has been critical to the platform maintaining its dominance as <a href=\"http://w3techs.com/technologies/overview/content_management/all\" target=\"_blank\">the world&#8217;s most used CMS</a>.</p>
<p>Thousands of WordPress developers make a living from products that are based on custom post types. Five years ago, when the feature was still new, you had to know how to write the code to register a new post type. That&#8217;s when the folks at <a href=\"http://webdevstudios.com/\" target=\"_blank\">WebDevStudios</a> released <a href=\"https://wordpress.org/plugins/custom-post-type-ui/\" target=\"_blank\">Custom Post Type UI</a>, a plugin that offers an admin interface for creating and managing post types and their associated taxonomies.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/cptui_post_type_editor.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/cptui_post_type_editor.png?resize=1024%2C604\" alt=\"cptui_post_type_editor\" class=\"aligncenter size-full wp-image-47028\" /></a></p>
<p>The company counts more than <a href=\"https://profiles.wordpress.org/webdevstudios/#content-plugins\" target=\"_blank\">30 plugins</a> in its collection on WordPress.org, but Custom Post Type UI is by far the most successful. Last week it passed one million downloads and maintains a 4.6 out of 5-star average rating from users. The plugin is currently active on more than 200,000 WordPress sites.</p>
<h3>Passing the 1 Million Downloads Milestone</h3>
<p>Michael Beckwith, the current maintainer of Custom Post Type UI, published a <a href=\"http://webdevstudios.com/2015/07/17/the-custom-post-type-ui-million-download-celebration/\" target=\"_blank\">post</a> detailing the evolution of the plugin&#8217;s UI and codebase. His transparent account covers how the team overcame the challenges of their massive codebase overhaul and the undetected bugs that come crawling out of the woodwork with a major release.</p>
<p>A plugin with a user base in the hundreds of thousands that manages to maintain a nearly 5-star average rating on WordPress.org is a notable achievement, especially when it involves weathering the UI and code updates required to keep pace with WordPress.</p>
<p>&#8220;I believe this milestone represents the fact that making features usable and more user-friendly to the &#8216;average Joe&#8217; can take you a long ways,&#8221; Beckwith said. &#8220;Custom Post Type UI made it easier for more people to tap into the power and customization ability that custom post types and taxonomies offer to a WordPress powered website. Because of that ease of use, many have added it to their toolbox for every website they have or work on, and recommend it to their friends.&#8221;</p>
<p>The plugin is being developed on <a href=\"https://github.com/WebDevStudios/custom-post-type-ui\" target=\"_blank\">GitHub</a>. Although there are many <a href=\"https://github.com/WebDevStudios/custom-post-type-ui/labels/enhancement\" target=\"_blank\">enhancements</a> under consideration, Beckwith said that no major changes are planned for the near future.</p>
<p>&#8220;I would love more to get more people up-to-date on the current version and let it be the stable version for awhile,&#8221; he said.</p>
<p>&#8220;Looking at our stats page, we still have reported active installs using as far back as version 0.6. While I can sit here scratching my head as to why, I also have to consider that that version is stable enough and still meeting the needs of 0.6% of our users.</p>
<p>&#8220;If it is not breaking for them, and there is no security concerns, then it is not all bad that they are still marching on. There is also the minimum version requirement to keep in mind. There are still WordPress installs active and out in the wild that are not running WordPress 3.8 or higher. Until they are, those users are not going to be notified that there is even an update available,&#8221; he said.</p>
<p>If you want to learn more about what it takes to maintain a popular plugin while successfully navigating the years of changes and support, check out WebDevStudios&#8217; <a href=\"http://webdevstudios.com/2015/07/17/the-custom-post-type-ui-million-download-celebration/\" target=\"_blank\">1 million downloads celebration post</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Jul 2015 01:35:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: WordPress 4.3 Moves Customize to Its Own Top-level Menu in the Admin Bar\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46979\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/wordpress-4-3-moves-customize-to-its-own-top-level-menu-in-the-admin-bar\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3156:\"<p>When menu management was <a href=\"http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3\">proposed to be merged into WordPress 4.3</a>, a common complaint <a href=\"http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3#comment-68988\">expressed by readers</a> was that clicking the Widgets menu item in the admin bar loads the customizer instead of the Widgets admin screen. WordPress 4.3 separates the management interfaces by moving the Customize link to the top-level menu of the admin bar. This link opens the customizer, allowing you to manage menus, appearance, and widgets through the customizer interface.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png\"><img class=\"wp-image-46995 size-full\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP42AdminBar.png?resize=429%2C232\" alt=\"WordPress 4.2 Admin Bar\" /></a>WordPress 4.2 Admin Bar
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png\"><img class=\"wp-image-46996 size-full\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/WP43AdminBar.png?resize=428%2C202\" alt=\"WP43AdminBar\" /></a>WordPress 4.3 Admin Bar
<p>The Dashboard, Themes, Widgets, and Menus links take users to their corresponding admin pages in the backend of WordPress. This makes it clear which interface users are about to enter. The enhancement is a result of <a href=\"https://core.trac.wordpress.org/ticket/32678\">ticket #32678</a> where Helen Hou-Sandí and other WordPress core contributors discussed ways to improve the context of each link over the course of five weeks.</p>
<p>Within the ticket, Nick Halsey, who has spent a lot of time on the customizer, explains that the approach taken in the ticket addresses short-term problems while setting the stage for future improvements.</p>
<blockquote><p>The Customizer gets the visibility it deserves and becomes more conceptually separated from &#8216;Appearance&#8217;, the admin becomes significantly more accessible from the front-end, the often-unhelpful dashboard is de-emphasized, etc. We also have the ability to easily upgrade the Customize link to do a much faster/shinier loading of the Customizer in the future without moving it.</p>
<p>Notably, the add-content and edit-content links remain separated from the admin menu (and we skip submenus there for simplicity), setting us up to be able to point them to a front-end-contextual content-creating/editing experience if we build that in the future, without moving links around. This minor rearrangement should be able to last several years without things moving around much if at all, even as further adjustments are made to the features they point to.</p></blockquote>
<p>On the surface, it appears to be a simple change but a lot of time and effort went into it. It required several core contributors to discuss a variety of mockups, ideas, and flows before the team figured out a solution.</p>
<p>Separating how users enter each interface will be a welcome enhancement to anyone who prefers one over the other to manage themes, widgets, and menus.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 23:28:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"WPTavern: How and When Mullenweg Learned Thesis Changed Back to a Proprietary License\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46960\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"http://wptavern.com/how-and-when-mullenweg-learned-thesis-changed-back-to-a-proprietary-license\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5837:\"<p>We now know when Matt Mullenweg discovered Chris Pearson changed Thesis&#8217; license from split GPL to a proprietary one. On April 1st 2014, Siobhan McKeown <a href=\"http://archive.wordpress.org/interviews/2014_04_01_Mullenweg.html\">interviewed Matt Mullenweg</a> for the <a href=\"https://github.com/WordPress/book\">WordPress history book</a>.</p>
<p>In the interview, we learn about the history of WordPress themes, the GPL, how Automattic unintentionally created the commercial theme market, why 200 themes were removed from the directory for sponsored links and much more.</p>
<p>At the 30 minute mark, McKeown asks Mullenweg, at what point did he decide to go to the Software Freedom Law Center to receive clarification on if the default themes that ship with WordPress are derivatives? He responds:</p>
<blockquote><p>I believe that was around our engagement with Mr. Pearson. I don&#8217;t know if it was before or after the Mixergy interview with our spirited online debate, but it was definitely around that time. I&#8217;m not a lawyer! I can read it and I can understand it from a logical point of view, but the Software Freedom Law Center is obviously the world experts in this and having them officially opine is the closest we can get to &#8211; it&#8217;s the next best thing to having a court case.</p>
<p>I was actually very excited that perhaps Chris would actually go to court, because as you know there isn&#8217;t a ton of case law around the GPL and normally, because no one is stubborn enough to actually go to court over it, and I thought, &#8220;Oh, we finally got one!&#8221; And I was looking forward to being able to discuss in the U.S. law system and provide the precedent for anyone who comes after us to protect the GPL.</p>
<p>Because companies like Cisco and LinkSys and huge companies with billions of dollars in resources have opted to not fight it, so you really do need someone who is going to be stubborn enough to fight it.</p></blockquote>
<p>At the climax of the debate in 2010, <a href=\"http://ma.tt/2010/07/syn-thesis-1/#comment-481743\">some members</a> of the WordPress community wanted to see the argument go to court so a ruling could set a precedent on when a work becomes derivative.</p>
<p>At the 33 minute mark, McKeown informs Mullenweg that Thesis switched from a split GPL license to a proprietary license. This is the first time since his debate with Pearson in 2010, that Mullenweg discovers Thesis switched back to a proprietary license. He responds:</p>
<blockquote><p>I have not seen that. So we&#8217;d have to do a code analysis again. As you know the Software Freedom Law Center says that non-PHP, so non-linked code which can be CSS, images and JavaScript, isn&#8217;t required to be GPL. It doesn&#8217;t trigger the viral nature of WordPress&#8217; GPL code.</p>
<p>The stance of the WordPress community was that a theme without images or CSS isn&#8217;t much of a theme so, even though something could be legally compliant, if the entire package isn&#8217;t providing the same freedoms for users it&#8217;s not something that we want to link to or promote. Because it doesn&#8217;t really follow the things that we hold dear and true in WordPress.</p></blockquote>
<p>On January 15, 2014, <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php\">Chris Pearson received</a> a copy of Mullenweg&#8217;s inquiry into thesis.com from Larry of GetYourDomain.com. This is approximately four months prior to discovering Thesis was being sold under a proprietary license. However, the exact date in which Mullenweg obtained ownership of the domain is unknown.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png\"><img class=\"size-full wp-image-46845\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png?resize=486%2C191\" alt=\"Email shared by Pearson showing Mullenweg\'s interest in the domain\" /></a>Email shared by Pearson showing Mullenweg&#8217;s interest in the domain
<p>The first <a href=\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks\">publicly known use of the domain</a> that confirmed Mullenweg&#8217;s ownership was on October 26th, 2014, at WordCamp San Francisco during the Question and Answer session.</p>
<p>As the interview continues, McKeown asks Mullenweg if he reached out to companies like Template Monster that sells WordPress themes that are not GPL Licensed. He responds:</p>
<blockquote><p>We got in touch with everyone that we could, and it was definitely &#8211; it was a lot of time. There are times when WordPress core stuff is more than a full-time job for me and now is definitely one of them.</p>
<p>I see your link to a [inaudible]. There&#8217;s always ways to word licenses around multi-site support where perhaps the code is GPL but the developer chooses to not provide support for more than one site unless you buy a special license. So sometimes people interpret those to be a GPL violation when actually they&#8217;re not.</p>
<p>I&#8217;m not aware of what Chris has done and I&#8217;d like to think that he is supportive &#8211; he has done so well from the WordPress community that he&#8217;d be supportive of themes continuing to be GPL, especially since his business didn&#8217;t crash like he was worried it would.</p></blockquote>
<p>McKeown jokes that lawyers might have written Thesis&#8217; license agreement. Mullenweg responds, &#8220;Well, maybe we&#8217;ll dive back into it.&#8221; More than 14 months later, <a href=\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks\">Mullenweg has dived back into it with Pearson</a>.</p>
<p>It&#8217;s unclear if in this second round of arguments, Mullenweg will take Pearson to court to settle the GPL derivative argument once and for all.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 23:21:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"WPTavern: Create and Manage BuddyPress Member Types with the BP Member Type Generator Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46893\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:102:\"http://wptavern.com/create-and-manage-buddypress-member-types-with-the-bp-member-type-generator-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4810:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/different-users.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/09/different-users.jpg?resize=1024%2C492\" alt=\"photo credit: Dunechaser - cc\" class=\"size-full wp-image-30565\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/dunechaser/6042984689/\">Dunechaser</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p><a href=\"http://wptavern.com/buddypress-2-2-spumoni-released-featuring-new-member-type-api\" target=\"_blank\">BuddyPress 2.2</a> introduced a <a href=\"https://codex.buddypress.org/developer/member-types/\" target=\"_blank\">Member Type API</a>, which allows developers to register their own unique member types, i.e. teacher, student, coach, etc. This was an exciting addition to BuddyPress but not very accessible to non-technical community managers, since it requires writing your own plugin to utilize it.</p>
<p><a href=\"https://wordpress.org/plugins/bp-member-type-generator/\" target=\"_blank\">BP Member Type Generator</a> is a new plugin from Brajesh Singh, prolific plugin author and owner of <a href=\"http://buddydev.com/\" target=\"_blank\">BuddyDev</a>. The plugin makes it easy for site administrators to create and manage member types in the admin &#8211; without having to write any code.</p>
<p>A quick overview of its features includes:</p>
<ul>
<li>Create/Edit/Delete Member Types from WordPress admin</li>
<li>Bulk assign member type to users from the users list screen</li>
<li>A member type can be marked active/inactive from the edit member type page</li>
<li>Compatible with multisite installations</li>
</ul>
<p>When creating a new member type, administrators have the option to enable a directory that will list all members from that type on one page.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/create-member-type.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/create-member-type.png?resize=968%2C725\" alt=\"create-member-type\" class=\"aligncenter size-full wp-image-46984\" /></a></p>
<p>If you want to add the plugin and separate your members into different types, the task is not as overwhelming as it might sound. When you visit the user listing page in the admin, you can use the plugin&#8217;s bulk &#8220;change member type&#8221; dropdown to bulk assign users to a new member type. (This feature is also available in the Extended Profile section for each individual user in the admin.)</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/change-member-type.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/change-member-type.png?resize=737%2C440\" alt=\"change-member-type\" class=\"aligncenter size-full wp-image-46988\" /></a></p>
<p>If you want to make the member types available for selection upon user registration, Singh created a free companion plugin called <a href=\"http://buddydev.com/buddypress/using-buddypress-member-type-as-profile-field-introducing-bp-xprofile-member-type-field-plugin/\" target=\"_blank\">BP Xprofile Member Type Field</a> that puts this on the frontend. If you want to restrict members from modifying their user type after registration, you can also add the free <a href=\"http://buddydev.com/plugins/bp-non-editable-profile-fields/\" target=\"_blank\">Non Editable Profile</a> field plugin.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/registration-member-type-field.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/registration-member-type-field.png?resize=490%2C337\" alt=\"registration-member-type-field\" class=\"aligncenter size-full wp-image-46992\" /></a></p>
<p>Please note that BP Member Type Generator cannot detect and manage other member types that have previously been added via code in a plugin. This might create some confusion if you already have existing member types. However, if you&#8217;re just starting with setting up and organizing member types, or are willing to reorganize member types, the BP Member Type Generator offers an easy way to do it.</p>
<p>This plugin is an important and much needed new tool that puts the creation of unique member types into the hands of BuddyPress community administrators, regardless of skill level. You can download <a href=\"https://wordpress.org/plugins/bp-member-type-generator/\" target=\"_blank\">BP Member Type Generator</a> for free from WordPress.org. Singh does not officially support his plugins via the WordPress forums, but users can provide feedback via the <a href=\"http://buddydev.com/buddypress/introducing-buddypress-member-type-generator/\" target=\"_blank\">BuddyDev blog</a> or get professional support on the <a href=\"http://buddydev.com/support/forums/\" target=\"_blank\">BuddyDev Premium Support Forums</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 21:51:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Joseph: Recommended Consultants\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://josephscott.org/?p=9888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://josephscott.org/archives/2015/07/recommended-consultants/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:277:\"<p>My personal list of WordPress consultants has dried up ( some took full time jobs, the rest are always booked solid ).  Now I&#8217;m directing people to the <a href=\"http://jkudish.com/recommendations/\">Recommended Consultants &amp; Resources list</a> from Joey Kudish.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 14:01:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Joseph Scott\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: Nick Haskins Receives Cease and Desist Letter for Violating LassoSoft Trademarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46768\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://wptavern.com/nick-haskins-receives-cease-and-desist-letter-for-violating-lassosoft-trademarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4619:\"<p><a href=\"http://nickhaskins.com/\">Nick Haskins</a>, the founder and lead developer of <a href=\"https://lasso.is/\">Lasso</a>, is <a href=\"https://lasso.is/the-ugly-truth-about-trademarks/\">rebranding the product</a> after being served a cease and desist letter.</p>
<p>A few days ago, Haskins was served a cease and desist letter from <a href=\"http://lassosoft.com/\">LassoSoft</a>. According <a href=\"http://www.lassosoft.com/What-Is-Lasso\">to LassoSoft</a>, &#8220;Lasso is a development platform and is the easiest, quickest and most secure method of supporting custom, data-driven web sites on the market today.&#8221;</p>
<p>Before launching a product, Haskins searches Google to see if similar products exist with the same name, &#8220;Apparently we didn’t look hard enough when naming Lasso,&#8221; he said.</p>
<h2>Three Requirements That Must Be Met</h2>
<p>Haskins <a href=\"http://cl.ly/39400J3A100k\">shared the letter</a> to educate others in the business of WordPress. In the letter, attorney&#8217;s for LassoSoft point out the company&#8217;s <a href=\"http://www.tmfile.com/mark/?q=861046116\">registered trademarks</a> and says it commenced using the mark in the US in 1998 and in Canada in 1997.</p>
<p>LassoSoft claims to have documented at least one case of confusion between the two brands and says the continued use of Lasso will cause even more confusion.</p>
<p>Attorney&#8217;s for LassoSoft provided three requirements that must be met for an amicable end to the dispute:</p>
<ol>
<li>Permanently ceasing all use of the term &#8220;Lasso&#8221; and any trademark which includes or incorporates the term &#8220;Lasso&#8221;, in connection with any software or related goods and services.</li>
<li>Removing all references to the term &#8220;Lasso&#8221; from the Website.</li>
<li>Removing all references to the term &#8220;Lasso&#8221; from any marketing materials including flyers, catalogs, etc.</li>
</ol>
<p>Haskins has until <strong>July 29th</strong> to satisfy the requirements and provide LassoSoft with written confirmation that he has permanently ceased all use of the term &#8220;Lasso&#8221; in association with software.</p>
<h2>Transitioning Momentum</h2>
<p>Rebranding a product that has momentum can be a crushing blow to a business that doesn&#8217;t manage the transition correctly. I asked Haskins how he plans to shift momentum from Lasso to the new brand name.</p>
<p>&#8220;The first idea I had, was to let the community rename it, possibly even have a $500 prize to the winning name. By incentivizing a rebranding campaign, together with a concentrated effort on re-educating, along with URL redirects and custom messages, I feel pretty strongly that we&#8217;ll be able to move right along without skipping a beat,&#8221; he said.</p>
<p>When it comes to naming a WordPress product and launching it into the WordPress ecosystem, Haskins offers the following advice:</p>
<p>&#8220;Use Google to see if it already exists either in the WordPress ecosystem or in a related field. This may seem like a no-brainer and it&#8217;s really common sense, but for some reason, I either never searched or that company never popped up. At any rate, I think you&#8217;ll be in good shape by sticking to something with wp prefixed or appended to the name.&#8221;</p>
<p>&#8220;Avoid generic terms and verbs because apparently, you can trademark a verb. I&#8217;d also run the search again in six months and if it&#8217;s a product that you plan on working on for a while, go through the process of getting the term trademarked.&#8221;</p>
<p>In addition to Haskins&#8217; advice, I recommend using a search and discovery process provided by legal counsel familiar with trademark law.</p>
<h2>Help Haskins Rebrand Lasso</h2>
<p>In light of the battle between <a href=\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks\">Chris Pearson and Matt Mullenweg</a> involving patents, GPL, and trademarks, Haskins decided to rebrand Lasso, &#8220;There are a lot more important things in life than the name of a plugin for WordPress,&#8221; he said.</p>
<p>Haskins is giving the community an opportunity to rebrand his product. So far, he&#8217;s ruled out WP Front End Editor as it&#8217;s too similar to the <a href=\"https://wordpress.org/plugins/wp-front-end-editor/\">name of a feature plugin</a> that may one day be merged into WordPress core.</p>
<p>If you have an idea on what to call Lasso, please leave a comment on this post. Sometime next week, Haskins will gather the suggestions and publish a poll where the community can vote on which one is best.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 22 Jul 2015 01:08:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"Matt: There is No Such Thing as a Split License\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45256\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"http://ma.tt/2015/07/licenses-going-dutch/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2845:\"<p>There&#8217;s a term that pops in the WordPress community, &#8220;split license&#8221;, that we should put to rest. It&#8217;s sloppy at best, misleading at worst.</p>
<p>First, some background. WordPress is under a license called the GPL, which basically says you can do whatever you like with the software, but if you distribute changes or create derivative works they also need to be under the GPL. Think of it like a Creative Commons Sharealike license.</p>
<p>In the past people weren&#8217;t sure if themes for WordPress were derivative works and needed to be GPL. <a href=\"https://wordpress.org/news/2009/07/themes-are-gpl-too/\">In 2009 we got an outside legal opinion that cleared up the matter</a> saying that the PHP in themes definitely had to be GPL, and for CSS and images it was optional. Basically everyone in the WP community went fully GPL, sometimes called 100% GPL, for all the files required to run their theme (PHP, JS, CSS, artwork). The predicted theme apocalypse and death of WordPress didn&#8217;t happen and in fact both theme shops and WordPress flourished, and best of all users had all the same freedoms from their themes as they got from WordPress. It was controversial at the time, but I think history has reflected well on the approach the WP community took.</p>
<p>As I said the PHP has to be GPL, the other stuff can be something else &#8212; many people started to use the term &#8220;split license&#8221; or &#8220;split GPL&#8221; to describe this. The problem, especially with the latter, is it leaves out the most important information. &#8220;Split GPL&#8221; doesn&#8217;t say whether the theme is violating WordPress&#8217; license or not (maybe it&#8217;s proprietary PHP and GPL CSS), and more importantly doesn&#8217;t say what the non-GPL stuff is, which is the part you need to worry about! It also makes it sound like a split license is a thing, when all it really means is there are different licenses for different parts of the work. If something has a &#8220;split license&#8221; you have no idea what restrictions or freedoms it provides.</p>
<p>If someone decides to have different licenses for different parts of a theme they ship in one package, it&#8217;s probably worth taking a few extra words to spell out what the rights and restrictions are, like &#8220;GPL PHP, and a restrictive proprietary license for all other elements included with the theme.&#8221; This is really important because if you&#8217;re a smart WordPress consumer you should avoid proprietary software, there is always a GPL alternative that <a href=\"http://www.gnu.org/philosophy/free-sw.en.html\">gives you the rights and freedoms you deserve</a>, and probably is from a nicer person who is more in line with the philosophy of the rest of WordPress. Vote with your pocketbook, buy GPL software!</p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2015 20:55:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:94:\"WPTavern: Shortcake Bakery Plugin Offers a Suite of Useful Shortcodes for WordPress Publishers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46896\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/shortcake-bakery-plugin-offers-a-suite-of-useful-shortcodes-for-wordpress-publishers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4116:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/baker.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/baker.jpg?resize=1024%2C516\" alt=\"photo credit: Panettiere - (license)\" class=\"size-full wp-image-46899\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/27505428@N06/16282512996\">Panettiere</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">(license)</a>
<p>In March, the <a href=\"http://wptavern.com/shortcake-is-now-a-wordpress-feature-plugin\" target=\"_blank\">Shortcake project officially began its journey as a feature plugin</a> with regular meetings for contributors working to make it ready to propose for inclusion in WordPress core. The <a href=\"https://wordpress.org/plugins/shortcode-ui/\" target=\"_blank\">plugin</a> provides a friendly UI for adding shortcodes and transforms them to render a nice preview in the visual editor.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/pullquote-shortcode.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/pullquote-shortcode.png?resize=1025%2C538\" alt=\"pullquote-shortcode\" class=\"aligncenter size-full wp-image-46904\" /></a></p>
<p>Last week, <a href=\"https://twitter.com/danielbachhuber\" target=\"_blank\">Daniel Bachhuber</a> and the engineering team at <a href=\"http://fusion.net/\" target=\"_blank\">Fusion</a> released <a href=\"https://wordpress.org/plugins/shortcake-bakery/\" target=\"_blank\">Shortcake Bakery</a>, a plugin that extends the Shortcake project to supply a suite of handy shortcodes for publishers. The plugin currently includes the following:</p>
<ul>
<li>Image Comparison (powered by <a href=\"https://juxtapose.knightlab.com/\" target=\"_blank\">JuxtaposeJS</a>)</li>
<li>Facebook embeds</li>
<li>iFrames (require whitelisted hostnames)</li>
<li>Infogram embeds</li>
<li>PDF’s (powered by <a href=\"https://mozilla.github.io/pdf.js/\" target=\"_blank\">PDF.js</a>)</li>
<li>Playbuzz embeds</li>
<li>Rap Genius annotations</li>
<li>Scribd embeds</li>
<li>Scripts (require whitelisted hostnames)</li>
</ul>
<p>&#8220;We’ve been steadily making shortcodes for use by the Fusion newsroom since we launched Shortcake in November, and by releasing these universally useful patterns to the world, we hope to create a large repository of structured post elements for use by the WordPress community,&#8221; Bachhuber said.</p>
<p>For example, Shortcake Bakery supplies a friendly UI for embedding an infographic from <a href=\"https://infogr.am/\" target=\"_blank\">Infogra.am</a>. The author selects the post element and then pastes in the URL to the infographic. It instantly appears in the post editor with a TinyMCE preview.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-demo.mp4\">http://wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-demo.mp4</a></p>
<p>Shortcake Bakery also makes it easy to embed a single Facebook post, PDF, image comparison, and other content types that might otherwise prove troublesome to include in WordPress. Each content type is optimized for instant visual preview in the editor.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-facebook-embed.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/shortcake-bakery-facebook-embed.png?resize=919%2C689\" alt=\"shortcake-bakery-facebook-embed\" class=\"aligncenter size-full wp-image-46917\" /></a></p>
<p>Version 0.1.0 includes nine useful post elements that make it easy to embed content from external services commonly referenced by publishers. Shortcodes for Instagram, Tubmlr, and Silk are listed as possible upcoming enhancements on the project&#8217;s <a href=\"https://github.com/fusioneng/shortcake-bakery/labels/enhancement\" target=\"_blank\">GitHub issues queue</a>. <a href=\"https://wordpress.org/plugins/shortcake-bakery/\" target=\"_blank\">Shortcake Bakery</a> is an open source plugin and is now available on WordPress.org. It works best when combined with the <a href=\"https://wordpress.org/plugins/shortcode-ui/\" target=\"_blank\">Shortcake</a> plugin.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Jul 2015 02:16:59 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WP Rocket Reports $355K in Annual Revenue After 2 Years in Business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46719\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/wp-rocket-reports-355k-in-annual-revenue-after-2-years-in-business\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4872:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-feature.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/05/wp-rocket-feature.jpg?resize=1025%2C452\" alt=\"wp-rocket-feature\" class=\"aligncenter size-full wp-image-22199\" /></a></p>
<p><a href=\"http://wp-rocket.me/\" target=\"_blank\">WP Rocket</a> is celebrating its second year in business. The commercial caching plugin for WordPress launched two years ago in the French market and <a href=\"http://blog.wp-rocket.me/2-years-reports-feedbacks/\" target=\"_blank\">opened its doors to international customers</a> last May.</p>
<p>At that time, WP Rocket was entering unproven territory as the first major caching plugin to launch with a 100% commercial model. Could the plugin succeed in a market dominated by free caching solutions like <a href=\"https://wordpress.org/plugins/w3-total-cache/\" target=\"_blank\">W3 Total Cache</a> and <a href=\"https://wordpress.org/plugins/wp-super-cache/\" target=\"_blank\">WP Super Cache</a>?</p>
<p>WP Rocket has the numbers to prove that WordPress users are willing to pay for an easy-to-configure solution to site optimization. In February, the 100% bootstrapped company published a transparency report showing that the product was now active on 15,000+ websites and <a href=\"http://wptavern.com/wp-rocket-grows-from-0-to-35k-in-monthly-revenue\" target=\"_blank\">averaging $35K in monthly revenue</a>. Six months later, the plugin is now active on more than 32,000 websites. From July 2014 &#8211; July 2015, WP Rocket <a href=\"http://blog.wp-rocket.me/2-years-reports-feedbacks/\" target=\"_blank\">reports</a> that the company pulled in a total of $351,097 in revenue.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/wprocket-2014-2015.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/wprocket-2014-2015.jpg?resize=629%2C525\" alt=\"photo credit: WP Rocket</a.\" /></a>photo credit: <a href=\"http://blog.wp-rocket.me/2-years-reports-feedbacks/\">WP Rocket</a>
<p>WP Rocket has been successful in identifying ways to stand out among established competitors. During our <a href=\"http://wptavern.com/wp-rocket-launches-commercial-caching-plugin-for-wordpress\" target=\"_blank\">initial tests of the plugin</a>, we found that it took under a minute to configure caching for a small blogging site using its simple, basic settings panel. Without even touching the more advanced options, such as DNS prefetching and file exclusions, we were able to reduce the page size and load time by roughly 50%.</p>
<p>Inspired by a recent three-month stay in San Francisco, WP Rocket developers and co-founders  Jonathan Buttigieg and Jean-Baptiste Marchand-Arvier are now working to diversify their product offerings.</p>
<p>&#8220;WP Rocket will be one product among others from our startup and not the only one,&#8221; Marchand-Arvier said. &#8220;We want to have a portfolio of products and not depend on only one.&#8221;</p>
<p>To that end, the company is dipping its toes into multiple potentially welcoming revenue streams, including plugins, themes, and SaaS.</p>
<p>&#8220;For the past few months, Julio has been working on a security plugin,&#8221; Marchand-Arvier said. &#8220;This is going to be a great challenge for us as we experiment with a freemium model for the first time, and because there are great competitors in the space, like WordFence and iThemes Security.</p>
<p>WP Rocket currently has a dedicated team working on <a href=\"https://imagify.io/\" target=\"_blank\">Imagify</a>, an image compression toolkit and their first SaaS venture. The company also plans to enter the theme market with its own shop.</p>
<p>&#8220;We want to take on that huge challenge which will be very different compared to selling a plugin,&#8221; Marchand-Arvier said.</p>
<p>WP Rocket&#8217;s founders believe that building a strong company culture will be one of the key factors to their continued success.</p>
<p>&#8220;To work in a mostly remote team can create a lack of human connection,&#8221; Marchand-Arvier said. &#8220;That’s why we’ve decided to organize a ‘startup retreat’ every year.&#8221; This decision was inspired by the founders&#8217; 2014 trip to explore Silicon Valley, a pivotal event that changed the way they approached business in the WordPress ecosystem.</p>
<p>&#8220;This [trip] transformed three guys who were selling a WordPress plugin into a Startup of eight people (today) with a strong company culture,&#8221; he said.</p>
<p>If the success of WP Rocket&#8217;s caching plugin is any indication, WordPress users should be on the lookout for the company to bring a new twist into other existing product niches. Momentum is running high on their currently incubating projects with <a href=\"https://imagify.io/\" target=\"_blank\">Imagify</a> on track to launch in the upcoming weeks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 20 Jul 2015 20:33:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Matt: Streak Broken\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45251\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"http://ma.tt/2015/07/streak-broken/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:689:\"<p>Due to some distractions and mishandling of scheduled posts on my part, I broke my blogging streak. I got up to 198 days, which isn&#8217;t bad, and I&#8217;m looking forward to beating it next time. A lot of people might not know this, but if you&#8217;re on <a href=\"http://wordpress.com/\">WordPress.com</a> or run <a href=\"http://jetpack.me/\">Jetpack</a> when you start a posting streak it will give you a notification high-five every day you continue it, this was the last one I got:</p>
<p><img class=\"aligncenter  wp-image-45252\" src=\"http://i2.wp.com/ma.tt/files/2015/07/Screen-Shot-2015-07-18-at-9.06.19-AM.png?resize=386%2C394\" alt=\"Screen Shot 2015-07-18 at 9.06.19 AM\" /></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 18 Jul 2015 13:08:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Mullenweg and Pearson Square Off on Patents, GPL, and Trademarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46814\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"http://wptavern.com/mullenweg-and-pearson-square-off-on-patents-gpl-and-trademarks\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8449:\"<p>In a post titled &#8220;<a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php\" target=\"_blank\">The Truth About Thesis.com</a>,&#8221; Chris Pearson responded to the recent heated discussions about his <a href=\"http://wptavern.com/automattic-wins-cybersquatting-case-against-chris-pearson\" target=\"_blank\">legal battle with Automattic over the Thesis.com domain</a> and related trademarks. His public response revives a <a href=\"http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/\">five-year old licensing disagreement</a>.</p>
<p>&#8220;I think the most important place to start is by asking: Why would Automattic—a website software company with over $300 million in funding—buy thesis.com when I owned the trademark for Thesis in the website software space?&#8221; Pearson asked.</p>
<p>In February 2013, Pearson started negotiations with a domain broker named Larry of GetYourDomain.com in an attempt to purchase thesis.com. He opened with an offer of $37,500 which he considered to be more than enough for an unused domain. After months of negotiating, the deal fell through.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png\"><img class=\"size-full wp-image-46845\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-matt.png?resize=486%2C191\" alt=\"Email shared by Pearson showing Mullenweg\'s interest in the domain\" /></a>Email shared by Pearson showing Mullenweg&#8217;s interest in the domain
<p>&#8220;I didn’t see how Matt could justify buying the domain for $100,000. Because of my trademark, there was no way he could legally use the domain for Automattic, and therefore, I didn’t believe there was a reason for him to spend that much money,&#8221; Pearson said.</p>
<p>Nine months after negotiations failed, Pearson received an email from Larry asking if he&#8217;d like to renegotiate since Mullenweg showed interest in the domain. Further negotiations went nowhere and Mullenweg won the domain for $100K.</p>
<p>News of Mullenweg&#8217;s purchase didn&#8217;t reach the public until he replied to a question about WordPress&#8217; relationship with commercial theme providers at the 2014 State of the Word Q&amp;A. In his response, he encouraged the audience to visit Thesis.com. Notice Mullenweg&#8217;s delivery and how the crowd reacts to his announcement.</p>
<p></p>
<p></p>
<p>Pearson also accused Mullenweg of <a href=\"http://tsdr.uspto.gov/#caseNumber=4039583&caseType=US_REGISTRATION_NO&searchType=statusSearch\">violating his trademark</a>.</p>
<blockquote><p>Principles? Matt spent $100,000 to buy thesis.com—a domain in which he had no legitimate business interest—forwarded the domain to his property, and violated my trademark.</p>
<p>This is ironic considering how vigilant Matt has been about protecting the WordPress trademark—especially as it <a href=\"http://wptavern.com/the-wordpress-foundation-sues-jeff-yablon-for-trademark-infringement\">relates to domain names</a>.</p></blockquote>
<p>Pearson goes on to describe his duty to protect to his trademark and the details of the UDRP Case Ruling, as well as the fallout regarding the court&#8217;s decision in Automattic&#8217;s favor.</p>
<p>&#8220;It’s time for the community to ask itself if using $300 million in funding to purchase $100,000 domains, fund aggressive lawsuits, and fuel unending drama is properly representative of the WordPress project,&#8221; he said.</p>
<p>Pearson admitted to &#8220;being a jerk&#8221; both in the post and the comments. This admission is based on his attitude and the way he presented himself in 2010 in the <a href=\"http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/\">interview with Andrew Warner</a> on Mixergy. Mullenweg focused on the fact that Pearson changed the licensing structure of Thesis so that part of it is incompatible with the GPL:</p>
<p>&#8220;So why do the exact same thing you did before, change your license to violate the GPL and take rights away from your users? And then litigate against someone else?&#8221; Mullenweg asked.</p>
<p>He is referring to Thesis&#8217; <a href=\"http://diythemes.com/thesis/rtfm/software-license-agreement/\">license agreement</a> customers agree to when they purchase the theme. The agreement has terms that take user freedoms away that GPL licensed software provides. Here are a few of terms in the agreement:</p>
<ul>
<li>You can’t sell, rent, or otherwise transfer the software to anyone else.</li>
<li>The license provides you, and only you, with the rights to use the software for its intended purpose.</li>
<li>Other than for educational purposes, any modification of the Thesis “core” is prohibited.</li>
</ul>
<p>Mullenweg is well known as a zealous protector of the GPL and users&#8217; rights. However, Pearson and many others perceived his comments on licensing to be a distraction from the main issue.</p>
<p>In responding to commenters on whether the issue is dead, he <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507944\" target=\"_blank\">said</a>:</p>
<blockquote><p>The issue isn’t dead — Chris went back on his word and re-changed his license to be 100% proprietary and violate the GPL, sneakily sometime in the past 5 years since the last time he did that. He also patented how themes work, and color pickers.</p></blockquote>
<p>The patent Mullenweg is <a href=\"http://www.google.com/patents/US20140095982\">referring to</a> was published in September of 2012. The patent describes systems, servers, and methods for managing websites using the Thesis software. One of the fears is that the patent is vague and closely describes how WordPress themes work in general, although Pearson claims the patent has <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962\">nothing to do with WordPress</a>.</p>
<p>Pearson <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507962\" target=\"_blank\">clarified Thesis&#8217; new proprietary licensing</a>, which Mullenweg believes to be in violation of their agreement in 2010:</p>
<blockquote><p>In October 2012, I released an all-new version of Thesis that carried the same name as the original (which had a split-GPL license), but that’s where the similarities stopped.</p>
<p>The new Thesis is not a Theme—it is an operating system for templates and design. This system runs Skins and Boxes, which are similar to Themes and Plugins, but with a boatload of built-in efficiencies that Themes and Plugins cannot provide.</p>
<p>Skins and Boxes carry MIT licenses, which are not only open source, but also easy for anyone to understand and use.</p>
<p>There is nothing sneaky about the licensing structure that has been in place since October 2012. DIYthemes customers must agree to the proprietary licensing on the Thesis core before downloading and using the software.</p></blockquote>
<p>After Mullenweg purchased the domain, he <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507947\">received no personal communication from Pearson</a> on the issue until Automattic was hit with litigation. The litigation stems from Pearson trying to protect his trademark.</p>
<p>&#8220;I don’t know the last time I got an email from Chris directly (3+ years?), and myself and Automattic didn’t hear anything from him before we got the litigation notice he was trying to seize the domain,&#8221; Mullenweg commented. &#8220;No questions, no concerns, no offer to resolve, no discussion, we were just hit with legal action out of the blue.&#8221;</p>
<p>In a <a href=\"http://www.pearsonified.com/2015/07/truth-about-thesis-com.php#comment-1507959\">comment published</a> on Pearson&#8217;s blog post, Mullenweg contends that Pearson is repeating the same mistake he made in 2010 by not licensing Thesis as GPL.</p>
<p>&#8220;It doesn’t matter if you admit what you did was wrong in the past if you go and do the exact same thing again: violate the GPL, and make it worse by patenting common theme practices,&#8221; he said.</p>
<p>Up until this point, Mullenweg has declined to comment directly on Automattic&#8217;s interest in purchasing thesis.com in the first place. There are a lot of forces at play, including patents, GPL adherence, trademarks, and domain names. This is a developing and complicated story that we&#8217;ll continue to keep our eyes on.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 18 Jul 2015 05:24:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"WPTavern: New Feature Plugin Proposed: oEmbed for WordPress Posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46826\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/new-feature-plugin-proposed-oembed-for-wordpress-posts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2809:\"<p>WordPress has a <a href=\"https://codex.wordpress.org/Embeds\" target=\"_blank\">whitelist</a> of 31 trusted sites from which users can oEmbed content, but one source is noticeably missing &#8211; WordPress itself. During this week&#8217;s <a href=\"https://make.wordpress.org/core/2015/07/10/feature-plugin-chat-on-july-14/\" target=\"_blank\">feature plugin chat</a>, Pascal Birchler and a group of contributors proposed the idea of <a href=\"https://make.wordpress.org/core/2015/07/10/feature-plugin-chat-on-july-14/#comment-26324\" target=\"_blank\">oEmbed for WordPress Posts</a>:</p>
<blockquote><p>Basically, we want to make WordPress an oEmbed provider. Users should be able to paste an URL from a WordPress blog and the post gets embedded right away. Difficulties here are discovering other WordPress sites as oEmbed providers and whitelisting them. The oEmbed endpoint requires the WP-API to be in use, so this can’t land in core until the API does.</p></blockquote>
<p>The <a href=\"https://github.com/swissspidy/oEmbed-API\" target=\"_blank\">oEmbed API</a> proof-of-concept feature plugin is currently in development on GitHub. It requires WordPress 4.3 beta 3 or later and version 2 of the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">WP REST API</a> plugin.</p>
<p>Mel Choyce, author of the trac <a href=\"https://core.trac.wordpress.org/ticket/32522\" target=\"_blank\">ticket</a> requesting the feature, created a mockup of how embedded WordPress posts might look:</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-oembed-feature-plugin-mockup.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-oembed-feature-plugin-mockup.jpg?resize=1024%2C960\" alt=\"wordpress-oembed-feature-plugin-mockup\" class=\"aligncenter size-full wp-image-46828\" /></a></p>
<p>The <a href=\"https://core.trac.wordpress.org/ticket/32522\" target=\"_blank\">ticket</a> is home to an active discussion with excellent reasons on both sides of the argument for why this should or should not be included in core, highlighting the many <a href=\"https://core.trac.wordpress.org/ticket/32522#comment:32\" target=\"_blank\">considerations</a> that would be involved with having oEmbed discovery turned on. Tackling <a href=\"https://core.trac.wordpress.org/ticket/32522#comment:34\" target=\"_blank\">abuse of the feature</a> could also pose a significant challenge.</p>
<p>The feature plugin is still in the early development stages and discussion regarding its implementation is ongoing. Birchler said the team needs help with design and development, particularly with the oEmbed auto-discovery part of the project. If you&#8217;d like to get involved with the discussion, you can join in the weekly chats in the <strong>#feature-oembed</strong> WordPress Slack channel.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Jul 2015 22:51:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: New Roots Radio Podcast Discusses WordPress and Modern Web Development Topics\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46679\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"http://wptavern.com/new-roots-radio-podcast-discusses-wordpress-and-modern-web-development-topics\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3530:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/roots.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/roots.jpg?resize=700%2C300\" alt=\"roots\" class=\"aligncenter size-full wp-image-46801\" /></a></p>
<p>Ben Word and the team behind <a href=\"https://roots.io/\" target=\"_blank\">Roots</a> are launching a new WordPress-related podcast called <a href=\"https://roots.io/radio0/\" target=\"_blank\">Roots Radio</a>. Earlier this year, Word <a href=\"http://wptavern.com/roots-wordpress-starter-theme-rebrands-as-sage-with-8-0-release\" target=\"_blank\">rebranded the Roots starter theme as “Sage”</a> under the Roots organization as part of <a href=\"http://wptavern.com/roots-starter-theme-for-wordpress-will-become-framework-agnostic-in-2015\" target=\"_blank\">a long-term plan to make it framework-agnostic</a>. Opening up the starter theme to be available for use with a variety of frontend frameworks means that the Roots community is utilizing a wide range of technologies for development.</p>
<p>The new podcast was created to discuss WordPress and Roots development and will also explore general modern web development topics. The <a href=\"https://roots.io/radio0/\" target=\"_blank\">inaugural episode</a> introduces Roots team members, many of whom use WordPress and others who are more active outside of WordPress development. They also discuss their individual WordPress workflows, dependency management, and project structure.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">If you’re interested in a smoother WordPress workflow, listen to Roots Radio, whether you use Roots or not. <a href=\"https://t.co/vhocxb9tkC\">https://t.co/vhocxb9tkC</a></p>
<p>&mdash; Fränk Klein (@fklux) <a href=\"https://twitter.com/fklux/status/621432291341017088\">July 15, 2015</a></p></blockquote>
<p></p>
<p>Ben Word and Scott Walkinshaw recently appeared on <a href=\"https://changelog.com/podcast/\" target=\"_blank\">The Changelog</a> podcast, a weekly show that covers the intersection of software development and open source, to discuss &#8220;<a href=\"https://changelog.com/156/\" target=\"_blank\">Modern WordPress using Bedrock and Sage</a>.&#8221;</p>
<p>&#8220;After Scott and I appeared on the Changelog podcast, the guys on the team wanted to get something going,&#8221; Word said. Even though the WordPress community already has many regular podcasts devoted to news, business, and development, Word believes that the Roots team has something unique to offer with their experience and dedication to using modern web development tools.</p>
<p>He shared a sneak preview of some of the topics the team plans to cover in future episodes of Roots Radio:</p>
<ul>
<li>Deployments</li>
<li>Theme wrapper and DRY</li>
<li>Security</li>
<li>Composer</li>
<li>Forking WordPress</li>
<li>Open Source Support/Maintenance/Burnout</li>
<li>Keeping Roots projects up-to-date</li>
<li>Framework agnostic workflow</li>
<li>Theming tips and tricks</li>
<li>How to contribute to Roots / open source</li>
<li>Stepping outside of WordPress land</li>
<li>Unit tests</li>
</ul>
<p>Word confirmed that Roots Radio will have guests on upcoming episodes. If these topics have piqued your interest, you can subscribe to the podcast via <a href=\"https://itunes.apple.com/us/podcast/roots-radio/id1015480854\" target=\"_blank\">iTunes</a> or <a href=\"http://feeds.soundcloud.com/users/soundcloud:users:160680092/sounds.rss\" target=\"_blank\">RSS</a>. New episodes will be released every couple of weeks.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 17 Jul 2015 20:24:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: WordPress 4.3 Beta 3 Adds Site Icon Feature to the Customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46676\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"http://wptavern.com/wordpress-4-3-beta-3-adds-site-icon-feature-to-the-customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4288:\"<p>WordPress 4.3 <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\" target=\"_blank\">beta 3</a> was released this week right on <a href=\"https://make.wordpress.org/core/version-4-3-project-schedule/\" target=\"_blank\">schedule</a>, and beta 4 is expected to arrive next Wednesday. This release includes more than <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&mode=stop_on_copy&rev=33286&stop_rev=33141&limit=150\" target=\"_blank\">140 fixes and improvements</a> since last week&#8217;s beta.</p>
<p>One of the most important changes you&#8217;ll notice is that the <a href=\"http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this\" target=\"_blank\">Site Icon feature</a> is now available in the customizer in addition to its spot under <strong>General > Settings</strong>. The new panel is called Site Identity and it includes the site title, tagline, and the icon upload controls.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/site-identity-new-customizer-panel.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/site-identity-new-customizer-panel.jpg?resize=1025%2C690\" alt=\"site-identity-new-customizer-panel\" class=\"aligncenter size-full wp-image-46773\" /></a></p>
<p>&#8220;The feature is now complete and requires lots of testing,&#8221; WordPress 4.3 release lead Konstantin Obenland said in the announcement. &#8220;Please help us ensure the site icon feature works well in both Settings and the Customizer.&#8221;</p>
<p>Mark Jaquith&#8217;s work to improve passwords has also been added to the installation process so that administrators will be prompted to select a strong password when setting up a new site. This screenshot from Ryan Boren&#8217;s most recent &#8220;<a href=\"https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/\" target=\"_blank\">Today in the Nightly</a>&#8221; update shows the password strength meter&#8217;s feedback added to the UI.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/passwords-ui-on-install-screen-1024x740.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/passwords-ui-on-install-screen-1024x740.png?resize=1024%2C740\" alt=\"photo credit: Ryan Boren\" class=\"size-full wp-image-46779\" /></a>photo credit: <a href=\"https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/passwords-ui-on-install-screen/\">Ryan Boren</a>
<p>Boren also highlighted the value of the new Markdown-esque patterns recognized in the post editor and their convenience for mobile users. Instead of trying to format HTML on a tiny screen, users will be able to take advantage of the new shortcuts which require fewer keystrokes.</p>
<p>&#8220;Create bulleted lists, ordered lists, and blockquotes using markdown like patterns,&#8221; he said. &#8220;I find this particularly handy on phones when the editor toolbar is offscreen.&#8221;</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/editor-patterns-keyboard-shortcuts-list.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/editor-patterns-keyboard-shortcuts-list.jpg?resize=1025%2C541\" alt=\"photo credit: Ryan Boren\" class=\"size-full wp-image-46785\" /></a>photo credit: <a href=\"https://make.wordpress.org/core/2015/07/15/today-in-the-nightly-site-icons-in-the-customizer-editor-patterns-more-accessible-comment-bubbles-row-toggle-focus-styling/\">Ryan Boren</a>
<p>Beta 3 also improves the accessibility of comments and media list tables with a better design for comment bubbles and focus styling for row toggles. Obenland welcomes feedback on the accessibility improvements from those who are using WordPress with screen readers.</p>
<p>With 140 changes in beta 3, a new round of testing is in order. You can help by installing the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin on a development site and reporting any bugs you find in the recent improvements. The official WordPress 4.3 release is now just four weeks away.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 22:01:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"WPTavern: WPWeekly Episode 199 – Preview of WordPress 4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=46746&preview_id=46746\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"http://wptavern.com/wpweekly-episode-199-preview-of-wordpress-4-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2747:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I preview WordPress 4.3. We discuss what WordPress.tv should do with old videos now that the site is six years old. There&#8217;s a conference this weekend devoted to the Genesis Framework and we let you know how you can watch it for free.</p>
<p>Theme translations and language packs are on their way to the WordPress theme directory. Last but not least, we congratulate Topher DeRosia on reaching his funding goals to attend WordCamp Pune, India.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\">WordPress 4.3 Beta 3</a><br />
<a href=\"http://www.wpbeginner.com/news/whats-coming-in-wordpress-4-3-features-and-screenshots\">What’s Coming in WordPress 4.3</a><br />
<a href=\"https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/\">UI For Outdated Content on WordPress.tv</a><br />
<a href=\"http://wptavern.com/theme-translations-and-language-packs-are-coming-to-wordpress-org\">Theme Translations and Language Packs are Coming to WordPress.org</a><br />
<a href=\"http://wptavern.com/the-first-24hr-conference-devoted-to-the-genesis-framework-set-for-july-19-20\">The First 24hr Conference Devoted to the Genesis Framework Set for July 18-20</a><br />
<a href=\"http://wptavern.com/topher-derosia-launches-gofundme-campaign-to-attend-wordcamp-pune-india\">Topher DeRosia Launches GoFundMe Campaign to Attend WordCamp Pune, India</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/background-image-cropper/\">Background Image Cropper</a> is a WordPress core feature-plugin that adds cropping to background images for parity with header images.</p>
<p><a href=\"https://wordpress.org/plugins/frontier-restrict-media/\">Frontier Restrict Media</a> will restrict users so they can only access their own media files from the media library.</p>
<p><a href=\"https://wordpress.org/plugins/image-hover-effects/\">Image Hover Effects</a> allows users to add 40+ hover effects to images with captions.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 22nd 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #199:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 19:02:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"WPTavern: How to Give Back to the WordPress Foundation when Shopping on Amazon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46683\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"http://wptavern.com/how-to-give-back-to-the-wordpress-foundation-when-shopping-on-amazon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5051:\"<p>Consumer disappointment ran high yesterday when Amazon Prime Day <a href=\"https://twitter.com/hashtag/PrimeDayFail?src=hash\" target=\"_blank\">failed</a> to deliver on its ambitious claim to have &#8220;more deals than Black Friday.&#8221; Prime customers were surprised to find modest deals on knee braces, shoe horns, and pet grooming kits instead of steep discounts on shiny electronics.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">A Diane Keaton T Shirt,  with a 5 pack of brass knuckles AND ham?!?! DREAMS CAN COME TRUE <a href=\"https://twitter.com/hashtag/PrimeDayFail?src=hash\">#PrimeDayFail</a> <a href=\"http://t.co/hE1X6lhGb5\">pic.twitter.com/hE1X6lhGb5</a></p>
<p>&mdash; Roy Buckingham (@shave_my_lemon) <a href=\"https://twitter.com/shave_my_lemon/status/621462914533232640\">July 15, 2015</a></p></blockquote>
<p></p>
<p>The world was optimistic that if any company could create a consumer holiday out of thin air, Amazon would be the one to do it. Despite Prime Day&#8217;s humor-inspiring failure, consumer obsession with the online retail giant isn&#8217;t likely to wane anytime soon. In fact, the company reported that its &#8220;&#8216;<a href=\"http://phx.corporate-ir.net/phoenix.zhtml?c=176060&p=irol-newsArticle&ID=2068090\" target=\"_blank\">Prime Day&#8217; peak order rates surpassed that of 2014’s Black Friday</a>&#8221; early in the day.</p>
<p>If you&#8217;re a die hard Amazon shopper, you&#8217;ll probably continue on as if Prime Day never happened. Here&#8217;s how you can do something good for WordPress while you&#8217;re at it:</p>
<p>The <a href=\"http://smile.amazon.com/\" target=\"_blank\">AmazonSmile Foundation</a> enables shoppers to support their favorite charitable organizations when making purchases, at no extra cost. If you select a charity, AmazonSmile will automatically donate 0.5% of the purchase price from your eligible purchases. The <a href=\"http://wordpressfoundation.org/\" target=\"_blank\">WordPress Foundation</a> is among the nearly one million organizations that you can support.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-wordpress-foundation.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-wordpress-foundation.jpg?resize=1025%2C479\" alt=\"amazon-wordpress-foundation\" class=\"aligncenter size-full wp-image-46731\" /></a></p>
<p>To sign up, simply visit <a href=\"http://smile.amazon.com/\" target=\"_blank\">Smile.Amazon.com</a> and select the WordPress Foundation. You&#8217;ll be presented with options that will help you navigate to Smile.Amazon.com more conveniently the next time you shop. If you have already selected a charity and want to change it, you can visit your account settings to search and select a new organization.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-smile-change-charity.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/amazon-smile-change-charity.jpg?resize=877%2C492\" alt=\"amazon-smile-change-charity\" class=\"aligncenter size-full wp-image-46735\" /></a></p>
<h3>What does the WordPress Foundation do?</h3>
<p>Before you opt to support the <a href=\"http://wordpressfoundation.org/\" target=\"_blank\">WordPress Foundation</a>, it&#8217;s important to know what it&#8217;s all about. The 501(c)3 non-profit organization was established &#8220;to further the mission of the WordPress open source project: to democratize publishing through Open Source, GPL software.&#8221; Matt Mullenweg created the charity to ensure that future generations will have access to WordPress as the project&#8217;s leadership and contributor base continue to evolve. It also exists to protect the WordPress and WordCamp trademarks and logos.</p>
<p>A large portion of donations to the foundation go towards subsidizing WordCamp expenses, including video production of presentations for WordCamp.tv. The foundation also <a href=\"http://wptavern.com/wordpress-foundation-to-foot-the-bill-for-meetup-com-organizer-dues\" target=\"_blank\">covers Meetup.com organizer dues</a> for those who run WordPress meetups. At the beginning of this year, the foundation <a href=\"http://wptavern.com/the-wordpress-foundation-creates-a-traveling-scholarship-in-memory-of-kim-parsell\" target=\"_blank\">created a new traveling scholarship for women attending WordCamp US</a>, in memory of Kim Parsell, a prolific WordPress contributor who passed away this year.</p>
<p>When you support the WordPress Foundation, you are supporting a variety of community initiatives that help ensure the future of WordPress for years to come. Rose Goldman, who helps manage the foundation, recently set the organization up on AmazonSmile. So far, she said the donations from Amazon represent just a trickle of the budget, but that&#8217;s probably due to lack of awareness of AmazonSmile. If you haven&#8217;t yet selected a charity for automatic donations from <a href=\"http://smile.amazon.com/\" target=\"_blank\">AmazonSmile</a>, the WordPress Foundation is a worthy cause.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 18:52:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"WPTavern: What Should WordPress.tv Do with Old Videos?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46713\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wptavern.com/what-should-wordpress-tv-do-with-old-videos\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4208:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordPressTVFeaturedImage.png\"><img class=\"size-full wp-image-46739\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordPressTVFeaturedImage.png?resize=666%2C254\" alt=\"WordPress TV Featured Image\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/30719244@N06/8648634062\">tvs</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">(license)</a>
<p><a href=\"http://wordpress.tv/\">WordPress.tv</a> launched in <a href=\"https://wordpress.org/news/2009/01/wordpresstv/\">January of 2009</a> and since then has become one of the largest repositories of information dedicated to WordPress. To put that in perspective, WordPress 2.8 and 2.9 were released the same year.</p>
<p>However, with more than six years of content available, the team has run into a problem. On July 3rd, Brash Rebel, who helps manage WordPress.tv, <a href=\"https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/\">asked</a> if there should be a user interface for outdated content.</p>
<blockquote><p>A reality we are now facing is the fact that the software we know and love has evolved and changed considerably over this time period, thus rendering much of the early content on this site no longer applicable to users of more current releases of WordPress. In <a href=\"https://wordpress.slack.com/archives/wptv/p1435856572000421\">today’s TV team Slack meeting</a> the question was raised about how to properly address outdated, deprecated, no-longer-accurate content.</p></blockquote>
<p>The first question considered is whether to keep or delete old content, specifically, videos in the <a href=\"http://wordpress.tv/category/how-to/\">How To</a> category. Since so many people watch older tutorial style videos, the team decided that removing the content permanently from the site is not the best course of action. The other question considered is whether older presentations on specific subjects should be deleted.</p>
<p>For example, the following two sessions are about the same subject but four years apart. The content in the 2015 video is more likely to match the Google Analytics experience of today.</p>
<ol>
<li><a href=\"http://wordpress.tv/2013/03/16/melinda-samson-workshop-google-analytics-101/\">Melinda Samson: Google Analytics 101 Workshop (2011)</a></li>
<li><a href=\"http://wordpress.tv/2015/05/16/david-bird-google-analytics-and-wordpress-for-beginners-2/\">David Bird: Google Analytics and WordPress for Beginners (May, 2015)</a></li>
</ol>
<p>The team also discussed a variety of ideas on how to display information to viewers that they&#8217;re watching outdated content. These included, text prompts, information bars, links, and determining the best method to indicate videos don&#8217;t reflect the current WordPress experience.</p>
<p>Rebel says the goal isn&#8217;t to strictly deal with the issue today, but also set a precedence for the future. As more WordCamps occur across the globe and more <a href=\"https://make.wordpress.org/tv/2015/06/16/do-you-screencast-or-make-video-tutorials-of-how-to-use-wordpress-wordpress-tv-wants-you/\">screencasts</a> show up on WordPress.tv, the team needs to figure out a balance between displaying old content and making the most out of fresh content.</p>
<h2>Mimic the Plugin Directory</h2>
<p>I&#8217;m happy that the team won&#8217;t delete old videos. As someone who writes about WordPress everyday, the videos on WordPress.tv contain a wealth of knowledge. It would be a shame to see so much information deleted.</p>
<p>I think the best and easiest solution is to mimic the WordPress plugin directory in how it deals with plugins that haven&#8217;t been updated in two years or more. A prominent message displays on the page telling the viewer that the content they&#8217;re watching is outdated. It could be taken a step further by showing the viewer a list of related videos that are more recent.</p>
<p>I encourage you to<a href=\"https://make.wordpress.org/tv/2015/07/03/ui-for-outdated-content/\"> read the blog post</a> and the associated comments as they contain some good ideas. What do you think should be done with old content on WordPress.tv?</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 18:12:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt: TSA Jazz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45236\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"http://ma.tt/2015/07/tsa-jazz/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:769:\"<p>At an airport in Frankfurt airport security asked famous jazz saxophonist <a href=\"http://www.joshuaredman.com/\">Joshua Redman</a> to prove it was a real instrument.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">[airport security, FRA]&#10;*sax flagged*&#10;“Pls play”&#10;“Seriously?”&#10;“Yes”&#10;*i play Ornithology*&#10;*midway thru 1st chorus*&#10;“Enuf u’re clear pls stop”</p>
<p>&mdash; Joshua Redman (@Joshua_Redman) <a href=\"https://twitter.com/Joshua_Redman/status/619144413369909248\">July 9, 2015</a></p></blockquote>
<p></p>
<p>Hilarious! I can&#8217;t find any recordings of Joshua playing that classic bebop song, but here&#8217;s a Charlie Parker recording:</p>
<p><span class=\"embed-youtube\"></span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 15:12:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Explore the WordPress REST API with the New Interactive Console Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46685\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/explore-the-wordpress-rest-api-with-the-new-interactive-console-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3697:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg?resize=1025%2C469\" alt=\"wp-rest-api\" class=\"aligncenter size-full wp-image-43000\" /></a></p>
<p>WordPress REST API project lead <a href=\"https://twitter.com/rmccue\" target=\"_blank\">Ryan McCue</a>, in cooperation with <a href=\"https://twitter.com/AutomatticEng\" target=\"_blank\">Automattic&#8217;s Engineering team</a>, released a <a href=\"https://wordpress.org/plugins/rest-api-console/\" target=\"_blank\">REST API Console</a> plugin on WordPress.org today. It&#8217;s a basic console that fits right into the WordPress admin and allows you to explore the API, make small changes, and find out what your site is exposing.</p>
<p>&#8220;This is a forked version of the WP.com console that myself and members of the Apollo team at Automattic worked on,&#8221; McCue told the Tavern. The console was converted in approximately four casual days, and McCue credits <a href=\"http://viewsource.beaucollins.com/\" target=\"_blank\">Beau Collins</a> for this, as he originally wrote the majority of the console for developers working on WordPress.com.</p>
<p>&#8220;It&#8217;s pretty useful for exploring the API as a learning tool, but also for developers who are extending the API to get a sense of how their stuff fits in,&#8221; he said.</p>
<p>The REST API Console plugin requires the <a href=\"https://wordpress.org/plugin/rest-api/\" target=\"_blank\">WP REST API plugin</a> version 2.0 or later. You can find this on the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">GitHub project page</a> and version 2 should be up on WordPress.org within the next day or two. Once you have both plugins installed, the console is visible in the admin under <strong>Tools > Rest API Console</strong>.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg?resize=829%2C236\" alt=\"wp-rest-api-console-demo\" class=\"aligncenter size-full wp-image-46693\" /></a></p>
<p>You can actually make changes to your site using the console, so it&#8217;s advisable to install it on a local site and play with it there. While the GET requests can&#8217;t change anything, the other types can edit or delete posts (which would end up in your trash).</p>
<p>The plugin can only connect to the local site you&#8217;re currently on and cannot access remote WordPress sites. McCue recommends using something like <a href=\"https://www.getpostman.com/\" target=\"_blank\">Postman</a> or <a href=\"http://luckymarmot.com/paw\" target=\"_blank\">Paw</a> if you want to play around with remote sites.</p>
<p>In the future, he hopes to add more features and improve the plugin&#8217;s parameter documentation.</p>
<p>&#8220;The older WordPress.com console had the ability to click through to links, so I&#8217;d like to re-add that at some point,&#8221; he said. &#8220;The parameter documentation and tooling hasn&#8217;t been fleshed out yet, but the plan is to do it eventually &#8211; we&#8217;re working on exposing more from the API itself, too.&#8221;</p>
<p>If you want to tinker with the API but don&#8217;t have a local testing site handy, check out the live demo at <a href=\"http://demo.wp-api.org\" target=\"_blank\">demo.wp-api.org</a> where you can click around to explore. This will save you the trouble of installing the plugin, if you just want to try it out. Also, you can&#8217;t perform any destructive changes there. Version 2 of the WP REST API plugin should be available on WordPress.org within 24-48 hours.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 00:31:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: WordPress Theme Review Team Unanimously Approves Roadmap to Improve Directory and Review Process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46551\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"http://wptavern.com/wordpress-theme-review-team-unanimously-approves-roadmap-to-improve-directory-and-review-process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2613:\"<p>The <a href=\"https://make.wordpress.org/themes/\">Theme Review Team</a> has spent the last two months <a href=\"http://wptavern.com/wordpress-theme-review-team-seeks-feedback-on-the-review-process-themes-and-the-directory\">collecting data from surveys</a> to discover common pain points people experience using the theme directory and going through the theme review process. The results of those surveys were used to <a href=\"https://make.wordpress.org/themes/2015/07/07/roadmap-for-phase-one/\">create a roadmap</a> of areas to focus on.</p>
<p>In yesterday&#8217;s meeting, the Theme Review Team voted and those in attendance <a href=\"https://wordpress.slack.com/archives/themereview/p1436896772000053\">unanimously approved</a> the roadmap.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png\"><img class=\"size-full wp-image-46668\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png?resize=471%2C560\" alt=\"Phase One Roadmap Approved\" /></a>Phase One Roadmap Approved
<p>One of the key parts to the roadmap is creating groups with a scope of responsibilities. The groups include:</p>
<ul>
<li>Directory</li>
<li>Documentation</li>
<li>Tools</li>
<li>Reviews and queues</li>
<li>UX and research</li>
</ul>
<p>Each group needs a point person who acts as the communication bridge between the group and Theme Review Team. Tammie Lister explains what the point person&#8217;s role is within a group.</p>
<blockquote><p>This person will report weekly what is going on during the chats. They will also post on the make.blog each week about what is going on in each group. This should ensure we keep up communication and make sure things get done.</p></blockquote>
<p>They&#8217;re not necessarily in charge of getting things done but rather, act as a facilitator to make sure the group stays on track.</p>
<p>One part of the roadmap that I&#8217;m interested in is the possibility of a report button added to the theme directory to allow users to report themes. If this happens, it will be interesting to see how it&#8217;s used or abused and whether it adds any additional work load to the theme reviewers.</p>
<p>The roadmap looks solid and shows the team is focused on improving several aspects of the Theme Directory. This is a great opportunity for new contributors to get involved with the project. If you&#8217;re interested in joining any of the groups within the Theme Review Team, please visit the <strong>#themereview</strong> channel on <a href=\"https://make.wordpress.org/chat/\">Slack</a> and let the team know.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 21:10:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 08 Aug 2015 01:16:40 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"296073\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Sat, 08 Aug 2015 01:00:18 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("319","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1439039801","no");
INSERT INTO `arc1542_options` VALUES("320","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1438996601","no");
INSERT INTO `arc1542_options` VALUES("321","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1439039802","no");
INSERT INTO `arc1542_options` VALUES("322","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 08 Aug 2015 01:03:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"18101@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"http://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"15@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"http://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"23862@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Your WordPress, Streamlined.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"753@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"1169@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 12 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"29832@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Hello Dolly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wordpress.org/plugins/hello-dolly/#post-5790\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 29 May 2008 22:11:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"5790@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"132@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"http://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2082@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"http://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"29860@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"http://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2316@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Yoast SEO\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"http://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"8321@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:114:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"WP-PageNavi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/plugins/wp-pagenavi/#post-363\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 23:17:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"363@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"Adds a more advanced paging navigation interface.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Lester Chan\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"25254@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2141@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2572@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Really Simple CAPTCHA\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://wordpress.org/plugins/really-simple-captcha/#post-9542\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 09 Mar 2009 02:17:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"9542@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Regenerate Thumbnails\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"http://wordpress.org/plugins/regenerate-thumbnails/#post-6743\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 23 Aug 2008 14:38:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"6743@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"Allows you to regenerate your thumbnails after changing the thumbnail sizes.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Alex Mills (Viper007Bond)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"W3 Total Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"http://wordpress.org/plugins/w3-total-cache/#post-12073\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 29 Jul 2009 18:46:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"12073@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:132:\"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Frederick Townes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Disable Comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"http://wordpress.org/plugins/disable-comments/#post-26907\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 27 May 2011 04:42:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"26907@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:134:\"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Samir Shah\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Duplicate Post\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://wordpress.org/plugins/duplicate-post/#post-2646\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 05 Dec 2007 17:40:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"2646@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Clone posts and pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"lopo\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WP Multibyte Patch\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/plugins/wp-multibyte-patch/#post-28395\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Jul 2011 12:22:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"28395@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Multibyte functionality enhancement for the WordPress Japanese package.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"plugin-master\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"iThemes Security (formerly Better WP Security)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"21738@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Chris Wiegman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"31973@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Meta Slider\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"http://wordpress.org/plugins/ml-slider/#post-49521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Feb 2013 16:56:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"49521@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Matcha Labs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"51888@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Google Analytics\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"http://wordpress.org/plugins/googleanalytics/#post-11199\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2009 22:09:25 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"11199@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"Enables google analytics on all pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Kevin Sylvestre\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WP-DB-Backup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wordpress.org/plugins/wp-db-backup/#post-472\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 17 Mar 2007 04:41:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"472@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"On-demand backup of your WordPress database.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"ringmaster\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"50539@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Duplicator\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wordpress.org/plugins/duplicator/#post-26607\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 16 May 2011 12:15:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"26607@http://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"Duplicate, clone, backup, move and transfer an entire site from one location to another.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Cory Lamle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:45:\"http://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Sat, 08 Aug 2015 01:16:42 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Sat, 08 Aug 2015 01:38:53 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Sat, 08 Aug 2015 01:03:53 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("323","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1439039802","no");
INSERT INTO `arc1542_options` VALUES("324","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1438996602","no");
INSERT INTO `arc1542_options` VALUES("325","_transient_timeout_plugin_slugs","1439083281","no");
INSERT INTO `arc1542_options` VALUES("326","_transient_plugin_slugs","a:3:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"better-wp-security/better-wp-security.php\";i:2;s:23:\"wordfence/wordfence.php\";}","no");
INSERT INTO `arc1542_options` VALUES("327","_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51","1439039802","no");
INSERT INTO `arc1542_options` VALUES("328","_transient_dash_4077549d03da2e451c8b5f002294ff51","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/08/wordpress-4-2-4-security-and-maintenance-release/\'>WordPress 4.2.4 Security and Maintenance Release</a> <span class=\"rss-date\">August 4, 2015</span><div class=\"rssSummary\">WordPress 4.2.4 is now available. This is a security release for all previous versions and we strongly encourage you to update your sites immediately. This release addresses six issues, including three cross-site scripting vulnerabilities and a potential SQL injection that could be used to compromise a site, which were discovered by Marc-Alexandre Montpas of Sucuri, Helen Hou-Sandí [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/skipress-a-week-long-excursion-in-the-french-alps\'>WPTavern: SkiPress a Week Long Excursion in the French Alps</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/richard-best-publishes-human-readable-version-of-the-gplv2-license\'>WPTavern: Richard Best Publishes Human Readable Version of the GPLv2 License</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wpweekly-episode-202-prestige-is-serious-business\'>WPTavern: WPWeekly Episode 202 – Prestige is Serious Business</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'http://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=15f061d8fb&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Install</a>)</span></li></ul></div>","no");
INSERT INTO `arc1542_options` VALUES("330","theme_mods_twentyfifteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1438996827;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:18:\"orphaned_widgets_1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `arc1542_options` VALUES("333","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1438996879;s:7:\"checked\";a:3:{s:19:\"akismet/akismet.php\";s:5:\"3.1.3\";s:41:\"better-wp-security/better-wp-security.php\";s:5:\"4.9.0\";s:23:\"wordfence/wordfence.php\";s:6:\"6.0.15\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"3.1.3\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.3.1.3.zip\";}s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"18308\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:5:\"4.9.0\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:67:\"https://downloads.wordpress.org/plugin/better-wp-security.4.9.0.zip\";}s:23:\"wordfence/wordfence.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"25305\";s:4:\"slug\";s:9:\"wordfence\";s:6:\"plugin\";s:23:\"wordfence/wordfence.php\";s:11:\"new_version\";s:6:\"6.0.15\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wordfence/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/plugin/wordfence.6.0.15.zip\";}}}","yes");
INSERT INTO `arc1542_options` VALUES("334","widget_nav_menu","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("335","widget_pages","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("337","widget_tag_cloud","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("339","widget_ut_site_info_contactus_widget","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("340","widget_ut_highlight","a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("345","_site_transient_timeout_itsec_upload_dir","1439341523","yes");
INSERT INTO `arc1542_options` VALUES("346","_site_transient_itsec_upload_dir","a:6:{s:4:\"path\";s:51:\"/Users/ahayter/Sites/arc/arc-assets/uploads/2015/08\";s:3:\"url\";s:41:\"http://arc.dev/arc-assets/uploads/2015/08\";s:6:\"subdir\";s:8:\"/2015/08\";s:7:\"basedir\";s:43:\"/Users/ahayter/Sites/arc/arc-assets/uploads\";s:7:\"baseurl\";s:33:\"http://arc.dev/arc-assets/uploads\";s:5:\"error\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("347","_transient_doing_cron","1439255124.0635330677032470703125","yes");
INSERT INTO `arc1542_options` VALUES("348","_site_transient_timeout_itsec_notification_running","1439258724","yes");
INSERT INTO `arc1542_options` VALUES("349","_site_transient_itsec_notification_running","1","yes");


DROP TABLE IF EXISTS `arc1542_postmeta`;

CREATE TABLE `arc1542_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `arc1542_postmeta` VALUES("2","4","_menu_item_type","custom");
INSERT INTO `arc1542_postmeta` VALUES("3","4","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("4","4","_menu_item_object_id","4");
INSERT INTO `arc1542_postmeta` VALUES("5","4","_menu_item_object","custom");
INSERT INTO `arc1542_postmeta` VALUES("6","4","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("7","4","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("8","4","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("9","4","_menu_item_url","http://test.dev/");
INSERT INTO `arc1542_postmeta` VALUES("11","5","_menu_item_type","post_type");
INSERT INTO `arc1542_postmeta` VALUES("12","5","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("13","5","_menu_item_object_id","2");
INSERT INTO `arc1542_postmeta` VALUES("14","5","_menu_item_object","page");
INSERT INTO `arc1542_postmeta` VALUES("15","5","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("16","5","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("17","5","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("18","5","_menu_item_url","");
INSERT INTO `arc1542_postmeta` VALUES("20","6","_menu_item_type","post_type");
INSERT INTO `arc1542_postmeta` VALUES("21","6","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("22","6","_menu_item_object_id","2");
INSERT INTO `arc1542_postmeta` VALUES("23","6","_menu_item_object","page");
INSERT INTO `arc1542_postmeta` VALUES("24","6","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("25","6","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("26","6","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("27","6","_menu_item_url","");


DROP TABLE IF EXISTS `arc1542_posts`;

CREATE TABLE `arc1542_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_posts` VALUES("1","2","2015-06-15 19:42:40","2015-06-15 19:42:40","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","publish","open","open","","hello-world","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?p=1","0","post","","1");
INSERT INTO `arc1542_posts` VALUES("2","2","2015-06-15 19:42:40","2015-06-15 19:42:40","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://test.dev/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","publish","open","open","","sample-page","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?page_id=2","0","page","","0");
INSERT INTO `arc1542_posts` VALUES("3","2","2015-06-15 19:42:53","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2015-06-15 19:42:53","0000-00-00 00:00:00","","0","http://test.dev/?p=3","0","post","","0");
INSERT INTO `arc1542_posts` VALUES("4","2","2015-07-16 01:54:35","2015-07-16 05:54:35","","Home","","publish","open","open","","home","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=4","1","nav_menu_item","","0");
INSERT INTO `arc1542_posts` VALUES("5","2","2015-07-16 01:54:35","2015-07-16 05:54:35"," ","","","publish","open","open","","5","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=5","2","nav_menu_item","","0");
INSERT INTO `arc1542_posts` VALUES("6","2","2015-07-16 01:54:35","2015-07-16 05:54:35"," ","","","publish","open","open","","6","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=6","3","nav_menu_item","","0");


DROP TABLE IF EXISTS `arc1542_term_relationships`;

CREATE TABLE `arc1542_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_relationships` VALUES("1","1","0");
INSERT INTO `arc1542_term_relationships` VALUES("4","2","0");
INSERT INTO `arc1542_term_relationships` VALUES("5","2","0");
INSERT INTO `arc1542_term_relationships` VALUES("6","2","0");


DROP TABLE IF EXISTS `arc1542_term_taxonomy`;

CREATE TABLE `arc1542_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `arc1542_term_taxonomy` VALUES("2","2","nav_menu","","0","3");


DROP TABLE IF EXISTS `arc1542_terms`;

CREATE TABLE `arc1542_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `arc1542_terms` VALUES("2","Menu 1","menu-1","0");


DROP TABLE IF EXISTS `arc1542_usermeta`;

CREATE TABLE `arc1542_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_usermeta` VALUES("1","2","nickname","Andre Hayter");
INSERT INTO `arc1542_usermeta` VALUES("2","2","first_name","");
INSERT INTO `arc1542_usermeta` VALUES("3","2","last_name","");
INSERT INTO `arc1542_usermeta` VALUES("4","2","description","");
INSERT INTO `arc1542_usermeta` VALUES("5","2","rich_editing","true");
INSERT INTO `arc1542_usermeta` VALUES("6","2","comment_shortcuts","false");
INSERT INTO `arc1542_usermeta` VALUES("7","2","admin_color","fresh");
INSERT INTO `arc1542_usermeta` VALUES("8","2","use_ssl","0");
INSERT INTO `arc1542_usermeta` VALUES("9","2","show_admin_bar_front","true");
INSERT INTO `arc1542_usermeta` VALUES("10","2","arc1542_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `arc1542_usermeta` VALUES("11","2","arc1542_user_level","10");
INSERT INTO `arc1542_usermeta` VALUES("12","2","dismissed_wp_pointers","wp360_locks,wp390_widgets");
INSERT INTO `arc1542_usermeta` VALUES("13","2","show_welcome_panel","1");
INSERT INTO `arc1542_usermeta` VALUES("14","2","session_tokens","a:1:{s:64:\"c31e9ef0976489d49d0095126e78b99b6ad99f0668e6e036bfdbeb191705c4e3\";a:4:{s:10:\"expiration\";i:1439169395;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36\";s:5:\"login\";i:1438996595;}}");
INSERT INTO `arc1542_usermeta` VALUES("15","2","arc1542_dashboard_quick_press_last_post_id","3");
INSERT INTO `arc1542_usermeta` VALUES("16","2","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `arc1542_usermeta` VALUES("17","2","metaboxhidden_nav-menus","a:3:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}");


DROP TABLE IF EXISTS `arc1542_users`;

CREATE TABLE `arc1542_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_users` VALUES("2","ahayter","$P$Bv7PyMKGXpEmyukWPx7wtK5UuTwoO10","andre-hayter","andre.hayter+arc@gmail.com","","2015-06-15 19:42:40","","0","Andre Hayter");


DROP TABLE IF EXISTS `arc1542_wfBadLeechers`;

CREATE TABLE `arc1542_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfBlockedIPLog`;

CREATE TABLE `arc1542_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`unixday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocks`;

CREATE TABLE `arc1542_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocksAdv`;

CREATE TABLE `arc1542_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfConfig`;

CREATE TABLE `arc1542_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfConfig` VALUES("actUpdateInterval","");
INSERT INTO `arc1542_wfConfig` VALUES("addCacheComment","0");
INSERT INTO `arc1542_wfConfig` VALUES("advancedCommentScanning","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertEmails","andre.hayter+arc@gmail.com");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_adminLogin","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_block","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_critical","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_loginLockout","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_lostPasswdForm","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_nonAdminLogin","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_throttle","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_update","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_warnings","1");
INSERT INTO `arc1542_wfConfig` VALUES("alert_maxHourly","0");
INSERT INTO `arc1542_wfConfig` VALUES("allowed404s","/favicon.ico
/apple-touch-icon*.png
/*@2x.png");
INSERT INTO `arc1542_wfConfig` VALUES("allowHTTPSCaching","0");
INSERT INTO `arc1542_wfConfig` VALUES("apiKey","db0301f529f254dbf9220171caf7ddd101ee22964ad7cd38e529908964a2239b77621a5354eba6cd87e15b40cce0d2013dc4d1933782fba373cf1551df12afda");
INSERT INTO `arc1542_wfConfig` VALUES("autoBlockScanners","0");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdateChoice","1");
INSERT INTO `arc1542_wfConfig` VALUES("bannedURLs","");
INSERT INTO `arc1542_wfConfig` VALUES("blockedTime","300");
INSERT INTO `arc1542_wfConfig` VALUES("blockFakeBots","0");
INSERT INTO `arc1542_wfConfig` VALUES("cacheType","falcon");
INSERT INTO `arc1542_wfConfig` VALUES("cbl_restOfSiteBlocked","1");
INSERT INTO `arc1542_wfConfig` VALUES("checkSpamIP","0");
INSERT INTO `arc1542_wfConfig` VALUES("currentCronKey","");
INSERT INTO `arc1542_wfConfig` VALUES("debugOn","0");
INSERT INTO `arc1542_wfConfig` VALUES("deleteTablesOnDeact","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCodeExecutionUploads","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableConfigCaching","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCookies","0");
INSERT INTO `arc1542_wfConfig` VALUES("emailedIssuesList","a:4:{i:0;a:2:{s:7:\"ignoreC\";s:32:\"106719a1dd449e2636475e907c5f49da\";s:7:\"ignoreP\";s:32:\"106719a1dd449e2636475e907c5f49da\";}i:1;a:2:{s:7:\"ignoreC\";s:32:\"52388f270b5efc2b6d97a713c9ba5aca\";s:7:\"ignoreP\";s:32:\"52388f270b5efc2b6d97a713c9ba5aca\";}i:2;a:2:{s:7:\"ignoreC\";s:32:\"ff13dfaaceee016ccb5c2953dc03880b\";s:7:\"ignoreP\";s:32:\"ff13dfaaceee016ccb5c2953dc03880b\";}i:3;a:2:{s:7:\"ignoreC\";s:32:\"70ba4ebbe4ca61e940ed6d0fd4b510dd\";s:7:\"ignoreP\";s:32:\"70ba4ebbe4ca61e940ed6d0fd4b510dd\";}}");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_dashboard_widget_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_excluded_directories","wp-content/cache,wp-content/wfcache,wp-content/plugins/wordfence/tmp");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_interval","biweekly");
INSERT INTO `arc1542_wfConfig` VALUES("encKey","69b5df86475affbe");
INSERT INTO `arc1542_wfConfig` VALUES("firewallEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("howGetIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("lastAdminLogin","a:6:{s:6:\"userID\";i:2;s:8:\"username\";s:7:\"ahayter\";s:9:\"firstName\";s:0:\"\";s:8:\"lastName\";s:0:\"\";s:4:\"time\";s:27:\"Fri 7th August @ 09:16:36PM\";s:2:\"IP\";s:3:\"::1\";}");
INSERT INTO `arc1542_wfConfig` VALUES("lastEmailHash","1438996596:051b3653b1f5d0f0be99aa2a74d45cb8");
INSERT INTO `arc1542_wfConfig` VALUES("lastScanCompleted","ok");
INSERT INTO `arc1542_wfConfig` VALUES("lastScheduledScanStart","1438996048");
INSERT INTO `arc1542_wfConfig` VALUES("liveTrafficEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignorePublishers","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUA","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUsers","");
INSERT INTO `arc1542_wfConfig` VALUES("loginSecurityEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_blockAdminReg","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_countFailMins","5");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_disableAuthorScan","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockInvalidUsers","0");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockoutMins","5");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maskLoginErrors","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxFailures","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxForgotPasswd","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_strongPasswds","pubs");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_userBlacklist","");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxExecutionTime","");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxMem","256");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("neverBlockBG","neverBlockVerified");
INSERT INTO `arc1542_wfConfig` VALUES("other_blockBadPOST","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_hideWPVersion","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_noAnonMemberComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_pwStrengthOnUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanOutside","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_WFNet","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_comments","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_core","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_database","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_diskSpace","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_dns","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_fileContents","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_heartbleed","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_highSense","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_malware","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_oldVersions","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_options","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_passwds","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_plugins","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_posts","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_public","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_scanImages","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_themes","0");
INSERT INTO `arc1542_wfConfig` VALUES("scan_exclude","");
INSERT INTO `arc1542_wfConfig` VALUES("scheduledScansEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("securityLevel","2");
INSERT INTO `arc1542_wfConfig` VALUES("spamvertizeCheck","0");
INSERT INTO `arc1542_wfConfig` VALUES("ssl_verify","1");
INSERT INTO `arc1542_wfConfig` VALUES("startScansRemotely","0");
INSERT INTO `arc1542_wfConfig` VALUES("totalAlertsSent","2");
INSERT INTO `arc1542_wfConfig` VALUES("totalLoginHits","4");
INSERT INTO `arc1542_wfConfig` VALUES("totalLogins","2");
INSERT INTO `arc1542_wfConfig` VALUES("totalScansRun","5");
INSERT INTO `arc1542_wfConfig` VALUES("tourClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("vulnRegex","/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i");
INSERT INTO `arc1542_wfConfig` VALUES("welcomeClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("wfKillRequested","0");
INSERT INTO `arc1542_wfConfig` VALUES("wfPeakMemory","41191760");
INSERT INTO `arc1542_wfConfig` VALUES("wfsd_engine","");
INSERT INTO `arc1542_wfConfig` VALUES("wfStatusStartMsgs","a:14:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";i:7;s:0:\"\";i:8;s:0:\"\";i:9;s:0:\"\";i:10;s:0:\"\";i:11;s:0:\"\";i:12;s:0:\"\";i:13;s:0:\"\";}");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsA","test.dev points to 127.0.53.53");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsCNAME","");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsLogged","1");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsMX","your-dns-needs-immediate-attention.dev");
INSERT INTO `arc1542_wfConfig` VALUES("wf_scanRunning","");
INSERT INTO `arc1542_wfConfig` VALUES("wf_summaryItems","a:16:{s:10:\"totalUsers\";i:1;s:10:\"totalPages\";s:1:\"1\";s:10:\"totalPosts\";s:1:\"1\";s:13:\"totalComments\";s:1:\"1\";s:15:\"totalCategories\";s:1:\"1\";s:11:\"totalTables\";i:34;s:9:\"totalRows\";i:1607;s:12:\"totalPlugins\";i:3;s:10:\"lastUpdate\";i:1438996075;s:11:\"totalThemes\";i:1;s:9:\"totalData\";s:8:\"23.15 MB\";s:10:\"totalFiles\";i:1008;s:9:\"totalDirs\";i:88;s:10:\"linesOfPHP\";i:251502;s:10:\"linesOfJCH\";i:125739;s:8:\"scanTime\";d:1438996075.822505950927734375;}");
INSERT INTO `arc1542_wfConfig` VALUES("whitelisted","");


DROP TABLE IF EXISTS `arc1542_wfCrawlers`;

CREATE TABLE `arc1542_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfFileMods`;

CREATE TABLE `arc1542_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfFileMods` VALUES("\00��#�9���Z4�j$","wp-admin/network/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1�s�̶>��Ѕc��");
INSERT INTO `arc1542_wfFileMods` VALUES("\05g���꫔c�0�\"D","wp-includes/css/media-views-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2q_�9�5VLT");
INSERT INTO `arc1542_wfFileMods` VALUES("\0C_
��jD��@k","wp-admin/network/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�V1�r/���.���J");
INSERT INTO `arc1542_wfFileMods` VALUES("\0`Y�ϭrG����","wp-includes/SimplePie/Restriction.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*qhd�s�;�y");
INSERT INTO `arc1542_wfFileMods` VALUES("\0���;f��Q�=*Ǖ�","wp-includes/js/wp-emoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�{G��B�ʚ�W");
INSERT INTO `arc1542_wfFileMods` VALUES("\0�|9��u�e���@��","wp-admin/includes/image.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�3q��.����О���");
INSERT INTO `arc1542_wfFileMods` VALUES("NQ�\"*hz�r�w|�","wp-admin/images/media-button-other.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ƴk�|��,O�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�T�h���zP��r�","wp-admin/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˂�ב�_/h�
:");
INSERT INTO `arc1542_wfFileMods` VALUES("t]�ٟu��u���j�","wp-admin/images/menu-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q���L�,_�;1/�E�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~�w`�5;F㮮","wp-includes/js/jquery/ui/effect-size.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":I�k�C�*���]�");
INSERT INTO `arc1542_wfFileMods` VALUES("�=��q�ljA+","wp-admin/user/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*zu�c���m	J��e�");
INSERT INTO `arc1542_wfFileMods` VALUES("<)8T*.�SuS�ĺ�","wp-includes/SimplePie/Cache/MySQL.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B�C�H�xV�");
INSERT INTO `arc1542_wfFileMods` VALUES("HC���!���\"(�","wp-includes/js/tinymce/plugins/compat3x/css/dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͕�\0A��It�dH");
INSERT INTO `arc1542_wfFileMods` VALUES("u��s��y6\'v,��=","wp-includes/js/tinymce/plugins/wordpress/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�Bf��n�`��");
INSERT INTO `arc1542_wfFileMods` VALUES("����7�&��Ȁ","wp-includes/js/tinymce/skins/lightgray/content.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","oS�pZ5��Ǜ4�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���љ����\0H<_","wp-admin/includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J물�@��Y�OS�p");
INSERT INTO `arc1542_wfFileMods` VALUES("i��PÙ��ld\0��","wp-includes/css/jquery-ui-dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
��d����\\6�");
INSERT INTO `arc1542_wfFileMods` VALUES("!���@|�4��n���","wp-includes/class-http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Qc.F��B�6�l��");
INSERT INTO `arc1542_wfFileMods` VALUES("\'ڞ\0;��?�+VҪ�","wp-admin/network/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�Y�&��;^���");
INSERT INTO `arc1542_wfFileMods` VALUES("E�&��VN���\"N","wp-admin/css/ie.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F�Y\0��g�H�0��");
INSERT INTO `arc1542_wfFileMods` VALUES("�P\0\'�0l���v�#J<","wp-includes/js/jquery/ui/effect-fold.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6^�����<��DEl");
INSERT INTO `arc1542_wfFileMods` VALUES("Ȅ���xy�����","wp-includes/js/tinymce/skins/wordpress/images/embedded.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�N��y~�n\"");
INSERT INTO `arc1542_wfFileMods` VALUES("ϴ 3P`#8^��Z","wp-admin/css/colors/coffee/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2���#6��`τ}L");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��N߬jj)��\0��N","wp-admin/images/menu-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jG�����{�>�^;$��");
INSERT INTO `arc1542_wfFileMods` VALUES("tZQ��Yz0����跫","wp-admin/images/wordpress-logo.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ư�y��o�8��8S�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k�5S�H���Ы","wp-includes/SimplePie/Author.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�q�_�A�%�Nw�1");
INSERT INTO `arc1542_wfFileMods` VALUES("���e�bW�A0�d","wp-admin/images/comment-grey-bubble.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�*\'����t���F");
INSERT INTO `arc1542_wfFileMods` VALUES("Q� ��(;ؠ|~R8�b","wp-admin/includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_���zd��BO�V");
INSERT INTO `arc1542_wfFileMods` VALUES("���%bQ�bM<�x","wp-includes/js/imgareaselect/border-anim-h.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��,�ntZ^6�{Lp�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ѧ�_�4a!�F��","wp-admin/css/ie.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","IBT�\'�n�i�)P�");
INSERT INTO `arc1542_wfFileMods` VALUES("��i)33ܥ��s�*","wp-admin/includes/class-wp-ms-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��&�+�zĘ�}�İ#");
INSERT INTO `arc1542_wfFileMods` VALUES("���#����	>�7","wp-includes/js/tinymce/skins/wordpress/images/pagebreak.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I��m���LWyݓH");
INSERT INTO `arc1542_wfFileMods` VALUES("k����b��gS�","wp-includes/js/tinymce/plugins/wplink/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���`�{WﺾUi\'w");
INSERT INTO `arc1542_wfFileMods` VALUES("����g�~�w�hh","wp-admin/css/themes-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\0�wE�i�O�!��}");
INSERT INTO `arc1542_wfFileMods` VALUES("	QW���~-�\0d�","wp-includes/class-phpass.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�FDP�\0�f�G�Ƨ");
INSERT INTO `arc1542_wfFileMods` VALUES("	?������q�uM","wp-includes/js/mediaelement/mediaelementplayer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�ؗx�����[�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("	,��/Օ�!�gy�d","wp-includes/js/media-editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��$�m+�:xܔ��D");
INSERT INTO `arc1542_wfFileMods` VALUES("	P=N>��b\"j:~[Q{�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[ߢ�9��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("	X�t\\4vNI5��j��","wp-admin/async-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<Br?d�T\'��Z�0X");
INSERT INTO `arc1542_wfFileMods` VALUES("	�9��fވU�f����","wp-includes/js/tinymce/tinymce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/ZV�9��N.{�Ћ");
INSERT INTO `arc1542_wfFileMods` VALUES("	����09��-b��ͩW","wp-admin/network/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Zv\\����ǝ{�g2");
INSERT INTO `arc1542_wfFileMods` VALUES("
f���Y��4&�L�","wp-admin/images/se.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȔB�`��.}\'7:");
INSERT INTO `arc1542_wfFileMods` VALUES("
���b-�V�:��|m��","wp-admin/edit-link-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7����d�G�G�\0�G%");
INSERT INTO `arc1542_wfFileMods` VALUES("
��NNM��ۑ4;�p�4","wp-includes/js/customize-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","OK�.�q;�t��N�
");
INSERT INTO `arc1542_wfFileMods` VALUES("
��B��p̭","wp-admin/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH���wY���");
INSERT INTO `arc1542_wfFileMods` VALUES("\"w%�_��K\\��u�","wp-admin/images/wpspin_light.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("&c�YD�#�P{+��","wp-includes/js/jquery/ui/effect-blind.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<O�mA�_;OL");
INSERT INTO `arc1542_wfFileMods` VALUES("���,H(b�_F�O","wp-admin/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�G𿤂X�ΗN��");
INSERT INTO `arc1542_wfFileMods` VALUES("��HVե�d��p�Vp","wp-includes/images/media/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���4���\0T��̇?�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c\"ml� �Ǟ>o","wp-admin/images/wordpress-logo.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N�%�d���g���p");
INSERT INTO `arc1542_wfFileMods` VALUES("{�M��i�i2n��6�","wp-includes/js/jquery/ui/effect-highlight.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����*��øN���!");
INSERT INTO `arc1542_wfFileMods` VALUES("xݍ�^������<;","wp-admin/my-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W_H�3��8	����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ҧxOz���z���h","wp-includes/class-wp-customize-panel.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����v�x~;)�]��l�");
INSERT INTO `arc1542_wfFileMods` VALUES("��:�:���HH�:d","wp-admin/css/edit.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����~�1Y*�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%����%�yS�`�","wp-includes/js/crop/cropper.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����H.s�o����");
INSERT INTO `arc1542_wfFileMods` VALUES("Ѫ1s1=��`(�y","wp-admin/options-head.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֕`^m�N@
Tof~�");
INSERT INTO `arc1542_wfFileMods` VALUES("X��H奥(�:�Z��","wp-admin/admin-ajax.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����:��em�-XL$");
INSERT INTO `arc1542_wfFileMods` VALUES("go�s�V�;����
$","wp-includes/js/tinymce/plugins/compat3x/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=�\\�-����e���U");
INSERT INTO `arc1542_wfFileMods` VALUES("� ��C�Y���","wp-includes/pomo/entry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�L�ǼƢ�v�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�M�8� ٵ��|","wp-includes/images/crystal/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S������I0An�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"J\04��\'i�","wp-admin/js/password-strength-meter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�(F�Vp��#*�{�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�&�nb��i�ٷ�","wp-includes/js/mediaelement/silverlightmediaelement.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�:=C\".K�|�n\0t�");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����AV*籿","wp-includes/js/jquery/ui/slider.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}	1l4�&��QW��L�");
INSERT INTO `arc1542_wfFileMods` VALUES("\0��]�a�v���CY","wp-includes/class-wp-walker.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W#�\'����m");
INSERT INTO `arc1542_wfFileMods` VALUES("���NVԱ��z�Z","wp-includes/js/jquery/ui/effect-shake.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'JgV�̯\0�@p�");
INSERT INTO `arc1542_wfFileMods` VALUES(")��_���J�����","wp-includes/js/media-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".xd��#c�n�3{��");
INSERT INTO `arc1542_wfFileMods` VALUES("`�&��锥~K3/d","wp-admin/css/login.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�n�h�&Yk
cB�");
INSERT INTO `arc1542_wfFileMods` VALUES("�~��L��*�,�<:�","wp-admin/includes/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�at{V��Qƅ�*քU");
INSERT INTO `arc1542_wfFileMods` VALUES("�Sx��4�@o�w�N","wp-admin/js/widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�nLyuf6�o�1�LfjM");
INSERT INTO `arc1542_wfFileMods` VALUES("���:m��[ݢ�:#","wp-includes/l10n.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T��YdIq?�8");
INSERT INTO `arc1542_wfFileMods` VALUES("�I��\\j���x���g","wp-admin/images/date-button-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")R�,$k���)6C��c");
INSERT INTO `arc1542_wfFileMods` VALUES("���j7r[�,���Z��","wp-admin/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-&6��ۉ<g�k�6s�");
INSERT INTO `arc1542_wfFileMods` VALUES("D�8hFޛBViR�","wp-admin/css/colors/blue/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�
��`trk");
INSERT INTO `arc1542_wfFileMods` VALUES("j׻���q.�*;��2","wp-admin/css/colors/sunrise/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y�N�^�&R\"�6�a�");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�W�3���᥾V","wp-admin/css/color-picker-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z4w��l�e�$��");
INSERT INTO `arc1542_wfFileMods` VALUES(":�X��2�M���~��","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G6	=���<�%�#");
INSERT INTO `arc1542_wfFileMods` VALUES("L����8���\\�ݼ+","wp-admin/images/imgedit-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",��\'��6U�������t");
INSERT INTO `arc1542_wfFileMods` VALUES("p۞�2N<:Z�7�r�","wp-includes/js/tw-sack.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���������9>���");
INSERT INTO `arc1542_wfFileMods` VALUES("u�)8FG9�C�(���","wp-includes/js/wp-ajax-response.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bC;�s�{�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Clo�������","wp-admin/nav-menus.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x������͉���");
INSERT INTO `arc1542_wfFileMods` VALUES("��-��i>bs��1�","wp-includes/js/jquery/ui/resizable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�*��W�i�X㝶տ");
INSERT INTO `arc1542_wfFileMods` VALUES("��4r�%����j���","wp-includes/SimplePie/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���kU�6�
�+�)%�");
INSERT INTO `arc1542_wfFileMods` VALUES("��KS+�e׎A�@��","wp-admin/css/colors/light/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �V{��)\\_~��q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0��5��mk��","wp-includes/js/wp-a11y.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����z�L�u�Jg��k");
INSERT INTO `arc1542_wfFileMods` VALUES("΢�S˪�
��B�V\"","wp-includes/fonts/dashicons.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�)x䌉��[�w�");
INSERT INTO `arc1542_wfFileMods` VALUES("��ܡ9�u_\\
�9�\'","wp-admin/css/color-picker.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����}��U��F��\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("�KU�g0MU�/��ʇ","wp-admin/admin-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ga���c�3�aq�");
INSERT INTO `arc1542_wfFileMods` VALUES("4;V��\'�/����f�","wp-includes/js/jquery/ui/effect-scale.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}0e,)����+m�T");
INSERT INTO `arc1542_wfFileMods` VALUES("���C
���U���","wp-admin/js/custom-header.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2�\0X���`o���uf�");
INSERT INTO `arc1542_wfFileMods` VALUES("��0l��j�0+%�","wp-includes/SimplePie/Source.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������S{�*���");
INSERT INTO `arc1542_wfFileMods` VALUES("�)����t�,�Jڼ","wp-admin/options-permalink.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Kj�rU�54�Z�R�$");
INSERT INTO `arc1542_wfFileMods` VALUES("Ր(������@��","wp-admin/js/press-this.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h.[t�y�	��1��J");
INSERT INTO `arc1542_wfFileMods` VALUES("Wl��y:�\0Vn`�d\0�","wp-includes/js/tinymce/plugins/wpview/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�������� -�X��g");
INSERT INTO `arc1542_wfFileMods` VALUES("�,�4#��(�#","wp-signup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���*�I
�gF�t");
INSERT INTO `arc1542_wfFileMods` VALUES("�:8�Ia��øl�m","wp-admin/includes/class-ftp-pure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�\\.B���������");
INSERT INTO `arc1542_wfFileMods` VALUES("����KqM���{���","wp-admin/css/dashboard.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����p�0��ۃ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�TB��O>�v2��}Ea","wp-includes/SimplePie/Locator.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s����;�uvf^��");
INSERT INTO `arc1542_wfFileMods` VALUES("F��e���}�(��","wp-includes/js/jquery/ui/dialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$aV�{Ԅ��,�0");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�/ᡇ_�����","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4 �\\B�i�M銋");
INSERT INTO `arc1542_wfFileMods` VALUES("�&UX�L4{����","wp-includes/js/utils.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�9����!�;�	��x�");
INSERT INTO `arc1542_wfFileMods` VALUES("�e���j!^��	��","wp-includes/js/mediaelement/bigplay.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","qd6�=�Ҟk7�b�Rgj");
INSERT INTO `arc1542_wfFileMods` VALUES("������)qtsCI9","wp-includes/functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�Q��oNw�}��$7");
INSERT INTO `arc1542_wfFileMods` VALUES("�y��8R#O�y��","wp-admin/css/nav-menus-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��@�2��Ҏb4�V_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�UE�s(���#E�p","wp-includes/images/smilies/icon_mrgreen.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J����Rw��w��");
INSERT INTO `arc1542_wfFileMods` VALUES("A�Z�哖̅L��(","wp-includes/js/mediaelement/skipback.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�m�0�E���k��o�HF");
INSERT INTO `arc1542_wfFileMods` VALUES("�y���!�\0pZ�[A","wp-includes/js/mediaelement/mediaelement-and-player.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5:���\0 vu�k�");
INSERT INTO `arc1542_wfFileMods` VALUES("ֻE
�<�B�[�,","wp-includes/class-wp-ajax-response.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r6`0}�dmĂQ���\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�m��n9�F�6�","wp-admin/css/admin-menu-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�0Wi�Qκ~�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�M��^�ûoz�","wp-admin/images/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-[��t�P���d�");
INSERT INTO `arc1542_wfFileMods` VALUES("4%�IH�O��ʰ�L","wp-includes/css/media-views.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w�0**�b6��Џ�");
INSERT INTO `arc1542_wfFileMods` VALUES("C�/�;)��ّ�o","wp-admin/js/comment.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���I���4�D�O#]");
INSERT INTO `arc1542_wfFileMods` VALUES("T�gslF���ʞ��Ly","wp-admin/js/set-post-thumbnail.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����8�կ!�1z[");
INSERT INTO `arc1542_wfFileMods` VALUES("vs�%�z�����F�","wp-admin/css/ie-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Fܣ��sȶ��?��\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
$z�X�`�1Bw","wp-includes/js/tinymce/plugins/charmap/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a���w��g��\\c�H�");
INSERT INTO `arc1542_wfFileMods` VALUES("��=b�6��hs���t","wp-admin/ms-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�K��$�IZ1�i%�");
INSERT INTO `arc1542_wfFileMods` VALUES("
��O�_��;]/^��","wp-includes/images/down_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��]:u�Wv���\"��");
INSERT INTO `arc1542_wfFileMods` VALUES("G_bc�.,]&���","wp-admin/js/image-edit.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�1���l2���z�^");
INSERT INTO `arc1542_wfFileMods` VALUES("fMx�����	�+9�U�","wp-admin/js/customize-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B\0��$�A쟠");
INSERT INTO `arc1542_wfFileMods` VALUES("�%��\\��MA�����","wp-admin/images/wordpress-logo-white.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c=Yܵ����s����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"j�ǧ`�����1�","wp-admin/css/press-this-editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�?�V���\"��\'ŝ");
INSERT INTO `arc1542_wfFileMods` VALUES("�=�}C���i��HT","wp-admin/network/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i&�Q\\Ӣ�綨");
INSERT INTO `arc1542_wfFileMods` VALUES("�g��I�!٭���_�","wp-includes/ms-blogs.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",	�-�U{�%��	 �");
INSERT INTO `arc1542_wfFileMods` VALUES("��]/~���q��XŎE","wp-includes/js/jquery/ui/button.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~���B��h�F��Vml");
INSERT INTO `arc1542_wfFileMods` VALUES("|�&;�r�Ls5��","wp-admin/includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\\�����\'3�)ާQ");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ye�.�0s��","wp-admin/includes/class-wp-comments-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�NGA��R��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'-�p�-���f�","wp-admin/css/l10n-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:8σH57cM��G");
INSERT INTO `arc1542_wfFileMods` VALUES("L��bP�-I׭1f�","wp-includes/theme-compat/header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x������vY����");
INSERT INTO `arc1542_wfFileMods` VALUES("�{��Y�\\�z錿�}c","wp-includes/images/smilies/rolleyes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ���O�2�Ofݣi�");
INSERT INTO `arc1542_wfFileMods` VALUES(" *@ADғ�=pu���E","wp-admin/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":��P�>.����M^�");
INSERT INTO `arc1542_wfFileMods` VALUES(" ��c̫)I�
p,͑��","wp-includes/css/jquery-ui-dialog-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����7���ִ�F3");
INSERT INTO `arc1542_wfFileMods` VALUES(" �p(?Qn����a��Z","wp-includes/js/plupload/plupload.silverlight.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<RGPTmᳪ�o���");
INSERT INTO `arc1542_wfFileMods` VALUES("!o���A��v7��e","wp-admin/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�$B3FOl`�8");
INSERT INTO `arc1542_wfFileMods` VALUES("!1b݅9��*���\\��","wp-admin/admin-footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bKtvoC��Nwjv�A�");
INSERT INTO `arc1542_wfFileMods` VALUES("!_��輵p3p�n��L","wp-includes/images/smilies/icon_eek.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��s���jN��_z�");
INSERT INTO `arc1542_wfFileMods` VALUES("!�R���p�nL�w�m7","wp-includes/js/tinymce/plugins/lists/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4,~I�i%E���[");
INSERT INTO `arc1542_wfFileMods` VALUES("!����Y0-z1�dm>�","wp-admin/js/plugin-install.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zb�
�d�&�o�f�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"(}G��r�	0��V(","wp-admin/ms-options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'�\0�}��:��ㆯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"IFn����@�a�}�9","wp-admin/includes/class-wp-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@̔m��`b���TyTH5");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����b9��e�|�_�","wp-includes/feed-atom-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�D1;�)��-�B?6s");
INSERT INTO `arc1542_wfFileMods` VALUES("\"�����u>1�7���","wp-includes/class-pop3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���S��|����/}");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����c���9�&","wp-includes/js/plupload/plupload.full.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�6�G��
�!:D");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��6+K{�!a","wp-admin/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�҅yE�F@$�D9�");
INSERT INTO `arc1542_wfFileMods` VALUES("$����0S�r���","wp-includes/images/smilies/icon_redface.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m��A��R!4a");
INSERT INTO `arc1542_wfFileMods` VALUES("$���C����/�9��","wp-includes/class-wp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�iG!��Q�l�3nI%�");
INSERT INTO `arc1542_wfFileMods` VALUES("%����8^�V<�t�","wp-admin/edit-tag-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F?��E���/)w%�");
INSERT INTO `arc1542_wfFileMods` VALUES("&�Sǲby\0E���5�","arc-website.zip","0","(0��	��u�k.��1","(0��	��u�k.��1");
INSERT INTO `arc1542_wfFileMods` VALUES("&*���dĆָ�	�H5","wp-admin/images/align-center.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�ݶ�4y�dY1�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("&=�+t�\"�/k\'
","wp-includes/js/jquery/jquery.form.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�À�s���E�VM�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("&ee�
3K���vZ��","wp-admin/ms-delete-site.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A��;t�?OaQvQ�");
INSERT INTO `arc1542_wfFileMods` VALUES("&t!0^g��bJ�c,>3","wp-admin/upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2\'�w�%�M�Ǽ��");
INSERT INTO `arc1542_wfFileMods` VALUES("&���Rw?~�j�hJ�D","wp-includes/Text/Diff/Renderer/inline.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�n5�P�����B\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("&��]0W��
)�=��","wp-includes/js/tinymce/plugins/directionality/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�W%<�:oJ��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("&�`�O�Q5�Q�43�","wp-admin/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NGQn�]/�A�E_��");
INSERT INTO `arc1542_wfFileMods` VALUES("(��g%\0��4��l>��","wp-includes/js/jquery/jquery.schedule.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��T�k�f؞���");
INSERT INTO `arc1542_wfFileMods` VALUES("(?���>��S�N揚�&","wp-includes/images/media/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-����I�B�h�@���b");
INSERT INTO `arc1542_wfFileMods` VALUES("([d��������BQ��","wp-admin/js/updates.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","鎖b�����AYM�Tw");
INSERT INTO `arc1542_wfFileMods` VALUES("(~6vqV�0�{�\"","wp-includes/ID3/readme.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����Ɯ���VLN[�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���v|T�— ¥�","wp-admin/includes/screen.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B<Y����N��&ȼ�>");
INSERT INTO `arc1542_wfFileMods` VALUES("(�^�3N������3","wp-includes/wp-diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z{�&���Q����\"");
INSERT INTO `arc1542_wfFileMods` VALUES("){�jW-_�Q=?�GlҢ","wp-includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k&` ��C8�]:�t�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�Oz=�u����˷","wp-includes/rewrite.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j˨�D��~^��T�");
INSERT INTO `arc1542_wfFileMods` VALUES("* a�F���4��u�vU","wp-admin/images/menu-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J�ZY<�i�Y��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("*t$�ߋv��n��s�","wp-includes/js/swfupload/swfupload.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z%�5�e,�r��HO");
INSERT INTO `arc1542_wfFileMods` VALUES("*��-3�u��E�[�O#","wp-includes/images/down_arrow-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s���$�6(�@�a");
INSERT INTO `arc1542_wfFileMods` VALUES("*���L�m&&2��
b","wp-includes/js/tinymce/utils/form_utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�D{}��wk��k|");
INSERT INTO `arc1542_wfFileMods` VALUES("*�07ѥ1O���َ8","wp-includes/js/json2.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t������uD�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("+9���[BU�E�e","wp-admin/js/updates.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%q�I���^M?ڲJ=,");
INSERT INTO `arc1542_wfFileMods` VALUES("+��G*#�������f�","wp-admin/network/site-info.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|�P�|�N�F
Ύm6");
INSERT INTO `arc1542_wfFileMods` VALUES("+���t�%R?������","wp-admin/network/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8,�4,���X���u�");
INSERT INTO `arc1542_wfFileMods` VALUES(",<�� �?C]�0A�","wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��(oT���R��a�");
INSERT INTO `arc1542_wfFileMods` VALUES(",B�c���ԛZ�4Y","wp-includes/js/swfupload/plugins/swfupload.speed.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AZ7��k���E`,*�s�");
INSERT INTO `arc1542_wfFileMods` VALUES(",���@��hj�qrޒ�","wp-includes/ID3/module.tag.id3v2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U[��,j�}jAؚ��c");
INSERT INTO `arc1542_wfFileMods` VALUES(",�hɃs?4B[�^՝","wp-includes/SimplePie/Cache/DB.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y�OU���.�b���");
INSERT INTO `arc1542_wfFileMods` VALUES("-kdϯ���X�w\\7���","wp-includes/admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.A�~E��L+,H[d�");
INSERT INTO `arc1542_wfFileMods` VALUES("-����Ǹ�%w=��","wp-admin/css/colors/ocean/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|[���l�|ٱf%h");
INSERT INTO `arc1542_wfFileMods` VALUES("-��)7�5y�8c��Wv�","wp-admin/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�.9<�e�@�q��");
INSERT INTO `arc1542_wfFileMods` VALUES("-�_��+��Yn��S","wp-includes/js/jquery/ui/tooltip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]G҃������@EQ");
INSERT INTO `arc1542_wfFileMods` VALUES("-�f��4]�#\"u��l","wp-admin/css/colors/light/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R�[Ƴ�O�I\\");
INSERT INTO `arc1542_wfFileMods` VALUES("-��藂��Y{]ns�","wp-includes/css/wp-pointer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȡN�mH˟,3g\"��b");
INSERT INTO `arc1542_wfFileMods` VALUES(". �\0_oE�]A�_�0PJ","wp-includes/js/tinymce/plugins/wpautoresize/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","d�\0Xc�O�@p��%�");
INSERT INTO `arc1542_wfFileMods` VALUES(".IhU���3��+B��","wp-includes/images/admin-bar-sprite-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q����8��o��");
INSERT INTO `arc1542_wfFileMods` VALUES(".Z{=U�uߩAJ��*","wp-admin/css/press-this.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�1GX,ٝQG_k�QB=");
INSERT INTO `arc1542_wfFileMods` VALUES("/<ا^ɼf}�\"���$�","wp-includes/images/media/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�4�8�Αy�6�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("/�s��C4��������","wp-admin/network/setup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Bm>n9z]�њ�");
INSERT INTO `arc1542_wfFileMods` VALUES("/鹠���ΰ1�iw��","wp-includes/images/uploader-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���&-��O��Õ�~");
INSERT INTO `arc1542_wfFileMods` VALUES("0<�����lڿ��J��","wp-includes/js/wp-backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i���H.�^�V!");
INSERT INTO `arc1542_wfFileMods` VALUES("0]�qK\'�f�x����","wp-includes/js/tinymce/plugins/compat3x/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����������r��");
INSERT INTO `arc1542_wfFileMods` VALUES("0���E\00���X�H","wp-includes/js/colorpicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5
���w�-g���:OH�");
INSERT INTO `arc1542_wfFileMods` VALUES("1s�)6�Ӷ���C��Η","wp-admin/user/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\'�$�U�m�x�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("1�EfQ�v#)�
�0EkQ","wp-admin/images/media-button-image.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~���WÎ�@��b�rճ");
INSERT INTO `arc1542_wfFileMods` VALUES("1��X�/�t60^Ҁ!�7","wp-includes/js/comment-reply.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���~��i_");
INSERT INTO `arc1542_wfFileMods` VALUES("2@�j�j\0�kӲ��Ә","wp-admin/includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f���*�4�d��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("2j�L,���W��W$��","wp-admin/css/colors/sunrise/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2�$
�`��5H��");
INSERT INTO `arc1542_wfFileMods` VALUES("2��^(��ʭ�-^x��","wp-includes/SimplePie/Enclosure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�B�n΍K�s]");
INSERT INTO `arc1542_wfFileMods` VALUES("3k��oW�5	k[mq","wp-admin/includes/continents-cities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","KWٛ���3��ǝ");
INSERT INTO `arc1542_wfFileMods` VALUES("3���\'���RK�Bf�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���G���7�(tt�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("3��fQ3�h�5[��W�<","wp-includes/Text/Diff/Renderer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����������菨)");
INSERT INTO `arc1542_wfFileMods` VALUES("48�Vt���+^X�","wp-includes/pomo/mo.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�h�^2�.��t��a");
INSERT INTO `arc1542_wfFileMods` VALUES("4AI�n09��7c`","wp-includes/js/tinymce/utils/validate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hf�
[�ٺ��V�}4");
INSERT INTO `arc1542_wfFileMods` VALUES("4a��[I�}���H�m)","wp-admin/css/deprecated-media.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bR\'�5�Y��t�S6");
INSERT INTO `arc1542_wfFileMods` VALUES("4ڂ��L$�,K[�u��","xmlrpc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���u�w��nƻ1��");
INSERT INTO `arc1542_wfFileMods` VALUES("5�?��y��<�2�","wp-admin/css/dashboard-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a��l�*���li&j");
INSERT INTO `arc1542_wfFileMods` VALUES("58�d�`S61K>ۮ�v","wp-admin/css/colors/blue/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4
��`C��9�Ĉ�");
INSERT INTO `arc1542_wfFileMods` VALUES("5C�)
Wu�꽝/F�cK","wp-includes/js/plupload/wp-plupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��;�2�@_e��R|");
INSERT INTO `arc1542_wfFileMods` VALUES("5Z����Sμ�v�`6�9","wp-includes/version.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��O�_�Y2���T���");
INSERT INTO `arc1542_wfFileMods` VALUES("5\\h>��w	���N�","wp-includes/registration.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q�ύH^�ܲ��I��i�");
INSERT INTO `arc1542_wfFileMods` VALUES("5`�]\\ͭi\0���J�T","wp-includes/class-wp-embed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S�����#�=��&-");
INSERT INTO `arc1542_wfFileMods` VALUES("6����X/��HL","wp-includes/js/mediaelement/wp-playlist.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ɘY8@v��\'ٿ�");
INSERT INTO `arc1542_wfFileMods` VALUES("6;I(�H�m�%��f�","wp-admin/css/farbtastic-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�@!!�Ek�");
INSERT INTO `arc1542_wfFileMods` VALUES("6�]j�v�W�k3-�","wp-admin/load-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">7�q�\0�}�0[��0");
INSERT INTO `arc1542_wfFileMods` VALUES("6̠,��_���q���u�","wp-admin/includes/class-wp-filesystem-ftpext.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4��P�?~$�e4~");
INSERT INTO `arc1542_wfFileMods` VALUES("6٨	��:{�^D�","wp-includes/js/jquery/ui/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","asy��6�=�(�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("7|oOU���z\0Ef���","wp-admin/network/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"?}R2{8\\��?R�");
INSERT INTO `arc1542_wfFileMods` VALUES("7�%Wy~׹P?�x��","wp-includes/js/tinymce/skins/wordpress/images/playlist-video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lzV6`wmZBs���");
INSERT INTO `arc1542_wfFileMods` VALUES("7��O+�����ǋ\'n","wp-includes/js/mediaelement/bigplay.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	qm�^@$��ȍ");
INSERT INTO `arc1542_wfFileMods` VALUES("7�c�¢)��S�eb�","wp-includes/js/jquery/ui/menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�Y����-�9|�l�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("8=�I��a�%��k�~�","wp-admin/js/editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�#�h�3;��q�Fq");
INSERT INTO `arc1542_wfFileMods` VALUES("8�R6�DH��q�-{�:`","wp-admin/includes/translation-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a�
]��r6�o�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("8�@)��6yg[y�sQR","wp-admin/css/deprecated-media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U��R�ڹy��C���");
INSERT INTO `arc1542_wfFileMods` VALUES("9�5\'X���>?�","wp-includes/js/customize-preview-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z{�Y}q�y�ڴ�");
INSERT INTO `arc1542_wfFileMods` VALUES("9ψ[�1d{���@","wp-includes/class.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4� �?�M�nI��t�");
INSERT INTO `arc1542_wfFileMods` VALUES("9:��d�o
��p`Ry��","wp-includes/js/tinymce/langs/wp-langs-en.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f�tS�uc�.k�7a7");
INSERT INTO `arc1542_wfFileMods` VALUES("9�} B^��?	�\"�","wp-includes/script-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<l
ԟW:L#㐢");
INSERT INTO `arc1542_wfFileMods` VALUES("9ՍҢ��9��d�Y","wp-includes/ID3/license.commercial.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�GD �.}�c�H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("9��s�3�SZ,p�8g","wp-includes/images/media/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z��s��0�ȝ�Q�K");
INSERT INTO `arc1542_wfFileMods` VALUES(":{���{7�9����","wp-admin/link.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c���Na�b���d");
INSERT INTO `arc1542_wfFileMods` VALUES(":�|L�H6(��c�g��","wp-includes/ID3/module.audio.ogg.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���v�N�5�O۬��");
INSERT INTO `arc1542_wfFileMods` VALUES(":<�$��0,w\"&e({","wp-includes/class-feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<��Byْ���");
INSERT INTO `arc1542_wfFileMods` VALUES(":���%H`!����Z","wp-admin/js/media-gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2��� Ғ�����n");
INSERT INTO `arc1542_wfFileMods` VALUES(":�Xqݝ�J\\�5P�4","wp-includes/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES(":�n̣RM�ti#��=","wp-includes/images/media/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�taCA����.��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES(";�b�fȖ0����x","wp-admin/css/colors/midnight/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x(���V�?OD�{��`");
INSERT INTO `arc1542_wfFileMods` VALUES(";1ы#�Y_N��t�","wp-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ���r(�l2}+��");
INSERT INTO `arc1542_wfFileMods` VALUES(";R�yh���RxK�","wp-admin/js/farbtastic.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�T�2Aq]����4�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�Wct���*+��Br�","wp-includes/images/smilies/icon_surprised.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")�r�����i�^@8��");
INSERT INTO `arc1542_wfFileMods` VALUES(";����*1n��4�","wp-includes/js/wp-emoji-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�i��׽-}�_��{)l");
INSERT INTO `arc1542_wfFileMods` VALUES("<F���Pz�22��~","wp-includes/js/imgareaselect/imgareaselect.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}(��()��3���󵕯");
INSERT INTO `arc1542_wfFileMods` VALUES("<��9�u�j����!�$","wp-admin/css/install.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B��$\0���D��9j�");
INSERT INTO `arc1542_wfFileMods` VALUES("<�hj�	�4���4a�2�","wp-includes/js/utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����o���o,Ê");
INSERT INTO `arc1542_wfFileMods` VALUES("<��u꿖ܜ��Y�^","wp-includes/js/tinymce/plugins/wpeditimage/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c<�{��!���o");
INSERT INTO `arc1542_wfFileMods` VALUES("=f�u�A><Th���@","wp-includes/js/jquery/ui/progressbar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�{��˚q��t	�");
INSERT INTO `arc1542_wfFileMods` VALUES("=��k�[4��� ��=�","wp-includes/comment-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	p��������3@֝:");
INSERT INTO `arc1542_wfFileMods` VALUES(">hЩ�XX*�v1���","wp-includes/theme-compat/comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�Q�K?G��}�1");
INSERT INTO `arc1542_wfFileMods` VALUES(">ql�+�m�\05Ħ\"�^","wp-includes/js/customize-preview.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��%Hh�������T�");
INSERT INTO `arc1542_wfFileMods` VALUES(">��X��b��ڟ�$W","wp-includes/class-wp-image-editor-gd.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��3��\0P\0C6�o");
INSERT INTO `arc1542_wfFileMods` VALUES("?]�P�.��1����2b","wp-includes/js/tinymce/plugins/textcolor/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ޔ��]|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("@V�$�K���<�1*��","wp-includes/css/jquery-ui-dialog.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�(}��eB{xS	");
INSERT INTO `arc1542_wfFileMods` VALUES("@b�Hf�Q�\"$��S","wp-admin/js/press-this.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:�q��⭊%�sR~");
INSERT INTO `arc1542_wfFileMods` VALUES("@k/�����I�?T,","wp-includes/js/jquery/ui/datepicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I�N�u��QA�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("@��̘9�#�L�y(��","wp-includes/images/arrow-pointer-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w��b�·*L���[��");
INSERT INTO `arc1542_wfFileMods` VALUES("@�XD
�
RN��t���","wp-admin/images/menu.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��9#�d�Y`	���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�;5�X��V��O�Z","wp-admin/images/mask.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���g~�\"��J��䩎�");
INSERT INTO `arc1542_wfFileMods` VALUES("@�m����O��W","wp-admin/admin-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��I�:s,Ί���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�s�Z��^����q�v","wp-admin/images/media-button-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�WI��\\��?��");
INSERT INTO `arc1542_wfFileMods` VALUES("@��+�T΄\'����٤","wp-includes/ID3/module.audio.flac.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,�g�\0.���i�");
INSERT INTO `arc1542_wfFileMods` VALUES("AE���[�`����","wp-includes/js/thickbox/thickbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���C�eR���wS�%");
INSERT INTO `arc1542_wfFileMods` VALUES("Aa�@J������Ł�","wp-includes/js/tinymce/plugins/colorpicker/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�{�\'sVnш�ӹ|�");
INSERT INTO `arc1542_wfFileMods` VALUES("A{&� ��V>��Νs","wp-admin/css/login-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�?�(6�zү��sz");
INSERT INTO `arc1542_wfFileMods` VALUES("B��j�)��q�D�S","wp-admin/install-helper.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T����R�~����R3Z");
INSERT INTO `arc1542_wfFileMods` VALUES("Dm�
��z�H��S���","wp-includes/images/crystal/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'^c�s���D��3T\\");
INSERT INTO `arc1542_wfFileMods` VALUES("D.���:�\0��S�R8","wp-includes/ID3/module.audio-video.asf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��H�!�0�� �s�W");
INSERT INTO `arc1542_wfFileMods` VALUES("D6m�e�r{pK�O�","wp-includes/locale.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��~h]:�T�1��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("D����)ba�k��{��","wp-admin/includes/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T\"AR��hy�ۺCQ)");
INSERT INTO `arc1542_wfFileMods` VALUES("Dչ������$Oa����","wp-admin/css/colors/ectoplasm/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o�qjGY|UI���\'");
INSERT INTO `arc1542_wfFileMods` VALUES("D��5
\'�\\��~W��","wp-includes/category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�*ˀ�j��5 e�");
INSERT INTO `arc1542_wfFileMods` VALUES("E4��fu#R:k!jgh","wp-includes/js/wp-list-revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��OBy��MK�/�l");
INSERT INTO `arc1542_wfFileMods` VALUES("Eh���������@aq��","wp-includes/session.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")|o�.;eX�+}N�");
INSERT INTO `arc1542_wfFileMods` VALUES("E�V���,�%��,SM=","wp-admin/ms-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/�Ħý��:E�");
INSERT INTO `arc1542_wfFileMods` VALUES("F�Hȝl�e��#�","wp-includes/js/tinymce/skins/wordpress/images/more-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l,��r�%�^x�%");
INSERT INTO `arc1542_wfFileMods` VALUES("FF�v��V;v�8/���","wp-includes/SimplePie/Misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���y�-���^�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("FH���30m�:��s��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-edit.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","xR�	�Y�X���ݤ���");
INSERT INTO `arc1542_wfFileMods` VALUES("F���Ã\\�O�fg�","wp-includes/js/tinymce/skins/wordpress/images/gallery-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1����v��R");
INSERT INTO `arc1542_wfFileMods` VALUES("F�\'�B�/�4{J�{w","wp-admin/js/edit-comments.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�������u��");
INSERT INTO `arc1542_wfFileMods` VALUES("F���?�C;$��H","wp-admin/css/color-picker.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-M�_�h���lf/");
INSERT INTO `arc1542_wfFileMods` VALUES("G6U�2\01R������J","wp-admin/js/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";���q���S���$�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gm��:�MľV��LЉ","wp-includes/js/tinymce/utils/editable_selects.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��\0!�e�f��");
INSERT INTO `arc1542_wfFileMods` VALUES("Gq�@����gm屪","wp-includes/js/mediaelement/controls.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@�oZsm������ۊR�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gu�^�/1��ՁS�7","wp-includes/atomlib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�e�.���[�\0
f�A");
INSERT INTO `arc1542_wfFileMods` VALUES("G�9q���=ʥ[3?a�","wp-admin/images/bubble_bg-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R=[����;��c��");
INSERT INTO `arc1542_wfFileMods` VALUES("G�7��I&:�x","wp-admin/edit-form-comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%��8H�p�?H2�x�");
INSERT INTO `arc1542_wfFileMods` VALUES("H+�E~�}�1Q���","wp-includes/js/wp-util.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9�f1��bQ
�ʭ&2");
INSERT INTO `arc1542_wfFileMods` VALUES("Hý��i�Z�U,H�L","wp-admin/includes/meta-boxes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w>��+%+�%��_ڟ");
INSERT INTO `arc1542_wfFileMods` VALUES("If@n����;c>�8","wp-includes/js/tinymce/wp-mce-help.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�G;e�������Eq�\'");
INSERT INTO `arc1542_wfFileMods` VALUES("I��:Bs�#����@�","wp-blog-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��n:�����5�S�5�");
INSERT INTO `arc1542_wfFileMods` VALUES("I�V/��6�s���","wp-admin/js/editor-expand.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x��]p1(� bΎP");
INSERT INTO `arc1542_wfFileMods` VALUES("Jf�3?���_r�C�","wp-admin/images/w-logo-white.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*�,K��i�l��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("J��E[�7U���~","wp-includes/js/plupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��WPIʿ���F�Ug)");
INSERT INTO `arc1542_wfFileMods` VALUES("J{�ֹZi^ùx�I","wp-admin/media-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���x�\"������[��");
INSERT INTO `arc1542_wfFileMods` VALUES("J򾁬��Oh���sDؾ","wp-includes/js/zxcvbn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�;��uc���<��");
INSERT INTO `arc1542_wfFileMods` VALUES("K��W�&\0\0K�\06�G�","wp-admin/js/set-post-thumbnail.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","+QSWm�@�~��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("L<#�������}","wp-includes/js/tinymce/skins/lightgray/img/loader.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9K���M�:�Tf�9");
INSERT INTO `arc1542_wfFileMods` VALUES("L#��/۰*��3���","wp-admin/includes/class-wp-terms-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�<&y�!�A���\\");
INSERT INTO `arc1542_wfFileMods` VALUES("L(���n�9[2�C6�","wp-includes/js/zxcvbn-async.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��p9	�9�~��");
INSERT INTO `arc1542_wfFileMods` VALUES("LsЇś
�c}>�K��","wp-includes/css/editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","JE�0I	,l�95�y");
INSERT INTO `arc1542_wfFileMods` VALUES("L��e�t\"pc(	�e�","wp-includes/wp-db.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\\Úo��=a��8");
INSERT INTO `arc1542_wfFileMods` VALUES("L�>t���N�����","wp-admin/css/colors/blue/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5Iה�g,)Z�YM�");
INSERT INTO `arc1542_wfFileMods` VALUES("L��)��a$�D-�Ӯ�J","wp-includes/js/tinymce/plugins/wplink/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.\"C��b>��K�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("M?,5�*�����K*�f","wp-admin/js/post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}���N�CR���Yp�");
INSERT INTO `arc1542_wfFileMods` VALUES("MW�	���:��ي","wp-admin/images/align-none.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�eqd2���u����");
INSERT INTO `arc1542_wfFileMods` VALUES("MР\0�A���9Q�+��","wp-includes/js/admin-bar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�Oas�{�-v\'�&#");
INSERT INTO `arc1542_wfFileMods` VALUES("M�;C�����8Yyﲏ","wp-includes/js/twemoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|A\0^ֆl�,·MF");
INSERT INTO `arc1542_wfFileMods` VALUES("M���I�M����rD��-","wp-includes/post-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b��
�U\'���(�{�m�");
INSERT INTO `arc1542_wfFileMods` VALUES("N|�Jв�zn��sw","wp-includes/pluggable-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۠���v�!l\"Ȥ�-");
INSERT INTO `arc1542_wfFileMods` VALUES("N�3�j@pu5����^��","wp-includes/js/tinymce/skins/wordpress/images/more.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
�
m\0;�˫�z");
INSERT INTO `arc1542_wfFileMods` VALUES("N���HV����}�4G","wp-admin/css/customize-widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�Aʹ]����j9�");
INSERT INTO `arc1542_wfFileMods` VALUES("O	��S����#��Yi�v","wp-admin/includes/class-wp-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������>�[L�shB");
INSERT INTO `arc1542_wfFileMods` VALUES("OlqCcێ���������","wp-admin/css/forms-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bޡ��I�Z�j�ey��");
INSERT INTO `arc1542_wfFileMods` VALUES("O��\\���P5���{�R�","wp-admin/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j������");
INSERT INTO `arc1542_wfFileMods` VALUES("O����&�r�蓏�� ","wp-admin/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e������SvLXy¸");
INSERT INTO `arc1542_wfFileMods` VALUES("O����R�r����D�?�","wp-admin/js/postbox.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#��$�-�!i>");
INSERT INTO `arc1542_wfFileMods` VALUES("O�hu�G���&\0�L�","wp-includes/Text/Diff/Engine/native.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'*�����*�x");
INSERT INTO `arc1542_wfFileMods` VALUES("PE۫�7r|oI�6��>","wp-includes/js/backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���z�����)�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("P\'�(���?+�z��$�","wp-admin/js/postbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����o%�zb|䨎�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("P73o�	��\0�=��","wp-admin/js/word-count.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f%i�@Q��1��N");
INSERT INTO `arc1542_wfFileMods` VALUES("P��iz�t�a�}�a","wp-admin/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�ep<\'��ݖ�?5��");
INSERT INTO `arc1542_wfFileMods` VALUES("P�1$���\\*�C","wp-admin/images/stars-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A���#�S�Me.^");
INSERT INTO `arc1542_wfFileMods` VALUES("P��0��a��R�z= ","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�|hּk8ʙ");
INSERT INTO `arc1542_wfFileMods` VALUES("QT���*�f�P��.�","wp-admin/includes/file.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��D�|#_x5�Y�Wh�");
INSERT INTO `arc1542_wfFileMods` VALUES("QY��1�Tl��Vr<","wp-includes/js/customize-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��;�z��	�YM�#y�");
INSERT INTO `arc1542_wfFileMods` VALUES("QuoPX��\0��Sڞ","wp-admin/images/bubble_bg.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=,����(��2cV� 8");
INSERT INTO `arc1542_wfFileMods` VALUES("Q�`���8�M�8","wp-admin/press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:U�/��vřc�K�J");
INSERT INTO `arc1542_wfFileMods` VALUES("Q������l��g�-��","wp-admin/js/comment.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8�i/y��}��*�C��");
INSERT INTO `arc1542_wfFileMods` VALUES("R3�Us�3��}T���","wp-includes/js/autosave.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�i|}f���C�S�/");
INSERT INTO `arc1542_wfFileMods` VALUES("RQ�b7f�� |~ۓ�(","wp-admin/js/widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%\0x$i%�O��f$��");
INSERT INTO `arc1542_wfFileMods` VALUES("R�x�4Mp@�9u
֊ p","wp-includes/images/wpspin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("R��|Rx/�bzn9\0*�J","wp-admin/includes/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">�8��aK�M�P�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("R�\\SC�|ju�9��A","wp-includes/js/media-grid.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<fl� � �~\\����");
INSERT INTO `arc1542_wfFileMods` VALUES("R¥�����Le�q	�&�","wp-admin/js/user-suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3)��()ݰ4}
�");
INSERT INTO `arc1542_wfFileMods` VALUES("S.FȫA�j���(�:","wp-includes/js/hoverIntent.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�P
ޅL1A�Wb��\0");
INSERT INTO `arc1542_wfFileMods` VALUES("S0�־��K/17u���","wp-includes/js/jquery/ui/selectmenu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}�˪2�9Zhxi\"6�");
INSERT INTO `arc1542_wfFileMods` VALUES("SX+7��1?����-","wp-includes/js/jcrop/Jcrop.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��7e�����Q�%K");
INSERT INTO `arc1542_wfFileMods` VALUES("S����p�>��Wr�YE","wp-comments-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����Х�l��%�f�");
INSERT INTO `arc1542_wfFileMods` VALUES("S��&�az8�Jض9�","wp-includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z6����̒��$2�p");
INSERT INTO `arc1542_wfFileMods` VALUES("T^Ih�����Ύ���(","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v����W`?�I_����=");
INSERT INTO `arc1542_wfFileMods` VALUES("T�.o@Ψ2�w�v��X�","wp-includes/js/jcrop/jquery.Jcrop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/a��Lru�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("T���vm?,�a���T4�","wp-includes/ID3/module.audio-video.quicktime.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�`��f�.�0�F˼");
INSERT INTO `arc1542_wfFileMods` VALUES("U�\\p{J��O�Q�&","wp-includes/SimplePie/Cache/Base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�C�����2]�]#|j");
INSERT INTO `arc1542_wfFileMods` VALUES("U���$i\"u��&���9","wp-includes/images/crystal/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����l��ڤ�;�=");
INSERT INTO `arc1542_wfFileMods` VALUES("V
��U`�_�5���8","wp-includes/js/customize-base.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".��ҖX�`�5A");
INSERT INTO `arc1542_wfFileMods` VALUES("VL6�7G^l%D5z3��","wp-includes/default-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X����Q��eT����\0");
INSERT INTO `arc1542_wfFileMods` VALUES("Vne!�z0u1?��","wp-includes/shortcodes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���ƍ/K����%");
INSERT INTO `arc1542_wfFileMods` VALUES("Vrm�KE�p�j��6�","wp-admin/images/w-logo-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�[N�W��_p�w�0");
INSERT INTO `arc1542_wfFileMods` VALUES("V�����댏$�x","wp-admin/js/post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_��K�g�{=q�rbI�");
INSERT INTO `arc1542_wfFileMods` VALUES("W{�g- X���\'=n8","wp-admin/moderation.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","TB���YR��\"4�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("W})Ӗ7���e�}5�9,","wp-admin/load-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��E��0VO��r����");
INSERT INTO `arc1542_wfFileMods` VALUES("X,�E�Cj$_��8I��0","wp-includes/images/smilies/icon_cool.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F~��ߢ.���>t8");
INSERT INTO `arc1542_wfFileMods` VALUES("X�:8+˓2>V]��8�","wp-admin/images/sort-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","nQ&�] �0�-����");
INSERT INTO `arc1542_wfFileMods` VALUES("X���G������z�X","wp-admin/includes/class-wp-upgrader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M(qmu��]��w���");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�La���h�(","wp-admin/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ၢ�8�q�}u���");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�,�e�A��w�`���","wp-includes/images/media/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9����h�\0��ì�u");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�68�H;%,�_c
�","wp-includes/css/wp-auth-check.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�`�4j@9��Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("Y����]���ŞI���","wp-includes/js/jquery/ui/effect-slide.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#G_��MVژ�y�");
INSERT INTO `arc1542_wfFileMods` VALUES("Y֝��U����}�r/","wp-includes/SimplePie/Cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y���:�oMh�vL�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ZҌ�[��
v���	F","wp-includes/SimplePie/gzdecode.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8��a��al�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("Z����� %/�Z�z9��","wp-admin/includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E���6��|J��Ჵ");
INSERT INTO `arc1542_wfFileMods` VALUES("Z�\0��Y���� æfg","wp-includes/js/crop/marqueeVert.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\0���9��R���");
INSERT INTO `arc1542_wfFileMods` VALUES("[��#ܧ>]��<�","wp-admin/css/colors/ectoplasm/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ӓ�J�׺��S�b�H");
INSERT INTO `arc1542_wfFileMods` VALUES("[�>�x�;�wn/t�H","wp-includes/js/wp-emoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Jǿd����$��Kg");
INSERT INTO `arc1542_wfFileMods` VALUES("[���1�YAdk�,","wp-includes/SimplePie/Sanitize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Bظ��F�إ�H��u");
INSERT INTO `arc1542_wfFileMods` VALUES("[ꠏ�|K�o�یb7�","wp-admin/user/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������-x���Nb��");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����9������","wp-admin/ms-upgrade-network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��&\"�S�m��8h�m");
INSERT INTO `arc1542_wfFileMods` VALUES("\\[��i%Ͱ<��e�>�","wp-includes/css/wp-pointer-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͆���j_�L�J");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�т�?$�̈́8����","wp-admin/includes/dashboard.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z[�P��FX���-R�");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�\0��>�+���Fb��","wp-admin/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����f��#�=�|�B�");
INSERT INTO `arc1542_wfFileMods` VALUES("](R�&!��1;�3��","wp-includes/js/wp-ajax-response.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��#Pv�\\��p��");
INSERT INTO `arc1542_wfFileMods` VALUES("]B#�2�z���bU��/","wp-includes/Text/Diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��gkj@b�%���\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("]��P���Tkvt��8A","wp-admin/network/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=S[�fx�������");
INSERT INTO `arc1542_wfFileMods` VALUES("]�����\"}[�Y�R�","wp-admin/css/edit-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q&d�@�$�=�WČ�");
INSERT INTO `arc1542_wfFileMods` VALUES("^9(-(Ų�y ���0q*","wp-admin/user/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\0ڍ�KN� ���N�-");
INSERT INTO `arc1542_wfFileMods` VALUES("^@ղ{\'��_���92","wp-admin/upgrade-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^����uP�qX\\e��");
INSERT INTO `arc1542_wfFileMods` VALUES("^�Ð����+�y|�","wp-includes/images/crystal/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�9�Т1�T��n��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�\0��d �MP~��D","wp-includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{)8\'\'���8���u");
INSERT INTO `arc1542_wfFileMods` VALUES("_*�⽞L�0�>","wp-includes/feed-rss2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��`\'r}��b� QG");
INSERT INTO `arc1542_wfFileMods` VALUES("_j���_��/���yӱ","wp-includes/load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T�fuJ�\0�G�G0");
INSERT INTO `arc1542_wfFileMods` VALUES("_�|��T�M^���J","wp-includes/css/editor.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����m-o>�q��");
INSERT INTO `arc1542_wfFileMods` VALUES("_���4�3���=��","wp-includes/images/uploader-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\\M�����m��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�(�C���M6�9�","wp-admin/includes/class-wp-links-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pP�����{4W�EW");
INSERT INTO `arc1542_wfFileMods` VALUES("_�����8}���?�","wp-includes/css/media-views-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t[kn�i�+�/���j�I");
INSERT INTO `arc1542_wfFileMods` VALUES("`���S�`NI�^G�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a5Dn��r-m�@5P");
INSERT INTO `arc1542_wfFileMods` VALUES("`%�ֽ�j��\'��P��","wp-admin/js/edit-comments.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{(Æ�c|�љģ*3");
INSERT INTO `arc1542_wfFileMods` VALUES("`���;�\"�-���+~;","wp-includes/js/tinymce/plugins/media/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�\"��ʧ�Z�¥v
");
INSERT INTO `arc1542_wfFileMods` VALUES("a)�TMW�Oo��Q�|�","wp-admin/images/media-button.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6@p�z^ye��");
INSERT INTO `arc1542_wfFileMods` VALUES("a\\c,I\"5T��#̋�","wp-admin/images/media-button-music.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��]�2\\Z�/��ޕ");
INSERT INTO `arc1542_wfFileMods` VALUES("a�?��_�ˢ��6j��X","readme.html","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1<�y��;�k��/h�u");
INSERT INTO `arc1542_wfFileMods` VALUES("a�����(m�EB�l�","wp-includes/media-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������K��Y�?�");
INSERT INTO `arc1542_wfFileMods` VALUES("a�c�CH��=l@ĸ","wp-admin/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~��`3��}@�[V�P");
INSERT INTO `arc1542_wfFileMods` VALUES("bY�,��ϥY�r۝�;�","wp-includes/js/crop/cropper.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ky5�ni*M(��");
INSERT INTO `arc1542_wfFileMods` VALUES("b�����Ҍ &�?�{","wp-includes/js/customize-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<�ܽL-�Im");
INSERT INTO `arc1542_wfFileMods` VALUES("c,���[xޫ�3�
�@","wp-includes/js/jquery/jquery.masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����R�(��e^");
INSERT INTO `arc1542_wfFileMods` VALUES("d��:w���O�І","wp-includes/ID3/getid3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"�
Q�Q.���b�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("d��1�쵓-�;O��","wp-admin/js/custom-background.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j�)N���ˈ¨iv#");
INSERT INTO `arc1542_wfFileMods` VALUES("d�(��%J���@�G�","wp-admin/options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�o�sn���]�T�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�hħ{q4�2�K\"�","wp-includes/SimplePie/Rating.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=p�m	�K�دat�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�4�j�2U�V��$�P","wp-admin/css/wp-admin.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�RF��)�m");
INSERT INTO `arc1542_wfFileMods` VALUES("e.PȴNB�Sx[�&��","wp-admin/includes/class-wp-plugin-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i1*\\E�`r����C");
INSERT INTO `arc1542_wfFileMods` VALUES("e��__�%��x���","wp-includes/class-snoopy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mMz�Mr�;v��");
INSERT INTO `arc1542_wfFileMods` VALUES("e�^#|ۍ�TЩ��z","wp-includes/Text/Diff/Engine/xdiff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ֹ�b�t�X8�GX");
INSERT INTO `arc1542_wfFileMods` VALUES("f�u3
�M\\�}6*0�","wp-includes/class-wp-customize-setting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=t��$Q����I");
INSERT INTO `arc1542_wfFileMods` VALUES("f�霰f؟|h��U�L","wp-admin/includes/ms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�*H[�s@��");
INSERT INTO `arc1542_wfFileMods` VALUES("f�����e��R�)�","wp-includes/SimplePie/Item.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�!�Cz�\0�c<ܧ");
INSERT INTO `arc1542_wfFileMods` VALUES("g#�,vM������:��","wp-includes/js/jquery/jquery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N*ht��(�#Y�(JC");
INSERT INTO `arc1542_wfFileMods` VALUES("g+yr���q����D��/","wp-includes/vars.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'���8u���Ƶ8;");
INSERT INTO `arc1542_wfFileMods` VALUES("g|y_�o4\"��X�N���","wp-includes/images/smilies/mrgreen.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-5��^����J�j���");
INSERT INTO `arc1542_wfFileMods` VALUES("g�$G\\��;�r���1X","wp-includes/images/wpicons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","dS��uq��V_���a�");
INSERT INTO `arc1542_wfFileMods` VALUES("g��]bR%� Z��E�","wp-includes/js/shortcode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2\0`y��L8�*�");
INSERT INTO `arc1542_wfFileMods` VALUES("g�Ed��1��D}�����","wp-includes/js/jquery/ui/autocomplete.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���PصC��8�zj�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("hOhl��_��Lm/�","wp-includes/class-wp-customize-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G����.��F���ά(");
INSERT INTO `arc1542_wfFileMods` VALUES("h d��껅2��_�r","wp-includes/functions.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|{�D�v��	��:B");
INSERT INTO `arc1542_wfFileMods` VALUES("h0X-�i����^�G`8","wp-includes/pluggable.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�Y�C��eF��H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("h4���#3�`�-݈�\"�","wp-admin/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���?���>z�ͩ��z&");
INSERT INTO `arc1542_wfFileMods` VALUES("h@Z�%�R�F�;ti\\m","wp-admin/css/login-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���e�d}
p���?��");
INSERT INTO `arc1542_wfFileMods` VALUES("h|hE��f:Ʊ2��~","wp-admin/network/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&շ�1Up�%��1=$�");
INSERT INTO `arc1542_wfFileMods` VALUES("iAh{���M(�|J,��","wp-admin/js/wp-fullscreen.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f��A�o��\0)`�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("i�-��X�8V[~E�","wp-admin/css/install-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���5�n���J� ");
INSERT INTO `arc1542_wfFileMods` VALUES("i�\\����=X�h$","wp-admin/js/language-chooser.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�P�V0��tJ�J");
INSERT INTO `arc1542_wfFileMods` VALUES("jQ���e���;�e","wp-includes/css/wp-pointer-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l>SR1�i�Y�7��");
INSERT INTO `arc1542_wfFileMods` VALUES("jmE��AX�uw�>܆","wp-admin/css/colors/ectoplasm/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Ѳ��E��ϡuI�");
INSERT INTO `arc1542_wfFileMods` VALUES("j�䱋����%���]�","wp-includes/class-wp-xmlrpc-server.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WUT��W��r��͜");
INSERT INTO `arc1542_wfFileMods` VALUES("j�����5F+���o","wp-includes/images/crystal/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�R�m`���`�9��");
INSERT INTO `arc1542_wfFileMods` VALUES("k���$6O��-N�x�","wp-includes/js/tinymce/plugins/charmap/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��c������ni�?K%");
INSERT INTO `arc1542_wfFileMods` VALUES("kM�������̙Ysp","wp-admin/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m`$�����Y�J");
INSERT INTO `arc1542_wfFileMods` VALUES("k��B˞�b=y��","wp-includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q��*�;\'�ep");
INSERT INTO `arc1542_wfFileMods` VALUES("mD��T�ms���A�}","wp-includes/certificates/ca-bundle.crt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��vǻ��!�o
�f��o");
INSERT INTO `arc1542_wfFileMods` VALUES("mA��Y�����Rb|�S�","wp-includes/ms-default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NM�������9�b�%");
INSERT INTO `arc1542_wfFileMods` VALUES("mE������\\�)��o�","wp-includes/js/jquery/ui/spinner.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ש�/k&HQ��;j��");
INSERT INTO `arc1542_wfFileMods` VALUES("mY����}ɽ��?","wp-includes/js/jquery/jquery.ui.touch-punch.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�m�Q4փ��]�");
INSERT INTO `arc1542_wfFileMods` VALUES("m��-m1�����w��","wp-includes/js/jquery/ui/sortable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Xw���k^�");
INSERT INTO `arc1542_wfFileMods` VALUES("n]�j7<3ISsQ�","wp-admin/images/post-formats32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t.E���5G�N��v");
INSERT INTO `arc1542_wfFileMods` VALUES("n#�t=�\'�����b]{�","wp-includes/js/tinymce/themes/modern/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL]�����Tg2%�");
INSERT INTO `arc1542_wfFileMods` VALUES("nZ/1T:{&^�/n���","wp-admin/js/media-gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��f����8�}+&");
INSERT INTO `arc1542_wfFileMods` VALUES("nef���A@���R�?��","wp-includes/js/jquery/ui/position.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}��{:�pKv�ht�");
INSERT INTO `arc1542_wfFileMods` VALUES("n����@��A��F�","wp-admin/network/sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��bd�Y.|��K�");
INSERT INTO `arc1542_wfFileMods` VALUES("oP��c����o�.�r","wp-includes/js/tinymce/skins/lightgray/img/object.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�rdP�E}u
/M�A�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("oZ0�������<c�0","wp-includes/SimplePie/IRI.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n� �憒�;a{�_6�");
INSERT INTO `arc1542_wfFileMods` VALUES("o㮚-�;?X:��pҡ","wp-trackback.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��d���#k�l");
INSERT INTO `arc1542_wfFileMods` VALUES("o�[��n3u��ʹ�P5","wp-admin/options-general.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�����7֔�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��7u�L�_{2Û�","wp-includes/js/jquery/ui/draggable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","PV�d��@��Y��");
INSERT INTO `arc1542_wfFileMods` VALUES("pUy�a	�b��va�;�8","wp-includes/js/comment-reply.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�(e=N�(ZMV{�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��.а��[ÍD�","wp-includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v��_�S��^Yv�");
INSERT INTO `arc1542_wfFileMods` VALUES("q\"�co���>�2Rh�]","wp-admin/includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e�\\y����:�8");
INSERT INTO `arc1542_wfFileMods` VALUES("qh�665�y|�=�?S	","wp-includes/js/jquery/jquery.serialize-object.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\)������J�l<�\"");
INSERT INTO `arc1542_wfFileMods` VALUES("r��h��v��Lk/��","wp-admin/network/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#9091N���d�H");
INSERT INTO `arc1542_wfFileMods` VALUES("r+zk;� 4��WI","wp-includes/js/tinymce/themes/modern/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<ڎ\'�,s�bP�;S�");
INSERT INTO `arc1542_wfFileMods` VALUES("r�(n՞���j��b\"","wp-admin/js/media.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","υ�^p0LB�uSŅ");
INSERT INTO `arc1542_wfFileMods` VALUES("r�_�/��HG=�%�<�","wp-includes/images/arrow-pointer-blue-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%m�rތ]4�9c�");
INSERT INTO `arc1542_wfFileMods` VALUES("r��r�(J�g�(�y�t","wp-includes/js/mce-view.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","պ�������w���dj");
INSERT INTO `arc1542_wfFileMods` VALUES("r��
��b��#��","wp-admin/css/media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��?ً�./+#S�G_�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�ŏU\'���e@�d�","wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�y�_1u�݇�bo�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�C4M�*��*B�)�","wp-includes/css/wp-pointer.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=|t��r`�֖}|?�");
INSERT INTO `arc1542_wfFileMods` VALUES("t6��O�a��Ȇ�f","wp-admin/js/plugin-install.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XR7�5�1:]��S�");
INSERT INTO `arc1542_wfFileMods` VALUES("t8����p�̋�z{jDp","wp-includes/css/buttons-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1>�����:�z^��");
INSERT INTO `arc1542_wfFileMods` VALUES("tU�/Ds�Iڤ�st�","wp-includes/js/wp-auth-check.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�	�8��_oDdJy��s");
INSERT INTO `arc1542_wfFileMods` VALUES("tm6ۗ�q���.��=j","wp-admin/css/colors/blue/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��-K�e��:8�");
INSERT INTO `arc1542_wfFileMods` VALUES("ue�,\"
	�h�g.","wp-admin/css/colors/_mixins.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S�_���|�\'4.o\'6�");
INSERT INTO `arc1542_wfFileMods` VALUES("u��3!pA�f�)R�M�","wp-includes/js/tinymce/plugins/wpgallery/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���A�#j�d�&�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("u�qg\0�8�hԭ�\0�","wp-admin/custom-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��.��08�#�z&�");
INSERT INTO `arc1542_wfFileMods` VALUES("vڴ����V���K��P","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��6�_¸�f���");
INSERT INTO `arc1542_wfFileMods` VALUES("vK;@�s�aU1;�	^�","wp-config.php","0","�;����8�f���o","�;����8�f���o");
INSERT INTO `arc1542_wfFileMods` VALUES("vw��@�H��z�F�","wp-admin/ms-admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���@�ͯE�b6�");
INSERT INTO `arc1542_wfFileMods` VALUES("v]�z������3�tB","wp-admin/includes/class-wp-importer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ky�lCK��W.���5");
INSERT INTO `arc1542_wfFileMods` VALUES("v��ޣ��R�","wp-includes/js/jquery/jquery-migrate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7��5�X��QN�z");
INSERT INTO `arc1542_wfFileMods` VALUES("v�G�.�g�A��#�r�","wp-admin/images/align-right-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h�l�>r�]�lW��x");
INSERT INTO `arc1542_wfFileMods` VALUES("v����4�|>�<����","wp-admin/js/xfn.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����t�+��n�(k");
INSERT INTO `arc1542_wfFileMods` VALUES("v�{#��l��b\0}��B","wp-admin/css/colors/light/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��ʒw�����^�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("v�Ҹ);�D��~J\"��q","wp-includes/js/jquery/jquery.form.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.�,�+��
q");
INSERT INTO `arc1542_wfFileMods` VALUES("wu�l|��p��Q","wp-includes/js/autosave.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�,@��g�h/7");
INSERT INTO `arc1542_wfFileMods` VALUES("w���L��0���]r.","wp-includes/images/crystal/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�1������1�9");
INSERT INTO `arc1542_wfFileMods` VALUES("w������:}V��P","wp-admin/js/common.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<���=�rG����");
INSERT INTO `arc1542_wfFileMods` VALUES("x	G!N�$�.�d�Tb�","wp-includes/ID3/module.audio-video.flv.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ֈ?�d�h�@�D��");
INSERT INTO `arc1542_wfFileMods` VALUES("xIH�.�9�Y��BO","wp-admin/css/colors/coffee/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9~8 �z#C0�^%a�");
INSERT INTO `arc1542_wfFileMods` VALUES("x�^m�]̲�/��L4vU","wp-admin/includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ǒU�+zm��\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("x덂��@}Y��i�+","wp-includes/js/tinymce/plugins/tabfocus/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j��dFЂ�\"Ex�");
INSERT INTO `arc1542_wfFileMods` VALUES("y���E�a��:�[\0","wp-includes/class.wp-dependencies.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T_[@j��j�\\?ou");
INSERT INTO `arc1542_wfFileMods` VALUES("y���G�\\`����MR�","wp-admin/network/site-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q��y����(�l�#nK");
INSERT INTO `arc1542_wfFileMods` VALUES("z;j2WD�6��[�V","wp-admin/js/accordion.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^V�
�8.7p�Ct�7:");
INSERT INTO `arc1542_wfFileMods` VALUES("z����JX�w{!F���","wp-admin/includes/class-wp-upgrader-skins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<]��:�PGV5]f�");
INSERT INTO `arc1542_wfFileMods` VALUES("{��a�t�
\">��S","wp-includes/js/mediaelement/flashmediaelement.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{�l9�N���	�");
INSERT INTO `arc1542_wfFileMods` VALUES("{N���2�Q�u��=	�","wp-admin/network/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�F��dm����j");
INSERT INTO `arc1542_wfFileMods` VALUES("{t�E~��P�A�1��","wp-admin/js/tags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�Bf�Z��<���/s");
INSERT INTO `arc1542_wfFileMods` VALUES("{�)�4e4p:�fW�","wp-includes/js/jquery/jquery.query.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�Xz�ǰ����wC");
INSERT INTO `arc1542_wfFileMods` VALUES("{�RC���.*\"�Q","wp-includes/feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\3!/���)Tj");
INSERT INTO `arc1542_wfFileMods` VALUES("{��-��}�^��","wp-includes/images/smilies/frownie.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q���������");
INSERT INTO `arc1542_wfFileMods` VALUES("{��P8���5x��-�","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","݃�r\\�+zJ���");
INSERT INTO `arc1542_wfFileMods` VALUES("{���?������
\'","wp-admin/images/imgedit-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K�\\2���}�G�i;O");
INSERT INTO `arc1542_wfFileMods` VALUES("|j��x7�(Q}�0�\'�","wp-admin/css/list-tables.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D�J�$���e벚�");
INSERT INTO `arc1542_wfFileMods` VALUES("|/ڒ�\0[*4��x��","wp-includes/js/admin-bar.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�o�\0�H�[�H");
INSERT INTO `arc1542_wfFileMods` VALUES("|��Y�>���	�Ɔ�","wp-admin/link-add.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�G�D�/�ϥ�W��");
INSERT INTO `arc1542_wfFileMods` VALUES("}ĉ=�t�����","wp-includes/images/toggle-arrow-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���\\����CDr�");
INSERT INTO `arc1542_wfFileMods` VALUES("}`��g\"P�2��V��","wp-includes/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("}���>/���+i�V","wp-admin/js/wp-fullscreen.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","֨���9�Z%�S=2�");
INSERT INTO `arc1542_wfFileMods` VALUES("}�7 ޘ�DHD�Pl","wp-includes/SimplePie/Registry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ȣ����1v9�d\0�ٸ");
INSERT INTO `arc1542_wfFileMods` VALUES("}�Ȑ�\\L��`���i)","wp-includes/ID3/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�����jQ���#1�");
INSERT INTO `arc1542_wfFileMods` VALUES("}���{RҢ����\"","wp-includes/default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j����vj�$��%��+");
INSERT INTO `arc1542_wfFileMods` VALUES("~79�h�g$+�=���\\0","wp-admin/js/bookmarklet.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`8����#���\03");
INSERT INTO `arc1542_wfFileMods` VALUES("~?�J�I�b*׺�e�C","wp-admin/images/resize.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�D�$��Xv����a");
INSERT INTO `arc1542_wfFileMods` VALUES("~F��㫎>dy��j�","wp-includes/css/jquery-ui-dialog-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2iy6�v���&]�2��");
INSERT INTO `arc1542_wfFileMods` VALUES("~ť�s\0�1y�$�L}h","wp-config-sample.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o\"M�p��q��$vB");
INSERT INTO `arc1542_wfFileMods` VALUES("j&��^����b����","wp-includes/ms-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��sv�ɂhz�*�e��");
INSERT INTO `arc1542_wfFileMods` VALUES("�K�Q�}U&;&���Q","wp-includes/meta.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�؏�oS�Byy}�;�");
INSERT INTO `arc1542_wfFileMods` VALUES("�tr�εF_� ���","wp-includes/js/wp-emoji-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ԩ�?�WJ���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�R�*�����������",".htaccess","0","\'蘖][�!9��=q�","\'蘖][�!9��=q�");
INSERT INTO `arc1542_wfFileMods` VALUES("��ں�u���M���[","wp-admin/images/wpspin_light-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("����e��97�aJS","wp-includes/images/smilies/icon_smile.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��G)ö��u��\\
M");
INSERT INTO `arc1542_wfFileMods` VALUES("�el�5�s��E�úQ�","wp-admin/js/media-upload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a�p�3� 
�^$e&z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��,CUU����9i-","wp-includes/css/wp-auth-check.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�G7���_�h�Q�^");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȉV?	��]�)A","wp-includes/js/media-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�@�<d4�z��1��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\'>�[��·�","wp-admin/js/user-profile.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","(		!�{��*�=�&�\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�3��Ƈe�(ú9�","wp-includes/js/jquery/suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!����^�~k�ۥ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\�(��wB��I�","wp-admin/network/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E�^�!��u��)�u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�(tTlDά7&��MP.�","wp-includes/js/tinymce/tiny_mce_popup.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B3�)7�{U�/�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�B��ه�v<Sv稳","wp-includes/SimplePie/Parse/Date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
2m0�H�����n\'`");
INSERT INTO `arc1542_wfFileMods` VALUES("�F� �GJ��B��s7�","wp-includes/js/media-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u|z���kNئ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0���+OW+�","index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%0;��s��Dm\\�:[");
INSERT INTO `arc1542_wfFileMods` VALUES("�����A���1�;�","wp-includes/rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VYhƤ�3����u	�");
INSERT INTO `arc1542_wfFileMods` VALUES("���ʆ��n�D㮖�(","wp-admin/css/install.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3?�zP��&O�<R�9`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�:+[��g��CZ���","wp-includes/template-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s�~ǹ��Q9�Zl�=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�B%v6�I\"Jb��4ӡT","wp-admin/link-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AlN.���+Qc��и�");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�A�B�7�Sz!�e","wp-admin/includes/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�o=a�*A���Td�");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�eU��MV��^��","wp-admin/includes/misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","҆F�T���?�;�Հ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0�>#����z(","wp-includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���F��a*�s�<�7");
INSERT INTO `arc1542_wfFileMods` VALUES("���������}��","wp-admin/media-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��J@�����!���");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�w���0�h�9","wp-includes/js/tinymce/plugins/fullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x�2����]�D�yZC");
INSERT INTO `arc1542_wfFileMods` VALUES("�J�&_#��3S�q���","wp-admin/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\:��ڈ��)g,\\","wp-includes/images/smilies/icon_twisted.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b���.�8|`�Q�LF");
INSERT INTO `arc1542_wfFileMods` VALUES("���3v�U�3�P�^O ","wp-admin/css/widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I�0�ݭ,L�Q6,R\0");
INSERT INTO `arc1542_wfFileMods` VALUES("��L �U����f��u�<","wp-admin/images/icons32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�P*���{>v��Uf");
INSERT INTO `arc1542_wfFileMods` VALUES("��`��kYL_��h%\'","wp-includes/theme-compat/comments-popup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�U/����aڌ.u<.");
INSERT INTO `arc1542_wfFileMods` VALUES("�:=�%�����M�۵","wp-includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_���Q��G������");
INSERT INTO `arc1542_wfFileMods` VALUES("�I�{�?��r�]��7","wp-admin/images/resize-rtl.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ےc�ZY�6��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7*���\"{��
�K<","wp-admin/includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/bmO��dNL	i��X");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�8������Z��N�","wp-includes/ID3/module.tag.lyrics3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�׬㑎��0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j��I���<꟟��iU","wp-includes/category-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v�uW����dai");
INSERT INTO `arc1542_wfFileMods` VALUES("��B]nȄ�8�7g��","wp-includes/images/smilies/icon_rolleyes.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȼ�_�Ҹ*>,�!j");
INSERT INTO `arc1542_wfFileMods` VALUES("�Mj�A�M��O�\"If","wp-includes/SimplePie/Net/IPv6.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Fy!j�ـ�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��$��xM1>�_8P\0","wp-includes/js/swfupload/swfupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�E%ρz���s~");
INSERT INTO `arc1542_wfFileMods` VALUES("���6�d��x�D��","wp-includes/js/mediaelement/background.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","p<e�K�c�\\c8�r~\0l");
INSERT INTO `arc1542_wfFileMods` VALUES("�n97�I.O�ҝ޿�","wp-includes/js/heartbeat.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��톙�@��Cm");
INSERT INTO `arc1542_wfFileMods` VALUES("����h+��B����","wp-includes/js/tw-sack.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'��7�ē��n�̄");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�\"��vh�$Lb��","wp-includes/js/imgareaselect/border-anim-v.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �z!�<�7������*�");
INSERT INTO `arc1542_wfFileMods` VALUES("��yc�0O�g)ρ�Mf�","wp-admin/network/site-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j@�~%�����xs");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�
5��H�?������","wp-admin/css/customize-controls.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4��ٻF���$4���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����juGCtO����","wp-admin/css/colors/coffee/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"rü�+��w����\'");
INSERT INTO `arc1542_wfFileMods` VALUES("��l�.H|S���{��","wp-includes/js/jquery/ui/effect-transfer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ި\0w}����n�");
INSERT INTO `arc1542_wfFileMods` VALUES("���an���V=Ty X�","wp-includes/SimplePie/Copyright.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�T��	Ù���j");
INSERT INTO `arc1542_wfFileMods` VALUES("�} �yT��Z�H�cDJ","wp-admin/js/custom-background.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#Y>W� �����e�");
INSERT INTO `arc1542_wfFileMods` VALUES("��{�0l(Ʋu9,wS�u","wp-includes/js/media-audiovideo.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�h �������^��");
INSERT INTO `arc1542_wfFileMods` VALUES("� �A$ۤfC�N��37","wp-includes/query.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�qN��
��b��");
INSERT INTO `arc1542_wfFileMods` VALUES("�(���ה�W�h@=a","wp-includes/images/smilies/icon_mad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","׾�iec�{��0");
INSERT INTO `arc1542_wfFileMods` VALUES("����v���ό�Y9�","wp-includes/ID3/getid3.lib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�sQ�F����0");
INSERT INTO `arc1542_wfFileMods` VALUES("��֗]NR���S{qv?�","wp-admin/css/wp-admin-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"�ew@3�u��|˻");
INSERT INTO `arc1542_wfFileMods` VALUES("��+�Ϳ�#Ft�EǍ7","wp-includes/js/mediaelement/froogaloop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*�B����#�D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�����j�X�])D:","wp-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!�i�A��>\'����ж�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j%M�ɍ��p)Z��","wp-admin/images/generic.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�[#98!�");
INSERT INTO `arc1542_wfFileMods` VALUES("��;(Xp`ҙ��pݷ","wp-includes/js/plupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<�`a*6Y$�qpM�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("��t�0�g�a�/���","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%���ցl R
1�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
�qo�qZVyX��9","wp-admin/includes/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X&Jʅ�q.�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ư	\'CԻ��ګ","wp-includes/images/admin-bar-sprite.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S���:�W����^");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"�Z0\0ؿe�Ԧp�","wp-admin/css/admin-menu.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�>d�\0?�h��/���!");
INSERT INTO `arc1542_wfFileMods` VALUES("����x8[!>�X","wp-admin/includes/class-wp-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o���z��4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("�S����KK2iɈ","wp-includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�D�ǅ<�}F�>UJ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y�g��zaU\"�	XKG","wp-includes/js/hoverIntent.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʳY�C��c�On�כ");
INSERT INTO `arc1542_wfFileMods` VALUES("�v{L�Jlō�Yz�`�(","wp-includes/js/thickbox/thickbox.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%R��j��o�AYx�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X�VטO|8}���","wp-includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)��݉:ث��;�c");
INSERT INTO `arc1542_wfFileMods` VALUES("�V}�P���m�/�|I*�","wp-includes/js/customize-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!0�&�q���\0�~�");
INSERT INTO `arc1542_wfFileMods` VALUES("��.��v8-rJŕ�qQ","wp-includes/js/wp-auth-check.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����]k���Z!V");
INSERT INTO `arc1542_wfFileMods` VALUES("��7��E#�wŧj���","wp-admin/includes/image-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o	z�*����R����");
INSERT INTO `arc1542_wfFileMods` VALUES("��v���|�-��","wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6������t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�!HUN&�\"����z��","wp-admin/css/widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J�����)0��x��C�");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�tU�q�^!�0ƣl�","wp-includes/post-formats.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�M�ґ�VȔ$L;Cd�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k���zߣ����bo�R","wp-admin/post-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z�6>!?~E����De�");
INSERT INTO `arc1542_wfFileMods` VALUES("��@��{�J��5䷴X","wp-includes/js/tinymce/skins/wordpress/images/playlist-audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U,�:)��؋\"�QqY");
INSERT INTO `arc1542_wfFileMods` VALUES("����L��6	���׳","wp-includes/ID3/module.audio.ac3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��E�p:�A��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES("��T��V�����\\��","wp-admin/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n8�]<�Ĕr��W7�@W");
INSERT INTO `arc1542_wfFileMods` VALUES("�ܵ[Ҳm%�6�S8:D","wp-includes/images/toggle-arrow.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��·�a��;�d��*�");
INSERT INTO `arc1542_wfFileMods` VALUES("����!ެ��߳���p","wp-includes/images/crystal/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�>)*/��!�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�h�����FuQe� �","wp-includes/images/wlw/wp-comments.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�6]P����.s���");
INSERT INTO `arc1542_wfFileMods` VALUES("��f0��ͭ��~�)","wp-includes/fonts/dashicons.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�����a�I�~t~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�|;�;8�Q�4�k��","wp-admin/install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH��H�.�Ӧ��%��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9�e�E��bݾl�3�","wp-includes/js/wp-lists.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t|r��5��xŇ�ґ");
INSERT INTO `arc1542_wfFileMods` VALUES("��5o��#R\'/��l","wp-includes/fonts/dashicons.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","΢6d����HD��Qك");
INSERT INTO `arc1542_wfFileMods` VALUES("����E�?��Юᾠ","wp-includes/js/media-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ԣ~蜿���gį�");
INSERT INTO `arc1542_wfFileMods` VALUES("��Cg����}|�E��","wp-admin/js/word-count.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮�E��^�:��/_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�	v�O.�|ߤҵ�","wp-includes/js/tinymce/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�t\"ٞ3��[�t�|");
INSERT INTO `arc1542_wfFileMods` VALUES("��b�������|e~�","wp-admin/css/customize-widgets.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�����?[���<�");
INSERT INTO `arc1542_wfFileMods` VALUES("����8(�j�Z]}","wp-includes/js/jquery/ui/effect-pulsate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&`������f��");
INSERT INTO `arc1542_wfFileMods` VALUES("�X����g5����(�=c","wp-includes/js/tinymce/skins/lightgray/img/trans.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7I �1F�Gu�j^");
INSERT INTO `arc1542_wfFileMods` VALUES("�pt_ Y����7L�Kt","wp-admin/css/deprecated-media-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{aPt�X?�A���IY");
INSERT INTO `arc1542_wfFileMods` VALUES("����T��D��F�K1�","wp-admin/css/media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x��{�%���U�");
INSERT INTO `arc1542_wfFileMods` VALUES("��/GΞӶ[�ǜ��C","wp-admin/js/gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K~�l���");
INSERT INTO `arc1542_wfFileMods` VALUES("���[�/�9}�`:w�P","license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","98��v���hP֡�>q");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0�����.}�fwA","wp-includes/date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u���<��OI");
INSERT INTO `arc1542_wfFileMods` VALUES("�[���QH\"pS1Ȫ�c","wp-admin/images/arrows-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Q��}��ydb#6�");
INSERT INTO `arc1542_wfFileMods` VALUES("��[ixT�q��~Wv�e","wp-admin/network/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�͚�GM�XZi=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�-��x7��(A�4���","wp-includes/js/swfupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�`�^�-�o�QWz");
INSERT INTO `arc1542_wfFileMods` VALUES("�1W;c�����N��\"�u","wp-includes/pomo/streams.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q;�}���,ʠ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��B�GT�;,l��T","wp-includes/images/smilies/icon_exclaim.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�qE�!HY__=�{_�");
INSERT INTO `arc1542_wfFileMods` VALUES("���7�M3�$��","wp-includes/images/smilies/icon_question.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'u��&E�qA���mN�");
INSERT INTO `arc1542_wfFileMods` VALUES("����2@�k�w>K�2","wp-includes/feed-atom.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q5B���4���D
W");
INSERT INTO `arc1542_wfFileMods` VALUES("�����H\0ۙ��h�C��","wp-admin/css/colors/ectoplasm/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8�K���࿬8��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("��wt�H���-s�\0�n","wp-includes/js/wplink.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�$m��y�l�e���");
INSERT INTO `arc1542_wfFileMods` VALUES("����=֬H�@-i��","wp-includes/css/admin-bar-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��`��
L�&6;");
INSERT INTO `arc1542_wfFileMods` VALUES("���^��\'�q���0��","wp-links-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c���v��Il�mf�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%n��Tߒ	^�gXΰ","wp-admin/js/inline-edit-post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Vӎ���}�_��
�)�");
INSERT INTO `arc1542_wfFileMods` VALUES("�5������k��","wp-admin/js/color-picker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����2dMM��T���");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�������P5aĨ�	","wp-includes/images/smilies/icon_wink.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�Z���g9�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y85���æb�","wp-admin/css/colors/sunrise/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Cp��L�I��tv}���T");
INSERT INTO `arc1542_wfFileMods` VALUES("����PQ�E|E}7+","wp-admin/includes/class-wp-filesystem-ftpsockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�<Rр��D�Fv���");
INSERT INTO `arc1542_wfFileMods` VALUES("��U���$�\\*�1^�S�","wp-includes/js/jquery/ui/effect-clip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ǔ�W�#�GZas");
INSERT INTO `arc1542_wfFileMods` VALUES("��P��/���l%�","wp-includes/js/jquery/jquery.hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","┃��&�݋Fư��");
INSERT INTO `arc1542_wfFileMods` VALUES("�
%f[!aE�r�tg�i","wp-includes/images/media/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����u�h����q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�S짿o�$��0�n","wp-includes/author-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l�@Ñ��P>�itz\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�G�|$p֠+(�","wp-admin/js/tags-box.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t��f����  ��#�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Q����ԁ�2�7u��L","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��W�)�˩��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ѻ�\"�P5��^U�i","wp-admin/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",u��J�%yZ.�");
INSERT INTO `arc1542_wfFileMods` VALUES("��m���z4�L��K","wp-admin/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("����A�G,��<���","wp-includes/js/jquery/ui/effect-fade.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�OO_��;{r�5$m");
INSERT INTO `arc1542_wfFileMods` VALUES("���<��po@S�q��","wp-admin/includes/class-wp-press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���ī��MJ�(6Q");
INSERT INTO `arc1542_wfFileMods` VALUES("� �n�$��q��^qf��","wp-includes/images/smilies/icon_lol.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M�Z8|����,���");
INSERT INTO `arc1542_wfFileMods` VALUES("�*T�u�����~�m","wp-admin/css/colors/ocean/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� 8��J4Z�Jf{
");
INSERT INTO `arc1542_wfFileMods` VALUES("�E-j��1j���E�","wp-includes/registration-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_?<���&T�xH�X�CL");
INSERT INTO `arc1542_wfFileMods` VALUES("��p?E^�@�\'��PE�","wp-admin/edit-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")O��I=4�]VyK�");
INSERT INTO `arc1542_wfFileMods` VALUES("�<��(����*A]�O��","wp-admin/css/colors/ocean/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2Pjģ�$��f�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�bv��E��H���΄","wp-includes/js/wp-lists.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�.�+#/*إ�I08o");
INSERT INTO `arc1542_wfFileMods` VALUES("���&��N�,���6P","wp-admin/images/icons32-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*04�G4F�	&Z�i}\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�h���Bc�92��","wp-admin/network/site-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�!l|�2��V_��");
INSERT INTO `arc1542_wfFileMods` VALUES("��d]\0F�mŲp�D","wp-includes/js/tinymce/plugins/media/moxieplayer.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NY�N�-���3Yj���");
INSERT INTO `arc1542_wfFileMods` VALUES("���v��\\Q���-��","wp-includes/js/tinymce/plugins/hr/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\#%Z����,3�I�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��і�q��SGKy(�","wp-includes/kses.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\\L�Ŋ[����a");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�Hn[P�.~���FU|","wp-includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7h�ޝ�:޿�-�7");
INSERT INTO `arc1542_wfFileMods` VALUES("����Z�xcy�d��\'","wp-admin/js/language-chooser.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h\"8Jq	t���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:x��=�}�","wp-includes/js/jquery/ui/mouse.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8\']��!��Iٲ��");
INSERT INTO `arc1542_wfFileMods` VALUES("� a\"KwT�bc1S","wp-admin/css/revisions.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��tp��p��P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4g��e���>���ߝ","wp-admin/images/list-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hջIS�2��i�g�");
INSERT INTO `arc1542_wfFileMods` VALUES("�fkj��N�Uei4=%�","wp-admin/js/tags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/I�@�!{�hL�R�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y%���Ǻ~�ne\"V","wp-admin/css/list-tables-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K �@���W�<");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�o%��q�A��","wp-admin/js/inline-edit-post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~{&�di�Y�0�\\�*z");
INSERT INTO `arc1542_wfFileMods` VALUES("��E����Q?��	(�","wp-includes/class-oembed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-fO������Ó�f��|");
INSERT INTO `arc1542_wfFileMods` VALUES("�.݁B��xK�Y�","wp-includes/ms-default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ӱ���eu`�.@7");
INSERT INTO `arc1542_wfFileMods` VALUES("�*O-�Lτ���[�u","wp-admin/css/about-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��/��v�R)�`�E!Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�??n������_2g��j","wp-includes/js/wp-util.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
��%;�I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R;lzO�8m<3�Nie","wp-admin/user/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˹��޳H�t��i.");
INSERT INTO `arc1542_wfFileMods` VALUES("�afh=F���T�:��6�","wp-admin/includes/class-ftp-sockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��[���6��+��\'<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����;~ӷR�>��","wp-includes/class.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��
s? Ei9{�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("���nvp�e������}�","wp-admin/js/customize-controls.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�T�ח
�%��c");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�|n���sARF�+","wp-includes/js/crop/marqueeHoriz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮����;���Lo
");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:[&b�[�hY��","wp-includes/images/smilies/icon_razz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��˭��=��J�@��");
INSERT INTO `arc1542_wfFileMods` VALUES("����8`9��?Bb�Б","wp-includes/js/jquery/ui/effect-puff.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Iml�c�G�@�ȳ� �");
INSERT INTO `arc1542_wfFileMods` VALUES("�c�̎��$
\'@���","wp-admin/setup-config.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�K�[D+^����/");
INSERT INTO `arc1542_wfFileMods` VALUES("���J1��M�F��<�","wp-admin/js/tags-box.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Kn���<ס�x٩");
INSERT INTO `arc1542_wfFileMods` VALUES("���?ڟ�E���$PF","wp-includes/pomo/translations.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fWۥ�\"�\0Dwf��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����6��b�g�>_�","wp-includes/images/wlw/wp-watermark.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��uMmܭD|�w���D");
INSERT INTO `arc1542_wfFileMods` VALUES("� �(T5!��h�u","wp-admin/css/press-this-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q���X�A�8�V�\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�?���Gc	¯l1e","wp-includes/class-wp-theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6���qߒAz`!�d");
INSERT INTO `arc1542_wfFileMods` VALUES("�H�����Pw��%8��","wp-includes/images/smilies/icon_sad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'=��Oj�?�uA|��");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�n�G{��\'��q:�","wp-includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_Y+�W��+Ŗ Lp�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ȁ�~_q�I��S�","wp-admin/js/password-strength-meter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��|��=��m�U��");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\�D �>�F,���","wp-admin/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��z�ehV��
�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("��=CѠ��*TX���4","wp-admin/css/colors/_variables.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":�	k	r�L���Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�� ��It13&","wp-admin/js/nav-menu.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"YG�]���Sʫ��");
INSERT INTO `arc1542_wfFileMods` VALUES("�&F�g��25xm��J&","robots.txt","0","��m�`��=F^+(","��m�`��=F^+(");
INSERT INTO `arc1542_wfFileMods` VALUES("�;?2��S��\0��p","wp-admin/customize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T���xv9|5H3x ");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�.�1PXL�","wp-admin/includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D
��mz/��:���");
INSERT INTO `arc1542_wfFileMods` VALUES("������|� ��","wp-includes/js/masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iq}Eigo@���T��");
INSERT INTO `arc1542_wfFileMods` VALUES("��p�$^���d�Z","wp-admin/network/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��Oy_��4�)����");
INSERT INTO `arc1542_wfFileMods` VALUES("��[K���b���28�","wp-includes/pomo/po.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6+\0��n�_HSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("�o����l>��x~I� �","wp-admin/network/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��=���SV��V���");
INSERT INTO `arc1542_wfFileMods` VALUES("���0j�l�S��K�","wp-includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�e�R~�O��;eV��G�");
INSERT INTO `arc1542_wfFileMods` VALUES("�«��-j=�u�N\\q\'","wp-admin/css/farbtastic.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��8)���}{��C�h2U");
INSERT INTO `arc1542_wfFileMods` VALUES("���ᗏ�3�-��4�","wp-admin/css/colors/midnight/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","FӍ���W�����&%�");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"ڕK[@�G����9�","wp-admin/includes/class-wp-theme-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��u�g��������4");
INSERT INTO `arc1542_wfFileMods` VALUES("�3!9�=�6�ݡ","wp-admin/images/resize-rtl-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ɞ�@��T0:��}");
INSERT INTO `arc1542_wfFileMods` VALUES("�)[\"J�H��|�jk��$","wp-admin/js/customize-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q�*N��>�˘�");
INSERT INTO `arc1542_wfFileMods` VALUES("�JTV0D��oTA［@�","wp-admin/options-discussion.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c{��7��ֺX��.tR�");
INSERT INTO `arc1542_wfFileMods` VALUES("����S�h���S�%Tz�","wp-includes/js/mediaelement/wp-mediaelement.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ؒj�F�5ρ�acR�");
INSERT INTO `arc1542_wfFileMods` VALUES("���\"ܒ����nzD","wp-includes/SimplePie/Caption.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����BjM��g[����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Z
u�oK� ��T;e","wp-admin/images/list.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">��*��ӳ�S��");
INSERT INTO `arc1542_wfFileMods` VALUES("���Uy/�*%���;","wp-admin/includes/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�9�`o��I},סQM");
INSERT INTO `arc1542_wfFileMods` VALUES("�E��U���̈́��","wp-includes/images/wpspin-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("�������sp���e�","wp-admin/includes/class-wp-ms-sites-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i�6���|�K�{h");
INSERT INTO `arc1542_wfFileMods` VALUES("�-1�8�;�T�/X�]","wp-admin/ms-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]b$�����q����h");
INSERT INTO `arc1542_wfFileMods` VALUES("����(5�aH�yo,X�","wp-includes/js/jquery/ui/tabs.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�gUZ���D�����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�͓�bHn��,\0-","wp-includes/images/smilies/icon_confused.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�sYFPZ6��,��");
INSERT INTO `arc1542_wfFileMods` VALUES("�L���yE�{��f�","wp-includes/css/dashicons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U�Y��V=}W(}�.N");
INSERT INTO `arc1542_wfFileMods` VALUES("�k�UL��ǡ�$���","wp-admin/ms-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H#�f{#ʃ��	6G�");
INSERT INTO `arc1542_wfFileMods` VALUES("����{^��W����C�","wp-admin/css/colors/ocean/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lv,|����\"��O");
INSERT INTO `arc1542_wfFileMods` VALUES("�_f��;w�a��ځ�","wp-includes/js/tinymce/skins/wordpress/images/gallery.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_���Pw��PU�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�u��<e�x��@ֈ>","wp-includes/js/underscore.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����T��Hk�zd..");
INSERT INTO `arc1542_wfFileMods` VALUES("��q?%��rp��0�7�q","wp-admin/css/colors/coffee/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H<�S�-�g�����");
INSERT INTO `arc1542_wfFileMods` VALUES("����x�Й�)DC��<","wp-includes/js/customize-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Һ�zCp�OE�a�V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�~����U�\"�&��","wp-includes/images/wpicons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��n�V�o�$��Of~7");
INSERT INTO `arc1542_wfFileMods` VALUES("��W2��D��G�7�V","wp-admin/css/common-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��������J<��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Vb(kt�W\"�6(;ƴ�","wp-admin/includes/class-wp-media-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�K��]$��V����");
INSERT INTO `arc1542_wfFileMods` VALUES("�tfF	�r{�܇�_I�x","wp-includes/SimplePie/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�.�b���~����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("��߲;��0����","wp-includes/feed-rss2-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<����7Uv9Q�7");
INSERT INTO `arc1542_wfFileMods` VALUES("��3�T.^�ƙ<���","wp-mail.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R:�߱5�$6��");
INSERT INTO `arc1542_wfFileMods` VALUES("��K���OȖ9�3|<�","wp-admin/maint/repair.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�#\0�24P2�pe�4");
INSERT INTO `arc1542_wfFileMods` VALUES("��I����.$U0]\'�S_","wp-admin/includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J#�%sժ��ka.R�");
INSERT INTO `arc1542_wfFileMods` VALUES("��+D�FܿTZ[H7","wp-admin/images/post-formats-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�l��H\\�������");
INSERT INTO `arc1542_wfFileMods` VALUES("�GV\\z��#���!;��","wp-includes/js/media-audiovideo.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���86(H��_N���");
INSERT INTO `arc1542_wfFileMods` VALUES("�O�r#���T�G��!","wp-includes/js/swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���,�I}p�e~2�q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�l&�*�������&","wp-includes/SimplePie/Content/Type/Sniffer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|r��i�Ub�lw����3");
INSERT INTO `arc1542_wfFileMods` VALUES("���$(�g�(���P��/","wp-admin/css/wp-admin-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ɖu�/�o�`QS�0f�");
INSERT INTO `arc1542_wfFileMods` VALUES("�������kM��?�uX","wp-admin/css/ie-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	wʢ���5յSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("���q�K�U�j��","wp-includes/SimplePie/Category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~��?��.
ܯd�*");
INSERT INTO `arc1542_wfFileMods` VALUES("��-Z���:E�:","wp-admin/js/image-edit.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@ɡ�mz���4n�/GX");
INSERT INTO `arc1542_wfFileMods` VALUES("���|�jX����|�fb","wp-admin/css/login.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����HtU���R��");
INSERT INTO `arc1542_wfFileMods` VALUES("�MR��l�B�F�u","wp-includes/option.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��!+��1,�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�\\�j�����A$�","wp-includes/js/customize-base.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�0�g���ν����");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\"Sέ`t@","wp-admin/network/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��|��MM0\0���");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��.1��-��:","wp-admin/options-media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7�3�1T�w&;��");
INSERT INTO `arc1542_wfFileMods` VALUES("��ΝH�*��*.ځS","wp-admin/includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V��._%B)�j�A��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ul1�ȕD�bmg�","wp-includes/css/buttons-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z�e��=�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
fv�8���1���-I","wp-includes/SimplePie/Exception.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	K�v&���<\\ڏ�S5");
INSERT INTO `arc1542_wfFileMods` VALUES("���ZQ4��\\(�܇","wp-admin/network/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N��5Cs��	�");
INSERT INTO `arc1542_wfFileMods` VALUES("����l����3Ȋ�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���Ѕ�k��#M��");
INSERT INTO `arc1542_wfFileMods` VALUES("�J|6}�P�,ٛ","wp-admin/css/colors/_admin.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W耢��hL��%");
INSERT INTO `arc1542_wfFileMods` VALUES("�����[��:�����q","wp-admin/includes/class-wp-plugins-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�m[ދ���`
jܸ");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�Of;���/��","wp-includes/SimplePie/Decode/HTML/Entities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�^/�B���Z#�%/a");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\ ��Iѻ���,","wp-includes/class-simplepie.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ys�r�	�m���D;��.");
INSERT INTO `arc1542_wfFileMods` VALUES("�/&�����2�ѡgDs","wp-includes/http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��w��$~�r�4T$");
INSERT INTO `arc1542_wfFileMods` VALUES("��?�0|���5uơ��","wp-admin/custom-background.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�إO��\0Q�-��");
INSERT INTO `arc1542_wfFileMods` VALUES("���qh�n�J�j�","wp-admin/css/nav-menus.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&cDݱ��t�q��a");
INSERT INTO `arc1542_wfFileMods` VALUES("�ÏuL�,�&Ǒ�1","wp-admin/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2=KB������H��B");
INSERT INTO `arc1542_wfFileMods` VALUES("��$�<@�Řa���c\"","wp-includes/js/swfupload/plugins/swfupload.swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","̵q�V7�T\\���s");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�@o��\'��kb���","wp-includes/js/jquery/jquery-migrate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q+�(0�BY�<�4:��");
INSERT INTO `arc1542_wfFileMods` VALUES("����^[X��i�	�","wp-admin/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Lg8pt.����ץn");
INSERT INTO `arc1542_wfFileMods` VALUES("��4T�(�\\9\'��3�)","wp-admin/css/customize-widgets-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��PO?$�L�~�U��j�");
INSERT INTO `arc1542_wfFileMods` VALUES("��k{��&��x
��","wp-includes/class-wp-error.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4ĸ\'��3��Bd
���");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��%3[$x\0��.��(","wp-admin/images/marker.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�*O2/�3I2���");
INSERT INTO `arc1542_wfFileMods` VALUES("�	���Em[�����l�<","wp-includes/js/tinymce/plugins/image/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�6_�� ��N�#�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("�������\"�R�Ŝ","wp-includes/images/crystal/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�� Ѳ��#�d�%�[�");
INSERT INTO `arc1542_wfFileMods` VALUES("�v%���S�[�̪�Ѿ","wp-includes/ms-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�zn��GNpܯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("���X\"�-{��$48sx","wp-admin/css/deprecated-media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
ڌe�6|�����Ʀ");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��9�ѕ�F�w�","wp-admin/js/revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�F�{�~��\'Y�i");
INSERT INTO `arc1542_wfFileMods` VALUES("����N����@�(�3�","wp-includes/ID3/module.audio.mp3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#��~e�����J�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��h���)UG@�x��v	","wp-admin/edit-tags.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�{#kb����ao�~");
INSERT INTO `arc1542_wfFileMods` VALUES("��(�[3?�H/�[�e]","wp-includes/js/tinymce/skins/lightgray/fonts/readme.md","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zd��+���E@�1�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�AuI.F��/���","wp-includes/js/wp-pointer.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ˋ8�.�r:ě���");
INSERT INTO `arc1542_wfFileMods` VALUES("�<{����,-�![M��","wp-includes/js/tinymce/skins/lightgray/skin.ie7.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���m_ҐsԥG");
INSERT INTO `arc1542_wfFileMods` VALUES("�@��,�n\\���+k�","wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�,s�M������Pm");
INSERT INTO `arc1542_wfFileMods` VALUES("���=V;�����N.K","wp-includes/js/wp-list-revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","GQu`�*�L��n$��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Κ,�Q�a�gl���","wp-includes/class-smtp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P�����ʄb�.");
INSERT INTO `arc1542_wfFileMods` VALUES("��dA#���*�Źo7","wp-admin/js/customize-controls.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��B�؏�f��@��.");
INSERT INTO `arc1542_wfFileMods` VALUES("��3\"�(z�a�4�8�","wp-includes/images/media/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-o��Uʓ��U�U_");
INSERT INTO `arc1542_wfFileMods` VALUES("��5��[,	j�(�ƪ�","wp-includes/js/mediaelement/controls.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$�\"�Ӭ����?�Ȥ");
INSERT INTO `arc1542_wfFileMods` VALUES("���2zs��4x�EB","wp-includes/ID3/module.tag.id3v1.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h؜�ٱal��w�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Obc��\" ���|J(","wp-includes/images/smilies/icon_evil.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c����VM<�\"!�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�1��WV(2��6����","wp-admin/images/icons32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۬[�m9��J�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("��1���|�}���dQ","wp-admin/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-s�t���?_�_J");
INSERT INTO `arc1542_wfFileMods` VALUES("��	1��А々�S:(","wp-includes/js/thickbox/loadingAnimation.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"h�c�����&�");
INSERT INTO `arc1542_wfFileMods` VALUES("�.�B�|xӳ��E�","wp-admin/css/press-this-editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P`d�L�-#wM!�_");
INSERT INTO `arc1542_wfFileMods` VALUES("�C�3�!0Q�o�J�e `","wp-includes/js/plupload/plupload.flash.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����g�}F�9�\"�~S");
INSERT INTO `arc1542_wfFileMods` VALUES("�_���jSX�2�QQ=","wp-includes/ms-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ӎ�p�?k,�H��");
INSERT INTO `arc1542_wfFileMods` VALUES("��tnR�ؔ����%^�","wp-admin/images/align-right.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B���Oe#�l@:P+\"v");
INSERT INTO `arc1542_wfFileMods` VALUES("���5�V\"�$$�_��","wp-admin/includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","up�ꩣ�ud+��퀥D");
INSERT INTO `arc1542_wfFileMods` VALUES("��iY����\0
R)��","wp-includes/post-thumbnail-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e�1L5R���Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("��u�X�ݼ#�-����","wp-includes/class-wp-http-ixr-client.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","tJr�P�?��bU��a");
INSERT INTO `arc1542_wfFileMods` VALUES("Ĉ^A��+l���o�d��","wp-includes/js/tinymce/skins/wordpress/images/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7~!���\0�����\"w");
INSERT INTO `arc1542_wfFileMods` VALUES("ĔԼ���pP�Z	H��","wp-includes/images/smilies/icon_cry.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E>z?��Ap�mWlA�`");
INSERT INTO `arc1542_wfFileMods` VALUES("��ʙ\0}��甠K��.�","wp-includes/js/jquery/jquery.color.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���E�G����>vJ");
INSERT INTO `arc1542_wfFileMods` VALUES("��{A��mm��*�K","wp-includes/nav-menu-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{y�E�-�2�Q�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�`#��G�b�C��֊�","wp-includes/js/swfupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y,k?�X�N�0G�;");
INSERT INTO `arc1542_wfFileMods` VALUES("��-�p�lE���k�/�","wp-includes/js/jquery/jquery.hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S!}EU�\\b�g�h��=");
INSERT INTO `arc1542_wfFileMods` VALUES("�+���g���q6�^\0�","wp-admin/images/wheel.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E0� q0m��Y%V�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("ƅ����|_�i/y��	","wp-includes/js/tinymce/plugins/media/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�/~.SM�6L�5\\");
INSERT INTO `arc1542_wfFileMods` VALUES("Ƭ+���I�d^i <\0","wp-includes/js/jquery/suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�k�7*헸Hޞ");
INSERT INTO `arc1542_wfFileMods` VALUES("ǂ-i)�.�\\���z�^a","wp-includes/Text/Diff/Engine/shell.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�Aܑ�~J�^t����");
INSERT INTO `arc1542_wfFileMods` VALUES("ǅ�9��9:����","wp-includes/cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��G�-��E���B�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ǥ>z�Ԅ��!J]>","wp-includes/css/wp-auth-check-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6&B���Kb�");
INSERT INTO `arc1542_wfFileMods` VALUES("ǫ�=��m�/���^","wp-admin/includes/schema.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��W��y�$��G��m�@");
INSERT INTO `arc1542_wfFileMods` VALUES("ǳ\\��_L-Y�Ō%$","wp-includes/ID3/module.audio.dts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lA��E��O87�$(");
INSERT INTO `arc1542_wfFileMods` VALUES("�{g��?�3gڢ�","wp-admin/images/icons32-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%�*�����g����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"u@��T��S��5�","wp-includes/images/smilies/icon_idea.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"m%h�����S��r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y$\'����o���","wp-includes/css/wp-auth-check-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Gn+��i�7���b�$");
INSERT INTO `arc1542_wfFileMods` VALUES("ȍP�� �3����
��","wp-includes/class-wp-customize-control.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ͩ�t��!rl��{~");
INSERT INTO `arc1542_wfFileMods` VALUES("�����~K4(#��","wp-admin/user/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ����ǀ[K}�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�A7�\'�C#�w�S�s�","wp-admin/css/about.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ɵ���^Xl�|��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����2D�i�e�","wp-admin/css/l10n.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�T�����=�!�T");
INSERT INTO `arc1542_wfFileMods` VALUES("�!&�i�)^�W���R�","wp-includes/js/jquery/ui/widget.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�5��~�%�]c���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�q�4P�}�5Oz�k","wp-admin/js/inline-edit-tax.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� q�8^uၓ�)?��<");
INSERT INTO `arc1542_wfFileMods` VALUES("�R���ш�޿�0","wp-admin/css/themes.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�7�Ջ�b�LI�+w�");
INSERT INTO `arc1542_wfFileMods` VALUES("�hFM<@`%q-��","wp-admin/includes/class-wp-filesystem-direct.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|h@{Q}5�c!�K0Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�xjP�����!c�x","wp-admin/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/�Q�٩̪}5,
");
INSERT INTO `arc1542_wfFileMods` VALUES("��	b���8�[����y","wp-includes/js/wp-emoji-release.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Yv�S44lzb�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�!��#��I|���F�","wp-includes/js/tinymce/plugins/directionality/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��V���ʬ� Hy�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�<��C�﮿�V:(r","wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J¾U�a��g���");
INSERT INTO `arc1542_wfFileMods` VALUES("�U<�?Y,����ػ(","wp-admin/js/svg-painter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����fu���");
INSERT INTO `arc1542_wfFileMods` VALUES("ˍ�G䯀oe���o�","wp-includes/js/shortcode.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� z�>1���J�92�");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�E,�-O�{���","wp-includes/link-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\\�\\�i�/�:��I");
INSERT INTO `arc1542_wfFileMods` VALUES("�!�LT�3��i��x�","wp-admin/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�w�C�!_H�;D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�M�Tq&[?��>칊�
","wp-admin/css/colors/ectoplasm/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q�9+�\"��+��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V�ڮ����M��jӁ","wp-includes/js/plupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u&
�TI�z����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ê5ff�;,G!\'��\'-","wp-admin/css/colors/ocean/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Oe����\"&�����~");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǌ�E�v�c,�صyS^","wp-includes/images/crystal/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]�Lc�iG�fQ���");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�j֛`��w","wp-admin/css/customize-controls-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'���-��k��;!�");
INSERT INTO `arc1542_wfFileMods` VALUES("�d���lP�O��I�","wp-admin/network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��9�{e�,Yj��
");
INSERT INTO `arc1542_wfFileMods` VALUES("�w�9=�_\"h%��v","wp-admin/css/install-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��CM:�������");
INSERT INTO `arc1542_wfFileMods` VALUES("͓�Y�36��l�Y��","wp-includes/js/tinymce/plugins/textcolor/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��
�������}�W0�");
INSERT INTO `arc1542_wfFileMods` VALUES("ͽ3��=��O�G�|~�","wp-includes/SimplePie/Credit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M猋*>
�|");
INSERT INTO `arc1542_wfFileMods` VALUES("����j(g��~jU#��","wp-admin/includes/class-wp-filesystem-ssh2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=酅�c�o��<�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�_)-�]�ˌkO	���","wp-includes/ID3/module.tag.apetag.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7��l,�iwF�Q�ql");
INSERT INTO `arc1542_wfFileMods` VALUES("�œ���ϔ�=��#6","wp-admin/images/post-formats32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WY~�O��{�+_L�kE;");
INSERT INTO `arc1542_wfFileMods` VALUES("�-�+�e���m�u\"��x","wp-admin/css/colors/sunrise/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E6G�QSU�E�a�B�8");
INSERT INTO `arc1542_wfFileMods` VALUES("�uF��^G��E+��c","wp-admin/network/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�O~+�~�1");
INSERT INTO `arc1542_wfFileMods` VALUES("π�tGȩ�����D","wp-includes/js/tinymce/plugins/image/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�r�J\0�3��\\�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("ϊ=��X���bBz\' �","wp-includes/js/jquery/ui/effect-explode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`YU����Q}X�Q�0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����HԹ��f�k�","wp-includes/js/tinymce/wp-tinymce.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b
��0pr���Hv");
INSERT INTO `arc1542_wfFileMods` VALUES("�ݙ�P(���O\'E��e","wp-includes/js/jquery/ui/effect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A֢�pi��u+`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�鋭��{^�MU*�_","wp-includes/js/twemoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��37�[:.i Ĵ|t�");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�s�l�WD7�M�","wp-includes/bookmark-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���!m<������O4");
INSERT INTO `arc1542_wfFileMods` VALUES("Т�펹�|����@","wp-includes/images/smilies/icon_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ʵ	�������(");
INSERT INTO `arc1542_wfFileMods` VALUES("��^�\\�X�PvS�\\�{","wp-admin/js/media-upload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_f����b�f��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("�/��0��
*7�f(��","wp-includes/js/wp-a11y.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�9s�%o����V<4");
INSERT INTO `arc1542_wfFileMods` VALUES("�_\\c9mL�v��1���","wp-includes/compat.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ڲ@;h_�yu]�H���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Jh|��0�`Zp�E","wp-admin/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fϧ=�iw�U���x�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҟ����ǟ�	Ks���","wp-includes/images/icon-pointer-flag-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�b��&�Z�r");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҫ*���H���
;t��","wp-admin/includes/ajax-actions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y*tf�Md�K�W��i�");
INSERT INTO `arc1542_wfFileMods` VALUES("ҲE5|�ѵ�C�d闼","wp-admin/options-reading.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V�qu��}��-.�Ja");
INSERT INTO `arc1542_wfFileMods` VALUES("��Lt593�u^���)��","wp-admin/images/comment-grey-bubble-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TY�ŝ2�s,�m��");
INSERT INTO `arc1542_wfFileMods` VALUES("�E#l��L��_&ܪ���","wp-admin/images/arrows.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�v�$�>����>�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�{ڭd3T�Xy����7;","wp-includes/css/admin-bar-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֥]��_C?��+]�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�].�oo�ȦM-n	�","wp-admin/images/align-none-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XC�)[���-�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ȇp���]4��L��q�","wp-includes/css/admin-bar.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U(X,�3tB��_");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��S��`�]T]D�","wp-includes/css/dashicons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}\0�c���\'ޒà�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X��$�a��B��^","wp-admin/js/user-suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T\\���\\|��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("����ͤ6�\0/��k���","wp-includes/js/imgareaselect/jquery.imgareaselect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\00ԺLB�wm#��wu�:");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z��	r!ޏf���	�","wp-includes/images/icon-pointer-flag.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,���E^�j`\'");
INSERT INTO `arc1542_wfFileMods` VALUES("�oҨ*K��o�7{� <","wp-includes/ID3/module.audio-video.matroska.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�!�Z0zDj&Cp�");
INSERT INTO `arc1542_wfFileMods` VALUES("�rY�S�xwDY˚J�[","wp-includes/images/media/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R׬˂���ôŉh�H");
INSERT INTO `arc1542_wfFileMods` VALUES("ֶ��9؞f�po3t","wp-includes/class-wp-admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","YS�y�Ρ����Q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Gȩ��6����\0Y","wp-admin/includes/class-wp-posts-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��La��FH[��a\'��");
INSERT INTO `arc1542_wfFileMods` VALUES("מ�y�7mE5���O_�","wp-admin/js/media.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".���$!&��^$�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("��j0���w�E}®R�","wp-admin/css/wp-admin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n{�������n�I��6");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�I:wm�\'~K-","wp-includes/ID3/module.audio-video.riff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TfbpGO�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�Zh�$�Éo�","wp-includes/class-json.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�SA���̈́���%");
INSERT INTO `arc1542_wfFileMods` VALUES("�8/B��$8���`m�","wp-includes/js/imgareaselect/jquery.imgareaselect.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U���K(t���0���");
INSERT INTO `arc1542_wfFileMods` VALUES("�A�h)I�]Gr���E","wp-admin/includes/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ޱ�wCrݩA�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�M&�3��3CMaQ{","wp-admin/images/yes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�+��7܉�qZ�Qk");
INSERT INTO `arc1542_wfFileMods` VALUES("�o�ǣ�	ף�f0�Y","wp-includes/SimplePie/Core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���#���������");
INSERT INTO `arc1542_wfFileMods` VALUES("�v�������&X��","wp-includes/js/jquery/ui/selectable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q�\"�{�B�M���");
INSERT INTO `arc1542_wfFileMods` VALUES("�,(�i7:^�^�#","wp-includes/js/tinymce/plugins/paste/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)>�|�K*bH�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k��/y�����&��G","wp-includes/images/rss-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ya[�Q�����rj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��!}�=�`*�gZ=","wp-admin/network/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����y|��C");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�~�!�g�q��","wp-includes/js/tinymce/skins/lightgray/skin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�uw*S������-�]");
INSERT INTO `arc1542_wfFileMods` VALUES("��w�=Ţ�O�&�F�","wp-admin/css/colors/midnight/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&܍���|DW��!E�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�|�#�԰#�{�����","wp-admin/js/link.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��0�;���3�%-");
INSERT INTO `arc1542_wfFileMods` VALUES("��!�(t��<Թ","wp-includes/js/heartbeat.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� �	�1�]�d*D�G");
INSERT INTO `arc1542_wfFileMods` VALUES("��_�JL�#�@B��","wp-admin/css/colors/midnight/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H�]�Q�T�kܤc");
INSERT INTO `arc1542_wfFileMods` VALUES("� �I�_X�����?","wp-admin/js/gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o����m���dOo");
INSERT INTO `arc1542_wfFileMods` VALUES("۪���	.�ո�\\���","wp-includes/js/tinymce/skins/wordpress/wp-content.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ٞ�R��F1oj�3�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("��r�����؁=�Ԓ�","wp-includes/images/rss.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�(�.��*NZ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��
p���Gnu:���","wp-includes/js/colorpicker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��V g�����-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȼ�؟�\'`����","wp-includes/feed-rdf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<C���H�,D\'��7i");
INSERT INTO `arc1542_wfFileMods` VALUES("�2G�?�_��\\���-B","wp-includes/canonical.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<!
�4?ζ6�O�Q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�F|
�MN,8�ݪ�\'�","wp-admin/css/press-this.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u�5$).M)��Hc");
INSERT INTO `arc1542_wfFileMods` VALUES("��ջZml��4�ˮU","wp-includes/images/smilies/simple-smile.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K��{��f�w�h");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0FJ��B��e�","wp-login.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Q�S��Y���st�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J0����j�Yg�h�","wp-includes/js/tinymce/plugins/lists/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��1�����I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�[6�5��+�	�n9�","wp-admin/images/sort.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�ˍ���lHj�]");
INSERT INTO `arc1542_wfFileMods` VALUES("�f��y���ħ�*!","wp-admin/js/nav-menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hxÈ�o\0c��;(��");
INSERT INTO `arc1542_wfFileMods` VALUES("�3^��PM�Y���H�D�","wp-includes/js/tinymce/skins/wordpress/images/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�¶��B�=z��3j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�N�\\�|�`*�,)@4","wp-includes/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'g!�:�H��),�","wp-includes/SimplePie/XML/Declaration/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���p(Å��B��s#b");
INSERT INTO `arc1542_wfFileMods` VALUES("����\"�����c)j�\"","wp-includes/js/wplink.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Μ�^g�o]Dq�`JMi");
INSERT INTO `arc1542_wfFileMods` VALUES("�q����%ű� m+","wp-admin/css/colors/light/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʘ_�
JT�¹���J");
INSERT INTO `arc1542_wfFileMods` VALUES("ߌ��(������2���","wp-includes/js/quicktags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z\0�j��7%�� 4");
INSERT INTO `arc1542_wfFileMods` VALUES("ߗ�Q��u�!ٶx�[","wp-includes/js/wpdialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���\0�g�Fġ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%�f\\+,���\0\\Y","wp-admin/includes/class-wp-filesystem-base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=>q��$����_�p");
INSERT INTO `arc1542_wfFileMods` VALUES("��^��bR��SI�!�?","wp-includes/class-wp-image-editor-imagick.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��,h2�԰�ڙ�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z���(>(�1bޫ�Z�","wp-includes/js/tinymce/skins/lightgray/content.inline.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[Θ|.zlˏ.�}լ");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�@/��ꦑٞ-M�","wp-admin/network/site-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ڄ\"�\'��.���");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\9ã>���Iz4�c","wp-includes/js/tinymce/plugins/hr/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��<�<{LU798�ۆ");
INSERT INTO `arc1542_wfFileMods` VALUES("�L�>�ٟ�#{6p}Y��","wp-admin/options-writing.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��H��J1dk����");
INSERT INTO `arc1542_wfFileMods` VALUES("��ĸ:�,p�1��Hr","wp-admin/js/dashboard.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-O�U���n����]");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��וoxi3%+]kg","wp-admin/images/post-formats.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���\0���%3���");
INSERT INTO `arc1542_wfFileMods` VALUES("�0�;�-,�A�Ey�","wp-includes/theme-compat/sidebar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">���\"}Wuo���.H");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�Oj\'�ŻD*ցV4","wp-cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����hc�����p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��q�82��v�&#M","wp-includes/js/tinymce/plugins/wpview/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I$;$���k6a���W}");
INSERT INTO `arc1542_wfFileMods` VALUES("���<kUJv%��1��","wp-includes/fonts/dashicons.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ez{�C7|�2�");
INSERT INTO `arc1542_wfFileMods` VALUES("�w����V���!�","wp-admin/includes/class-wp-ms-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����&��ʠ��|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("����zpKC�{\\>��","wp-admin/js/dashboard.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��>{�Y�m�wcZ��c");
INSERT INTO `arc1542_wfFileMods` VALUES("��\00��q�ĊNy)��","wp-includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�#���i�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��5?�- S�^H��","wp-admin/js/editor-expand.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\0�2���=��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��b\\��ɍ���","wp-admin/edit-form-advanced.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:���?�k�b6;��");
INSERT INTO `arc1542_wfFileMods` VALUES("�G��5�@����07��","wp-includes/images/blank.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H�+��51	��f]��9");
INSERT INTO `arc1542_wfFileMods` VALUES("��W���\"���Sk:�","wp-admin/images/align-center-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���-�r�5*J7�If");
INSERT INTO `arc1542_wfFileMods` VALUES("�⣣�M�O����U�","wp-admin/js/editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Aı��P��������");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"�ơ���7vs+�","wp-admin/includes/class-pclzip.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","67(�C���ki��8�");
INSERT INTO `arc1542_wfFileMods` VALUES("�b`K�\'��컜���K","wp-includes/functions.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x?!�bc�Q��*B36n");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��ёe�Xd��$�","wp-includes/class-wp-customize-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��\'�x=e8Ժ�#");
INSERT INTO `arc1542_wfFileMods` VALUES("�l�XNEM�CgVsA:","wp-includes/js/swfupload/plugins/swfupload.queue.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�SR/�J��5�-v͏");
INSERT INTO `arc1542_wfFileMods` VALUES("���K�g���o#�0","wp-activate.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pUȪ�N�ੌ�{eG�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ŉ�	i����/Э","wp-includes/formatting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ƍn��~�O:� ");
INSERT INTO `arc1542_wfFileMods` VALUES("��H���l��{!D#�!","wp-admin/js/color-picker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}\"[}����P-�)");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�ZY��C8��3E","wp-admin/css/colors/blue/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ѱ�^pJ��G�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�%y�>}H�o���(6","wp-includes/js/jquery/ui/core.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," Ms����a���{");
INSERT INTO `arc1542_wfFileMods` VALUES("�f�i�`�=@T��o�","wp-admin/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES("�J���y��0m�`�/","wp-includes/class-IXR.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n�V�8��0�P\"yP_");
INSERT INTO `arc1542_wfFileMods` VALUES("�F�j!Y�{.J=,��","wp-admin/images/stars.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[����><�k�{��(�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�W/>�}<8� VF�","wp-admin/includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/��k�Tb�Kx�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�^.�jT}�<��I��","wp-admin/js/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ϡ�M\0���GÁ]��");
INSERT INTO `arc1542_wfFileMods` VALUES("�\' ��#s��߾U|","wp-includes/js/mediaelement/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�&��B\"o�!e���");
INSERT INTO `arc1542_wfFileMods` VALUES("頻�yN<���9�o<","wp-admin/js/xfn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�\'�(�.�J9^");
INSERT INTO `arc1542_wfFileMods` VALUES("��m�Mt���W�B","wp-admin/images/align-left.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�y0��d�Z�o.h��");
INSERT INTO `arc1542_wfFileMods` VALUES("����t���Z�O\'� 
","wp-includes/js/thickbox/macFFBgHack.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȱg�W�,/u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����V,E@�X���y","wp-includes/SimplePie/Cache/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=�@��B[	S�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4���2�)A.;4�","wp-includes/js/customize-preview.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","C2������,ھ");
INSERT INTO `arc1542_wfFileMods` VALUES("ꍥ��2jEbg؈W�x�","wp-includes/css/editor-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�o��\"�K��PzJ��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǉ���4˓T`�k","wp-includes/js/wp-pointer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6��|dMpX\0��fɐ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0���R�J�{y�ˣ��","wp-includes/general-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�G;Y=.����T1!");
INSERT INTO `arc1542_wfFileMods` VALUES("�F �8�+�)��r�P�","wp-admin/images/no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k�d�$��ܟV7���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Oӿ�;�=\\J�zy","wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)F.jT&����I�O");
INSERT INTO `arc1542_wfFileMods` VALUES("뭷�!z}ML�K�E","wp-includes/ms-files.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�yï�<�r �L�F|");
INSERT INTO `arc1542_wfFileMods` VALUES("��Sڰp��GMǯ�l�","wp-includes/css/media-views.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[52*�6���V�");
INSERT INTO `arc1542_wfFileMods` VALUES("��vA�ds�����K�]","wp-admin/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*�7m���=g�\"�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("��YC��o�oR�亞�","wp-includes/capabilities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�m/ؾ�G�}+�y��");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�ڧ��s}��ն�Ni","wp-includes/class-phpmailer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","BqO7W��vai4c");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�����h�����;","wp-includes/js/quicktags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��:<���T��ʭ");
INSERT INTO `arc1542_wfFileMods` VALUES("�Dh}�����!
","wp-includes/js/jquery/ui/effect-drop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W�V��ǥ�Y��F2��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Pط��悇̺ƴ$@�","wp-includes/SimplePie/HTTP/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W%���4�6���6	");
INSERT INTO `arc1542_wfFileMods` VALUES("��c��.D�r� |��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R����Z�?f.��8��	");
INSERT INTO `arc1542_wfFileMods` VALUES("츃�v��6��;�~�","wp-includes/js/tinymce/utils/mctabs.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x$��
d��,�P��");
INSERT INTO `arc1542_wfFileMods` VALUES("��-x�(�E�oI�=�","wp-includes/class-wp-customize-section.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!������	�pP~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]��@�
��>ĺ�Yn","wp-admin/admin-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"�l�E�)�E�A");
INSERT INTO `arc1542_wfFileMods` VALUES("��QR\"��@3��v�S","wp-admin/js/link.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��5ϳt�{��z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a�]]�A��\'h���","wp-admin/network/settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Y����{D=l�e");
INSERT INTO `arc1542_wfFileMods` VALUES("����=��c�ه���","wp-admin/includes/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'Ha3.}�S(��");
INSERT INTO `arc1542_wfFileMods` VALUES("���eC����Di!��","wp-admin/css/colors/coffee/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�yb)�O�](�a�r��z");
INSERT INTO `arc1542_wfFileMods` VALUES("���f�%u�P���","wp-includes/js/mce-view.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S���sM:��K��e");
INSERT INTO `arc1542_wfFileMods` VALUES("�D=Jǅ/	6ރa�","wp-includes/js/swfupload/plugins/swfupload.cookies.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~�ڈ�k\\ 7̴��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y^~5~��p�G-���","wp-includes/js/customize-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��%cݹ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�z�������|�z�xv","wp-includes/js/jquery/ui/droppable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\"q�H�d����~A�P");
INSERT INTO `arc1542_wfFileMods` VALUES("���P��a`Xu","wp-admin/css/color-picker-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[��q4G։��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��X=U�pfp���Z","wp-includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/���ِ��9J1");
INSERT INTO `arc1542_wfFileMods` VALUES("�㯩�	\'��ި��V","wp-includes/images/smilies/icon_biggrin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�YpR�+�0}k�N{�k");
INSERT INTO `arc1542_wfFileMods` VALUES("����9��r�Mԧ��","wp-includes/js/customize-preview-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q~���6�a���");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�ī�I�^��3���","wp-admin/menu-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w\"\0R�|YrI��ׂR�");
INSERT INTO `arc1542_wfFileMods` VALUES("�з&�L۽¨��VN�","wp-includes/css/buttons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I@�3�#������");
INSERT INTO `arc1542_wfFileMods` VALUES("�������6$[���O�","wp-admin/css/customize-widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�?�!�`���j��x");
INSERT INTO `arc1542_wfFileMods` VALUES("���rp.u�3zx�","wp-admin/includes/class-ftp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2V�u�\\I�L��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7s�\\]�}�AA�we1�","wp-admin/tools.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�8�.�g���_\\+U");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z/���{Lt�ծF$�","wp-admin/js/svg-painter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����/�|ĩ���z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?��E_�)�xڅ$��","wp-admin/includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f[A���˷xg�K");
INSERT INTO `arc1542_wfFileMods` VALUES("�po���X0%������","wp-includes/css/editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u�]X)�*��﬋��");
INSERT INTO `arc1542_wfFileMods` VALUES("��M�٦M�/`�","wp-includes/js/swfupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Oۅ��߲�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("򱠭��B�R�z��Y","wp-includes/js/jquery/jquery.table-hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�go����~i�I	�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?{o_���\'�n�","wp-admin/images/resize-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e?�&h.��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("���_f $�O<o","wp-admin/js/common.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�zv5�<s!� �");
INSERT INTO `arc1542_wfFileMods` VALUES("��%�\0��z�f�N�pS","wp-includes/js/tinymce/plugins/wpemoji/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y2\0׳���<�r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#\\���/�vXR","wp-admin/js/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��b���
]]��\"0");
INSERT INTO `arc1542_wfFileMods` VALUES("�lF����c뒕�L���","wp-admin/js/iris.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�5`�@Ħ�Ue߰�");
INSERT INTO `arc1542_wfFileMods` VALUES("��V��k9۴�s���ֿ","wp-admin/css/customize-controls-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]����m�`$�M");
INSERT INTO `arc1542_wfFileMods` VALUES("���;�^𩸴8c�","wp-includes/css/buttons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1R�1��!��\\=P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J\'#��rN�0a�","wp-includes/images/crystal/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�nV�:�ω�G��-#k");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y��R�Yi/��l@HX�","wp-includes/js/media-grid.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�R�G�zpȟ�n��K");
INSERT INTO `arc1542_wfFileMods` VALUES("��j�8���ď����","wp-includes/js/wp-backbone.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���S��Y�|�פ�j)p");
INSERT INTO `arc1542_wfFileMods` VALUES("�-\"D��ʹD�5a�/","wp-includes/cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b�.*�r�T:~�t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�A4e���{�^����Z","wp-includes/js/wpdialog.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r�9_�M@9\0�S�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�u�N���.A_�_�","wp-includes/js/media-editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ��w��\"Wl���c6");
INSERT INTO `arc1542_wfFileMods` VALUES("������>+ܞL[�m","wp-includes/js/tinymce/skins/lightgray/img/anchor.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a5q��ȑ_4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("����(���%�#�9yn","wp-admin/css/forms.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��VA�ϱ9x�pW");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y��\0�\"��Q","wp-admin/user/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)��»�g��E�p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~������r�C��","wp-admin/link-parse-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Dm����䁐�f�8��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V9��K���goX��7�","wp-admin/images/align-left-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","i�8�O�����^��c");
INSERT INTO `arc1542_wfFileMods` VALUES("������H�S!;� �","wp-admin/js/user-profile.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","j@#�wP<Pw��2�");
INSERT INTO `arc1542_wfFileMods` VALUES("���+���q�pW��","wp-includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_�W�\\F�D�$�,0");
INSERT INTO `arc1542_wfFileMods` VALUES("���`�&X<�aQ�Vh\\","wp-admin/user/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0yݤ�&-");
INSERT INTO `arc1542_wfFileMods` VALUES("����Pq-�t�@l�","wp-includes/images/wlw/wp-icon.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1	�ʚ�7w3K��*");
INSERT INTO `arc1542_wfFileMods` VALUES("� @�;��*��|��","wp-includes/Text/Diff/Engine/string.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^��x@�R�ƙ=���");
INSERT INTO `arc1542_wfFileMods` VALUES("�@���sB0<�{l�3��","wp-includes/wlwmanifest.xml","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ԑ����i�^��");
INSERT INTO `arc1542_wfFileMods` VALUES("�k����e<F��4","wp-admin/js/revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2S�l��R;�]2�Lj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��6K1���(���}/AX","wp-admin/network/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6�\'G��g$�");
INSERT INTO `arc1542_wfFileMods` VALUES("��H�Mz�@�A��","wp-admin/css/press-this-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">�Wɤeʂ�Ȳ�Oi");
INSERT INTO `arc1542_wfFileMods` VALUES("��ɱ%��a{Z�j	%�","wp-includes/class-wp-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�;~^$���w�");
INSERT INTO `arc1542_wfFileMods` VALUES("����I�:4P�U���","wp-includes/SimplePie/Cache/Memcache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��JU���1SQ��?�");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�l4[���e���","wp-admin/js/inline-edit-tax.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J����`$?\0=>�G���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��=��*�d��n�","wp-admin/includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�RI\"��u�}��[da");
INSERT INTO `arc1542_wfFileMods` VALUES("�.ն���Zg{�=��","wp-admin/css/customize-controls.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J�|`����(���4");
INSERT INTO `arc1542_wfFileMods` VALUES("���~��a%��!�P","wp-includes/js/tinymce/skins/wordpress/images/pagebreak-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�6�#UQ:��|>#��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����L?@��.~O�","wp-admin/css/colors/midnight/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s���^�r\'\'8��n�I");
INSERT INTO `arc1542_wfFileMods` VALUES("����T
����e.(��","wp-includes/class-wp-image-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:T��Xd�L��ܕg");
INSERT INTO `arc1542_wfFileMods` VALUES("��}���PÛ�P\\�","wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL��	�gS\'����i");
INSERT INTO `arc1542_wfFileMods` VALUES("��R�,�A����GJ\'-","wp-includes/default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",}�\'�!��J�v�");
INSERT INTO `arc1542_wfFileMods` VALUES("���
\\��ɶ.5���","wp-includes/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("�D����]�|߼�$�","wp-includes/js/mediaelement/wp-mediaelement.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8؟\"{�պ��u�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ph�����rV�","wp-admin/css/revisions-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2����.�ĕx`x�a*");
INSERT INTO `arc1542_wfFileMods` VALUES("�\'������}����0","wp-includes/js/tinymce/wp-tinymce.js.gz","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5
Cx��^��-`");
INSERT INTO `arc1542_wfFileMods` VALUES("�])��	���{�?R}","wp-includes/feed-rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�kY���>�]DtH/");
INSERT INTO `arc1542_wfFileMods` VALUES("�0<Ps��מH���22","wp-includes/js/jquery/jquery.table-hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��֔#t�gP�g��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9(F�Rj2�n6]��","wp-admin/css/colors/light/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Cxڄx43�*Cn��/y");
INSERT INTO `arc1542_wfFileMods` VALUES("�g�\"�}_�7����J5","wp-includes/js/jcrop/jquery.Jcrop.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V̞��/K�x����");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��9�6è�R�","wp-admin/css/common.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iB���D�&�8Y���");
INSERT INTO `arc1542_wfFileMods` VALUES("�����ƪq�悳��","wp-includes/js/tinymce/plugins/paste/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�BU@��8�<ba");
INSERT INTO `arc1542_wfFileMods` VALUES("��<l�a��,�bX,��","wp-admin/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("�G���!#h�9	��&","wp-includes/js/tinymce/plugins/wordpress/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6B���û�yם");
INSERT INTO `arc1542_wfFileMods` VALUES("���\'�B���7S�","wp-includes/js/zxcvbn-async.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0�V]u#3");
INSERT INTO `arc1542_wfFileMods` VALUES("������)�(��<��","wp-includes/js/json2.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�A��`� �ȡ�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a��\'@T瑓����","wp-admin/images/date-button.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��I��V�ď�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����)z]!?��a�","wp-admin/images/media-button-video.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������r�x�4Q���");
INSERT INTO `arc1542_wfFileMods` VALUES("�I\"�p��t�Q��[Z6x","wp-includes/css/admin-bar.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mk�x�Hk�1q�W�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c��wk�(���4�3�","wp-admin/includes/list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����T8��>��_߂");
INSERT INTO `arc1542_wfFileMods` VALUES("�Qֿ6��yq�88","wp-includes/theme-compat/footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ~C~�M������=");
INSERT INTO `arc1542_wfFileMods` VALUES("���w��\'�6)","wp-includes/rss-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","g�����l]�4j0l=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�L����e5x?e=�&","wp-includes/js/plupload/wp-plupload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�y�,lf@�@");
INSERT INTO `arc1542_wfFileMods` VALUES("��a5[4�5�Me�pC","wp-includes/js/jquery/ui/effect-bounce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ؖ�0TQ�5����S");
INSERT INTO `arc1542_wfFileMods` VALUES("���T����Ç=w���","wp-admin/js/bookmarklet.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y��ἿvoFg\"��k");
INSERT INTO `arc1542_wfFileMods` VALUES("��S�CRC��l��","wp-admin/css/colors/sunrise/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V���z�	h���=�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k��i��.���\\��","wp-includes/images/smilies/icon_neutral.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������	����Z�");


DROP TABLE IF EXISTS `arc1542_wfHits`;

CREATE TABLE `arc1542_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `is404` tinyint(4) NOT NULL,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfHoover`;

CREATE TABLE `arc1542_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` binary(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfIssues`;

CREATE TABLE `arc1542_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfIssues` VALUES("1","1438996075","new","wfPluginUpgrade","1","70ba4ebbe4ca61e940ed6d0fd4b510dd","70ba4ebbe4ca61e940ed6d0fd4b510dd","The Plugin \"iThemes Security\" needs an upgrade.","You need to upgrade \"iThemes Security\" to the newest version to ensure you have any security fixes the developer has released.","a:13:{s:4:\"Name\";s:16:\"iThemes Security\";s:9:\"PluginURI\";s:28:\"https://ithemes.com/security\";s:7:\"Version\";s:5:\"4.8.0\";s:11:\"Description\";s:239:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting attack attempts and more. <cite>By <a href=\"https://ithemes.com\">iThemes.com</a>.</cite>\";s:6:\"Author\";s:45:\"<a href=\"https://ithemes.com\">iThemes.com</a>\";s:9:\"AuthorURI\";s:19:\"https://ithemes.com\";s:10:\"TextDomain\";s:26:\"it-l10n-better-wp-security\";s:10:\"DomainPath\";s:10:\"/languages\";s:7:\"Network\";b:1;s:5:\"Title\";s:59:\"<a href=\"https://ithemes.com/security\">iThemes Security</a>\";s:10:\"AuthorName\";s:11:\"iThemes.com\";s:10:\"pluginFile\";s:86:\"/Users/ahayter/Sites/test/arc-assets/plugins/better-wp-security/better-wp-security.php\";s:10:\"newVersion\";s:5:\"4.9.0\";}");


DROP TABLE IF EXISTS `arc1542_wfLeechers`;

CREATE TABLE `arc1542_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfLockedOut`;

CREATE TABLE `arc1542_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfLocs`;

CREATE TABLE `arc1542_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfLocs` VALUES("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1438996596","1","","","","","0.0000000","0.0000000");


DROP TABLE IF EXISTS `arc1542_wfLogins`;

CREATE TABLE `arc1542_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfLogins` VALUES("1","1437026046.617100","0","loginOK","ahayter","2","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36");
INSERT INTO `arc1542_wfLogins` VALUES("2","1438996596.023176","0","loginOK","ahayter","2","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.125 Safari/537.36");


DROP TABLE IF EXISTS `arc1542_wfNet404s`;

CREATE TABLE `arc1542_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfReverseCache`;

CREATE TABLE `arc1542_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arc1542_wfReverseCache` VALUES("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","localhost","1438996596");


DROP TABLE IF EXISTS `arc1542_wfScanners`;

CREATE TABLE `arc1542_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfStatus`;

CREATE TABLE `arc1542_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=267 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfStatus` VALUES("1","1434399538.055669","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("2","1434399538.059547","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("3","1434399540.061248","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("4","1434399542.064531","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("5","1434399544.068995","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("6","1434399546.073104","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("7","1434399546.076709","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("8","1434399547.096744","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("9","1434399547.101950","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("10","1434399547.103554","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("11","1434399547.105148","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("12","1434399547.108786","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("13","1434399549.944095","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("14","1434399549.948542","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("15","1434399554.640653","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("16","1434399554.644697","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("17","1434399554.645044","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("18","1434399554.645342","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("19","1434399554.647089","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("20","1434399555.746919","2","info","Analyzed 100 files containing 1.1 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("21","1434399555.941838","2","info","Analyzed 200 files containing 2.25 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("22","1434399556.219059","2","info","Analyzed 300 files containing 4.41 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("23","1434399556.371454","2","info","Analyzed 400 files containing 5.03 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("24","1434399556.568863","2","info","Analyzed 500 files containing 6.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("25","1434399556.822304","2","info","Analyzed 600 files containing 9.75 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("26","1434399556.935451","2","info","Analyzed 700 files containing 10.05 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("27","1434399557.110897","2","info","Analyzed 800 files containing 11.57 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("28","1434399557.259347","2","info","Analyzed 900 files containing 12.63 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("29","1434399557.482302","2","info","Analyzed 1000 files containing 15.47 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("30","1434399557.492406","2","info","Analyzed 1007 files containing 15.56 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("31","1434399557.493069","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("32","1434399557.494961","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("33","1434399557.516416","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("34","1434399557.518823","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("35","1434399557.623882","2","error","Scan terminated with error: There was an error connecting to the the Wordfence scanning servers: Failed to connect to noc1.wordfence.com port 443: Connection refused");
INSERT INTO `arc1542_wfStatus` VALUES("36","1434399557.624289","10","info","SUM_KILLED:Previous scan terminated with an error. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("37","1437026033.654710","1","info","Scheduled Wordfence scan starting at Thursday 16th of July 2015 01:53:53 AM");
INSERT INTO `arc1542_wfStatus` VALUES("38","1437026034.563137","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("39","1437026034.568249","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("40","1437026036.570460","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("41","1437026038.574119","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("42","1437026040.581354","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("43","1437026041.172146","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("44","1437026041.176124","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("45","1437026041.606124","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("46","1437026041.612177","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("47","1437026041.614592","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("48","1437026041.616585","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("49","1437026041.628367","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("50","1437026042.263976","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("51","1437026042.267244","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("52","1437026043.176870","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("53","1437026043.182201","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("54","1437026043.182659","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("55","1437026043.183025","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("56","1437026043.184780","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("57","1437026043.555045","2","info","Analyzed 100 files containing 8.65 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("58","1437026043.693428","2","info","Analyzed 200 files containing 9.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("59","1437026043.901311","2","info","Analyzed 300 files containing 11.98 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("60","1437026044.037007","2","info","Analyzed 400 files containing 12.58 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("61","1437026044.253772","2","info","Analyzed 500 files containing 14.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("62","1437026044.525427","2","info","Analyzed 600 files containing 17.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("63","1437026044.659289","2","info","Analyzed 700 files containing 17.62 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("64","1437026044.838869","2","info","Analyzed 800 files containing 19.14 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("65","1437026045.043948","2","info","Analyzed 900 files containing 20.2 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("66","1437026045.332099","2","info","Analyzed 1000 files containing 23.04 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("67","1437026045.351588","2","info","Analyzed 1008 files containing 23.13 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("68","1437026045.352340","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("69","1437026045.354147","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("70","1437026045.373559","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("71","1437026045.375937","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("72","1437026045.812382","2","info","Starting scan of file contents");
INSERT INTO `arc1542_wfStatus` VALUES("73","1437026046.858738","2","info","Scanned contents of 1 additional files at 0.96 per second");
INSERT INTO `arc1542_wfStatus` VALUES("74","1437026046.875259","2","info","Scanned contents of 4 additional files at 3.77 per second");
INSERT INTO `arc1542_wfStatus` VALUES("75","1437026046.875813","2","info","Asking Wordfence to check URL\'s against malware list.");
INSERT INTO `arc1542_wfStatus` VALUES("76","1437026046.876607","2","info","Checking 3 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("77","1437026047.293976","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("78","1437026047.295815","2","info","Done file contents scan");
INSERT INTO `arc1542_wfStatus` VALUES("79","1437026047.296621","10","info","SUM_ENDOK:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("80","1437026047.298471","10","info","SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("81","1437026047.301768","10","info","SUM_START:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("82","1437026047.733355","2","info","Starting scan of database");
INSERT INTO `arc1542_wfStatus` VALUES("83","1437026048.743311","2","info","Done database scan");
INSERT INTO `arc1542_wfStatus` VALUES("84","1437026048.744654","10","info","SUM_ENDOK:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("85","1437026048.747999","10","info","SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("86","1437026048.751548","2","info","Examining URLs found in posts we scanned for dangerous websites");
INSERT INTO `arc1542_wfStatus` VALUES("87","1437026048.752177","2","info","Done examining URLs");
INSERT INTO `arc1542_wfStatus` VALUES("88","1437026048.753778","10","info","SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("89","1437026048.758344","10","info","SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("90","1437026048.761594","2","info","Checking 1 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("91","1437026049.190769","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("92","1437026049.196518","10","info","SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("93","1437026049.200594","10","info","SUM_START:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("94","1437026049.201485","2","info","Starting password strength check on 1 users.");
INSERT INTO `arc1542_wfStatus` VALUES("95","1437026049.226990","10","info","SUM_ENDOK:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("96","1437026049.230671","10","info","SUM_START:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("97","1437026049.231348","2","info","Starting DNS scan for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("98","1437026049.319034","2","info","Scanning DNS A record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("99","1437026049.345831","2","info","Scanning DNS MX record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("100","1437026049.348638","10","info","SUM_ENDOK:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("101","1437026049.352585","10","info","SUM_START:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("102","1437026049.353259","2","info","Total disk space: 231.7394GB -- Free disk space: 22.7601GB");
INSERT INTO `arc1542_wfStatus` VALUES("103","1437026049.353714","2","info","The disk has 23306.36 MB space available");
INSERT INTO `arc1542_wfStatus` VALUES("104","1437026049.354505","10","info","SUM_ENDOK:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("105","1437026049.357546","10","info","SUM_START:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("106","1437026049.705358","10","info","SUM_ENDBAD:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("107","1437026049.722632","1","info","-------------------");
INSERT INTO `arc1542_wfStatus` VALUES("108","1437026049.723149","1","info","Scan Complete. Scanned 1008 files, 3 plugins, 1 themes, 2 pages, 1 comments and 1431 records in 15 seconds.");
INSERT INTO `arc1542_wfStatus` VALUES("109","1437026049.723630","10","info","SUM_FINAL:Scan complete. You have 3 new issues to fix. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("110","1437026049.771163","2","info","Wordfence used 11.38MB of memory for scan. Server peak memory usage was: 39.28MB");
INSERT INTO `arc1542_wfStatus` VALUES("111","1438100712.203064","1","info","Scheduled Wordfence scan starting at Tuesday 28th of July 2015 12:25:12 PM");
INSERT INTO `arc1542_wfStatus` VALUES("112","1438100713.203667","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("113","1438100713.208969","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("114","1438100715.210365","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("115","1438100717.212174","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("116","1438100719.219853","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("117","1438100719.230455","2","error","Scan terminated with error: There was an error connecting to the the Wordfence scanning servers: Couldn\'t resolve host \'noc1.wordfence.com\'");
INSERT INTO `arc1542_wfStatus` VALUES("118","1438100719.230977","10","info","SUM_KILLED:Previous scan terminated with an error. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("119","1438535883.982606","1","info","Scheduled Wordfence scan starting at Sunday 2nd of August 2015 01:18:03 PM");
INSERT INTO `arc1542_wfStatus` VALUES("120","1438535885.845517","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("121","1438535885.855127","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("122","1438535887.856830","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("123","1438535889.859586","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("124","1438535891.868250","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("125","1438535892.431462","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("126","1438535892.436182","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("127","1438535892.881959","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("128","1438535892.887872","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("129","1438535892.891073","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("130","1438535892.894521","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("131","1438535892.909868","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("132","1438535893.550930","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("133","1438535893.557479","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("134","1438535894.534706","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("135","1438535894.545402","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("136","1438535894.546668","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("137","1438535894.547900","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("138","1438535894.552708","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("139","1438535895.117200","2","info","Analyzed 100 files containing 8.66 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("140","1438535895.428123","2","info","Analyzed 200 files containing 9.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("141","1438535895.846942","2","info","Analyzed 300 files containing 11.98 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("142","1438535896.111515","2","info","Analyzed 400 files containing 12.59 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("143","1438535896.446791","2","info","Analyzed 500 files containing 14.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("144","1438535896.807946","2","info","Analyzed 600 files containing 17.31 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("145","1438535897.003233","2","info","Analyzed 700 files containing 17.63 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("146","1438535897.264308","2","info","Analyzed 800 files containing 19.14 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("147","1438535897.506470","2","info","Analyzed 900 files containing 20.21 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("148","1438535897.825744","2","info","Analyzed 1000 files containing 23.06 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("149","1438535897.850429","2","info","Analyzed 1008 files containing 23.15 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("150","1438535897.852218","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("151","1438535897.856677","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("152","1438535897.883850","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("153","1438535897.887462","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("154","1438535898.314691","2","info","Starting scan of file contents");
INSERT INTO `arc1542_wfStatus` VALUES("155","1438535899.396342","2","info","Scanned contents of 1 additional files at 0.93 per second");
INSERT INTO `arc1542_wfStatus` VALUES("156","1438535899.419805","2","info","Scanned contents of 4 additional files at 3.62 per second");
INSERT INTO `arc1542_wfStatus` VALUES("157","1438535899.420687","2","info","Asking Wordfence to check URL\'s against malware list.");
INSERT INTO `arc1542_wfStatus` VALUES("158","1438535899.422160","2","info","Checking 3 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("159","1438535899.845461","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("160","1438535899.850538","2","info","Done file contents scan");
INSERT INTO `arc1542_wfStatus` VALUES("161","1438535899.852195","10","info","SUM_ENDOK:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("162","1438535899.856181","10","info","SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("163","1438535899.862496","10","info","SUM_START:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("164","1438535900.290769","2","info","Starting scan of database");
INSERT INTO `arc1542_wfStatus` VALUES("165","1438535900.563152","2","info","Done database scan");
INSERT INTO `arc1542_wfStatus` VALUES("166","1438535900.566442","10","info","SUM_ENDOK:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("167","1438535900.571422","10","info","SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("168","1438535900.575560","2","info","Examining URLs found in posts we scanned for dangerous websites");
INSERT INTO `arc1542_wfStatus` VALUES("169","1438535900.576619","2","info","Done examining URLs");
INSERT INTO `arc1542_wfStatus` VALUES("170","1438535900.579686","10","info","SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("171","1438535900.585960","10","info","SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("172","1438535900.591681","2","info","Checking 1 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("173","1438535901.022148","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("174","1438535901.028642","10","info","SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("175","1438535903.347298","10","info","SUM_START:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("176","1438535903.349413","2","info","Starting password strength check on 1 users.");
INSERT INTO `arc1542_wfStatus` VALUES("177","1438535903.454506","10","info","SUM_ENDOK:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("178","1438535903.464571","10","info","SUM_START:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("179","1438535903.467017","2","info","Starting DNS scan for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("180","1438535903.591345","2","info","Scanning DNS A record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("181","1438535903.619947","2","info","Scanning DNS MX record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("182","1438535903.626395","10","info","SUM_ENDOK:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("183","1438535903.638834","10","info","SUM_START:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("184","1438535903.640905","2","info","Total disk space: 231.7394GB -- Free disk space: 20.2572GB");
INSERT INTO `arc1542_wfStatus` VALUES("185","1438535903.642426","2","info","The disk has 20743.38 MB space available");
INSERT INTO `arc1542_wfStatus` VALUES("186","1438535903.644738","10","info","SUM_ENDOK:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("187","1438535903.654668","10","info","SUM_START:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("188","1438535904.013708","10","info","SUM_ENDOK:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("189","1438535904.041920","1","info","-------------------");
INSERT INTO `arc1542_wfStatus` VALUES("190","1438535904.042714","1","info","Scan Complete. Scanned 1008 files, 3 plugins, 1 themes, 2 pages, 1 comments and 1527 records in 19 seconds.");
INSERT INTO `arc1542_wfStatus` VALUES("191","1438535904.043558","10","info","SUM_FINAL:Scan complete. Congratulations, no problems found.");
INSERT INTO `arc1542_wfStatus` VALUES("192","1438535904.050552","2","info","Wordfence used 11.48MB of memory for scan. Server peak memory usage was: 39.28MB");
INSERT INTO `arc1542_wfStatus` VALUES("193","1438996048.611813","1","info","Scheduled Wordfence scan starting at Friday 7th of August 2015 09:07:28 PM");
INSERT INTO `arc1542_wfStatus` VALUES("194","1438996049.922793","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("195","1438996049.935095","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("196","1438996051.938291","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("197","1438996053.942613","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("198","1438996055.948285","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("199","1438996056.668134","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("200","1438996056.671103","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("201","1438996057.179255","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("202","1438996057.187331","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("203","1438996057.190933","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("204","1438996057.194136","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("205","1438996057.213012","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("206","1438996057.986068","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("207","1438996057.993113","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("208","1438996064.024596","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("209","1438996064.030550","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("210","1438996064.031332","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("211","1438996064.032060","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("212","1438996064.035388","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("213","1438996064.483784","2","info","Analyzed 100 files containing 8.66 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("214","1438996064.687026","2","info","Analyzed 200 files containing 9.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("215","1438996064.978404","2","info","Analyzed 300 files containing 11.98 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("216","1438996065.169153","2","info","Analyzed 400 files containing 12.59 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("217","1438996065.447227","2","info","Analyzed 500 files containing 14.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("218","1438996065.765747","2","info","Analyzed 600 files containing 17.31 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("219","1438996065.937865","2","info","Analyzed 700 files containing 17.63 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("220","1438996066.176240","2","info","Analyzed 800 files containing 19.15 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("221","1438996066.388045","2","info","Analyzed 900 files containing 20.21 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("222","1438996066.694527","2","info","Analyzed 1000 files containing 23.06 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("223","1438996066.713376","2","info","Analyzed 1008 files containing 23.15 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("224","1438996066.714721","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("225","1438996066.718073","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("226","1438996069.140853","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("227","1438996069.143591","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("228","1438996069.681490","2","info","Starting scan of file contents");
INSERT INTO `arc1542_wfStatus` VALUES("229","1438996070.726209","2","info","Scanned contents of 1 additional files at 0.96 per second");
INSERT INTO `arc1542_wfStatus` VALUES("230","1438996070.743836","2","info","Scanned contents of 4 additional files at 3.78 per second");
INSERT INTO `arc1542_wfStatus` VALUES("231","1438996070.744500","2","info","Asking Wordfence to check URL\'s against malware list.");
INSERT INTO `arc1542_wfStatus` VALUES("232","1438996070.745605","2","info","Checking 3 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("233","1438996071.543117","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("234","1438996071.545675","2","info","Done file contents scan");
INSERT INTO `arc1542_wfStatus` VALUES("235","1438996071.547122","10","info","SUM_ENDOK:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("236","1438996071.550164","10","info","SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("237","1438996071.555118","10","info","SUM_START:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("238","1438996074.405017","2","info","Starting scan of database");
INSERT INTO `arc1542_wfStatus` VALUES("239","1438996074.689605","2","info","Done database scan");
INSERT INTO `arc1542_wfStatus` VALUES("240","1438996074.693360","10","info","SUM_ENDOK:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("241","1438996074.698122","10","info","SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("242","1438996074.702414","2","info","Examining URLs found in posts we scanned for dangerous websites");
INSERT INTO `arc1542_wfStatus` VALUES("243","1438996074.703470","2","info","Done examining URLs");
INSERT INTO `arc1542_wfStatus` VALUES("244","1438996074.705803","10","info","SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("245","1438996074.710490","10","info","SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("246","1438996074.715158","2","info","Checking 1 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("247","1438996075.235583","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("248","1438996075.238381","10","info","SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("249","1438996075.243315","10","info","SUM_START:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("250","1438996075.244368","2","info","Starting password strength check on 1 users.");
INSERT INTO `arc1542_wfStatus` VALUES("251","1438996075.273888","10","info","SUM_ENDOK:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("252","1438996075.279401","10","info","SUM_START:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("253","1438996075.280726","2","info","Starting DNS scan for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("254","1438996075.374998","2","info","Scanning DNS A record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("255","1438996075.415236","2","info","Scanning DNS MX record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("256","1438996075.418118","10","info","SUM_ENDOK:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("257","1438996075.423627","10","info","SUM_START:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("258","1438996075.424984","2","info","Total disk space: 231.7394GB -- Free disk space: 19.1400GB");
INSERT INTO `arc1542_wfStatus` VALUES("259","1438996075.425722","2","info","The disk has 19599.38 MB space available");
INSERT INTO `arc1542_wfStatus` VALUES("260","1438996075.426972","10","info","SUM_ENDOK:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("261","1438996075.431965","10","info","SUM_START:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("262","1438996075.793291","10","info","SUM_ENDBAD:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("263","1438996075.819476","1","info","-------------------");
INSERT INTO `arc1542_wfStatus` VALUES("264","1438996075.820466","1","info","Scan Complete. Scanned 1008 files, 3 plugins, 1 themes, 2 pages, 1 comments and 1607 records in 26 seconds.");
INSERT INTO `arc1542_wfStatus` VALUES("265","1438996075.821296","10","info","SUM_FINAL:Scan complete. You have 1 new issues to fix. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("266","1438996075.864330","2","info","Wordfence used 11.48MB of memory for scan. Server peak memory usage was: 39.28MB");


DROP TABLE IF EXISTS `arc1542_wfThrottleLog`;

CREATE TABLE `arc1542_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfVulnScanners`;

CREATE TABLE `arc1542_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





