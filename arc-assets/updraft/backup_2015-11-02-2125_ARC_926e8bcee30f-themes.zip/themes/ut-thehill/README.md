![Screenshot](screenshot.png "Screenshot")

# The 2015 UT WordPress Theme (The Hill)

***

Version: 1.0.3
Updated: Sept 18, 2015
- A few updates for accessiblity in the JS and CSS.
- Bug fix on the search form in the HTML templates.
- The WordPress theme updated to accomodate changes in WordPress 4.3.
- Various other rendering bugs fixed.
***

Version: 1.0.2
Updated: August 3, 2015
- Alignment issues on a handful of interface elements.
- New minifying CSS functionality. (For gulp/sass)
- Jquery CDN cahgned for Chinese compatiblitly (China blocks google)

***

Version: 1.0.1
Updated: July 1, 2015
- Menu bug fixes
- Resizing the screen flash fixes
- Parent Unit functionality change
- Various other bugs squashed

***

Version: 1.0
Updated: June 8, 2015

