<div class="hmbkp-upsell">

	<span><?php esc_html_e( 'Backup to', 'backupwordpress' ); ?></span>&nbsp;

	<span class="hmbkp-upsell-sep">
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-dropbox/">Dropbox</a> | 
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-google-drive/">Google Drive</a> | 
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-amazon-s3/">Amazon S3</a> | 
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-ftp/">FTP</a> | 
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-rackspace-cloud/">Rackspace Cloud</a> |
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-windows-azure/">Windows Azure</a> | 
		<a target="_blank" href="http://bwp.hmn.md/downloads/backupwordpress-to-dreamobjects/">DreamObjects</a>
	</span>&nbsp;

<?php

printf(
	__( '%1$sor buy the %2$sDeveloper Bundle%3$s now for only &dollar;99 (all Destinations &amp; Unlimited Sites)%4$s', 'backupwordpress' ),
	'<span>',
	'<a target="_blank" href="https://bwp.hmn.md/checkout?edd_action=add_to_cart&download_id=36">',
	'</a>',
	'</span>'
);

?>
</div>