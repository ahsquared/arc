<?php
/* Wordfence temporary file security header */
echo "Nothing to see here!\n"; exit(0);
?>a:11:{s:9:"cacheType";s:6:"falcon";s:17:"allowHTTPSCaching";s:1:"0";s:15:"firewallEnabled";s:1:"1";s:6:"apiKey";s:128:"db0301f529f254dbf9220171caf7ddd101ee22964ad7cd38e529908964a2239b77621a5354eba6cd87e15b40cce0d2013dc4d1933782fba373cf1551df12afda";s:9:"howGetIPs";s:0:"";s:18:"liveTrafficEnabled";s:1:"1";s:17:"actUpdateInterval";s:0:"";s:7:"debugOn";s:1:"0";s:10:"tourClosed";s:1:"1";s:13:"welcomeClosed";s:1:"1";s:11:"other_WFNet";s:1:"1";}