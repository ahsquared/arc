<?php



add_filter('the_content', 'bs_fix_shortcodes');




?>