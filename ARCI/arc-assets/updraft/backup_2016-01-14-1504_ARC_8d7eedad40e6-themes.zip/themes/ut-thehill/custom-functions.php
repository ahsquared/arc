<?php

//===================================================================================================================
// If you are modifying the theme and need to write your own functions, write them here. This will make updating your theme easier.
//===================================================================================================================
