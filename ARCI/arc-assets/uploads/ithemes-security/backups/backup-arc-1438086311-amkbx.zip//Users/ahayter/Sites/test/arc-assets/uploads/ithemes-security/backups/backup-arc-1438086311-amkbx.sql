DROP TABLE IF EXISTS `arc1542_commentmeta`;

CREATE TABLE `arc1542_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_comments`;

CREATE TABLE `arc1542_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_comments` VALUES("1","1","Mr WordPress","","https://wordpress.org/","","2015-06-15 19:42:40","2015-06-15 19:42:40","Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.","0","1","","","0","0");


DROP TABLE IF EXISTS `arc1542_itsec_lockouts`;

CREATE TABLE `arc1542_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_log`;

CREATE TABLE `arc1542_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_temp`;

CREATE TABLE `arc1542_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_links`;

CREATE TABLE `arc1542_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_options`;

CREATE TABLE `arc1542_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=269 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_options` VALUES("1","siteurl","http://test.dev","yes");
INSERT INTO `arc1542_options` VALUES("2","home","http://test.dev","yes");
INSERT INTO `arc1542_options` VALUES("3","blogname","ARC","yes");
INSERT INTO `arc1542_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `arc1542_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `arc1542_options` VALUES("6","admin_email","andre.hayter@gmail.com","yes");
INSERT INTO `arc1542_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `arc1542_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `arc1542_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `arc1542_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `arc1542_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `arc1542_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `arc1542_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `arc1542_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `arc1542_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `arc1542_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `arc1542_options` VALUES("18","default_category","1","yes");
INSERT INTO `arc1542_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `arc1542_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `arc1542_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `arc1542_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `arc1542_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `arc1542_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `arc1542_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `arc1542_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `arc1542_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `arc1542_options` VALUES("29","gzipcompression","0","yes");
INSERT INTO `arc1542_options` VALUES("30","hack_file","0","yes");
INSERT INTO `arc1542_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `arc1542_options` VALUES("32","moderation_keys","","no");
INSERT INTO `arc1542_options` VALUES("33","active_plugins","a:2:{i:0;s:41:\"better-wp-security/better-wp-security.php\";i:1;s:23:\"wordfence/wordfence.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("34","category_base","","yes");
INSERT INTO `arc1542_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `arc1542_options` VALUES("36","advanced_edit","0","yes");
INSERT INTO `arc1542_options` VALUES("37","comment_max_links","2","yes");
INSERT INTO `arc1542_options` VALUES("38","gmt_offset","","yes");
INSERT INTO `arc1542_options` VALUES("39","default_email_category","1","yes");
INSERT INTO `arc1542_options` VALUES("40","recently_edited","","no");
INSERT INTO `arc1542_options` VALUES("41","template","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("42","stylesheet","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("43","comment_whitelist","1","yes");
INSERT INTO `arc1542_options` VALUES("44","blacklist_keys","","no");
INSERT INTO `arc1542_options` VALUES("45","comment_registration","0","yes");
INSERT INTO `arc1542_options` VALUES("46","html_type","text/html","yes");
INSERT INTO `arc1542_options` VALUES("47","use_trackback","0","yes");
INSERT INTO `arc1542_options` VALUES("48","default_role","subscriber","yes");
INSERT INTO `arc1542_options` VALUES("49","db_version","31535","yes");
INSERT INTO `arc1542_options` VALUES("50","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `arc1542_options` VALUES("51","upload_path","","yes");
INSERT INTO `arc1542_options` VALUES("52","blog_public","0","yes");
INSERT INTO `arc1542_options` VALUES("53","default_link_category","2","yes");
INSERT INTO `arc1542_options` VALUES("54","show_on_front","posts","yes");
INSERT INTO `arc1542_options` VALUES("55","tag_base","","yes");
INSERT INTO `arc1542_options` VALUES("56","show_avatars","1","yes");
INSERT INTO `arc1542_options` VALUES("57","avatar_rating","G","yes");
INSERT INTO `arc1542_options` VALUES("58","upload_url_path","","yes");
INSERT INTO `arc1542_options` VALUES("59","thumbnail_size_w","150","yes");
INSERT INTO `arc1542_options` VALUES("60","thumbnail_size_h","150","yes");
INSERT INTO `arc1542_options` VALUES("61","thumbnail_crop","1","yes");
INSERT INTO `arc1542_options` VALUES("62","medium_size_w","300","yes");
INSERT INTO `arc1542_options` VALUES("63","medium_size_h","300","yes");
INSERT INTO `arc1542_options` VALUES("64","avatar_default","mystery","yes");
INSERT INTO `arc1542_options` VALUES("65","large_size_w","1024","yes");
INSERT INTO `arc1542_options` VALUES("66","large_size_h","1024","yes");
INSERT INTO `arc1542_options` VALUES("67","image_default_link_type","file","yes");
INSERT INTO `arc1542_options` VALUES("68","image_default_size","","yes");
INSERT INTO `arc1542_options` VALUES("69","image_default_align","","yes");
INSERT INTO `arc1542_options` VALUES("70","close_comments_for_old_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("71","close_comments_days_old","14","yes");
INSERT INTO `arc1542_options` VALUES("72","thread_comments","1","yes");
INSERT INTO `arc1542_options` VALUES("73","thread_comments_depth","5","yes");
INSERT INTO `arc1542_options` VALUES("74","page_comments","0","yes");
INSERT INTO `arc1542_options` VALUES("75","comments_per_page","50","yes");
INSERT INTO `arc1542_options` VALUES("76","default_comments_page","newest","yes");
INSERT INTO `arc1542_options` VALUES("77","comment_order","asc","yes");
INSERT INTO `arc1542_options` VALUES("78","sticky_posts","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("79","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("80","widget_text","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("81","widget_rss","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("82","uninstall_plugins","a:1:{s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:12:\"on_uninstall\";}}","no");
INSERT INTO `arc1542_options` VALUES("83","timezone_string","America/New_York","yes");
INSERT INTO `arc1542_options` VALUES("84","page_for_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("85","page_on_front","0","yes");
INSERT INTO `arc1542_options` VALUES("86","default_post_format","0","yes");
INSERT INTO `arc1542_options` VALUES("87","link_manager_enabled","0","yes");
INSERT INTO `arc1542_options` VALUES("88","initial_db_version","31535","yes");
INSERT INTO `arc1542_options` VALUES("89","arc1542_user_roles","a:6:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"UT_site_admin\";a:2:{s:4:\"name\";s:13:\"UT Site Admin\";s:12:\"capabilities\";a:39:{s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_pages\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_pages\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:18:\"edit_theme_options\";b:1;s:24:\"gravityforms_create_form\";b:1;s:27:\"gravityforms_delete_entries\";b:1;s:25:\"gravityforms_delete_forms\";b:1;s:25:\"gravityforms_edit_entries\";b:1;s:29:\"gravityforms_edit_entry_notes\";b:1;s:23:\"gravityforms_edit_forms\";b:1;s:27:\"gravityforms_export_entries\";b:1;s:17:\"gravityforms_feed\";b:1;s:25:\"gravityforms_view_entries\";b:1;s:29:\"gravityforms_view_entry_notes\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"upload_files\";b:1;s:10:\"view_stats\";b:1;s:14:\"show_admin_bar\";b:1;}}}","yes");
INSERT INTO `arc1542_options` VALUES("90","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("91","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("92","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("93","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("94","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("95","sidebars_widgets","a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:11:\"sidebar-404\";N;s:9:\"sidebar-3\";N;s:9:\"sidebar-4\";N;s:9:\"sidebar-5\";N;s:9:\"sidebar-6\";N;s:9:\"sidebar-7\";N;s:9:\"sidebar-8\";N;s:9:\"sidebar-9\";N;s:13:\"array_version\";i:3;}","yes");
INSERT INTO `arc1542_options` VALUES("97","cron","a:17:{i:1437026329;a:1:{s:28:\"wordfence_update_blocked_IPs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437029806;a:1:{s:21:\"wordfence_hourly_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1437032560;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1437033180;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1437075878;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1437075934;a:2:{s:16:\"itsec_purge_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"itsec_purge_lockouts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1437101933;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437112605;a:1:{s:20:\"wordfence_daily_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1437112631;a:1:{s:26:\"wordfence_daily_autoUpdate\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1437184858;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437272664;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437360853;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437447132;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437532984;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1437619642;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1438027200;a:1:{s:31:\"wordfence_email_activity_report\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `arc1542_options` VALUES("99","rewrite_rules","a:59:{s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `arc1542_options` VALUES("101","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.2\";s:7:\"version\";s:5:\"4.2.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1437026030;s:15:\"version_checked\";s:5:\"4.2.2\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("106","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1437026048;s:7:\"checked\";a:1:{s:10:\"ut-thehill\";s:3:\"0.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("108","_transient_random_seed","22b6e54e338937dec91721d5fa9f8541","yes");
INSERT INTO `arc1542_options` VALUES("109","_site_transient_timeout_browser_3a9721c33f29438e21880b312d32e7bb","1435002173","yes");
INSERT INTO `arc1542_options` VALUES("110","_site_transient_browser_3a9721c33f29438e21880b312d32e7bb","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"43.0.2357.124\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("111","can_compress_scripts","1","yes");
INSERT INTO `arc1542_options` VALUES("128","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1434408279","yes");
INSERT INTO `arc1542_options` VALUES("129","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:40:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"5223\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3269\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3204\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"2734\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2503\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2001\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"1906\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"1836\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1787\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1769\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1738\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1728\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1621\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1419\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1357\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1299\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1207\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1165\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1150\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1021\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:3:\"975\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:3:\"942\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:3:\"932\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"896\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"865\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"853\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"806\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"791\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"767\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"743\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:3:\"738\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"736\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"695\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"687\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"682\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"669\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"649\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"645\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"640\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"639\";}}","yes");
INSERT INTO `arc1542_options` VALUES("134","itsec_data","a:5:{s:5:\"build\";i:4036;s:20:\"activation_timestamp\";i:1434397534;s:17:\"already_supported\";b:0;s:15:\"setup_completed\";b:1;s:18:\"tooltips_dismissed\";b:1;}","yes");
INSERT INTO `arc1542_options` VALUES("135","itsec_global","a:24:{s:11:\"write_files\";b:1;s:18:\"notification_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:12:\"digest_email\";b:1;s:12:\"backup_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:19:\"email_notifications\";b:1;s:8:\"log_type\";i:0;s:12:\"log_rotation\";i:14;s:12:\"log_location\";s:66:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/logs\";s:11:\"did_upgrade\";b:0;s:14:\"allow_tracking\";b:0;s:10:\"nginx_file\";s:36:\"/Users/ahayter/Sites/test/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:8:\"log_info\";s:13:\"arc-g8FzN7rLD\";s:9:\"lock_file\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("136","itsec_initials","a:3:{s:5:\"login\";b:0;s:5:\"admin\";b:0;s:11:\"file_editor\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("138","itsec_ipcheck","a:1:{s:7:\"api_ban\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("139","itsec_four_oh_four","a:5:{s:7:\"enabled\";b:1;s:12:\"check_period\";i:5;s:15:\"error_threshold\";i:20;s:10:\"white_list\";a:9:{i:0;s:12:\"/favicon.ico\";i:1;s:11:\"/robots.txt\";i:2;s:21:\"/apple-touch-icon.png\";i:3;s:33:\"/apple-touch-icon-precomposed.png\";i:4;s:17:\"/wp-content/cache\";i:5;s:18:\"/browserconfig.xml\";i:6;s:16:\"/crossdomain.xml\";i:7;s:11:\"/labels.rdf\";i:8;s:27:\"/trafficbasedsspsitemap.xml\";}s:5:\"types\";a:5:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".gif\";i:4;s:4:\".css\";}}","yes");
INSERT INTO `arc1542_options` VALUES("140","itsec_away_mode","a:4:{s:4:\"type\";i:1;s:7:\"enabled\";b:0;s:5:\"start\";i:1434412800;s:3:\"end\";i:1434520800;}","yes");
INSERT INTO `arc1542_options` VALUES("141","itsec_ban_users","a:4:{s:7:\"default\";b:1;s:7:\"enabled\";b:1;s:9:\"host_list\";a:46:{i:0;s:10:\"8.21.4.254\";i:1;s:15:\"65.46.48.192/30\";i:2;s:17:\"65.160.238.176/28\";i:3;s:14:\"85.92.222.0/24\";i:4;s:14:\"206.51.36.0/22\";i:5;s:14:\"216.52.23.0/24\";i:6;s:14:\"38.100.19.8/29\";i:7;s:14:\"38.100.21.0/24\";i:8;s:15:\"38.100.41.64/26\";i:9;s:14:\"38.105.71.0/25\";i:10;s:14:\"38.105.83.0/27\";i:11;s:16:\"38.112.21.140/30\";i:12;s:15:\"38.118.42.32/29\";i:13;s:17:\"65.213.208.128/27\";i:14;s:16:\"65.222.176.96/27\";i:15;s:16:\"65.222.185.72/29\";i:16;s:16:\"38.103.17.160/27\";i:17;s:14:\"66.113.96.0/20\";i:18;s:16:\"70.35.113.192/27\";i:19;s:14:\"204.15.80.0/22\";i:20;s:15:\"66.17.15.128/26\";i:21;s:15:\"69.84.207.32/27\";i:22;s:16:\"69.84.207.128/25\";i:23;s:14:\"72.36.128.0/17\";i:24;s:13:\"72.232.0.0/16\";i:25;s:13:\"72.233.0.0/17\";i:26;s:13:\"216.32.0.0/14\";i:27;s:17:\"67.192.231.224/29\";i:28;s:15:\"208.90.236.0/22\";i:29;s:18:\"209.147.127.208/28\";i:30;s:16:\"198.186.190.0/23\";i:31;s:16:\"198.186.192.0/23\";i:32;s:16:\"198.186.194.0/24\";i:33;s:16:\"207.210.99.32/29\";i:34;s:11:\"4.53.120.22\";i:35;s:13:\"66.194.6.0/24\";i:36;s:17:\"67.117.201.128/28\";i:37;s:13:\"69.67.32.0/20\";i:38;s:15:\"131.191.87.0/24\";i:39;s:14:\"204.15.64.0/21\";i:40;s:15:\"208.80.192.0/21\";i:41;s:15:\"212.62.26.64/27\";i:42;s:16:\"213.168.226.0/24\";i:43;s:16:\"213.168.241.0/30\";i:44;s:16:\"213.168.242.0/30\";i:45;s:17:\"213.236.150.16/28\";}s:10:\"agent_list\";a:1:{i:0;s:0:\"\";}}","yes");
INSERT INTO `arc1542_options` VALUES("143","itsec_brute_force","a:5:{s:7:\"enabled\";b:1;s:17:\"max_attempts_host\";i:5;s:17:\"max_attempts_user\";i:10;s:12:\"check_period\";i:5;s:14:\"auto_ban_admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("144","itsec_backup","a:9:{s:6:\"method\";i:0;s:8:\"location\";s:69:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:3:{i:0;s:14:\"itsec_lockouts\";i:1;s:9:\"itsec_log\";i:2;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:9:\"all_sites\";b:0;s:8:\"last_run\";i:1438100710;}","yes");
INSERT INTO `arc1542_options` VALUES("145","itsec_file_change","a:9:{s:7:\"enabled\";b:1;s:5:\"split\";b:1;s:6:\"method\";b:1;s:9:\"file_list\";a:1:{i:0;s:0:\"\";}s:5:\"types\";a:6:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".log\";i:4;s:3:\".mo\";i:5;s:3:\".po\";}s:5:\"email\";b:1;s:12:\"notify_admin\";b:1;s:10:\"last_chunk\";i:0;s:8:\"last_run\";d:1437011628;}","yes");
INSERT INTO `arc1542_options` VALUES("146","itsec_hide_backend","a:7:{s:7:\"enabled\";b:1;s:4:\"slug\";s:8:\"arclogin\";s:12:\"theme_compat\";b:1;s:17:\"theme_compat_slug\";s:9:\"not_found\";s:16:\"post_logout_slug\";s:0:\"\";s:12:\"show-tooltip\";b:0;s:8:\"register\";s:15:\"wp-register.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("147","itsec_malware","a:2:{s:7:\"enabled\";b:1;s:7:\"api_key\";s:64:\"91f63fb64116aa3269a33bb0e05891edf78a823f2fc7383ef3a03850c1f2bd59\";}","yes");
INSERT INTO `arc1542_options` VALUES("148","itsec_ssl","a:3:{s:8:\"frontend\";i:0;s:5:\"login\";b:0;s:5:\"admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("150","itsec_strong_passwords","a:2:{s:7:\"enabled\";b:1;s:4:\"roll\";s:6:\"author\";}","yes");
INSERT INTO `arc1542_options` VALUES("151","itsec_tweaks","a:22:{s:13:\"protect_files\";b:1;s:18:\"directory_browsing\";b:1;s:15:\"request_methods\";b:1;s:24:\"suspicious_query_strings\";b:1;s:16:\"long_url_strings\";b:1;s:17:\"write_permissions\";b:1;s:11:\"uploads_php\";b:1;s:13:\"generator_tag\";b:1;s:18:\"wlwmanifest_header\";b:1;s:14:\"edituri_header\";b:1;s:12:\"comment_spam\";b:1;s:14:\"random_version\";b:1;s:11:\"file_editor\";b:1;s:14:\"disable_xmlrpc\";i:1;s:12:\"login_errors\";b:1;s:21:\"force_unique_nicename\";b:1;s:27:\"disable_unused_author_pages\";b:1;s:22:\"non_english_characters\";b:0;s:13:\"theme_updates\";b:0;s:14:\"plugin_updates\";b:0;s:12:\"core_updates\";b:0;s:11:\"safe_jquery\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("153","recently_activated","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("157","itsec_temp_whitelist_ip","a:2:{s:2:\"ip\";s:3:\"::1\";s:3:\"exp\";i:1434483993;}","yes");
INSERT INTO `arc1542_options` VALUES("158","itsec_message_queue","a:2:{s:9:\"last_sent\";i:1438100710;s:8:\"messages\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("162","_site_transient_timeout_available_translations","1434408549","yes");
INSERT INTO `arc1542_options` VALUES("163","_site_transient_available_translations","a:56:{s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:57:37\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-01 14:30:22\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 06:36:25\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-25 18:55:51\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-24 05:23:15\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-30 08:59:10\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-03 00:26:43\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 09:28:00\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-01 09:29:51\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-25 13:39:01\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-04 14:48:26\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-29 17:53:27\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:3:\"4.0\";s:7:\"updated\";s:19:\"2014-09-04 19:47:01\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-16 10:01:41\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-15 10:49:37\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 09:59:32\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:3:\"4.0\";s:7:\"updated\";s:19:\"2014-09-05 17:37:43\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/4.0/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 15:20:27\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.5/haz.zip\";s:3:\"iso\";a:1:{i:2;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 19:32:58\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 08:22:08\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:43:50\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:07:32\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 11:14:20\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-31 19:34:18\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-07 07:33:53\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:57:22\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 10:29:43\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:59:29\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-08 07:10:14\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-10 17:07:58\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.2.2/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-09 10:15:05\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.1.5/ps.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ps\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-27 09:25:14\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 01:38:15\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-21 15:14:01\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-31 11:58:44\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 09:29:23\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 16:25:46\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-29 08:27:12\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-04 20:54:02\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:08:28\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 15:16:26\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:01:28\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 16:45:38\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-28 13:43:48\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-29 06:37:03\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","yes");
INSERT INTO `arc1542_options` VALUES("164","WPLANG","","yes");
INSERT INTO `arc1542_options` VALUES("188","itsec_local_file_list_0","a:389:{s:18:\"wp-admin/about.php\";a:2:{s:1:\"d\";i:1430967808;s:1:\"h\";s:32:\"5863f4e68b87af955a3c6a15a68ca6e0\";}s:23:\"wp-admin/admin-ajax.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"57c0bcd9ee3a9e92656deb0d2d584c24\";}s:25:\"wp-admin/admin-footer.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"62134b74766f43dcca4e776a76f44182\";}s:28:\"wp-admin/admin-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"e3f39d6761a2cdce12638d33ad6171bd\";}s:25:\"wp-admin/admin-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"a013ac49d93a73142cce8ad419c71987\";}s:23:\"wp-admin/admin-post.php\";a:2:{s:1:\"d\";i:1417362144;s:1:\"h\";s:32:\"9405e022d36cdf45f029d94518ce4103\";}s:18:\"wp-admin/admin.php\";a:2:{s:1:\"d\";i:1422546802;s:1:\"h\";s:32:\"3490100547f0bfa48258b7ce974ee5c4\";}s:25:\"wp-admin/async-upload.php\";a:2:{s:1:\"d\";i:1423718130;s:1:\"h\";s:32:\"f83c42723f64875427828b5a179c3058\";}s:20:\"wp-admin/comment.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d7d2857905104581460d4024a44439bc\";}s:20:\"wp-admin/credits.php\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"6d600524bee7a3f198bd1788c559e44a\";}s:26:\"wp-admin/css/about-rtl.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"a2812f9bae76c25229981a60a3452159\";}s:22:\"wp-admin/css/about.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"f0c69f88bca95e586cd57cf7b50d56ce\";}s:31:\"wp-admin/css/admin-menu-rtl.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"9f8a90c453ec305769a851ceba7e13b5\";}s:27:\"wp-admin/css/admin-menu.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"833e64b0003fc66897e82fcfc7fc0121\";}s:33:\"wp-admin/css/color-picker-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f9e65b1bb803a9710e3447d689c1d361\";}s:37:\"wp-admin/css/color-picker-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b95a1b3477b0c06cfa7f65a11d24bbe8\";}s:29:\"wp-admin/css/color-picker.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2d0d4dc75f8710681395c1b31c6c662f\";}s:33:\"wp-admin/css/color-picker.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b4bbb3b27d8fa55598129646b3bf278f\";}s:31:\"wp-admin/css/colors/_admin.scss\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3dbce149457e880a29693684cecd425\";}s:32:\"wp-admin/css/colors/_mixins.scss\";a:2:{s:1:\"d\";i:1409135536;s:1:\"h\";s:32:\"53e25fcbec91e57c9127342e6f2736ee\";}s:35:\"wp-admin/css/colors/_variables.scss\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"3ab501096b1a091972d84c85b284135a\";}s:39:\"wp-admin/css/colors/blue/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"18340a88bc601743b7c70439cec488ed\";}s:43:\"wp-admin/css/colors/blue/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3ef984189150a8810a060747213016b\";}s:35:\"wp-admin/css/colors/blue/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"3518d1b1e45e704aeecc47c0b5e5fae0\";}s:39:\"wp-admin/css/colors/blue/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"998f2d1f4b8565cb04f4c28a3a38b611\";}s:36:\"wp-admin/css/colors/blue/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"d9d03549d79484672c29145aad594db3\";}s:41:\"wp-admin/css/colors/coffee/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"2272c3bc872bdcce77a6b8d0ec902701\";}s:45:\"wp-admin/css/colors/coffee/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"fc48153c9c53bf2d871067cbfca6c8c4\";}s:37:\"wp-admin/css/colors/coffee/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b4cd3218e3c6e52336a8da60cf847d4c\";}s:41:\"wp-admin/css/colors/coffee/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c8796229a84fa15d28de61c772a0d67a\";}s:38:\"wp-admin/css/colors/coffee/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"397e3820b27a234330c95e05250f61ce\";}s:44:\"wp-admin/css/colors/ectoplasm/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58f1d1b2e4ed824585e5cfa1757f49c1\";}s:48:\"wp-admin/css/colors/ectoplasm/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"6f85716a47597c040d5549bbd61ff927\";}s:40:\"wp-admin/css/colors/ectoplasm/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9538ad4bdbecfe10e0bfac3898ee6286\";}s:44:\"wp-admin/css/colors/ectoplasm/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"d392ab4aa1d7ba0fc2c7538e62b30448\";}s:41:\"wp-admin/css/colors/ectoplasm/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"940171d1392bd8071122a905d12b9195\";}s:40:\"wp-admin/css/colors/light/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"ca985fbb17060a4a54e0c2b9c9e4c54a\";}s:44:\"wp-admin/css/colors/light/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"14e0f61252198b7f5bc6b3954f86495c\";}s:36:\"wp-admin/css/colors/light/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"25e706f4ca9277b6f5c09ec85e8360ac\";}s:40:\"wp-admin/css/colors/light/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c64378da84783433e12a436eabb62f79\";}s:37:\"wp-admin/css/colors/light/colors.scss\";a:2:{s:1:\"d\";i:1395957374;s:1:\"h\";s:32:\"20a8567ba70294295c115f7ed9e071b7\";}s:43:\"wp-admin/css/colors/midnight/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7386ebd85ed17227277f38bf986ec649\";}s:47:\"wp-admin/css/colors/midnight/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"46d38df7939457add9e0cb01862625fd\";}s:39:\"wp-admin/css/colors/midnight/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7828a09a10e456933f4f44a27bc9e760\";}s:43:\"wp-admin/css/colors/midnight/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b048ef915d1fa35107bc54d96bdca463\";}s:40:\"wp-admin/css/colors/midnight/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"26dc8daaf0c47c4457b8bc2145f48634\";}s:40:\"wp-admin/css/colors/ocean/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83320550041b6ac4a3b224f8cd66a156\";}s:44:\"wp-admin/css/colors/ocean/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9b6c0b762c7c8c9edb0fdf22fd85084f\";}s:36:\"wp-admin/css/colors/ocean/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58be4f65a594e084222693e8fba9867e\";}s:40:\"wp-admin/css/colors/ocean/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b020388806a04a345a11b54a667b0f0a\";}s:37:\"wp-admin/css/colors/ocean/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"1a7c5bfd9faf7f6cc77cd9b166062568\";}s:42:\"wp-admin/css/colors/sunrise/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"1579864ea35ebc26521222e136a961e7\";}s:46:\"wp-admin/css/colors/sunrise/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"be0732f8240abe60df1783354817ade5\";}s:38:\"wp-admin/css/colors/sunrise/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"43709ad04cfe4981c074767db4cec654\";}s:42:\"wp-admin/css/colors/sunrise/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83453647da515355dc45a661ab42ea38\";}s:39:\"wp-admin/css/colors/sunrise/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"5692871a8a7a1914ee0968ddf9923dec\";}s:27:\"wp-admin/css/common-rtl.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"81f0f785dbd8eee0a11d054a3cbdf606\";}s:23:\"wp-admin/css/common.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"6942f692b44491261619b43859b8acfc\";}s:39:\"wp-admin/css/customize-controls-rtl.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"1d0e5ded99e0c19c6deab1602412ad4d\";}s:43:\"wp-admin/css/customize-controls-rtl.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"27d9de08d110062db4c26b9fea3b21cc\";}s:35:\"wp-admin/css/customize-controls.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"183493ffd9bb469e92882434bb95f33c\";}s:39:\"wp-admin/css/customize-controls.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"f94aad7c60a799b4bf28b0e6ea0b0134\";}s:38:\"wp-admin/css/customize-widgets-rtl.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7ab3411bcab95d99021791a7da6a39c8\";}s:42:\"wp-admin/css/customize-widgets-rtl.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"86d0504f3f24934ce87ed755d6d16a98\";}s:34:\"wp-admin/css/customize-widgets.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7cec3fb121b9608cfb8c6a089bdc1a78\";}s:38:\"wp-admin/css/customize-widgets.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"868832fcafbffba43f5ba4fbf31d3ca5\";}s:30:\"wp-admin/css/dashboard-rtl.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"ebb761dcfd6cb62a9983a41f6c69266a\";}s:26:\"wp-admin/css/dashboard.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"c178ee058ec19c709f30baed82db8392\";}s:37:\"wp-admin/css/deprecated-media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"558fe352dfdab9790dab9710438af5a9\";}s:41:\"wp-admin/css/deprecated-media-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"017b6102507494583f9241b9f8854959\";}s:33:\"wp-admin/css/deprecated-media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0ada8c65bb367cab1cabc0defa1ac6a6\";}s:37:\"wp-admin/css/deprecated-media.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"625227ce35e802591f85a974db531d36\";}s:25:\"wp-admin/css/edit-rtl.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"be99c57389c7d414f0f58f33678a0824\";}s:21:\"wp-admin/css/edit.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"dca1f2c9b549b0c85b279a27e4adc142\";}s:31:\"wp-admin/css/farbtastic-rtl.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"118f1189ffbb71e014402121b5456bc2\";}s:27:\"wp-admin/css/farbtastic.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"f9e33829b8faed7d7bbef843fb683255\";}s:26:\"wp-admin/css/forms-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"fe5319684165959b7b00b618009c3e81\";}s:22:\"wp-admin/css/forms.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8f95818bedd2456f61d3f82926bbe549\";}s:23:\"wp-admin/css/ie-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0b9e0977caa2f7f8f935d5b5536cf6d7\";}s:27:\"wp-admin/css/ie-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"46dca3fdd473c8b6cec51e3ff5d700c6\";}s:19:\"wp-admin/css/ie.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f146885900f710c867cd48f030851e97\";}s:23:\"wp-admin/css/ie.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"494254d427a06ead698729501d1706c9\";}s:28:\"wp-admin/css/install-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2a0fc0a9434d3aa6abfda715dfe80ca2\";}s:32:\"wp-admin/css/install-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"e3e8c235f96ea51104cde0104ae12010\";}s:24:\"wp-admin/css/install.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"42c906bd2400b2ab11aa44a8f8396a9e\";}s:28:\"wp-admin/css/install.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"333fb17a509abf264fd13c529939608b\";}s:25:\"wp-admin/css/l10n-rtl.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"fcb0063a38cf8348351737634db3f947\";}s:21:\"wp-admin/css/l10n.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"5dda0b5411fecbe1fac83dfe21c7540e\";}s:32:\"wp-admin/css/list-tables-rtl.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"a44b142006df40f488aec4ea1357883c\";}s:28:\"wp-admin/css/list-tables.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"b34413b3174ac624919ce065ebb29aba\";}s:26:\"wp-admin/css/login-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"35f23fc2280b36e67ad2afb8c6737a03\";}s:30:\"wp-admin/css/login-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"563cb2edac2f1e28bc7ba07afcdda851\";}s:22:\"wp-admin/css/login.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0e01b8fa9ea4487455a587c852b405c5\";}s:26:\"wp-admin/css/login.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c4661abb4164f292618baa46c3b04235\";}s:26:\"wp-admin/css/media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b5f2073fd98bf22e2f2b2353a2475f9f\";}s:22:\"wp-admin/css/media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f578fae6b47beea325ee8dc1a8551e88\";}s:30:\"wp-admin/css/nav-menus-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"91ff408d32eacbd28e621c34b7565f8d\";}s:26:\"wp-admin/css/nav-menus.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d3266344ddb105a2e774a071dd05a361\";}s:38:\"wp-admin/css/press-this-editor-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8de2501460648d4cb12d23774d21dd5f\";}s:34:\"wp-admin/css/press-this-editor.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"953fa7568d1de29bc722de0c8d27c59d\";}s:31:\"wp-admin/css/press-this-rtl.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"7f2b2879d22aa540d113a4af70999990\";}s:35:\"wp-admin/css/press-this-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"c6dcd57eb62b059f20223ca862046a02\";}s:27:\"wp-admin/css/press-this.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"dca19314e2e3871f91e07bcf64b23e53\";}s:31:\"wp-admin/css/press-this.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"48180a7b52dd60bec1fc7a0ae2be0826\";}s:30:\"wp-admin/css/revisions-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"cc328e9ddbef2ef2c495786078ff612a\";}s:26:\"wp-admin/css/revisions.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d266c3e67470bf8f70d91d920b1b50f1\";}s:27:\"wp-admin/css/themes-rtl.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"ed00d87745e51769e94fb921930d997d\";}s:23:\"wp-admin/css/themes.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"0f2c9837f4d58bec62e54c49bc2b7794\";}s:28:\"wp-admin/css/widgets-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d81963de7dff71f3295c5a42fba00ab7\";}s:24:\"wp-admin/css/widgets.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"4dc79b8deabc48edc3cb04b90633810d\";}s:29:\"wp-admin/css/wp-admin-rtl.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"7fbe22c3651b774033fa758ca07ccbbb\";}s:33:\"wp-admin/css/wp-admin-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"030caf3660328d0bb366809887d33a2a\";}s:25:\"wp-admin/css/wp-admin.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"ada11abbeb8553e9524605cbfc29d26d\";}s:29:\"wp-admin/css/wp-admin.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"225d1ef58b5ab0f793d3952967df269a\";}s:30:\"wp-admin/custom-background.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"89d8a54f939a110003510e982d8fe57f\";}s:26:\"wp-admin/custom-header.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5488cf2e8e9630388723c51a7a0726bc\";}s:22:\"wp-admin/customize.php\";a:2:{s:1:\"d\";i:1428009388;s:1:\"h\";s:32:\"5481909613787611390e7c3548337820\";}s:26:\"wp-admin/edit-comments.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"294f99f28d493d34925d56791d4b16ab\";}s:31:\"wp-admin/edit-form-advanced.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"833ab8eb05e8b63fb56b8c62363b9591\";}s:30:\"wp-admin/edit-form-comment.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"8325c6fe38489470c57f3f4832e17892\";}s:27:\"wp-admin/edit-link-form.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"fa37a6bab69f64e1479847f5008e4725\";}s:26:\"wp-admin/edit-tag-form.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"463fb3100f9f45fbd0ca2f297725e68f\";}s:22:\"wp-admin/edit-tags.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4dfc7b236b076202eda683d2616fb77e\";}s:17:\"wp-admin/edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"e181a2ab1d1838d41a71df7d75fe8a91\";}s:19:\"wp-admin/export.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d62d73bc749f99ef989dba3f5fc85f4a\";}s:21:\"wp-admin/freedoms.php\";a:2:{s:1:\"d\";i:1429072708;s:1:\"h\";s:32:\"65830b9bbe81aac353761e4c5879c2b8\";}s:32:\"wp-admin/images/bubble_bg-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"16523d5bf9efd8ca3b92e7631edfc513\";}s:29:\"wp-admin/images/bubble_bg.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3d2cb3f7baa628c9e51a326356e72038\";}s:34:\"wp-admin/images/date-button-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2952932c246bf9828429361643a8bb63\";}s:31:\"wp-admin/images/date-button.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"979d8e2e08aada49819556950ec48ff6\";}s:27:\"wp-admin/images/loading.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2d5b92b61674c850bff00cecaf0864ec\";}s:38:\"wp-admin/images/media-button-image.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7ea2c9c157c38edb40b1ce62d572d5b3\";}s:38:\"wp-admin/images/media-button-music.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"eff55df37f325c5aae2f02e4d913de95\";}s:38:\"wp-admin/images/media-button-other.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8bc6b46bc70c7c1918dce62c4fe3229c\";}s:38:\"wp-admin/images/media-button-video.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"abaac3dfd81fbf72e578f13451eae7d0\";}s:29:\"wp-admin/images/resize-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"f5e118653f892606682ee9c51d0aba99\";}s:33:\"wp-admin/images/resize-rtl-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"f7c99ee74014fe92541012303aaadc7d\";}s:30:\"wp-admin/images/resize-rtl.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"db9217196313c95a59d43601da19c51d\";}s:26:\"wp-admin/images/resize.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3fba1544df24f40dde5876c8c0aec461\";}s:27:\"wp-admin/images/sort-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"186e51267fca5d20b230c72d9a8983ee\";}s:24:\"wp-admin/images/sort.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2e8acb8dee99bfbcb61bd46c486a995d\";}s:30:\"wp-admin/images/spinner-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"5c1371bcb4392968647852a9c9df5d6c\";}s:27:\"wp-admin/images/spinner.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"b0a3dde331637e27aa6476d476481871\";}s:40:\"wp-admin/images/wordpress-logo-white.svg\";a:2:{s:1:\"d\";i:1384078330;s:1:\"h\";s:32:\"e1af633d59dcb5988cacff73b6dee9ff\";}s:34:\"wp-admin/images/wordpress-logo.svg\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f34ef6259364f7ef0ccf67cd1dddc970\";}s:35:\"wp-admin/images/wpspin_light-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7def33aad959cd289d49ddf2a41f076d\";}s:32:\"wp-admin/images/wpspin_light.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"dd4e6dd268a70ce4c1c5143b1a4092dd\";}s:26:\"wp-admin/images/xit-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8fb0729c541cbdc4609faf3f4ad02fc7\";}s:23:\"wp-admin/images/xit.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"e5012902a358fbb96031acdcf048d7ca\";}s:19:\"wp-admin/import.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6e389b5d3ce9c49472c2f65737894057\";}s:27:\"wp-admin/includes/admin.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"be54224152f2b4ec6879ffdbba435129\";}s:34:\"wp-admin/includes/ajax-actions.php\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"8d262c73247924453f1692cd240c75c3\";}s:30:\"wp-admin/includes/bookmark.php\";a:2:{s:1:\"d\";i:1416132982;s:1:\"h\";s:32:\"5682d92e5f2542298a6ab34186891a61\";}s:36:\"wp-admin/includes/class-ftp-pure.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"2cfd5c1b2e4288cef60faddbedeff8d3\";}s:39:\"wp-admin/includes/class-ftp-sockets.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"54d9e85b94c4e6368813852b9a81273c\";}s:31:\"wp-admin/includes/class-ftp.php\";a:2:{s:1:\"d\";i:1415803464;s:1:\"h\";s:32:\"ad8496325608fb75875c49f64c0b84fc\";}s:34:\"wp-admin/includes/class-pclzip.php\";a:2:{s:1:\"d\";i:1255652782;s:1:\"h\";s:32:\"01363728c843ff93e96b6983ce38eba6\";}s:50:\"wp-admin/includes/class-wp-comments-list-table.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"03b99541cc4e471541f6eb52fc993cdb\";}s:46:\"wp-admin/includes/class-wp-filesystem-base.php\";a:2:{s:1:\"d\";i:1424944104;s:1:\"h\";s:32:\"053d3e7194eb24bd010794b2e45f8070\";}s:48:\"wp-admin/includes/class-wp-filesystem-direct.php\";a:2:{s:1:\"d\";i:1419122424;s:1:\"h\";s:32:\"7c687f407b517d35e8986321df4b3059\";}s:48:\"wp-admin/includes/class-wp-filesystem-ftpext.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"b18e349ccc50fc1b3f7e240dd365347e\";}s:52:\"wp-admin/includes/class-wp-filesystem-ftpsockets.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"4eb43c52d18090a544df4676af189b9e\";}s:46:\"wp-admin/includes/class-wp-filesystem-ssh2.php\";a:2:{s:1:\"d\";i:1425889948;s:1:\"h\";s:32:\"d43d02e98585870d63d76fd7e23cb732\";}s:39:\"wp-admin/includes/class-wp-importer.php\";a:2:{s:1:\"d\";i:1421463082;s:1:\"h\";s:32:\"d04b79a26c434bac92572eb31da8a135\";}s:47:\"wp-admin/includes/class-wp-links-list-table.php\";a:2:{s:1:\"d\";i:1421288062;s:1:\"h\";s:32:\"7050b4928ed9e9a71e7b34570ff74557\";}s:41:\"wp-admin/includes/class-wp-list-table.php\";a:2:{s:1:\"d\";i:1424656106;s:1:\"h\";s:32:\"15b7819b8098a83efa5b124cd8736842\";}s:47:\"wp-admin/includes/class-wp-media-list-table.php\";a:2:{s:1:\"d\";i:1427846246;s:1:\"h\";s:32:\"5eaa024ba0f05d24b8ee56be1dc7c6f6\";}s:50:\"wp-admin/includes/class-wp-ms-sites-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"1603c869a83696c7f27c914b13aa7b68\";}s:51:\"wp-admin/includes/class-wp-ms-themes-list-table.php\";a:2:{s:1:\"d\";i:1421093842;s:1:\"h\";s:32:\"b7d8cddc268e99caa0fd867cc57a9d15\";}s:50:\"wp-admin/includes/class-wp-ms-users-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"e4f826892bb47ac498e17de592c4b023\";}s:56:\"wp-admin/includes/class-wp-plugin-install-list-table.php\";a:2:{s:1:\"d\";i:1428032968;s:1:\"h\";s:32:\"c169312a5c0d45bf60729cefc606cd43\";}s:49:\"wp-admin/includes/class-wp-plugins-list-table.php\";a:2:{s:1:\"d\";i:1427232808;s:1:\"h\";s:32:\"52c76d175bde8b9781e1600a6adcb812\";}s:47:\"wp-admin/includes/class-wp-posts-list-table.php\";a:2:{s:1:\"d\";i:1428178106;s:1:\"h\";s:32:\"eff04c61fdbf46485b95e161271493d8\";}s:41:\"wp-admin/includes/class-wp-press-this.php\";a:2:{s:1:\"d\";i:1429421668;s:1:\"h\";s:32:\"18e8b8c6e4c4abc97ffa4d4acb283651\";}s:47:\"wp-admin/includes/class-wp-terms-list-table.php\";a:2:{s:1:\"d\";i:1423035984;s:1:\"h\";s:32:\"5eb2173c2679ce21f141199be9f1165c\";}s:55:\"wp-admin/includes/class-wp-theme-install-list-table.php\";a:2:{s:1:\"d\";i:1425783808;s:1:\"h\";s:32:\"8ff475a867be95d6fdfd7fae9add0f34\";}s:48:\"wp-admin/includes/class-wp-themes-list-table.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"40cc946d84ea606286c8f15479544835\";}s:45:\"wp-admin/includes/class-wp-upgrader-skins.php\";a:2:{s:1:\"d\";i:1424639244;s:1:\"h\";s:32:\"3c5d0b0c99fe3af5504756355d661688\";}s:39:\"wp-admin/includes/class-wp-upgrader.php\";a:2:{s:1:\"d\";i:1428034708;s:1:\"h\";s:32:\"1fd2dd8f3265df13718ff7c90aa2eeb2\";}s:47:\"wp-admin/includes/class-wp-users-list-table.php\";a:2:{s:1:\"d\";i:1428196168;s:1:\"h\";s:32:\"936fe59e0bf3a8ed7ae1d91a34854015\";}s:29:\"wp-admin/includes/comment.php\";a:2:{s:1:\"d\";i:1414792582;s:1:\"h\";s:32:\"a2a4e95cdac0b8a2e42733ae29dea751\";}s:39:\"wp-admin/includes/continents-cities.php\";a:2:{s:1:\"d\";i:1242345926;s:1:\"h\";s:32:\"024b57d99bbe8b9e133316d1e98fc79d\";}s:31:\"wp-admin/includes/dashboard.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"7755ef730ecdc36415c482dbaf471b04\";}s:32:\"wp-admin/includes/deprecated.php\";a:2:{s:1:\"d\";i:1426101928;s:1:\"h\";s:32:\"0c665b41c9d916f3cbb7786711960e4b\";}s:28:\"wp-admin/includes/export.php\";a:2:{s:1:\"d\";i:1420715126;s:1:\"h\";s:32:\"78e46f3d610ca92a41acbea60e546496\";}s:26:\"wp-admin/includes/file.php\";a:2:{s:1:\"d\";i:1430292030;s:1:\"h\";s:32:\"aaf31744d17c235f7835b359cb5768d1\";}s:32:\"wp-admin/includes/image-edit.php\";a:2:{s:1:\"d\";i:1425070286;s:1:\"h\";s:32:\"dd6f097ac32ab3dac81fe65287bafde3\";}s:27:\"wp-admin/includes/image.php\";a:2:{s:1:\"d\";i:1425978448;s:1:\"h\";s:32:\"c13371e2d82ee708e7e8f3d09e84faa2\";}s:28:\"wp-admin/includes/import.php\";a:2:{s:1:\"d\";i:1419124224;s:1:\"h\";s:32:\"deb1db7743721bdda9411c8a5c04d70f\";}s:32:\"wp-admin/includes/list-table.php\";a:2:{s:1:\"d\";i:1405303756;s:1:\"h\";s:32:\"039a82ba14a35438ace23efba15fdf82\";}s:27:\"wp-admin/includes/media.php\";a:2:{s:1:\"d\";i:1428197726;s:1:\"h\";s:32:\"7ffe0152492297cb75fd7d96ef5b6461\";}s:26:\"wp-admin/includes/menu.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"58264a1bca858e1f712ec7f98f109899\";}s:32:\"wp-admin/includes/meta-boxes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"97773e9daa2b252b840c25f1ee5fda9f\";}s:26:\"wp-admin/includes/misc.php\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d28646b454f9f4e03fcf3be9b8d580cb\";}s:35:\"wp-admin/includes/ms-deprecated.php\";a:2:{s:1:\"d\";i:1425870568;s:1:\"h\";s:32:\"0b2f626d4faa139d644e4c0969f6aa58\";}s:24:\"wp-admin/includes/ms.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"aba87ff132e62a01485b10c37340f5bd\";}s:30:\"wp-admin/includes/nav-menu.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"914aebacbcbf40acb90559e04f53fe70\";}s:36:\"wp-admin/includes/plugin-install.php\";a:2:{s:1:\"d\";i:1428390566;s:1:\"h\";s:32:\"3eba38bff1614bec4d1a1f9650d04fff\";}s:28:\"wp-admin/includes/plugin.php\";a:2:{s:1:\"d\";i:1421457562;s:1:\"h\";s:32:\"ada165c90f5c7985fccb101bdf3afb38\";}s:26:\"wp-admin/includes/post.php\";a:2:{s:1:\"d\";i:1428198746;s:1:\"h\";s:32:\"d889e18d2c2714b9841da7bd03774b74\";}s:30:\"wp-admin/includes/revision.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"02ae8504c79255eebb2b7a6de6f65ca6\";}s:28:\"wp-admin/includes/schema.php\";a:2:{s:1:\"d\";i:1423568848;s:1:\"h\";s:32:\"d3e3579ef079b924c3dd4789fb6df040\";}s:28:\"wp-admin/includes/screen.php\";a:2:{s:1:\"d\";i:1426015948;s:1:\"h\";s:32:\"f5423c59bdc088834ed8e526c8bce73e\";}s:30:\"wp-admin/includes/taxonomy.php\";a:2:{s:1:\"d\";i:1422545662;s:1:\"h\";s:32:\"e345a18b9436e50ee17c4af7ffe1b2b5\";}s:30:\"wp-admin/includes/template.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"6699a307eb2ae234e38c6406b38956c3\";}s:35:\"wp-admin/includes/theme-install.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"e66174127b56d0eb51c685c32ad68455\";}s:27:\"wp-admin/includes/theme.php\";a:2:{s:1:\"d\";i:1429733486;s:1:\"h\";s:32:\"ebfda92f8dec9d6ba85462864b78c05a\";}s:41:\"wp-admin/includes/translation-install.php\";a:2:{s:1:\"d\";i:1423841006;s:1:\"h\";s:32:\"81931f61c70a5dbaa17236c86fe965ba\";}s:33:\"wp-admin/includes/update-core.php\";a:2:{s:1:\"d\";i:1430951968;s:1:\"h\";s:32:\"89bb7c2af227e6554315c3ee61ddff63\";}s:28:\"wp-admin/includes/update.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"83440a93ab1d6d7a2fd9d53a1589fdf4\";}s:29:\"wp-admin/includes/upgrade.php\";a:2:{s:1:\"d\";i:1430975550;s:1:\"h\";s:32:\"f0e28fe081e8a3a12087a695d3cb7a68\";}s:26:\"wp-admin/includes/user.php\";a:2:{s:1:\"d\";i:1428259468;s:1:\"h\";s:32:\"17eacf5ff7e5f4827a64d6c5424fd956\";}s:29:\"wp-admin/includes/widgets.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"f94a23c52573d5aab9c36b0c612e52c8\";}s:18:\"wp-admin/index.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2c75aa13fe1b4abb250879085a2efb0f\";}s:27:\"wp-admin/install-helper.php\";a:2:{s:1:\"d\";i:1416822444;s:1:\"h\";s:32:\"5480b0fabf52c37eee8bfed6db52335a\";}s:20:\"wp-admin/install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a48aee948fe2ea5d3a6b9a325b604f5\";}s:24:\"wp-admin/js/accordion.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"f25e56e30af6382e3770be437493373a\";}s:28:\"wp-admin/js/accordion.min.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"cfa0d94d00f7a8a147c3815dc819e114\";}s:26:\"wp-admin/js/bookmarklet.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"599601c1e1bcbf766f466722e50cb06b\";}s:30:\"wp-admin/js/bookmarklet.min.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"07603898b017e6cc23f7a5b90c003314\";}s:27:\"wp-admin/js/color-picker.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"0e948ad7ea32644d4dcadc0f54fac1e3\";}s:31:\"wp-admin/js/color-picker.min.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"1aa57d225b7d9bb8bfa8500e0c2de029\";}s:22:\"wp-admin/js/comment.js\";a:2:{s:1:\"d\";i:1384047010;s:1:\"h\";s:32:\"a3fefb4998b3f534e144db4f235d0f03\";}s:26:\"wp-admin/js/comment.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"38ff692f79a3e57df9b9192a9e43b4ea\";}s:21:\"wp-admin/js/common.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"dc9e2fa5c5e058e9a9466f48322e0f32\";}s:25:\"wp-admin/js/common.min.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"d3a3f5d88670f6fea04b6f523f67b528\";}s:32:\"wp-admin/js/custom-background.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"f26af7294ee07fb9a0cb88c2a8697623\";}s:36:\"wp-admin/js/custom-background.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"82d07f23593e578820b19fc9faad65a0\";}s:28:\"wp-admin/js/custom-header.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"32b3005887a4cb606fecc09c756605bb\";}s:33:\"wp-admin/js/customize-controls.js\";a:2:{s:1:\"d\";i:1428977430;s:1:\"h\";s:32:\"7c0e981e54ea85d7971d0a9b25a9c263\";}s:37:\"wp-admin/js/customize-controls.min.js\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"fa9142f8d88f8566d3dd0b40b602ce2e\";}s:32:\"wp-admin/js/customize-widgets.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"07f1519a2a074eb51cce3ec5cb9810d5\";}s:36:\"wp-admin/js/customize-widgets.min.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"ef95bf9c8588420084c724b541ec9fa0\";}s:24:\"wp-admin/js/dashboard.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"dcaf4f687c6c523cf0e2d5515234faa5\";}s:28:\"wp-admin/js/dashboard.min.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"39f67345a12faf1a3c53c9289fc59f86\";}s:28:\"wp-admin/js/edit-comments.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f6947b28c386e3637c99d199c4a32a33\";}s:32:\"wp-admin/js/edit-comments.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f303c21d68b4ebff99aab2df75f81db9\";}s:28:\"wp-admin/js/editor-expand.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"001eee141532f8fc1fac023dbb945a92\";}s:32:\"wp-admin/js/editor-expand.min.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"78a1af5d700f31280bfc20621bce8e50\";}s:21:\"wp-admin/js/editor.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"1e33af23a168b21a333bf6ba71ac4671\";}s:25:\"wp-admin/js/editor.min.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"a71c41c4b1c1f15084fe96f5f6d5e095\";}s:25:\"wp-admin/js/farbtastic.js\";a:2:{s:1:\"d\";i:1289507662;s:1:\"h\";s:32:\"a73af354a03241715d8698feea340b92\";}s:22:\"wp-admin/js/gallery.js\";a:2:{s:1:\"d\";i:1384873810;s:1:\"h\";s:32:\"1be9174b160c7eb40e6cdce4031ae89e\";}s:26:\"wp-admin/js/gallery.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"1c986fe3039dbacf126de2f0dc644f6f\";}s:25:\"wp-admin/js/image-edit.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c21931f1eecd6c1532a4c2ca7a7faa5e\";}s:29:\"wp-admin/js/image-edit.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"40c9a1866d7ab4aec2346e02d82f4758\";}s:31:\"wp-admin/js/inline-edit-post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"8c56d38ee4c4c97d875fdbc20ac029dd\";}s:35:\"wp-admin/js/inline-edit-post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"167e7b26c864699559d930fc5ce72a7a\";}s:30:\"wp-admin/js/inline-edit-tax.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"a920718b385e75e18193ee293ffdfd3c\";}s:34:\"wp-admin/js/inline-edit-tax.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4aa2a2e6ee60243f003d3ebb47edf4b4\";}s:23:\"wp-admin/js/iris.min.js\";a:2:{s:1:\"d\";i:1417362262;s:1:\"h\";s:32:\"75c63560c640c4a6c31f5565dfb0e8a9\";}s:31:\"wp-admin/js/language-chooser.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"09e20150c7561d0330d7158f744abb4a\";}s:35:\"wp-admin/js/language-chooser.min.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"1d6822384a71090c74add106e4468581\";}s:19:\"wp-admin/js/link.js\";a:2:{s:1:\"d\";i:1384506970;s:1:\"h\";s:32:\"1c8675dcd035cfb374f67bfcbf117a8c\";}s:23:\"wp-admin/js/link.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"f9ff4694933001933bdec2c133b2252d\";}s:28:\"wp-admin/js/media-gallery.js\";a:2:{s:1:\"d\";i:1384571950;s:1:\"h\";s:32:\"7cf21db8661f9201a784f638f77d2b26\";}s:32:\"wp-admin/js/media-gallery.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"3296d1fa20d292b002bba10490f1ba6e\";}s:27:\"wp-admin/js/media-upload.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"5f66a88c118be462a566029db50aa3a2\";}s:31:\"wp-admin/js/media-upload.min.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"61ea709a3314ba200a885e2465267aa2\";}s:20:\"wp-admin/js/media.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"cf85d75e70304c42f77553ee9b9ec585\";}s:24:\"wp-admin/js/media.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"2e8efd83242126157ff0bffd5e249159\";}s:23:\"wp-admin/js/nav-menu.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"d6facb8a8fe8d2ed1cdef140d006942a\";}s:27:\"wp-admin/js/nav-menu.min.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"e2fe94b081c4f0bb2e673b75b2d72b23\";}s:38:\"wp-admin/js/password-strength-meter.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"4d912846975670c9e2232a19ef7bb41b\";}s:42:\"wp-admin/js/password-strength-meter.min.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"3185f27c8fa4123db79a1d6de055c9d7\";}s:29:\"wp-admin/js/plugin-install.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"90585237ad358716313a1f5d9b9353b9\";}s:33:\"wp-admin/js/plugin-install.min.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"7a6211c90a9364fa26b36f9866d53e9e\";}s:19:\"wp-admin/js/post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"995f94db4b9e67b27b3d71ca72624988\";}s:23:\"wp-admin/js/post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c47dac85d54efe4352e7e5d6045970ab\";}s:22:\"wp-admin/js/postbox.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"87a08ca86f25ee997a627ce4a88ec359\";}s:26:\"wp-admin/js/postbox.min.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"8bf00b23dafb248f022d8b21693e0418\";}s:25:\"wp-admin/js/press-this.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"91993a940f719edbe2ad8a259973527e\";}s:29:\"wp-admin/js/press-this.min.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"682e5b74d3791a9c09b8c5317f84aa4a\";}s:24:\"wp-admin/js/revisions.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"41f746a4087bec7e9b0db4152759d169\";}s:28:\"wp-admin/js/revisions.min.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"3253906cffe4523bc05d0632af4c6af8\";}s:33:\"wp-admin/js/set-post-thumbnail.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"2b5153576d1eee4002fb7ed9e5831251\";}s:37:\"wp-admin/js/set-post-thumbnail.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"8bc5ca12fa38a607d5af2181311b7a5b\";}s:26:\"wp-admin/js/svg-painter.js\";a:2:{s:1:\"d\";i:1386295270;s:1:\"h\";s:32:\"87dcfbe97f902fa77cc4a9889c827afc\";}s:30:\"wp-admin/js/svg-painter.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"8db7f2acb2c205b766167517ccce7f8a\";}s:23:\"wp-admin/js/tags-box.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"74a49b1066cf04c0e5c92020e0ff23af\";}s:27:\"wp-admin/js/tags-box.min.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"e5824b6ec80b938c3c17d7a19e78d9a9\";}s:19:\"wp-admin/js/tags.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"4cc64266f1b35a86c63cc1b2c42f7306\";}s:23:\"wp-admin/js/tags.min.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"172f499d40d4217bbf684cd552031acb\";}s:20:\"wp-admin/js/theme.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"ce08e4628996a70a5d5deac9221e1130\";}s:24:\"wp-admin/js/theme.min.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"3bb1a6dc71edb4b953c6dec624b162c5\";}s:22:\"wp-admin/js/updates.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"79c9c0056693f2eba1f6007ccc6fb20b\";}s:26:\"wp-admin/js/updates.min.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"0f5a5b69ce6a28ec4efcaf68a55c21d5\";}s:27:\"wp-admin/js/user-profile.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"28090921c47b8aab172ab53dcc269d00\";}s:31:\"wp-admin/js/user-profile.min.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"6a1e4023a877503c50771b02f2d332c2\";}s:27:\"wp-admin/js/user-suggest.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"1e33290807fa8b2829ddb0347d0a9305\";}s:31:\"wp-admin/js/user-suggest.min.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"e089545cd7fcde5c7cd70de3a70139e1\";}s:22:\"wp-admin/js/widgets.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"485de2b76d48a457394827f2f5c5e0fb\";}s:26:\"wp-admin/js/widgets.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4c2c339725d1719abe9809b79e89d390\";}s:25:\"wp-admin/js/word-count.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"66256995400e51a5f931a11bc11e1e4e\";}s:29:\"wp-admin/js/word-count.min.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"c71cccaeb645b4e75e963aecff2f5fc6\";}s:28:\"wp-admin/js/wp-fullscreen.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"669dfa41fd076fadd200112960a46fcb\";}s:32:\"wp-admin/js/wp-fullscreen.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"d6a88a01bdc839e38c5a25c3533d32c4\";}s:18:\"wp-admin/js/xfn.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"e2d6eecbd774af1e2bb1a16ec117286b\";}s:22:\"wp-admin/js/xfn.min.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"66b227ca28f41f2e0615b04a390d5e04\";}s:21:\"wp-admin/link-add.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"759747ef8d44c52fadcfa5c457f3f283\";}s:25:\"wp-admin/link-manager.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"416c4e2eadb0a92b516391bed0b8ac02\";}s:28:\"wp-admin/link-parse-opml.php\";a:2:{s:1:\"d\";i:1428015688;s:1:\"h\";s:32:\"446ddcd3dec1e48190e666b238eba7e1\";}s:17:\"wp-admin/link.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"63adfdd74e61e01c62e1a1e41cd37f64\";}s:25:\"wp-admin/load-scripts.php\";a:2:{s:1:\"d\";i:1420268242;s:1:\"h\";s:32:\"3e0837db719900ab7dce30025b92ab30\";}s:24:\"wp-admin/load-styles.php\";a:2:{s:1:\"d\";i:1404431834;s:1:\"h\";s:32:\"e4fe4585bf1930564ff8d572a0a5eac2\";}s:25:\"wp-admin/maint/repair.php\";a:2:{s:1:\"d\";i:1404065416;s:1:\"h\";s:32:\"3ba2182300e632340850329b7065da34\";}s:22:\"wp-admin/media-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d37f8ace789522fe8d82eafda85bfbaf\";}s:25:\"wp-admin/media-upload.php\";a:2:{s:1:\"d\";i:1422964042;s:1:\"h\";s:32:\"54bfe84a40818aa5f0b886ef21e1f6ce\";}s:18:\"wp-admin/media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"a3323d084b4298fcada382ed48eed842\";}s:24:\"wp-admin/menu-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"1f77220052f77c59724983b5d782529a\";}s:17:\"wp-admin/menu.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"c6ee46bcfb7abb6568569add0aa18120\";}s:23:\"wp-admin/moderation.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"541242a293805952a0e22234f09d6fa9\";}s:21:\"wp-admin/ms-admin.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9a05b49740dfcdaf4516851b623606e4\";}s:27:\"wp-admin/ms-delete-site.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"19c0d841bde03b74c53f4f615176518b\";}s:20:\"wp-admin/ms-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"16d42ff617c4a616c3bd94ba103a4582\";}s:23:\"wp-admin/ms-options.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a21d278e00ca7dccfe3a81d4e386afa9\";}s:21:\"wp-admin/ms-sites.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"5d186224ebf4ddd0f1719c9ef4b80468\";}s:22:\"wp-admin/ms-themes.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"521cb94b9501ca24bc495a31c66925d8\";}s:31:\"wp-admin/ms-upgrade-network.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"7cb492260f22ee53816d96be3868be6d\";}s:21:\"wp-admin/ms-users.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4823c8667b23ca83b31bf9093647e5a2\";}s:21:\"wp-admin/my-sites.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"575f48b933eeb0ec3809b68584b56af6\";}s:22:\"wp-admin/nav-menus.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0378f1ac1491adffb9be1acd89a3a3e1\";}s:26:\"wp-admin/network/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"e9e33df9da15a95356e6da0e56889fec\";}s:26:\"wp-admin/network/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"4e85d4354373cc17b9099b130b121f12\";}s:28:\"wp-admin/network/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"38192cde34142cc7ecf558f58ef475f0\";}s:25:\"wp-admin/network/edit.php\";a:2:{s:1:\"d\";i:1417360882;s:1:\"h\";s:32:\"0deb5ea059c21f268c973b5ea0fcd21a\";}s:29:\"wp-admin/network/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"109efa9312c00370894f7e2ba27e9c31\";}s:26:\"wp-admin/network/index.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"8d5631ed02722fccdaef052efbdbcb4a\";}s:25:\"wp-admin/network/menu.php\";a:2:{s:1:\"d\";i:1412279358;s:1:\"h\";s:32:\"1ae13d535ba56678c4e08acf1989a3d5\";}s:34:\"wp-admin/network/plugin-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"3fb5cd9ab947024d84585a0d693dcc12\";}s:35:\"wp-admin/network/plugin-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"6bbd804f795fa5a934f529a51a9886bf\";}s:28:\"wp-admin/network/plugins.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4193887cb9cb7f4d4d3000bdf303bf1e\";}s:28:\"wp-admin/network/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d86926a7511d1d5cd3a2f0a502e7b6a8\";}s:29:\"wp-admin/network/settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"97e11d59cdfc86f0a6bb7b443d6cde65\";}s:26:\"wp-admin/network/setup.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ee19cf426d3e6e397a5d891f08d19ae2\";}s:30:\"wp-admin/network/site-info.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"817cc350d57c04ae4eec460ace8e6d36\";}s:29:\"wp-admin/network/site-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"710cf4cd7985b5acd028f46caf236e4b\";}s:34:\"wp-admin/network/site-settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"996a40c97e25b119ed171083c5f47873\";}s:32:\"wp-admin/network/site-themes.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"91216c7ce232e5b8d4565faf0e0c038a\";}s:31:\"wp-admin/network/site-users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"fada8422fa27bae1ad0d2e0ce6c8138d\";}s:26:\"wp-admin/network/sites.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"e67f0b0fd462649c592e7cbb11d24bad\";}s:33:\"wp-admin/network/theme-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"804f9a460fa9e3646d83f915c51cd36a\";}s:34:\"wp-admin/network/theme-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"26d5b7cd315570d025e09e11313d24e4\";}s:27:\"wp-admin/network/themes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"db78a791b08f071379027c1c93fa0543\";}s:32:\"wp-admin/network/update-core.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a1223f017d52327b385cac03833f52ea\";}s:27:\"wp-admin/network/update.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ba45a05ecc211e8cab75b4d529ff75f7\";}s:28:\"wp-admin/network/upgrade.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"a123393039314ec615e2a706fd64f548\";}s:30:\"wp-admin/network/user-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"318173b6ccb63ed80ba3d08563c3ff14\";}s:29:\"wp-admin/network/user-new.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"96a0ac3684162747bcb8150467241ca2\";}s:26:\"wp-admin/network/users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"5a765cddcc0698c1c79d067b1d9d6732\";}s:20:\"wp-admin/network.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"26ff9c3919857b65f02c596a8505b10a\";}s:31:\"wp-admin/options-discussion.php\";a:2:{s:1:\"d\";i:1429049366;s:1:\"h\";s:32:\"637b93ae37dcc1d6ba58f8e42e7452bf\";}s:28:\"wp-admin/options-general.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f8d0d4d971959bb780039e37d69404e1\";}s:25:\"wp-admin/options-head.php\";a:2:{s:1:\"d\";i:1362172450;s:1:\"h\";s:32:\"bad695605e6db04e400a546f667eb70b\";}s:26:\"wp-admin/options-media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"bf8e37c333ae3154ff77263bf0a17fd8\";}s:30:\"wp-admin/options-permalink.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4b6a1fc27255843534fc5a02d252a624\";}s:28:\"wp-admin/options-reading.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"56e7717583d57de60217fe2d2ec84a61\";}s:28:\"wp-admin/options-writing.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5f94fd48e5cd4a3164026b8e18fa898c\";}s:20:\"wp-admin/options.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2ceb6fed736ecaede0135d13f254b61a\";}s:26:\"wp-admin/plugin-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0d7eedb060331aa2ca7d40b25b56c150\";}s:27:\"wp-admin/plugin-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"c4e4f72fe3511fc7d9a9ccaa7d352c0a\";}s:20:\"wp-admin/plugins.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"adb4146ada0e0cbe08da010f9b189cb0\";}s:21:\"wp-admin/post-new.php\";a:2:{s:1:\"d\";i:1420882162;s:1:\"h\";s:32:\"5ae636173e213f7e459d9cd6d64465e9\";}s:17:\"wp-admin/post.php\";a:2:{s:1:\"d\";i:1425609084;s:1:\"h\";s:32:\"131721684c0879e83aaccf102245a2e1\";}s:23:\"wp-admin/press-this.php\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"e53a55cd2ffb9f76c59963d54bc0124a\";}s:20:\"wp-admin/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9184e53f96bade3e7ae7cda9eddf7a26\";}s:21:\"wp-admin/revision.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f38ac6fdd266bcc623cd3dc27c9b428b\";}s:25:\"wp-admin/setup-config.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"b7b732e94ba1185b442b5efd8cfad02f\";}s:25:\"wp-admin/theme-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4e47516edb5d0f2ff241ee455fab19fc\";}s:26:\"wp-admin/theme-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a1f48e9aef5c17759f3b38807e4cb1f\";}s:19:\"wp-admin/themes.php\";a:2:{s:1:\"d\";i:1429525646;s:1:\"h\";s:32:\"4c673870742ef8131cf78de2a5d7a56e\";}s:18:\"wp-admin/tools.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"7b8738972ea367f2d5d45f5c2b185513\";}s:24:\"wp-admin/update-core.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"75c977ae43d7215f48fa3b44c080ab81\";}s:19:\"wp-admin/update.php\";a:2:{s:1:\"d\";i:1428042748;s:1:\"h\";s:32:\"86b7431cd724423305464f6c19608838\";}s:30:\"wp-admin/upgrade-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"5ef6dfd8ec7550e071581d5c14658efc\";}s:20:\"wp-admin/upgrade.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2d2636f9b8db893c678c6ba5367312de\";}s:19:\"wp-admin/upload.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3227b777a925fc4d90c7bc0408eb0582\";}s:23:\"wp-admin/user/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"99ec00da8d914b4efd2098a3e44ebe2d\";}s:23:\"wp-admin/user/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"8de88527f924b455fb6d14bb7805f25a\";}s:25:\"wp-admin/user/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d920b4fb1be2c2c780081d5b4b7de55a\";}s:26:\"wp-admin/user/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"1ba6cbb9e2a9d3deb348997492ed692e\";}s:23:\"wp-admin/user/index.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"c8fd98f7fdd52d78bdadf74e620789fa\";}s:22:\"wp-admin/user/menu.php\";a:2:{s:1:\"d\";i:1399377496;s:1:\"h\";s:32:\"a529e3d3c2bb86671fb9cc1145cf70ee\";}s:25:\"wp-admin/user/profile.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"b9fa17a9811195800079dda4b1262d03\";}s:27:\"wp-admin/user/user-edit.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"2a7a75a363b0f88f0b6d094a91ef65ea\";}s:22:\"wp-admin/user-edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d666cfa73d8a691a77a5559afef67889\";}s:21:\"wp-admin/user-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3a7fc7ec50ea3e2eabb6f2bef44d5eef\";}s:18:\"wp-admin/users.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"349265703c279fb2dd960cc53f35a581\";}s:20:\"wp-admin/widgets.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"86cb82a0d791c45f2f1a680f8f0a1f3a\";}}","no");
INSERT INTO `arc1542_options` VALUES("200","itsec_salts","1434398983","yes");
INSERT INTO `arc1542_options` VALUES("211","itsec_jquery_version","","yes");
INSERT INTO `arc1542_options` VALUES("213","_transient_twentyfifteen_categories","1","yes");
INSERT INTO `arc1542_options` VALUES("216","theme_mods_twentyfifteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1434399272;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `arc1542_options` VALUES("217","current_theme","The Hill","yes");
INSERT INTO `arc1542_options` VALUES("218","theme_mods_ut-thehill","a:2:{i:0;b:0;s:18:\"nav_menu_locations\";a:1:{s:11:\"single-menu\";i:2;}}","yes");
INSERT INTO `arc1542_options` VALUES("219","theme_switched","","yes");
INSERT INTO `arc1542_options` VALUES("221","wordfence_version","6.0.11","yes");
INSERT INTO `arc1542_options` VALUES("222","wordfenceActivated","1","yes");
INSERT INTO `arc1542_options` VALUES("223","wf_plugin_act_error","","yes");
INSERT INTO `arc1542_options` VALUES("234","_site_transient_timeout_theme_roots","1437027830","yes");
INSERT INTO `arc1542_options` VALUES("235","_site_transient_theme_roots","a:1:{s:10:\"ut-thehill\";s:7:\"/themes\";}","yes");
INSERT INTO `arc1542_options` VALUES("239","_site_transient_timeout_browser_3a343c40138c409717df5b87960d9dd7","1437630847","yes");
INSERT INTO `arc1542_options` VALUES("240","_site_transient_browser_3a343c40138c409717df5b87960d9dd7","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"43.0.2357.134\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("241","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1437069250","no");
INSERT INTO `arc1542_options` VALUES("242","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 21:49:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://wordpress.org/?v=4.3-beta3-33291\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 21:49:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3787\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2529:\"<p>WordPress 4.3 Beta 3 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta3.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, check out the <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">Beta 1</a> and <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\">Beta 2</a> blog posts. Some of the changes in Beta 3 include:</p>
<ul>
<li>Performance improvements for <strong>Menus in the Customizer</strong>, as well as bug fixes and visual enhancements.</li>
<li>Added <strong>Site Icon</strong> to the Customizer. The feature is now complete and requires lots of testing. Please help us ensure the site icon feature works well in both Settings and the Customizer.</li>
<li>The improvements to <strong>Passwords</strong> have been added to the installation flow. When installing and setting up WordPress, a strong password will be suggested to site administrators. Please test and let us know if you encounter issues.</li>
<li>Improved <strong>accessibility of comments and media list tables</strong>. If you use a screen reader, please let us know if you encounter any issues.</li>
<li>Lots and lots of code documentation improvements.</li>
<li><strong>Various other bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33286&amp;stop_rev=33141&amp;limit=150\">more than 140 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a>.</p>
<p><em>Want to test new things?</em><br />
<em>Wonder how four three shapes up?</em><br />
<em>Answer: beta three</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 22:04:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3769\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.3 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2876:\"<p>WordPress 4.3 Beta 2 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta2.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.3, <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Fixed an issue in beta 1 where an alert appeared when saving or publishing a new post/page for the first time.</li>
<li><strong><strong>Customizer</strong></strong> improvements including enhanced accessibility, smoother menu creation and location assignment, and the ability to handle nameless menus. Please help us test menus in the Customizer to fix any remaining edge cases!</li>
<li>More robust<strong> list tables</strong> with full content support on small screens and a fallback for the primary column for custom list tables. We&#8217;d love to know how these list tables, such as All Posts and Comments, work for you now on small screen devices.</li>
<li>The <strong>Site Icon</strong> feature has been improved so that cropping is skipped if the image is the exact size (512px square) and the media modal now suggests a minimum icon size. Please let us know how the flow feels and if you encounter any glitches!</li>
<li>The <strong>toolbar</strong> now has a direct link to the customizer, along with quick access to themes, widgets, and menus in the dashboard.</li>
<li>We enabled <strong>utf8mb4 for MySQL</strong> extension users, which was previously unintentionally limited to MySQLi users. Please let us know if you run into any issues.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=33138&amp;stop_rev=33046\">almost 100 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;milestone=4.3&amp;group=component&amp;order=priority\">everything we’ve fixed</a>.</p>
<p><em>Edges polished up</em><br />
<em>Features meliorated</em><br />
<em>Beta Two: go test!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordCamps Update\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/news/2015/07/wordcamps-update/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordcamps-update/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 16:13:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:9:\"Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:6:\"Events\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:8:\"WordCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3758\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:311:\"Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year. There have been 39 WordCamps in 2015 so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Andrea Middleton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:9419:\"<p>Last week saw the halfway point for 2015, yay! This seems like a good time to update you on WordCamp happenings in the first half of this year.</p>
<p>There have been <a href=\"https://central.wordcamp.org/schedule/past-wordcamps/\">39 WordCamps in 2015</a> so far, with events organized in 17 different countries and on 5 continents. More than 14,000 people have registered for WordCamp tickets so far this year, isn&#8217;t that amazing?</p>
<p><a href=\"https://europe.wordcamp.org/2015/\">WordCamp Europe</a> was held in Seville, Spain just a few weeks ago, with close to 1,000 registered participants and over 500 live stream participants. You can watch  <a href=\"http://wordpress.tv/2015/07/04/matt-mullenweg-keynote-qanda-wordcamp-europe-2015/\">Matt Mullenweg’s keynote Q&amp;A</a> session from WordCamp Europe right now on WordPress.tv.</p>
<p>WordPress.tv has published 537 videos so far in 2015 from WordCamps around the world. Some of the more popular 2015 WordCamp talks on WordPress.tv include <a href=\"http://wordpress.tv/2015/03/13/tammie-lister-theme-dont-be-my-everything/\">Tammie Lister: Theme, Don’t Be My Everything </a>from WordCamp Maui, <a href=\"http://wordpress.tv/2015/04/17/jenny-munn-seo-for-2015-whats-in-whats-out-and-how-to-be-in-it-to-win-it-for-good/\">Jenny Munn: SEO for 2015 – What’s In, What’s Out and How to Be In It to Win It (For Good)</a> from WordCamp Atlanta, <a href=\"http://wordpress.tv/2015/02/27/fabrice-ducarme-les-constructeurs-de-page-pour-wordpress/\">Fabrice Ducarme: Les Constructeurs de Page pour WordPress</a> from WordCamp Paris, <a href=\"http://wordpress.tv/2015/06/02/ben-furfie-how-to-value-price-websites/\">Ben Furfie: How to Value Price Websites</a> from WordCamp London, and <a href=\"http://wordpress.tv/2015/06/09/morten-rand-hendriksen-building-themes-from-scratch-using-underscores-_s/\">Morten Rand-Hendriksen: Building Themes From Scratch Using Underscores (_S)</a> from WordCamp Seattle. Check them out!</p>
<h3>Lots of great WordCamps are still to come</h3>
<p><a href=\"http://ma.tt/2015/06/wordcamp-us-survey/\">WordCamp US</a> is currently in pre-planning, in the process of deciding on a host city. The following cities have proposed themselves as a great place to host the first WordCamp US: Chattanooga, Chicago, Detroit, Orlando, Philadelphia, and Phoenix. It&#8217;s possible the first WordCamp US will be held in 2016 so we can organize the best first WordCamp US imaginable.</p>
<p>At this time, there are 28 <a href=\"https://central.wordcamp.org/schedule/\">WordCamps</a>, in 9 different countries, that have announced their dates for the rest of 2015. Twelve of these have tickets on sale:</p>
<ul>
<li><a href=\"https://columbus.wordcamp.org/2015/\">WordCamp Columbus</a>, Columbus, Ohio: July 17-18</li>
<li><a href=\"https://scranton.wordcamp.org/2015/\">WordCamp Scranton</a>, Scranton, Pennsylvania: July 18</li>
<li><a href=\"https://boston.wordcamp.org/2015/\">WordCamp Boston</a>, Boston, Massachussetts: July 18-19</li>
<li><a href=\"https://milwaukee.wordcamp.org/2015/\">WordCamp Milwaukee</a>, Milwaukee, Wisconsin: July 24-26</li>
<li><a href=\"https://asheville.wordcamp.org/2015/\">WordCamp Asheville</a>, Asheville, North Carolina: July 24-26</li>
<li><a href=\"https://kansai.wordcamp.org/2015/\">WordCamp Kansai</a>, Kansai, Japan: July 25-26</li>
<li><a href=\"https://fayetteville.wordcamp.org/2015/\">WordCamp Fayetteville</a>, Fayetteville, Arkansas: July 31-August 2</li>
<li><a href=\"https://brighton.buddycamp.org/2015/\">BuddyCamp Brighton</a>,  Brighton, UK: August 8</li>
<li><a href=\"https://vancouver.wordcamp.org/2015/\">WordCamp Vancouver, BC,</a> Vancouver, BC, Canada: August 15-16</li>
<li><a href=\"https://russia.wordcamp.org/2015/\">WordCamp Russia</a>, Moscow, Russia: August 15</li>
<li><a href=\"https://norrkoping.wordcamp.org/2015/\">WordCamp Norrköping</a>, Norrköping, Sweden: August 28-29</li>
<li><a href=\"https://croatia.wordcamp.org/2015/\">WordCamp Croatia</a>, Rijeka, Croatia: September 5-6</li>
<li><a href=\"https://krakow.wordcamp.org/2015/\">WordCamp Krakow,</a>  Krakow, Poland: September 12-13</li>
<li><a href=\"https://nyc.wordcamp.org/2015/\">WordCamp NYC</a>, New York City, New York: October 30-November 1</li>
</ul>
<p>The other 16 events don’t have tickets on sale yet, but they’ve set their dates! Subscribe to the sites to find out when registration opens:</p>
<ul>
<li><a href=\"https://pune.wordcamp.org/2015/\">WordCamp Pune</a>, Pune, India: September 6</li>
<li><a href=\"https://capetown.wordcamp.org/2015/\">WordCamp Cape Town</a>, Cape Town, South Africa: September 10-11</li>
<li><a href=\"https://baltimore.wordcamp.org/2015/\">WordCamp Baltimore</a>, Baltimore, Maryland: September 12</li>
<li><a href=\"https://slc.wordcamp.org/2015/\">WordCamp Salt Lake City</a>, Salt Lake City, Utah: September 12</li>
<li><a href=\"https://lithuania.wordcamp.org/2015/\">WordCamp Lithuania</a>, Vilnius, Lithuania: September 19</li>
<li><a href=\"https://vegas.wordcamp.org/2015\">WordCamp Vegas</a>, Las Vegas, Nevada: September 19-20</li>
<li><a href=\"https://switzerland.wordcamp.org/2015/\">WordCamp Switzerland</a>, Zurich, Switzerland: September 19-20</li>
<li><a href=\"https://tampa.wordcamp.org/2015/\">WordCamp Tampa</a>, Tampa, Florida: September 25-27</li>
<li><a href=\"https://rhodeisland.wordcamp.org/2015/\">WordCamp Rhode Island</a>,  Providence, Rhode Island: September 25-26</li>
<li><a href=\"https://la.wordcamp.org/2015/\">WordCamp Los Angeles</a>, Los Angeles, California: September 26-27</li>
<li><a href=\"https://denmark.wordcamp.org/2015/\">WordCamp Denmark,</a>  Copenhagen, Denmark: October 3-4</li>
<li><a href=\"https://toronto.wordcamp.org/2015\">WordCamp Toronto</a>, Toronto, Ontario, Canada: October 3-4</li>
<li><a href=\"https://hamptonroads.wordcamp.org/2015/\">WordCamp Hampton Roads, </a>  Virginia Beach, VA, USA: October 17</li>
<li><a href=\"https://annarbor.wordcamp.org/2015\">WordCamp Ann Arbor</a>, Ann Arbor, Michigan: October 24</li>
<li><a href=\"https://portland.wordcamp.org/2015/\">WordCamp Portland</a>,  Portland, OR: October 24-25</li>
</ul>
<p>On top of all those exciting community events, there are 26 WordCamps in pre-planning as they look for the right event space.  If you have a great idea for a free or cheap WordCamp venue in any of the below locations, get in touch with the organizers through the WordCamp sites:</p>
<ul>
<li><a href=\"https://dfw.wordcamp.org/2015/\">WordCamp DFW</a>:  Dallas/Fort Worth, Texas</li>
<li><a href=\"https://riodejaneiro.wordcamp.org/2015/\">WordCamp Rio</a>: Rio de Janeiro, Brazil</li>
<li><a href=\"https://saratoga.wordcamp.org/2015/\">WordCamp Saratoga</a>:  Saratoga Springs, New York</li>
<li><a href=\"https://sofia.wordcamp.org/2015\">WordCamp Sofia</a>:  Sofia, Bulgaria</li>
<li><a href=\"https://austin.wordcamp.org/2015/\">WordCamp Austin</a>:  Austin, TX</li>
<li><a href=\"https://ottawa.wordcamp.org/2015/\">WordCamp Ottawa</a>:  Ottawa, Canada</li>
<li><a href=\"https://charleston.wordcamp.org/2015/\">WordCamp Charleston</a>:  Charleston, South Carolina</li>
<li><a href=\"https://chicago.wordcamp.org/2015/\">WordCamp Chicago</a>:  Chicago, Illinois</li>
<li><a href=\"https://albuquerque.wordcamp.org/2015/\">WordCamp Albuquerque</a>:  Albuquerque, New Mexico</li>
<li><a href=\"https://prague.wordcamp.org/2015/\">WordCamp Prague</a>:  Prague, Czech Republic</li>
<li><a href=\"https://seoul.wordcamp.org/2014/\">WordCamp Seoul: </a>Seoul, South Korea</li>
<li><a href=\"https://louisville.wordcamp.org/2014/\">WordCamp Louisville</a>: Louisville, Kentucky</li>
<li><a href=\"https://omaha.wordcamp.org/2015/\">WordCamp Omaha</a>:  Omaha, Nebraska</li>
<li><a href=\"https://grandrapids.wordcamp.org/2015/\">WordCamp Grand Rapids</a>:  Grand Rapids, Michigan</li>
<li><a href=\"https://easttroy.wordcamp.org/2015/\">WordCamp East Troy</a>:  East Troy, Wisconsin</li>
<li><a href=\"https://palmademallorca.wordcamp.org/2015\">WordCamp Mallorca</a>: Palma de Mallorca, Spain</li>
<li><a href=\"https://edinburgh.wordcamp.org/2015/\">WordCamp Edinburgh</a>:  Edinburgh, United Kingdom</li>
<li><a href=\"https://orlando.wordcamp.org/2015/\">WordCamp Orlando</a>:  Orlando, Florida</li>
<li><a href=\"https://mexico.wordcamp.org/2015/\">WordCamp Mexico City</a>:  Mexico City, Mexico</li>
<li><a href=\"https://netherlands.wordcamp.org/2015/\">WordCamp Netherlands</a>:  Utrecht, Netherlands</li>
<li><a href=\"https://phoenix.wordcamp.org/2016/\">WordCamp Phoenix</a>:  Phoenix, Arizona</li>
<li><a href=\"https://saopaulo.wordcamp.org/2015/\">WordCamp São Paulo</a>:  São Paulo, Brazil</li>
<li><a href=\"https://manchester.wordcamp.org/2015/\">WordCamp Manchester</a>:  Manchester, United Kingdom</li>
<li><a href=\"https://tokyo.wordcamp.org/2015/\">WordCamp Tokyo</a>:  Tokyo, Japan</li>
<li><a href=\"https://lima.wordcamp.org/2015/\">WordCamp Lima</a>:  Lima, Peru</li>
<li><a href=\"https://seattle.wordcamp.org/2015-beginner/\">WordCamp Seattle: Beginner</a>: Seattle, WA</li>
</ul>
<p>Don’t see your city on the list, but yearning for a local WordCamp? WordCamps are organized by local volunteers from the WordPress community, and we have a whole team of people to support new organizers setting up a first-time WordCamp. If you want to bring WordCamp to town, check out how you can <a href=\"https://central.wordcamp.org/become-an-organizer/\">become a WordCamp organizer</a>!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/news/2015/07/wordcamps-update/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.3 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 01:30:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3738\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.3 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Konstantin Obenland\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4352:\"<p>WordPress 4.3 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.3-beta1.zip\">download the beta here</a> (zip).</p>
<p>4.3 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Menus</strong> can now be managed with the <strong>Customizer</strong>, which allows you to live preview changes you’re making without changing your site for visitors until you’re ready. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href=\"https://core.trac.wordpress.org/ticket/32576\">#32576</a>).</li>
<li>Take control of another piece of your site with the <strong>Site Icon</strong> feature. You can now manage your site’s favicon and app icon from the admin area (<a href=\"https://core.trac.wordpress.org/ticket/16434\">#16434</a>).</li>
<li>We put a lot of work into <strong>Better Passwords</strong> throughout WordPress. Now, WordPress will limit the life time of password resets, no longer send passwords via email, and generate and suggest secure passwords for you. Try it out and let us know what you think! (<a href=\"https://core.trac.wordpress.org/ticket/32589\">#32589</a>)</li>
<li>We’ve also added <strong>Editor Improvements</strong>. Certain text patterns are automatically transformed as you type, including <code>*</code> and <code>-</code> transforming into unordered lists, <code>1.</code> and <code>1)</code> for ordered lists, <code>&gt;</code> for blockquotes and two to six number signs (<code>#</code>) for headings (<a href=\"https://core.trac.wordpress.org/ticket/31441\">#31441</a>).</li>
<li>We’ve improved the <strong>list view</strong> across the admin dashboard. Now, when you view your posts and pages <strong>on small screen devices</strong>, columns are not truncated and can be toggled into view (<a href=\"https://core.trac.wordpress.org/ticket/32395\">#32395</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a few of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href=\"https://make.wordpress.org/core/2015/06/09/eliminating-shared-taxonomy-terms-in-wordpress-4-3/\">now be split</a> into separate terms on update to 4.3. Please let us know if you hit any snags (<a href=\"https://core.trac.wordpress.org/ticket/30261\">#30261</a>).</li>
<li>Added <code>singular.php</code> to the template hierarchy as a fallback for <code>single.php</code> and <code>page.php</code>. (<a href=\"https://core.trac.wordpress.org/ticket/22314\">#22314</a>).</li>
<li>The old Distraction Free Writing code was removed (<a href=\"https://core.trac.wordpress.org/ticket/30949\">#30949</a>).</li>
<li>List tables now can (and often should) have a primary column defined. We’re working on a fallback for existing custom list tables but right now they likely have some breakage in the aforementioned responsive view (<a href=\"https://core.trac.wordpress.org/ticket/25408\">#25408</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.3, <a href=\"https://make.wordpress.org/core/tag/4-3/\">check out all 4.3-tagged posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3\">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Site icons for all</em><br />
<em>Live preview menu changes</em><br />
<em>Four three beta now</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 May 2015 02:24:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3718\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:355:\"WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3194:\"<p>WordPress 4.2.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>Version 4.2.2 addresses two security issues:</p>
<ul>
<li>The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site scripting attack. All affected themes and plugins hosted on <a href=\"https://wordpress.org/\">WordPress.org</a> (including the Twenty Fifteen default theme) have been updated today by the WordPress security team to address this issue by removing this nonessential file. To help protect other Genericons usage, WordPress 4.2.2 proactively scans the wp-content directory for this HTML file and removes it. Reported by Robert Abela of <a href=\"http://netsparker.com\">Netsparker</a>.</li>
<li>WordPress versions 4.2 and earlier are affected by a <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\">critical cross-site scripting vulnerability</a>, which could enable anonymous users to compromise a site. WordPress 4.2.2 includes a comprehensive fix for this issue. Reported separately by Rice Adu and Tong Shi.</li>
</ul>
<p>The release also includes hardening for a potential cross-site scripting vulnerability when using the visual editor. This issue was reported by Mahadev Subedi.</p>
<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.2 also contains fixes for 13 bugs from 4.2. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32418&amp;stop_rev=32324\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.2</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.2.</p>
<p>Thanks to everyone who contributed to 4.2.2:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, and <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 4.2.1 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Apr 2015 18:34:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:366:\"WordPress 4.2.1 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by Jouko Pynnönen. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1010:\"<p>WordPress 4.2.1 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by <a href=\"http://klikki.fi/\">Jouko Pynnönen</a>.</p>
<p>WordPress 4.2.1 has begun to roll out as an automatic background update, for sites that <a href=\"https://wordpress.org/plugins/background-update-tester/\">support</a> those.</p>
<p>For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.1\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 4.2 “Powell”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wordpress.org/news/2015/04/powell/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/powell/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Apr 2015 18:35:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3642\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:343:\"Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist Bud Powell, is available for download or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally. An easier way to share content Clip it, edit it, publish it. Get familiar with the new and improved Press This. From [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:29440:\"<p>Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist <a href=\"https://en.wikipedia.org/wiki/Bud_Powell\">Bud Powell</a>, is available for <a href=\"https://wordpress.org/download/\">download</a> or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally.</p>
<div id=\"v-e9kH4FzP-1\" class=\"video-player\"><embed id=\"v-e9kH4FzP-1-video\" src=\"https://v0.wordpress.com/player.swf?v=1.04&amp;guid=e9kH4FzP&amp;isDynamicSeeking=true\" type=\"application/x-shockwave-flash\" width=\"692\" height=\"388\" title=\"Introducing WordPress 4.2 &quot;Powell&quot;\" wmode=\"direct\" seamlesstabbing=\"true\" allowfullscreen=\"true\" allowscriptaccess=\"always\" overstretch=\"true\"></embed></div>
<hr />
<h2 style=\"text-align: center\">An easier way to share content</h2>
<p><img class=\"alignnone size-full wp-image-3677\" src=\"https://wordpress.org/news/files/2015/04/4.2-press-this-2.jpg\" alt=\"Press This\" width=\"1000\" height=\"832\" />Clip it, edit it, publish it. Get familiar with the new and improved Press This. From the Tools menu, add Press This to your browser bookmark bar or your mobile device home screen. Once installed you can share your content with lightning speed. Sharing your favorite videos, images, and content has never been this fast or this easy.</p>
<hr />
<h2 style=\"text-align: center\">Extended character support</h2>
<p><img class=\"alignnone size-full wp-image-3676\" src=\"https://wordpress.org/news/files/2015/04/4.2-characters.png\" alt=\"Character support for emoji, special characters\" width=\"1000\" height=\"832\" />Writing in WordPress, whatever your language, just got better. WordPress 4.2 supports a host of new characters out-of-the-box, including native Chinese, Japanese, and Korean characters, musical and mathematical symbols, and hieroglyphs.</p>
<p>Don’t use any of those characters? You can still have fun — emoji are now available in WordPress! Get creative and decorate your content with <img src=\"https://s.w.org/images/core/emoji/72x72/1f499.png\" alt=\"💙\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f438.png\" alt=\"🐸\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f412.png\" alt=\"🐒\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f355.png\" alt=\"🍕\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, and all the many other <a href=\"https://codex.wordpress.org/Emoji\">emoji</a>.</p>
<hr />
<div><img class=\"alignright size-medium wp-image-3656\" src=\"https://wordpress.org/news/files/2015/04/4.2-theme-switcher-300x230.png\" alt=\"Customizer theme switcher\" width=\"288\" height=\"221\" /></p>
<h3>Switch themes in the Customizer</h3>
<p>Browse and preview your installed themes from the Customizer. Make sure the theme looks great with your content, before it debuts on your site.</p>
</div>
<div style=\"clear: both\"></div>
<div><img class=\"alignright size-medium wp-image-3653\" src=\"https://wordpress.org/news/files/2015/04/4.2-embeds-300x230.png\" alt=\"Tumbr.com oEmbed example\" width=\"288\" height=\"221\" /></p>
<h3>Even more embeds</h3>
<p>Paste links from Tumblr.com and Kickstarter and watch them magically appear right in the editor. With every release, your publishing and editing experience get closer together.</p>
</div>
<div style=\"clear: both\"></div>
<div>
<p><img class=\"alignright size-medium wp-image-3654\" src=\"https://wordpress.org/news/files/2015/04/4.2-plugins-300x230.png\" alt=\"Inline plugin updates\" width=\"288\" height=\"221\" /></p>
<h3>Streamlined plugin updates</h3>
<p>Goodbye boring loading screen, hello smooth and simple plugin updates. Click <em>Update Now</em> and watch the magic happen.</p>
</div>
<div style=\"clear: both\"></div>
<hr />
<h2 style=\"text-align: center\">Under the Hood</h2>
<h5>utf8mb4 support</h5>
<p>Database character encoding has changed from utf8 to utf8mb4, which adds support for a whole range of new 4-byte characters.</p>
<h5>JavaScript accessibility</h5>
<p>You can now send audible notifications to screen readers in JavaScript with <code>wp.a11y.speak()</code>. Pass it a string, and an update will be sent to a dedicated ARIA live notifications area.</p>
<h5>Shared term splitting</h5>
<p>Terms shared across multiple taxonomies will be split when one of them is updated. Find out more in the <a href=\"https://developer.wordpress.org/plugins/taxonomy/working-with-split-terms-in-wp-4-2/\">Plugin Developer Handbook</a>.</p>
<h5>Complex query ordering</h5>
<p><code>WP_Query</code>, <code>WP_Comment_Query</code>, and <code>WP_User_Query</code> now support complex ordering with named meta query clauses.</p>
<hr />
<h2 style=\"text-align: center\">The Team</h2>
<p><a class=\"alignleft\" href=\"https://profiles.wordpress.org/drewapicture\"><img src=\"https://www.gravatar.com/avatar/95c934fa2c3362794bf62ff8c59ada08?d=mm&amp;s=150&amp;r=G\" alt=\"Drew Jaynes\" width=\"90\" height=\"90\" /></a>This release was led by <a href=\"http://werdswords.com\">Drew Jaynes</a>, with the help of these fine individuals. There are 283 contributors with props in this release, a new high. Pull up some Bud Powell on your music service of choice, and check out some of their profiles:</p>
<a href=\"https://profiles.wordpress.org/mercime\">@mercime</a>, <a href=\"https://profiles.wordpress.org/a5hleyrich\">A5hleyRich</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abhishekfdd\">abhishekfdd</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/alexkingorg\">Alex King</a>, <a href=\"https://profiles.wordpress.org/viper007bond\">Alex Mills (Viper007Bond)</a>, <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/collinsinternet\">Allan Collins</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/awbauer\">Andrew Bauer</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/norcross\">Andrew Norcross</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/ankitgadertcampcom\">Ankit Gade</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta\">Ankit K Gupta</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/aramzs\">Aram Zucker-Scharff</a>, <a href=\"https://profiles.wordpress.org/arminbraun\">ArminBraun</a>, <a href=\"https://profiles.wordpress.org/ashfame\">Ashfame</a>, <a href=\"https://profiles.wordpress.org/filosofo\">Austin Matzko</a>, <a href=\"https://profiles.wordpress.org/avryl\">avryl</a>, <a href=\"https://profiles.wordpress.org/barrykooij\">Barry Kooij</a>, <a href=\"https://profiles.wordpress.org/beaulebens\">Beau Lebens</a>, <a href=\"https://profiles.wordpress.org/bendoh\">Ben Doherty (Oomph, Inc)</a>, <a href=\"https://profiles.wordpress.org/bananastalktome\">Billy Schneider</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone B. Gorges</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/krogsgard\">Brian Krogsgard</a>, <a href=\"https://profiles.wordpress.org/bswatson\">Brian Watson</a>, <a href=\"https://profiles.wordpress.org/calevans\">CalEvans</a>, <a href=\"https://profiles.wordpress.org/carolinegeven\">carolinegeven</a>, <a href=\"https://profiles.wordpress.org/caseypatrickdriscoll\">Casey Driscoll</a>, <a href=\"https://profiles.wordpress.org/caspie\">Caspie</a>, <a href=\"https://profiles.wordpress.org/cdog\">Catalin Dogaru</a>, <a href=\"https://profiles.wordpress.org/chipbennett\">Chip Bennett</a>, <a href=\"https://profiles.wordpress.org/chipx86\">chipx86</a>, <a href=\"https://profiles.wordpress.org/chrico\">ChriCo</a>, <a href=\"https://profiles.wordpress.org/cbaldelomar\">Chris Baldelomar</a>, <a href=\"https://profiles.wordpress.org/c3mdigital\">Chris Olbekson</a>, <a href=\"https://profiles.wordpress.org/cfoellmann\">Christian Foellmann</a>, <a href=\"https://profiles.wordpress.org/cfinke\">Christopher Finke</a>, <a href=\"https://profiles.wordpress.org/clifgriffin\">Clifton Griffin</a>, <a href=\"https://profiles.wordpress.org/codix\">Code Master</a>, <a href=\"https://profiles.wordpress.org/corphi\">Corphi</a>, <a href=\"https://profiles.wordpress.org/couturefreak\">Courtney Ivey</a>, <a href=\"https://profiles.wordpress.org/craig-ralston\">Craig Ralston</a>, <a href=\"https://profiles.wordpress.org/cweiske\">cweiske</a>, <a href=\"https://profiles.wordpress.org/extendwings\">Daisuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/timersys\">Damian</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/redsweater\">Daniel Jalkut (Red Sweater)</a>, <a href=\"https://profiles.wordpress.org/dkotter\">Darin Kotter</a>, <a href=\"https://profiles.wordpress.org/nerrad\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/dllh\">Daryl L. L. Houston (dllh)</a>, <a href=\"https://profiles.wordpress.org/dmchale\">Dave McHale</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/davidanderson\">David Anderson</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/davideugenepratt\">davideugenepratt</a>, <a href=\"https://profiles.wordpress.org/davidhamiltron\">davidhamiltron</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/valendesigns\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/dsmart\">Derek Smart</a>, <a href=\"https://profiles.wordpress.org/designsimply\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dipeshkakadiya\">dipesh.kakadiya</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/doublesharp\">doublesharp</a>, <a href=\"https://profiles.wordpress.org/dzerycz\">DzeryCZ</a>, <a href=\"https://profiles.wordpress.org/kucrut\">Dzikri Aziz</a>, <a href=\"https://profiles.wordpress.org/emazovetskiy\">e.mazovetskiy</a>, <a href=\"https://profiles.wordpress.org/oso96_2000\">Eduardo Reveles</a>, <a href=\"https://profiles.wordpress.org/cais\">Edward Caissie</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/elliottcarlson\">elliottcarlson</a>, <a href=\"https://profiles.wordpress.org/enej\">enej</a>, <a href=\"https://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"https://profiles.wordpress.org/ebinnion\">Eric Binnion</a>, <a href=\"https://profiles.wordpress.org/ethitter\">Erick Hitter</a>, <a href=\"https://profiles.wordpress.org/evansolomon\">Evan Solomon</a>, <a href=\"https://profiles.wordpress.org/fab1en\">Fabien Quatravaux</a>, <a href=\"https://profiles.wordpress.org/fhwebcs\">fhwebcs</a>, <a href=\"https://profiles.wordpress.org/floriansimeth\">Florian Simeth</a>, <a href=\"https://profiles.wordpress.org/bueltge\">Frank Bueltge</a>, <a href=\"https://profiles.wordpress.org/frankpw\">Frank P. Walentynowicz</a>, <a href=\"https://profiles.wordpress.org/f-j-kaiser\">Franz Josef Kaiser</a>, <a href=\"https://profiles.wordpress.org/garyc40\">Gary Cao</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/geertdd\">Geert De Deckere</a>, <a href=\"https://profiles.wordpress.org/genkisan\">genkisan</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/grahamarmfield\">Graham Armfield</a>, <a href=\"https://profiles.wordpress.org/webord\">Gustavo Bordoni</a>, <a href=\"https://profiles.wordpress.org/hakre\">hakre</a>, <a href=\"https://profiles.wordpress.org/harishchaudhari\">Harish Chaudhari</a>, <a href=\"https://profiles.wordpress.org/hauvong\">hauvong</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/herbmillerjr\">herbmillerjr</a>, <a href=\"https://profiles.wordpress.org/hew\">Hew</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/horike\">horike</a>, <a href=\"https://profiles.wordpress.org/hlashbrooke\">Hugh Lashbrooke</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianmjones\">ianmjones</a>, <a href=\"https://profiles.wordpress.org/idealien\">idealien</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jacklenox\">Jack Lenox</a>, <a href=\"https://profiles.wordpress.org/jamescollins\">James Collins</a>, <a href=\"https://profiles.wordpress.org/janhenckens\">janhenckens</a>, <a href=\"https://profiles.wordpress.org/jfarthing84\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/cheffheid\">Jeffrey de Wit</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jesin\">Jesin A</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">jipmoors</a>, <a href=\"https://profiles.wordpress.org/jartes\">Joan Artes</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/yo-l1982\">Joel Bernerman</a>, <a href=\"https://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johneckman\">John Eckman</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/jlevandowski\">John Levandowski</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/joostdekeijzer\">joost de keijzer</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jcastaneda\">Jose Castaneda</a>, <a href=\"https://profiles.wordpress.org/joshlevinson\">Josh Levinson</a>, <a href=\"https://profiles.wordpress.org/jphase\">jphase</a>, <a href=\"https://profiles.wordpress.org/juliobox\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/kopepasah\">Justin Kopepasah</a>, <a href=\"https://profiles.wordpress.org/jtsternberg\">Justin Sternberg</a>, <a href=\"https://profiles.wordpress.org/justincwatt\">Justin Watt</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"https://profiles.wordpress.org/trepmal\">Kailey (trepmal)</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kevdotbadger\">Kevin Ruscoe</a>, <a href=\"https://profiles.wordpress.org/kpdesign\">Kim Parsell</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/mindrun\">Leonard</a>, <a href=\"https://profiles.wordpress.org/leopeo\">Leonardo Giacone</a>, <a href=\"https://profiles.wordpress.org/lgladdy\">Liam Gladdy</a>, <a href=\"https://profiles.wordpress.org/maimairel\">maimairel</a>, <a href=\"https://profiles.wordpress.org/mako09\">Mako</a>, <a href=\"https://profiles.wordpress.org/funkatronic\">Manny Fleurmond</a>, <a href=\"https://profiles.wordpress.org/marcelomazza\">marcelomazza</a>, <a href=\"https://profiles.wordpress.org/marcochiesi\">Marco Chiesi</a>, <a href=\"https://profiles.wordpress.org/mkaz\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/nofearinc\">Mario Peshev</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius (Clorith)</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/senff\">Mark Senff</a>, <a href=\"https://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/mgibbs189\">Matt Gibbs</a>, <a href=\"https://profiles.wordpress.org/sivel\">Matt Martz</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/mattwiebe\">Matt Wiebe</a>, <a href=\"https://profiles.wordpress.org/mzak\">Matt Zak</a>, <a href=\"https://profiles.wordpress.org/mboynes\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheweppelsheimer\">Matthew Eppelsheimer</a>, <a href=\"https://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/mattyrob\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/maxcutler\">Max Cutler</a>, <a href=\"https://profiles.wordpress.org/mehulkaklotar\">mehulkaklotar</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/meloniq\">meloniq</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Michael Adams (mdawaffe)</a>, <a href=\"https://profiles.wordpress.org/michael-arestad\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/tw2113\">Michael Beckwith</a>, <a href=\"https://profiles.wordpress.org/michalzuber\">michalzuber</a>, <a href=\"https://profiles.wordpress.org/mdgl\">Mike Glendinning</a>, <a href=\"https://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/thaicloud\">Mike Jordan</a>, <a href=\"https://profiles.wordpress.org/mikeschinkel\">Mike Schinkel</a>, <a href=\"https://profiles.wordpress.org/mikengarrett\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinic</a>, <a href=\"https://profiles.wordpress.org/mmn-o\">mmn-o</a>, <a href=\"https://profiles.wordpress.org/batmoo\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/momdad\">MomDad</a>, <a href=\"https://profiles.wordpress.org/morganestes\">Morgan Estes</a>, <a href=\"https://profiles.wordpress.org/morpheu5\">Morpheu5</a>, <a href=\"https://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/nathan_dawson\">nathan_dawson</a>, <a href=\"https://profiles.wordpress.org/neil_pie\">Neil Pie</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/nicnicnicdevos\">nicnicnicdevos</a>, <a href=\"https://profiles.wordpress.org/nikv\">Nikhil Vimal</a>, <a href=\"https://profiles.wordpress.org/ninnypants\">ninnypants</a>, <a href=\"https://profiles.wordpress.org/nitkr\">nitkr</a>, <a href=\"https://profiles.wordpress.org/nunomorgadinho\">Nuno Morgadinho</a>, <a href=\"https://profiles.wordpress.org/originalexe\">OriginalEXE</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya-1\">Paresh Radadiya</a>, <a href=\"https://profiles.wordpress.org/pathawks\">Pat Hawks</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/paulschreiber\">Paul Schreiber</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/sirbrillig\">Payton Swick</a>, <a href=\"https://profiles.wordpress.org/petemall\">Pete Mall</a>, <a href=\"https://profiles.wordpress.org/gungeekatx\">Pete Nelson</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/mordauk\">Pippin Williamson</a>, <a href=\"https://profiles.wordpress.org/podpirate\">podpirate</a>, <a href=\"https://profiles.wordpress.org/postpostmodern\">postpostmodern</a>, <a href=\"https://profiles.wordpress.org/nprasath002\">Prasath Nadarajah</a>, <a href=\"https://profiles.wordpress.org/prasoon2211\">prasoon2211</a>, <a href=\"https://profiles.wordpress.org/cyman\">Primoz Cigler</a>, <a href=\"https://profiles.wordpress.org/r-a-y\">r-a-y</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rahulbhangale\">rahulbhangale</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/lamosty\">Rastislav Lamos</a>, <a href=\"https://profiles.wordpress.org/ravindra-pal-singh\">Ravindra Pal Singh</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/ritteshpatel\">Ritesh Patel</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/rmarks\">Ryan Marks</a>, <a href=\"https://profiles.wordpress.org/welcher\">Ryan Welcher</a>, <a href=\"https://profiles.wordpress.org/sagarjadhav\">Sagar Jadhav</a>, <a href=\"https://profiles.wordpress.org/solarissmoke\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/samo9789\">samo9789</a>, <a href=\"https://profiles.wordpress.org/samuelsidler\">Samuel Sidler</a>, <a href=\"https://profiles.wordpress.org/sgrant\">Scott Grant</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scottgonzalez\">scott.gonzalez</a>, <a href=\"https://profiles.wordpress.org/greglone\">ScreenfeedFr</a>, <a href=\"https://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"https://profiles.wordpress.org/seanchayes\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sergejmueller\">Sergej Muller</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sevenspark\">sevenspark</a>, <a href=\"https://profiles.wordpress.org/simonwheatley\">Simon Wheatley</a>, <a href=\"https://profiles.wordpress.org/siobhan\">Siobhan</a>, <a href=\"https://profiles.wordpress.org/sippis\">sippis</a>, <a href=\"https://profiles.wordpress.org/slobodanmanic\">Slobodan Manic</a>, <a href=\"https://profiles.wordpress.org/stephdau\">Stephane Daury</a>, <a href=\"https://profiles.wordpress.org/sillybean\">Stephanie Leary</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevegrunwell\">Steve Grunwell</a>, <a href=\"https://profiles.wordpress.org/stevehickeydesign\">stevehickeydesign</a>, <a href=\"https://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, <a href=\"https://profiles.wordpress.org/iamtakashi\">Takashi Irie</a>, <a href=\"https://profiles.wordpress.org/hissy\">Takuro Hishikawa</a>, <a href=\"https://profiles.wordpress.org/themiked\">theMikeD</a>, <a href=\"https://profiles.wordpress.org/thomaswm\">thomaswm</a>, <a href=\"https://profiles.wordpress.org/ipm-frommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/tillkruess\">Till</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tiqbiz\">tiqbiz</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tmeister\">tmeister</a>, <a href=\"https://profiles.wordpress.org/tschutter\">Tobias Schutter</a>, <a href=\"https://profiles.wordpress.org/tobiasbg\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tomdxw\">tomdxw</a>, <a href=\"https://profiles.wordpress.org/travisnorthcutt\">Travis Northcutt</a>, <a href=\"https://profiles.wordpress.org/trishasalas\">trishasalas</a>, <a href=\"https://profiles.wordpress.org/tywayne\">Ty Carlson</a>, <a href=\"https://profiles.wordpress.org/uamv\">UaMV</a>, <a href=\"https://profiles.wordpress.org/desaiuditd\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/sorich87\">Ulrich Sossou</a>, <a href=\"https://profiles.wordpress.org/veritaserum\">Veritaserum</a>, <a href=\"https://profiles.wordpress.org/voldemortensen\">voldemortensen</a>, <a href=\"https://profiles.wordpress.org/volodymyrc\">VolodymyrC</a>, <a href=\"https://profiles.wordpress.org/vortfu\">vortfu</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>, and <a href=\"https://profiles.wordpress.org/wordpressorru\">WordPressor</a>.
<p style=\"margin-top: 22px\">Special thanks go to <a href=\"http://siobhanmckeown.com/\">Siobhan McKeown</a> for producing the release video and <a href=\"http://camikaos.com/\">Cami Kaos</a> for the voice-over.</p>
<p>Finally, thanks to all of the contributors who provided subtitles for the release video, which at last count had been translated into 30 languages!</p>
<p><a href=\"https://profiles.wordpress.org/adrianpop\">Adrian Pop</a>, <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/bagerathan\">Bagerathan Sivarajah</a>, <a href=\"https://profiles.wordpress.org/besnik\">Besnik</a>, <a href=\"https://profiles.wordpress.org/bjornjohansen\">Bjørn Johansen</a>, Chantal Coolsma, <a href=\"https://profiles.wordpress.org/cubells\">cubells</a>, Daisuke Takahashi, <a href=\"https://profiles.wordpress.org/dianakc\">Diana K. Cury</a>, <a href=\"https://profiles.wordpress.org/djzone\">DjZoNe</a>, <a href=\"https://profiles.wordpress.org/dyrer\">dyrer</a>, <a href=\"https://profiles.wordpress.org/semblance\">Elzette Roelofse</a>, <a href=\"https://profiles.wordpress.org/wordpress-tr\">Emre Erkan</a>, <a href=\"https://profiles.wordpress.org/fxbenard\">fxbenard</a>, <a href=\"https://profiles.wordpress.org/tacoverdo\">TacoVerdo</a>, <a href=\"https://profiles.wordpress.org/gabriel-reguly\">Gabriel Reguly</a>, <a href=\"https://profiles.wordpress.org/miss_jwo\">Jenny Wong</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/hgmb\">Håvard Grimelid</a>, <a href=\"https://profiles.wordpress.org/intoxstudio\">Joachim Jensen</a>, <a href=\"https://profiles.wordpress.org/jimmyxu\">Jimmy Xu</a>, <a href=\"https://profiles.wordpress.org/nukaga\">Junko Nukaga</a>, <a href=\"https://profiles.wordpress.org/pokeraitis\">Justina</a>, <a href=\"https://profiles.wordpress.org/kenan3008/\">Kenan Dervisevic</a>, <a href=\"https://profiles.wordpress.org/kosvrouvas\">Kostas Vrouvas</a>, <a href=\"https://profiles.wordpress.org/eclare\">Krzysztof Trynkiewicz</a>, <a href=\"https://profiles.wordpress.org/goblindegook\">Luís Rodrigues</a>, <a href=\"https://profiles.wordpress.org/luisrull\">Luis Rull</a>, <a href=\"https://profiles.wordpress.org/culturemark\">Mark Thomas Gazel </a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/matthee\">matthee</a>, <a href=\"https://profiles.wordpress.org/damst\">Mattias Tengblad</a>, Matúš Záhradník, Mayuko Moriyama, <a href=\"https://profiles.wordpress.org/michalvittek\">Michal Vittek</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mrshemek\">MrShemek</a>, <a href=\"https://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/peterhoob\">Peter Holme Obrestad</a>, <a href=\"https://profiles.wordpress.org/petya\">Petya Raykovska</a>, Przemysław Mirota, <a href=\"https://profiles.wordpress.org/qraczek\">qraczek</a>, <a href=\"https://profiles.wordpress.org/bi0xid\">Rafa Poveda</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/rasheed\">Rasheed Bydousi</a>, <a href=\"https://profiles.wordpress.org/gwgan\">Rhoslyn Prys</a>, <a href=\"https://profiles.wordpress.org/robee\">Robert Axelsen</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/siobhyb\">Siobhan Bamber</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/tohave\">ک To Have داشتن</a>, <a href=\"https://profiles.wordpress.org/zodiac1978\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/egalego\">Victor J. Quesada</a>, <a href=\"https://profiles.wordpress.org/wolly\">Wolly</a>, <a href=\"https://profiles.wordpress.org/xavivars\">Xavi Ivars</a>, <a href=\"https://profiles.wordpress.org/xibe\">Xavier Borderie</a></p>
<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.3!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://wordpress.org/news/2015/04/powell/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 4.1.2 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Apr 2015 13:44:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3628\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:383:\"WordPress 4.1.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by Cedric Van Bockhaven and fixed by [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3913:\"<p>WordPress 4.1.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by <a href=\"https://cedricvb.be\">Cedric Van Bockhaven</a> and fixed by <a href=\"http://pento.net/\">Gary Pendergast</a>, <a href=\"http://blogwaffe.com/\">Mike Adams</a>, and <a href=\"http://nacin.com/\">Andrew Nacin</a> of the WordPress security team.</p>
<p>We also fixed three other security issues:</p>
<ul>
<li>In WordPress 4.1 and higher, files with invalid or unsafe names could be uploaded. Discovered by <a href=\"http://HSASec.de\">Michael Kapfer and Sebastian Kraemer of HSASec</a>.</li>
<li>In WordPress 3.9 and higher, a very limited cross-site scripting vulnerability could be used as part of a social engineering attack. Discovered by <a href=\"http://zoczus.blogspot.com/\">Jakub Zoczek</a>.</li>
<li>Some plugins were vulnerable to an SQL injection vulnerability. Discovered by Ben Bidner of the WordPress security team.</li>
</ul>
<p>We also made four hardening changes, discovered by <a href=\"http://codesymphony.co/\">J.D. Grimes</a>, Divyesh Prajapati, <a href=\"http://www.allancollins.net/\">Allan Collins</a>, <a href=\"https://sucuri.net/\">Marc-Alexandre Montpas</a> and <a href=\"https://profiles.wordpress.org/jblz\">Jeff Bowen</a>.</p>
<p>We appreciated the <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of these issues directly to our security team. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.1.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.1?rev=32234&amp;stop_rev=32144\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.1.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221; Sites that support automatic background updates are already beginning to update to WordPress 4.1.2.</p>
<p>Thanks to everyone who contributed to 4.1.2: <a href=\"https://profiles.wordpress.org/collinsinternet\">Allan Collins</a>, <a href=\"https://profiles.wordpress.org/xknown\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/vortfu\">Ben Bidner</a>, <a href=\"https://profiles.wordpress.org/boonbgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/DrewAPicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, and <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>.</p>
<p>A number of plugins also released security fixes yesterday. Keep everything updated to stay secure. If you’re a plugin author, please read <a href=\"https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/\">this post</a> to confirm that your plugin is not affected by the same issue. Thank you to all of the plugin authors who worked closely with our security team to ensure a coordinated response.</p>
<p><em>Already testing WordPress 4.2? The third release candidate is now available (<a href=\"https://wordpress.org/wordpress-4.2-RC3.zip\">zip</a>) and it contains these fixes. For more on 4.2, see <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/\">the RC 1 announcement post</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 4.2 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Apr 2015 19:07:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3609\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:334:\"The release candidate for WordPress 4.2 is now available. We&#8217;ve made more than 140 changes since releasing Beta 4 a week and a half ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.2 on Wednesday, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2328:\"<p>The release candidate for WordPress 4.2 is now available.</p>
<p>We&#8217;ve made more than <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=32136&amp;stop_rev=31996&amp;limit=100\">140 changes</a> since releasing Beta 4 a week and a half ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.2 on <strong>Wednesday, April 22</strong>, but we need your help to get there.</p>
<p>If you haven’t tested 4.2 yet, now is the time! (Please though, not on your live site unless you’re adventurous.)</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href=\"https://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>To test WordPress 4.2 RC1, you can use the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin or you can <a href=\"https://wordpress.org/wordpress-4.2-RC1.zip\">download the release candidate here</a> (zip). </p>
<p>For more information about what’s new in version 4.2, check out the <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/\">Beta 2</a>, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/\">Beta 3</a>, and <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-beta-4/\">Beta 4</a> blog posts.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.2 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.2 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href=\"https://make.wordpress.org/core/\">follow along the core development blog</a>, where we&#8217;ll continue to post <a href=\"https://make.wordpress.org/core/tag/4-2-dev-notes/\">notes for developers</a> for 4.2.</p>
<p><em>Im-Press-ive saving</em><br />
<em>Achievement unlocked: RC</em><br />
<em>Release here we come</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Improvements to WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Apr 2015 20:19:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Meta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3494\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:335:\"If you visit WordPress.org regularly you might have noticed some changes around the place. If you don’t, now’s the time to check them out! We’ve been working hard to improve the site to make it more useful to everyone, both developers and users, and we hope you like what we’ve done. New Theme and Plugin Directories [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5551:\"<p>If you visit WordPress.org regularly you might have noticed some changes around the place. If you don’t, now’s the time to check them out! We’ve been working hard to improve the site to make it more useful to everyone, both developers and users, and we hope you like what we’ve done.</p>
<h2>New Theme and Plugin Directories</h2>
<p>Since WordPress 3.8, you’ve been enjoying improved theme management in your WordPress admin, and in WordPress 4.0 plugin management was refined. We’ve brought these experiences from your admin and re-created them right here on WordPress.org.</p>
<h3>Theme Directory</h3>
<p>The <a href=\"https://wordpress.org/themes/\">Theme Directory</a> has a better browsing experience, with handy tabs where you can view featured, popular, and the latest themes. As with the theme experience in your admin, you can use the feature filter to browse for just the right theme for your WordPress website.</p>
<p><img class=\"alignnone size-large wp-image-3572\" src=\"https://wordpress.org/news/files/2015/04/theme-directory-1024x768.png\" alt=\"theme-directory\" width=\"692\" height=\"519\" /></p>
<p>Click on a theme to get more information about it, including shiny screenshots, ratings, and statistics.</p>
<p><img class=\"alignnone size-large wp-image-3573\" src=\"https://wordpress.org/news/files/2015/04/theme-directory-individual-1024x768.png\" alt=\"theme-directory-individual\" width=\"692\" height=\"519\" /></p>
<p>Konstantin Obenland <a href=\"https://make.wordpress.org/meta/2015/03/10/new-theme-directory/\">posted a good overview</a> of everything involved with the theme directory overhaul and followed up with <a href=\"https://make.wordpress.org/meta/2015/03/31/theme-directory-stats/\">a post on improved statistics</a>.</p>
<h3>Plugin Directory</h3>
<p>The <a href=\"https://wordpress.org/plugins/\">Plugin Directory</a> has a brand new theme that mirrors the experience in your WordPress admin, with a more visual experience, and better search and statistics.</p>
<p><img class=\"alignnone size-large wp-image-3594\" src=\"https://wordpress.org/news/files/2015/04/plugin-directory-1024x768.png\" alt=\"plugin-directory\" width=\"692\" height=\"519\" /></p>
<p>As well as a facelift, there are some great new features for you to play around with:</p>
<ul>
<li>Favorites – when you’re logged in to you WordPress.org account, this page gives you direct access to the plugins that you have favorited.</li>
<li>Beta Testing – try out plugins where developers are experimenting with new features for WordPress.</li>
<li>Search by plugin author – you can search for a plugin author using their username.</li>
<li>Better statistics – listings now display the number of active installs so you can see how many people are actually using a plugin.</li>
</ul>
<p>An <a href=\"https://make.wordpress.org/meta/2015/03/04/new-plugin-directory-theme/\">overview of the new theme</a> was posted by Scott Reilly.</p>
<h2>Better Statistics</h2>
<p>We’ve made huge improvements to <a href=\"https://wordpress.org/about/stats/\">our statistics</a>. This gives us more useful information about the WordPress versions people are using, their PHP version, and their MySQL version.</p>
<p>Already these new statistics have provided us with useful insights into WordPress usage.</p>
<ul>
<li>More than 43% of all sites are running the latest version of WordPress. Previously, we thought only 10% of sites were up-to-date. By excluding sites that are no longer online we were able to improve these statistics.</li>
<li>We were able to clear up the data around WordPress 3.0, bringing it more in line with expectations. This anomaly was a by-product of spammers.</li>
<li>Only 15.9% of sites are using PHP 5.2, which is better than we thought.</li>
</ul>
<p>Over the coming months we’ll be able to use these statistics to bring you new tools and improvements, and to make more informed decisions across the board. Read <a href=\"https://make.wordpress.org/meta/2015/03/01/major-update-to-our-version-stats-for-php-mysql-and-wordpress/\">Andrew Nacin&#8217;s post about these changes</a> for more background.</p>
<h2>Thanks!</h2>
<p>Thanks to everyone who contributed to the theme directory redesign, the plugin directory refresh, and improved statistics: <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/colorful-tones/\">Damon Cook</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/mj12982\">Jan Cavan Boulas</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/BrashRebel\">Kyle Maurer</a>, <a href=\"https://profiles.wordpress.org/matveb\">Matías Ventura</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/nataliemac\">Natalie MacLees</a>, <a href=\"https://profiles.wordpress.org/pauldewouters\">Paul de Wouters</a>, <a href=\"https://profiles.wordpress.org/samuelsidler\">Samuel Sidler</a>, <a href=\"https://profiles.wordpress.org/Otto42\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/siobhan\">Siobhan McKeown</a>.</p>
<p>If you want to help out or follow along with future WordPress.org projects, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/meta/\">meta development blog</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 16 Jul 2015 05:54:08 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:10:\"x-pingback\";s:37:\"https://wordpress.org/news/xmlrpc.php\";s:13:\"last-modified\";s:29:\"Wed, 15 Jul 2015 21:49:35 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("243","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1437069250","no");
INSERT INTO `arc1542_options` VALUES("244","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1437026050","no");
INSERT INTO `arc1542_options` VALUES("245","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1437069251","no");
INSERT INTO `arc1542_options` VALUES("246","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"WPTavern: Explore the WordPress REST API with the New Interactive Console Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46685\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/explore-the-wordpress-rest-api-with-the-new-interactive-console-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3697:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/04/wp-rest-api.jpg?resize=1025%2C469\" alt=\"wp-rest-api\" class=\"aligncenter size-full wp-image-43000\" /></a></p>
<p>WordPress REST API project lead <a href=\"https://twitter.com/rmccue\" target=\"_blank\">Ryan McCue</a>, in cooperation with <a href=\"https://twitter.com/AutomatticEng\" target=\"_blank\">Automattic&#8217;s Engineering team</a>, released a <a href=\"https://wordpress.org/plugins/rest-api-console/\" target=\"_blank\">REST API Console</a> plugin on WordPress.org today. It&#8217;s a basic console that fits right into the WordPress admin and allows you to explore the API, make small changes, and find out what your site is exposing.</p>
<p>&#8220;This is a forked version of the WP.com console that myself and members of the Apollo team at Automattic worked on,&#8221; McCue told the Tavern. The console was converted in approximately four casual days, and McCue credits <a href=\"http://viewsource.beaucollins.com/\" target=\"_blank\">Beau Collins</a> for this, as he originally wrote the majority of the console for developers working on WordPress.com.</p>
<p>&#8220;It&#8217;s pretty useful for exploring the API as a learning tool, but also for developers who are extending the API to get a sense of how their stuff fits in,&#8221; he said.</p>
<p>The REST API Console plugin requires the <a href=\"https://wordpress.org/plugin/rest-api/\" target=\"_blank\">WP REST API plugin</a> version 2.0 or later. You can find this on the <a href=\"https://github.com/WP-API/WP-API\" target=\"_blank\">GitHub project page</a> and version 2 should be up on WordPress.org within the next day or two. Once you have both plugins installed, the console is visible in the admin under <strong>Tools > Rest API Console</strong>.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wp-rest-api-console-demo.jpg?resize=829%2C236\" alt=\"wp-rest-api-console-demo\" class=\"aligncenter size-full wp-image-46693\" /></a></p>
<p>You can actually make changes to your site using the console, so it&#8217;s advisable to install it on a local site and play with it there. While the GET requests can&#8217;t change anything, the other types can edit or delete posts (which would end up in your trash).</p>
<p>The plugin can only connect to the local site you&#8217;re currently on and cannot access remote WordPress sites. McCue recommends using something like <a href=\"https://www.getpostman.com/\" target=\"_blank\">Postman</a> or <a href=\"http://luckymarmot.com/paw\" target=\"_blank\">Paw</a> if you want to play around with remote sites.</p>
<p>In the future, he hopes to add more features and improve the plugin&#8217;s parameter documentation.</p>
<p>&#8220;The older WordPress.com console had the ability to click through to links, so I&#8217;d like to re-add that at some point,&#8221; he said. &#8220;The parameter documentation and tooling hasn&#8217;t been fleshed out yet, but the plan is to do it eventually &#8211; we&#8217;re working on exposing more from the API itself, too.&#8221;</p>
<p>If you want to tinker with the API but don&#8217;t have a local testing site handy, check out the live demo at <a href=\"http://demo.wp-api.org\" target=\"_blank\">demo.wp-api.org</a> where you can click around to explore. This will save you the trouble of installing the plugin, if you just want to try it out. Also, you can&#8217;t perform any destructive changes there. Version 2 of the WP REST API plugin should be available on WordPress.org within 24-48 hours.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 00:31:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:106:\"WPTavern: WordPress Theme Review Team Unanimously Approves Roadmap to Improve Directory and Review Process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46551\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:116:\"http://wptavern.com/wordpress-theme-review-team-unanimously-approves-roadmap-to-improve-directory-and-review-process\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2613:\"<p>The <a href=\"https://make.wordpress.org/themes/\">Theme Review Team</a> has spent the last two months <a href=\"http://wptavern.com/wordpress-theme-review-team-seeks-feedback-on-the-review-process-themes-and-the-directory\">collecting data from surveys</a> to discover common pain points people experience using the theme directory and going through the theme review process. The results of those surveys were used to <a href=\"https://make.wordpress.org/themes/2015/07/07/roadmap-for-phase-one/\">create a roadmap</a> of areas to focus on.</p>
<p>In yesterday&#8217;s meeting, the Theme Review Team voted and those in attendance <a href=\"https://wordpress.slack.com/archives/themereview/p1436896772000053\">unanimously approved</a> the roadmap.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png\"><img class=\"size-full wp-image-46668\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ThemeReviewTeamRoadmapVote.png?resize=471%2C560\" alt=\"Phase One Roadmap Approved\" /></a>Phase One Roadmap Approved
<p>One of the key parts to the roadmap is creating groups with a scope of responsibilities. The groups include:</p>
<ul>
<li>Directory</li>
<li>Documentation</li>
<li>Tools</li>
<li>Reviews and queues</li>
<li>UX and research</li>
</ul>
<p>Each group needs a point person who acts as the communication bridge between the group and Theme Review Team. Tammie Lister explains what the point person&#8217;s role is within a group.</p>
<blockquote><p>This person will report weekly what is going on during the chats. They will also post on the make.blog each week about what is going on in each group. This should ensure we keep up communication and make sure things get done.</p></blockquote>
<p>They&#8217;re not necessarily in charge of getting things done but rather, act as a facilitator to make sure the group stays on track.</p>
<p>One part of the roadmap that I&#8217;m interested in is the possibility of a report button added to the theme directory to allow users to report themes. If this happens, it will be interesting to see how it&#8217;s used or abused and whether it adds any additional work load to the theme reviewers.</p>
<p>The roadmap looks solid and shows the team is focused on improving several aspects of the Theme Directory. This is a great opportunity for new contributors to get involved with the project. If you&#8217;re interested in joining any of the groups within the Theme Review Team, please visit the <strong>#themereview</strong> channel on <a href=\"https://make.wordpress.org/chat/\">Slack</a> and let the team know.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 21:10:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: Proper Lite: A Free and Flexible WordPress Theme for Creatives\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46585\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"http://wptavern.com/proper-lite-a-free-and-flexible-wordpress-theme-for-creatives\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3530:\"<p>Last November, ModernThemes <a href=\"http://wptavern.com/modernthemes-launches-site-dedicated-to-providing-free-wordpress-themes\" target=\"_blank\">officially launched its free WordPress themes site</a> and has been gradually adding to its <a href=\"https://wordpress.org/themes/author/modernthemesnet/\" target=\"_blank\">collection</a> hosted on WordPress.org. Founders Robbie Grabowski and Mike Driscoll launched the site with a commitment to produce themes that support the native customizer and keep plugin functionality separate while still being &#8220;plugin-friendly.&#8221;</p>
<p><a href=\"https://modernthemes.net/wordpress-themes/proper-lite/\" target=\"_blank\">Proper Lite</a> is ModernThemes&#8217; latest release, created to be fully compatible with their new <a href=\"https://modernthemes.net/plugins/\" target=\"_blank\">library of free plugins</a> that add functionality like shortcodes, widgets, sidebars, services, testimonials, projects, etc.</p>
<p>The theme features a fullscreen homepage hero section with multiple controls for customizing the background, text, and buttons.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/properlite_mockups.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/properlite_mockups.png?resize=1000%2C700\" alt=\"properlite_mockups\" class=\"aligncenter size-full wp-image-46645\" /></a></p>
<p>Proper Lite was designed with a modular homepage layout that supports three flexible widget areas where you can drop in portfolio items, blogs, testimonials, or any other content you choose. This is one of the reasons why ModernThemes calls it their most flexible free theme to date.</p>
<p>In addition to the default template, Proper Lite includes Homepage, Full Width, and Left Sidebar templates. It also has specific styling for various content blocks added from the plugin library, as you can see in the <a href=\"https://modernthemes.net/demo/?theme=properlite\" target=\"_blank\">live demo</a>.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/team-members.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/team-members.jpg?resize=926%2C897\" alt=\"team-members\" class=\"aligncenter size-full wp-image-46654\" /></a></p>
<p>Proper Lite has an amazing array of controls included in the customizer. Users can easily adjust Google Fonts, logos and icons, nearly every color used in the theme, social media icons, a footer call-to-action, the number of columns in the widget areas, and much more. The theme was not created with a set, inflexible design. Versatility is one of its key features.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/proper-lite-customizer.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/proper-lite-customizer.png?resize=1025%2C426\" alt=\"proper-lite-customizer\" class=\"aligncenter size-full wp-image-46659\" /></a></p>
<p>Proper Lite, like other themes from ModernThemes, has extensive <a href=\"https://modernthemes.net/proper-lite-documentation/\" target=\"_blank\">documentation</a> available on the website for every section included in the theme. While this theme is heavily geared toward creatives with an emphasis on fullwidth images and portfolio content, it is also suitable for personal blogs, agencies, and creative businesses, thanks to the wide range of plugins available to extend it. <a href=\"https://modernthemes.net/wordpress-themes/proper-lite/\" target=\"_blank\">Download</a> it for free from the ModernThemes website.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 18:42:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Matt: Sleep Dep\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45247\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://ma.tt/2015/07/sleep-dep/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:186:\"<p><a href=\"http://www.theatlantic.com/health/archive/2013/12/how-sleep-deprivation-decays-the-mind-and-body/282395/\">How Sleep Deprivation Decays the Mind and Body</a>. Crazy story.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 04:46:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Plato, Phaedrus, Google\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45224\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"http://ma.tt/2015/07/plato-phaedrus/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:822:\"<blockquote><p>and now you, who are the father of letters, have been led by your affection to ascribe to them a power the opposite of that which they really possess. For this invention will produce forgetfulness in the minds of those who learn to use it, because they will not practice their memory. Their trust in writing, produced by external characters which are no part of themselves, will discourage the use of their own memory within them. You have invented an elixir not of memory, but of reminding; [&#8230;]</p></blockquote>
<p><a href=\"http://www.perseus.tufts.edu/hopper/text?doc=Perseus%3Atext%3A1999.01.0174%3Atext%3DPhaedrus%3Asection%3D275a\">A few thousand years ago Plato predicted how Google would make us less able to remember things</a>.</p>
<p>Hat tip: <a href=\"http://chris.ink/\">Chris Rudzki</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Jul 2015 04:24:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WPTavern: BuddyBoss Expands Into LMS Market with Free BuddyPress Plugins for LearnDash and Sensei\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46573\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:107:\"http://wptavern.com/buddyboss-expands-into-lms-market-with-free-buddypress-plugins-for-learndash-and-sensei\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3139:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/learndash.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/learndash.png?resize=680%2C310\" alt=\"learndash\" class=\"aligncenter size-full wp-image-46576\" /></a></p>
<p>In May, <a href=\"http://www.buddyboss.com/\" target=\"_blank\">BuddyBoss</a> founder Michael Eisenwasser shared with Tavern readers the <a href=\"http://wptavern.com/inside-buddyboss-with-michael-eisenwasser\" target=\"_blank\">challenges of creating a profitable business</a> in what is still a relatively small marketplace for BuddyPress themes and plugins. Developers are building niche social networks every day, but BuddyPress&#8217; appeal as a platform hinges on the availability of compelling and reliable third-party add-ons.</p>
<p>Over the past couple of months, BuddyBoss has branched out into serving the LMS market with free BuddyPress integration plugins for <a href=\"http://www.learndash.com/\" target=\"_blank\">LearnDash</a> and <a href=\"http://www.woothemes.com/products/sensei/\" target=\"_blank\">Sensei</a>, two of WordPress&#8217; most popular LMS solutions. Both <a href=\"https://wordpress.org/plugins/buddypress-learndash/\" target=\"_blank\">BuddyPress for LearnDash</a> and <a href=\"https://wordpress.org/plugins/sensei-buddypress/\" target=\"_blank\">BuddyPress for Sensei</a> were created to work with any theme, but are also guaranteed to work seamlessly with BuddyBoss&#8217; new Social Learner theme.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/social-learner.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/social-learner.png?resize=1000%2C573\" alt=\"social-learner\" class=\"aligncenter size-full wp-image-46620\" /></a></p>
<p>Both plugins have similar core feature sets that include the ability to create courses, lessons, quizzes, and tie it all in to BuddyPress activity, groups, and forums to create a social learning platform. Course managers can even introduce gamification into the learning process with open source <a href=\"http://badgeos.org/\" target=\"_blank\">BadgeOS</a> plugin integration.</p>
<p>Social learning communities, like popular social goal or fitness tracking apps, bring a higher level of engagement by leveraging the people factor. An LMS powered by WordPress and BuddyPress provides students with the ability to connect to new friends, collaborate, send messages, earn badges &#8211; all activities that contribute to a higher level of motivation for learning and success.</p>
<p>The idea is not new to BuddyPress, as the long-abandoned <a href=\"http://buddypress.coursewa.re/\" target=\"_blank\">BuddyPress Courseware</a> project brought a social aspect to e-learning nearly four years ago. However, it is difficult to maintain an LMS plugin that only works with BuddyPress, because it doesn&#8217;t have the benefit of contributions and testing from a larger community. BuddyBoss made a strategic move in building plugins that would bridge BuddyPress to extend existing LMS solutions that serve the larger WordPress market. Both newer alternatives are available for free on WordPress.org.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2015 22:53:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Theme Translations and Language Packs are Coming to WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46589\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"http://wptavern.com/theme-translations-and-language-packs-are-coming-to-wordpress-org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3610:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/08/globe.jpg?resize=1024%2C499\" alt=\"photo credit: . Entrer dans le rêve - cc\" class=\"size-full wp-image-29134\" /></a>photo credit: <a href=\"https://www.flickr.com/photos/tranbina/4765484383/\">. Entrer dans le rêve</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-sa/2.0/\">cc</a>
<p>WordPress.org will soon support translations and language packs for themes hosted in the official directory. In <a href=\"http://wptavern.com/highlights-of-matt-mullenwegs-qa-session-at-wordcamp-europe-2015\" target=\"_blank\">Matt Mullenweg&#8217;s Q&amp;A at WordCamp Europe 2015</a>, he emphasized the importance of having better language support for themes and plugins and identified this as a high priority for continued improvements to WordPress.org.</p>
<p>Today the WordPress meta team <a href=\"https://make.wordpress.org/themes/2015/07/14/theme-translations-on-wordpress-org/\" target=\"_blank\">announced</a> that theme translations will soon be available on WordPress.org at <a href=\"http://translate.wordpress.org\" target=\"_blank\">translate.wordpress.org</a>. Within the next few days or weeks, all active themes (those updated within the last two years) will have their strings imported.</p>
<p>&#8220;This will involve importing ~1500 themes, which, combined, have about 315,000 total strings,&#8221; Sam Sidler said in the announcement. &#8220;After duplicates, the number drops to only 80,000 unique strings.&#8221;</p>
<h3>Language Packs Will Reduce Download Sizes for Themes</h3>
<p>Sidler outlined several advantages for theme authors who opt to manage translations on WordPress.org, including the community&#8217;s large network of contributing translators who currently maintain 140 locales on <a href=\"http://translate.wordpress.org\" target=\"_blank\">translate.wordpress.org</a>.</p>
<p>The most exciting change is that themes hosted on WordPress.org will soon be able to take advantage of language packs. Theme authors will have the option to remove translations from their zip file in favor of allowing WordPress.org to deliver the language packs, resulting in smaller download sizes.</p>
<p>&#8220;Eventually, we also plan to give priority to localized themes in localized directories; e.g., someone searching the Romanian theme directory will see Romanian themes prioritized over English-only themes,&#8221; Sidler said.</p>
<p>The more languages a theme can be translated into, the greater its prominence in WordPress&#8217; language-specific theme directories. This should provide WordPress.org theme authors with a strong motivation to <a href=\"https://make.wordpress.org/polyglots/handbook/rosetta/theme-plugin-directories/\" target=\"_blank\">work with the polyglots team</a> to get more translations. Theme authors can also request new translation editors to be added to polyglots, if they want to continue working with their own translators.</p>
<p>Those who prefer to ship their own translations can continue to do so. Keeping the translation files in your zip package will essentially opt you out of language packs for those specific translations. If you need help adding support for translations and language packs, Sidler recommends Otto&#8217;s <a href=\"http://ottopress.com/2013/language-packs-101-prepwork/\" target=\"_blank\">Language Packs 101</a> tutorial in addition to the <a href=\"https://developer.wordpress.org/themes/functionality/internationalization/\" target=\"_blank\">Theme Developer Handbook section on Internationalization</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2015 20:22:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: The First 24hr Conference Devoted to the Genesis Framework Set for July 18-20\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46565\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"http://wptavern.com/the-first-24hr-conference-devoted-to-the-genesis-framework-set-for-july-19-20\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1461:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/GenesisCampFeaturedImage.png\"><img class=\"aligncenter size-full wp-image-46579\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/GenesisCampFeaturedImage.png?resize=880%2C275\" alt=\"Genesis Camp Featured Image\" /></a><a href=\"http://genesis.camp/\">Genesis Camp</a> is the first 24 hour conference dedicated to the Genesis framework by <a href=\"http://www.studiopress.com/\">Studiopress</a>. The event takes place on July 18-20 and is free to attend. Even though the event is dedicated to the Genesis framework, it&#8217;s not associated with Copyblogger Media or Studiopress.</p>
<p>Organized by a community of Genesis users, the event features <a href=\"http://genesis.camp/sessions/\">sessions</a> on development workflow, branding, collaboration, and more. Each session will include an area for viewers to chat and ask questions. Speakers include Chris Lema, Carrie Dils, Wes Linda, David Wang, Heather Porter, and more.</p>
<p>Sessions will be recorded in case you can&#8217;t stay awake to watch all 24 hours of the event. Videos will be handled by <a href=\"http://www.google.com/+/learnmore/hangouts/\">Google Hangouts</a> while <a href=\"https://www.crowdcast.io/\">Crowd Cast</a> will be used to allow viewers to chat during sessions. To watch the event you&#8217;ll need to register on the <a href=\"https://www.crowdcast.io/e/genesiscamp1\">Genesis Camp Crowd Cast site</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2015 17:43:43 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: Candid Conversation with Tom McFarlin About the WordPress Community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46549\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/candid-conversation-with-tom-mcfarlin-about-the-wordpress-community\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1158:\"<p>Earlier this month, Tom McFarlin <a href=\"https://tommcfarlin.com/the-wordpress-community-a-comedy-of-drama-ego-oligarchies-and-more/\">published a great post</a> where he shares his perspective on the WordPress community. His post struck a nerve and instead of discussing it through comments, I invited him to a Google Hangout to have a candid conversation. Within the conversation, McFarlin and I discuss a number of topics, including:</p>
<ul>
<li>Community behaviour and discourse</li>
<li>It&#8217;s not a WordPress problem</li>
<li>Comment moderation strategies</li>
<li>Subtweeting</li>
<li>How, as men, do we show that a significant portion of us are color/ethnicity/whatever blind?</li>
<li>Women in tech</li>
</ul>
<p>McFarlin is the father of two daughters which adds an interesting dynamic to the women in tech issue. I enjoyed the time I spent with him discussing topics we both feel are important. If you have any feedback concerning the content in this recording, please leave a comment.</p>
<p>There&#8217;s also a transcript of the interview <a href=\"http://www.wptavern.com/wpweeklyaudio/TomMcFarlinTranscript.zip\">available here</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2015 16:16:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Hacking Team Hack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45238\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/07/hacking-team-hack/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:966:\"<p>I haven&#8217;t been following the Hacking Team story too closely. If you&#8217;re the same, here&#8217;s a quick catch-up: an Italian company that sold hacking tools, often to questionable governments, had all of their internal company data including emails, source code, everything released. <a href=\"http://www.engadget.com/2015/07/09/how-spyware-peddler-hacking-team-was-publicly-dismantled/\">Engadget has the best summary I&#8217;ve seen so far of how they got hacked</a>, which was apparently done by a hacker vigilante who did something similar to another organization called the Gamma Group. <a href=\"https://firstlook.org/theintercept/2015/07/08/hacking-team-emails-exposed-death-squad-uk-spying/\">The Intercept also has a good look at some of the more egregious behavior</a>. Bruce Schneier <a href=\"https://www.schneier.com/blog/archives/2015/07/organizational_.html\">calls this new trend Organizational Doxxing and considers its ramifications</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 14 Jul 2015 03:43:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Topher DeRosia Launches GoFundMe Campaign to Attend WordCamp Pune, India\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46545\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/topher-derosia-launches-gofundme-campaign-to-attend-wordcamp-pune-india\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2000:\"<p>Topher DeRosia, founder of <a href=\"http://t.co/Q9hSlXsBKQ\">HeroPress</a>, is <a href=\"http://www.gofundme.com/heropress-in-pune\">asking for</a> $2,150 to attend <a href=\"https://pune.wordcamp.org/2015/\">WordCamp Pune</a>, India. DeRosia was asked to speak about HeroPress by Saurabh Shukla, who is a<a href=\"http://heropress.com/essays/ill-keep-looking-for-a-cms-unless-i-find-wordpress/\" target=\"_blank\"> HeroPress contributor</a> and also the lead organizer of WordCamp Pune, India.</p>
<p>In an effort to be transparent, DeRosia published how he will spend the money.</p>
<ul>
<li>$1400 for the plane ticket</li>
<li>$300 for hotel</li>
<li>$200 for food, cabs, Uber, etc</li>
<li>$100 for emergencies</li>
<li>$150 for GoFundMe&#8217;s fees</li>
</ul>
<p>If DeRosia has money left over from his trip, he plans to sponsor a WordCamp that&#8217;s having difficulty finding sponsors or donate it to the WordPress Foundation.</p>
<p>Since launching the campaign a few days ago, he&#8217;s raised $1,000. Unlike most other campaigns, <a href=\"https://www.gofundme.com/heropress-in-pune/donate\">donors can choose</a> the amount they want to give. Among the donors listed is Matt Mullenweg, who contributed $250. If you enjoy the time, work, and effort put into HeroPress, consider donating a few dollars.</p>
<p><strong>Within 24 hours since this post was published, DeRosia surpassed his funding goal.</strong></p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordCampPuneGoalMet.png\"><img class=\"size-full wp-image-46569\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/WordCampPuneGoalMet.png?resize=976%2C649\" alt=\"WordCamp Pune Goal Met\" /></a>WordCamp Pune Goal Met
<p>I asked DeRosia how it feels to meet is funding goal, &#8220;I&#8217;m super excited about this. Not just the fact that <em>other people</em> paid for a trip but that the HeroPress community feels this kind of thing is valuable enough to put money out for it. That means a lot.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jul 2015 23:11:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Embed Your Meerkat Stream on Your WordPress Site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46325\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wptavern.com/embed-your-meerkat-stream-on-your-wordpress-site\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4187:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat.png?resize=655%2C300\" alt=\"meerkat\" class=\"aligncenter size-full wp-image-46518\" /></a></p>
<p>Just one day after <a href=\"https://meerkatapp.co/\" target=\"_blank\">Meerkat</a>, the popular video streaming service, <a href=\"http://techcrunch.com/2015/06/26/meerkat-outs-an-embeddable-player-hooks-discovery-channels-shark-week/#.qqszef:XITC\" target=\"_blank\">launched its embedded player</a>, a WordPress plugin was in the works to make it easy for publishers to take advantage of it. <a href=\"http://www.artiss.co.uk\" target=\"_blank\">David Artiss</a>, an English developer and author of several popular embedding <a href=\"https://profiles.wordpress.org/dartiss/#content-plugins\" target=\"_blank\">plugins</a>, is the first to bring Meerkat embedding to WordPress.</p>
<p>The <a href=\"https://wordpress.org/plugins/meerkat/\" target=\"_blank\">Meerkat plugin</a> lets users embed their streams in WordPress content using a simple shortcode. The embedded player automatically does the following, according to Meerkat&#8217;s documentation:</p>
<blockquote><p>It will show your live stream if you’re live. If you’re not live, if will show your next upcoming stream. If you have no upcoming streams, it will display stats from your last stream. If you have not streamed yet, it will show your profile.</p></blockquote>
<p>All you need is the Meerkat username to use the shortcode in its simplest form:</p>
<p><code>[meerkat username=\"meerkatapi\"]</code></p>
<p>It also includes optional parameters for customizing the username, player type, participation, cover image, muted defaults, and debug settings. These parameters essentially let you customize everything available in the <a href=\"http://widgets.meerkatapp.co/embed\" target=\"_blank\">Meerkat embed code generator</a>.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-customize-embedded-player.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-customize-embedded-player.jpg?resize=746%2C515\" alt=\"meerkat-customize-embedded-player\" class=\"aligncenter size-full wp-image-46532\" /></a></p>
<p>The shortcode can be embedded in posts or pages. Artiss plans to add a widget option soon, as the default player size seems to lend itself to display in a sidebar. I tested the plugin with WordPress 4.3 beta 2 and found that it works as advertised.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-wordpress-plugin-example.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/meerkat-wordpress-plugin-example.jpg?resize=778%2C635\" alt=\"meerkat-wordpress-plugin-example\" class=\"aligncenter size-full wp-image-46533\" /></a></p>
<p>At TechCrunch Disrupt in May 2015, Meerkat founder Ben Rubin reported that the service was <a href=\"http://www.businessinsider.com/meerkat-has-nearly-2-million-users-2015-5\" target=\"_blank\">approaching nearly two million users</a>. Chances are that plenty of those users also have WordPress sites where they can gain more exposure for their streams.</p>
<p>Artiss wanted to make it easy for anyone to embed a stream. He isn&#8217;t a Meerkat user himself but found that its API was easy to work with for embedding content.</p>
<p>&#8220;I didn&#8217;t write it for myself but I thought putting the newly released embed function in a simple-to-use plugin for WordPress users would be useful,&#8221; he said. &#8220;I just happened to be working on <a href=\"https://wordpress.org/plugins/zingtree-embed/\" target=\"_blank\">Zingtree Embed plugin</a> at the same time, so it was quite simple to clone that and modify it for a different embed type.&#8221;</p>
<p>If you want your fans and followers to be able to find your Meerkat stream on the web, download the <a href=\"https://wordpress.org/plugins/meerkat/\" target=\"_blank\">Meerkat</a> embed plugin from the WordPress plugin directory. This will allow folks to join you live from your website, without having to use the app on their phones. The widget embed option should land in the next release.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jul 2015 19:47:17 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"WPTavern: Envato Targeted by DDoS Attack, WordPress Theme Authors Report Major Decline in Sales\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46485\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/envato-targeted-by-ddos-attack-wordpress-theme-authors-report-major-decline-in-sales\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6430:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/envato.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2014/09/envato.jpg?resize=697%2C314\" alt=\"envato\" class=\"aligncenter size-full wp-image-29973\" /></a></p>
<p>If you&#8217;ve attempted to access Themeforest or any other site on the <a href=\"http://www.envato.com/\" target=\"_blank\">Envato</a> network lately, you may have encountered some down time. The company <a href=\"http://inside.envato.com/denial-of-service-attacks-on-envato/\" target=\"_blank\">updated</a> customers and community members today, attributing the technical difficulties to a DDoS attack:</p>
<blockquote><p>Since July 1, Envato has been the target of a sustained DDoS (distributed denial of service) attack. The attacker, whose motive and identity are unknown, has repeatedly flooded our servers with high levels of traffic, causing our services to be unavailable at various times.</p></blockquote>
<p>The most recent outage happened over the weekend when Envato Market was down for three hours on Friday and one hour on Sunday. This is a significant chunk of time for a market that <a href=\"http://www.envato.com/2014\" target=\"_blank\">paid out $224 million dollars to its members in 2014</a>.</p>
<p>The downtime has also impacted WordPress theme authors, who continue to dominate the Envato&#8217;s marketplace. According to Ben Chan, the company&#8217;s director of growth and revenue, 30 of the 31 sellers who make up the <a href=\"http://elite.envato.com/wall-of-fame/\" target=\"_blank\">Power Elite wall of fame</a> (selling $1 million+ worth of items) are WordPress product authors.</p>
<p>The power of the WordPress economy on Envato is undeniable, but sales have taken a sharp decline in the past couple of months, even before the DDoS attack. According to PremiumWP, which cites reports from elite theme author Chris Robinson of Contempo and many others, <a href=\"http://www.premiumwp.com/themeforest-authors-report-50-70-drop-in-theme-sales/\" target=\"_blank\">sales have suddenly declined 50-70%</a>.</p>
<p>&#8220;Sales have declined over 70% starting from May with each passing day getting worse,&#8221; Robinson said in the <a href=\"http://themeforest.net/forums/thread/envato-are-youre-not-telling-us-something/185158\" target=\"_blank\">members&#8217; forum</a>. &#8220;I’ve also spoken with other elite authors explaining the same thing. One example going from $1500/day to $700 &#8211; sure that’s still a great deal of money BUT what the hell is happening?</p>
<p>&#8220;This isn’t just one or maybe twenty authors, it is marketplace wide affecting everyone. A marketplace wide decline in sales of this magnitude doesn’t just happen due to vacations, or other buyer factors. Going through the years of sales data (since 2008) this has never happened, I’ve personally gone from $2-3000/week to less than $700/week…that’s insane!&#8221;</p>
<p>With new authors and products entering the market every day, the market share for established authors is slowly diminishing, but members are not convinced that this is the sole cause of the sharp drop in sales.</p>
<p>FinalDestiny of TeoThemes, another author whose sales are declining, blames the <a href=\"http://wptavern.com/envato-continues-to-rake-in-the-cash-from-wordpress-themes-packaged-as-complete-website-solutions\" target=\"_blank\">one-size-fits-all theme products</a> for gobbling up a greater slice of the market share.</p>
<p>&#8220;Everybody is tired of these huge, monster multipurpose themes having the same price as normal themes, and that’s pretty much killing the marketplaces. But Envato couldn’t care less, as long as they get their share,&#8221; he <a href=\"http://themeforest.net/forums/thread/envato-are-youre-not-telling-us-something/185158?page=1&message_id=1303716#1303716\" target=\"_blank\">said</a>.</p>
<p>In another <a href=\"http://themeforest.net/forums/thread/whats-wrong-with-sales-on-tf-/181436\" target=\"_blank\">thread</a>, which ended up getting locked, there are 27 pages of comments from users speculating about why their sales have been dropping. Members cite seasonal buying fluctuations, piracy, Themeforest&#8217;s recent drop in Google search rankings, VAT and hidden price additions on checkout, and unfair pricing advantages for monster themes that claim to do everything, among other possible causes.</p>
<p>In one thread, titled &#8220;<a href=\"http://themeforest.net/forums/thread/more-than-50-sales-drop-for-most-of-the-authors-does-tf-care-for-authors/182262\" target=\"_blank\">More than 50% sales drop for most of the authors. Does TF care for Authors?</a>&#8220;, an Envato community officer offered the following comment:</p>
<blockquote><p>We don’t really give sales updates over the forums other than to say your sales can go up and down for a multitude of reasons. Try not to assume the sky is falling every time the USA has a long weekend :) We have fast and slow periods throughout the year same as any business, and your portfolio will no doubt have peaks and valleys as well.</p></blockquote>
<p>This kind of generic reply has left theme authors scratching their heads, despite multiple threads in the forums popping up with concerns from those who are alarmed by the sudden drop. Many WordPress theme authors depend on Themeforest as their primary source of income. In one <a href=\"http://themeforest.net/forums/thread/more-than-50-sales-drop-for-most-of-the-authors-does-tf-care-for-authors/182262?page=3&message_id=1291143#1291143\" target=\"_blank\">reply</a>, the Aligator Studio seller sums up their concerns and frustration with the inability to convince Envato of the unusual circumstances that are affecting large numbers of sellers:</p>
<blockquote><p>We are not talking about valleys and peaks, we’re talking about a general traffic and sales fall, from New Year until now, especially after April. We’re not talking about regular ups and downs (sometimes steeper, sometimes not), due to longer weekends, summer holidays, and general and the usual stuff happening here in the last couple of years.</p>
<p>It’s not a sky falling – it’s inability to pay our bills, we’re not fanatics that foresee the end of the world.</p></blockquote>
<p>Envato has yet to provide an official statement about the marketplace-wide decline in sales, apart from recognizing the network&#8217;s unavailability due to the recent DDoS attack.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 13 Jul 2015 16:42:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"Matt: Neil Gaiman Speech at University of the Arts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45241\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"http://ma.tt/2015/07/neil-gaiman-commencement/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"<p>&#8220;Make good art.&#8221;</p>
<p><span class=\"embed-youtube\"></span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 12 Jul 2015 20:15:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: WordCamp Scranton\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45234\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/07/wordcamp-scranton/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:800:\"<p>As was just announced, I&#8217;m going to make a not-surprise appearance at WordCamp Scranton next Saturday. It&#8217;s their first year <a href=\"https://central.wordcamp.org/\">doing a Wordcamp</a> and I was able to find some space in my schedule to swing by in between business meetings in New York and Philadelphia, so very much looking forward to meeting the Scranton community.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Matt Mullenweg (<a href=\"https://twitter.com/photomatt\">@photomatt</a>) will Host a Town Hall Q&amp;A at WordCamp Scranton! <a href=\"https://t.co/qmZSWYPQBS\">https://t.co/qmZSWYPQBS</a></p>
<p>&mdash; WordCamp Scranton (@WCScranton) <a href=\"https://twitter.com/WCScranton/status/619508207283625984\">July 10, 2015</a></p></blockquote>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 11 Jul 2015 16:03:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: WPWeekly Episode 198 – Tackling Mental Health With Cory Miller\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=46473&preview_id=46473\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wptavern.com/wpweekly-episode-198-tackling-mental-health-with-cory-miller\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2636:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I are joined by Cory Miller, <a href=\"https://ithemes.com/our-founder/\">founder of iThemes</a>. Miller discusses his entrepreneurship journey and shares in detail, how he <a href=\"http://wordpress.tv/2015/07/02/cory-miller-entrepreneurship-and-my-mental-health/\">maintains his mental health</a>.</p>
<p>We learn that people battling mental health are not alone and that it&#8217;s ok to ask for help. Miller explains how seeing a counselor four times a year helps him maintain his mental health. We also discuss coping mechanisms that might work for those not interested in seeing a counselor.</p>
<p>For more background on this episode, I highly encourage you to <a href=\"http://wordpress.tv/2015/07/02/cory-miller-entrepreneurship-and-my-mental-health/\">watch his presentation</a> at WordCamp Denver 2015, on mental health. Also, check out <a href=\"http://www.slideshare.net/corymiller303/the-emotional-roller-coaster-of-entrepreneurship-how-i-cope-7-years-in\">his slides on slideshare</a> that are filled with motivational messages.</p>
<p>I apologize for the audio quality in this episode. Miller was in New Mexico on a spotty WiFi connection that seemed to get worse as the show went on.</p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/save-import-image-from-url/\">Save and Import Image from URL</a> replaces the built-in &#8216;Import from URL&#8217; media upload tab. It allows users to download an image from a remote URL and upload it to the WordPress media gallery.</p>
<p class=\"shortdesc\"><a href=\"https://wordpress.org/plugins/meerkat/\">Meerkat</a> lets you embed your Meerkat stream on your site so your followers, friends, and fans can watch your stream anywhere.</p>
<p><a href=\"https://wordpress.org/plugins/simple-job-board/\">Simple Job Board</a> is an easy and lightweight plugin that adds a job board to your website.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, July 15th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #198:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2015 22:01:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"WPTavern: SocialCrumbs: A Free WordPress Theme that Streams Social Activity Using IFTTT Recipes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46448\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/socialcrumbs-a-free-wordpress-theme-that-streams-social-activity-using-ifttt-recipes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3949:\"<p>With all of the content an average user generates across social media sites, it can be challenging to get a full view of all that activity. Let&#8217;s face it, your social media posts are scattered all over the web.</p>
<p><a href=\"https://github.com/ademilter/socialcrumbs\" target=\"_blank\">SocialCrumbs</a> is a non-traditional, niche WordPress theme that aggregates all of your social media activity into one stream with the help of <a href=\"https://ifttt.com/\" target=\"_blank\">IFTTT</a> recipes. The theme was created by <a href=\"http://ademilter.com/\" target=\"_blank\">Adam Ilter</a>, a user interface designer and developer living in Istanbul. He designed a Pinterest-style display to output the social posts brought in by IFTTT. The masonry grid is responsive and colorful with posts featuring icons for each social network.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/socialcrumbs-screenshot.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/socialcrumbs-screenshot.jpg?resize=1025%2C745\" alt=\"socialcrumbs-screenshot\" class=\"aligncenter size-full wp-image-46451\" /></a></p>
<p>You can view a live demo of SocialCrumbs at <a href=\"http://adem.social/\" target=\"_blank\">adem.social</a>.</p>
<p>In order to use the theme, you need to sign up for IFTTT and set up recipes for all the social accounts you want to include in the stream. The theme&#8217;s readme.txt files includes a list of 19 <a href=\"https://github.com/ademilter/socialcrumbs#recipes\" target=\"_blank\">recipes</a> that Ilter has pre-configured, with a checklist of many more planned.</p>
<p>Certain networks have multiple options. For example, you can choose to include Twitter tweets and/or favorites:</p>
<ul>
<li>twitter-tweet-write <a href=\"https://ifttt.com/recipes/189363\" target=\"_blank\">https://ifttt.com/recipes/189363</a></li>
<li>twitter-tweet-favorite <a href=\"https://ifttt.com/recipes/189331\" target=\"_blank\">https://ifttt.com/recipes/189331</a></li>
</ul>
<p>It can take up to 15 minutes for the content to appear in your theme after posting to the social network, as most IFTTT recipes check for new trigger data at that interval.</p>
<p>It&#8217;s important to note that this theme is hosted on GitHub, not officially supported, and is an example of a fun, experimental concept that relies on IFTTT. As such, it doesn&#8217;t includes a single post template but rather outputs as an index. SocialCrumbs is not yet capable of providing a comprehensive archive for social media posts, so it&#8217;s not a theme you would use if you intend to record all of your social activities for preservation.</p>
<p>One might argue that this kind of functionality is better housed in a plugin. In that case you might want to take a look at the <a href=\"https://wordpress.org/plugins/social-streams/\" target=\"_blank\">Social Streams</a> or <a href=\"https://wordpress.org/plugins/wp-social-stream/\" target=\"_blank\">WP Social Stream</a> plugins on WordPress.org. WP Social Stream is based on <a href=\"https://github.com/christianv/jquery-lifestream\" target=\"_blank\">jQuery Lifestream</a>, as opposed to IFTTT. The methods of retrieving social posts vary from plugin to plugin, depending on how you want to fetch, display, and store that content.</p>
<p>The most ideal use for the SocialCrumbs theme would be where you dedicate a subsite to its display, i.e. for showing social media posts surrounding an event or brand. If it was forked to include the ability to make the social media content searchable and sortable, SocialCrumbs would be even more useful beyond a simple visual display of activities.</p>
<p>In its current state, the theme is a nice example of IFTTT and WordPress working together to create a configurable social stream that aggregates activity from multiple networks to a single page of your WordPress site. Check it out on <a href=\"https://github.com/ademilter/socialcrumbs\" target=\"_blank\">GitHub</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2015 18:31:54 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: Paired Opposites\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45232\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/07/paired-opposites/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:517:\"<blockquote><p>I used to think that paired opposites were a given, that love was the opposite of hate, right the opposite of wrong. But now I think we sometimes buy into these concepts because it is so much easier to embrace absolutes than to suffer reality. I don&#8217;t think anything is the opposite of love. Reality is unforgivingly complex.</p>
<p>&#8212; Anne Lamott</p></blockquote>
<p>From her great book <a href=\"http://www.amazon.com/Bird-Some-Instructions-Writing-Life/dp/0385480016\">Bird by Bird</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2015 14:58:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: Chris Pearson Loses Cybersquatting Case Against Automattic\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46365\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/automattic-wins-cybersquatting-case-against-chris-pearson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6258:\"<p>First <a href=\"http://domainnamewire.com/2015/07/08/wordpress-wins-another-round-against-chris-pearson/\">reported by Domain Name Wire</a>, Automattic has <a href=\"http://www.adrforum.com/domaindecisions/1613723.htm\">won their <span class=\"_Tgc\"> Uniform Domain-Name Dispute-Resolution Policy</span> (UDRP) case</a> against <a href=\"http://www.pearsonified.com/\">Chris Pearson</a>. UDRP requests are<span class=\"_Tgc\"> a process established by the Internet Corporation for Assigned Names and Numbers (ICANN) for the resolution of disputes regarding the registration of internet domain names. </span></p>
<h2>Automattic Wins Thesis.com</h2>
<p>According to <a href=\"http://www.adrforum.com/domaindecisions/1613723.htm\">findings by the UDRP panel</a>, in late 2014, a third-party who owned <a href=\"http://themeshaper.com/\">Thesis.com</a> approached Automattic and Pearson to see if they were interested in buying the domain. Automattic won the domain by bidding $100K.</p>
<p>Soon after winning the domain, Pearson filed a UDRP request with ICANN seeking relief requesting that the domain name be transferred from Automattic to himself. In June 2015, a three-member panel was appointed to review the case.</p>
<p>According to <a href=\"https://www.icann.org/resources/pages/rules-be-2012-02-25-en\">rule number five</a> set forth by ICANN for the UDRP process, Respondents have 20 days to respond to the Provider. If a Respondent does not submit a response, in the absence of exceptional circumstances, the Panel decides the dispute based upon the complaint.</p>
<p>In a controversial move, the Panel accepted and reviewed Automattic&#8217;s late response.</p>
<blockquote><p>The Panel notes that Respondent failed to submit its response within the requisite time period, failing to comply with ICANN Rule #5.  In its discretion, the Panel considered Respondent’s arguments in the late filed Response in the interest of justice.</p></blockquote>
<p>Pearson satisfied two of the three burdens imposed under the Policy in order for the Panel to order transfer of a domain name from the entity registering it. Pearson failed to provide evidence that showed Thesis.com redirects to Themeshaper.com. In its response to the Panel, Automattic admitted to using the domain in this way but it appears to have had no affect on the Panel&#8217;s decision.</p>
<p>The Panel noted that if Complainant’s submissions are insufficient, it may request additional exhibits or information under Rule 12 but given the outcome, the Panel chose not to seek additional submissions.</p>
<p>You can view the panel&#8217;s findings in <a href=\"http://www.adrforum.com/domaindecisions/1613723.htm\">this public document.</a> The panel concluded that the Complainant (Pearson) failed to establish all three elements required under the ICANN Policy and that relief shall be denied.</p>
<blockquote><p>A party must satisfy all three of the burdens imposed under the Policy in order for the Panel to order transfer of a domain name from the entity registering it. Here, Complainant failed to establish that Respondent registered and used the disputed domain name in bad faith.</p>
<p><em>See Starwood Hotels &amp; Resorts Worldwide, Inc. v. Samjo CellTech.Ltd</em>, FA 406512 (Nat. Arb. Forum Mar. 9, 2005) (finding that the complainant failed to establish that respondent registered and used the disputed domain name in bad faith because mere assertions of bad faith are insufficient for a complainant to establish Policy ¶ 4(a)(iii)). Therefore, the Panel finds that Complainant failed to support its allegations under Policy ¶ 4(a)(iii) and finds for Respondent.</p></blockquote>
<p>Therefore, Thesis.com is allowed to remain under Automattic&#8217;s ownership.</p>
<h2>Automattic Strikes Back</h2>
<p>On June 16th, Automattic struck back by <a href=\"http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1\">filing a petition for cancellation</a> with the United States Patent and Trademark Office. In their petition, Automattic argues that the three trademarks owned by Pearson, DIYTHEMES, THESIS THEME, and THESIS, should be cancelled.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/PetitionForCancellation.png\"><img class=\"size-full wp-image-46431\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/PetitionForCancellation.png?resize=704%2C721\" alt=\"Petition for Cancellation\" /></a>Petition for Cancellation
<p>When questioned about the Thesis.com domain and petition to cancel Perason&#8217;s trademarks, Automattic responded with the following statement:</p>
<blockquote><p>Chris Pearson tried to seize a domain Automattic owns through the UDRP process. As part of defending ourselves we have dug into the trademarks that were being claimed by the aggressor, as that was the basis of his claim.</p>
<p>We&#8217;re happy the panel ruled in our favor. We think Thesis.com is a cool, generic .com that could be used for a variety of things. Just because you have a small WordPress theme doesn&#8217;t mean you have a right to seize generic English word .com domains.</p></blockquote>
<p>I&#8217;ve reached out to Pearson for comment but have yet to receive a response.</p>
<h2>Automattic&#8217;s Interest in Thesis.com Remains Unexplained</h2>
<p>There are a lot of unanswered questions that need to be answered. For instance, why did Automattic participate in the bidding process for Thesis.com when it has nothing to do with WordPress.com or associated services?</p>
<p>The turbulent history between <a href=\"http://wordpress.tv/2010/07/15/mixergy-interview-pearson-mullenweg/\">Matt Mullenweg and Pearson in 2010</a> nearly resulted in a lawsuit over GPLv2 compliance. The statement from Automattic fails to clarify why the company pursued Pearson again years later by bidding on a domain relevant to his business, apart from stating that it&#8217;s &#8220;a cool generic.com&#8221;. Going after Pearson&#8217;s trademarks in order to have them cancelled raises questions as to whether the move is motivated by retribution.</p>
<p>We&#8217;ll keep a close eye on the <a href=\"http://ttabvue.uspto.gov/ttabvue/v?pno=92061714&pty=CAN&eno=1\">trademark cancellation petition</a> and if there are any updates, we&#8217;ll let you know.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 10 Jul 2015 04:40:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:96:\"WPTavern: PhpStorm 9 Introduces Partial PHP 7 Support, Inline Debugging, and Remote File Editing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46327\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:104:\"http://wptavern.com/phpstorm-9-introduces-partial-php-7-support-inline-debugging-and-remote-file-editing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3006:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/introduce_parameter.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/introduce_parameter.png?resize=1025%2C513\" alt=\"New in PhpStorm 9: Introduce parameter refactoring\" class=\"size-full wp-image-46421\" /></a>New in PhpStorm 9: <em>Introduce parameter</em> refactoring
<p><a href=\"http://www.jetbrains.com/phpstorm/whatsnew/\" target=\"_blank\">PhpStorm 9</a> was released this week with a slew of improvements and new features for PHP and web developers. The popular IDE is used by more than 300,000 developers and its development team usually puts out one major release per year. <a href=\"http://wptavern.com/phpstorm-8-released-with-full-wordpress-support\" target=\"_blank\">Version 8</a> was released last September with official support for WordPress.</p>
<p>Highlights of version 9 include:</p>
<ul>
<li>PHP Language &#038; Editing Experience: Includes <a href=\"http://blog.jetbrains.com/phpstorm/2015/05/postfix-code-completion-for-php-in-phpstorm-9-eap/\" target=\"_blank\">postfix code completion for PHP</a>, partial PHP 7 support, advanced code understanding, and other enhancements</li>
<li>New Debugging Experience: <a href=\"http://blog.jetbrains.com/phpstorm/2015/03/inline-debugging-for-php-in-phpstorm-9-eap/\" target=\"_blank\">Inline debugger</a> for PHP and <a href=\"http://blog.jetbrains.com/phpstorm/2015/07/debugging-improvements-in-phpstorm-9/\" target=\"_blank\">debugging workflow enhancements</a></li>
<li>Remote Development: <a href=\"http://blog.jetbrains.com/phpstorm/2015/04/remote-edit-in-phpstorm-9-eap/\" target=\"_blank\">Remote edit</a>, PHP Code Sniffer and Mess Detector via remote PHP interpreters</li>
<li>Many improvements related to frameworks and tools</li>
<li>A range of new and updated third-party plugins available in the <a href=\"https://plugins.jetbrains.com/phpStorm\" target=\"_blank\">PhpStorm plugin repository</a></li>
</ul>
<p>The new <a href=\"http://blog.jetbrains.com/phpstorm/2015/03/inline-debugging-for-php-in-phpstorm-9-eap/\" target=\"_blank\">inline debugging</a> feature is already a hit with WordPress developers. It lets you view variable values in the source code, next to their usages, without having to switch over to the Variables pane or Debug tool window.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Pretty much in love with <a href=\"https://twitter.com/phpstorm\">@phpstorm</a> 9\'s inline debugging h/t <a href=\"https://twitter.com/jeremyfelt\">@jeremyfelt</a></p>
<p>&mdash; Zack Tollman (@tollmanz) <a href=\"https://twitter.com/tollmanz/status/618905116326805504\">July 8, 2015</a></p></blockquote>
<p></p>
<p>Auto-recognition of <a href=\"https://youtrack.jetbrains.com/issue/WI-21339\" target=\"_blank\">common WordPress global variables</a> (global variable => classname) is also included in the latest release.</p>
<p>Check out the version 9 tour video to see some of the new features in action:</p>
<p><span class=\"embed-youtube\"></span></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 22:33:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Edit WordPress Email Templates in the Customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46394\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wptavern.com/edit-wordpress-email-templates-in-the-customizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3806:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/02/mailboxes.jpg?resize=1024%2C496\" alt=\"mailboxes\" class=\"aligncenter size-full wp-image-39214\" /></a></p>
<p>Argentinian WordPress developer <a href=\"https://wp.timersys.com/\" target=\"_blank\">Damian Logghe</a> had never touched the <a href=\"https://codex.wordpress.org/Theme_Customization_API\" target=\"_blank\">Customizer API</a>, but with all the controversy swirling around it, he decided to jump in to see what all the fuss was about.</p>
<p>&#8220;The customizer has been making a lot of noise lately, as we all know, bringing politics to WordPress, and by politics I mean people arguing but getting nowhere,&#8221; he said.</p>
<p>&#8220;As a plugin developer I never coded with the customizer and I only used it as a front end user. But at the latest <a href=\"https://buenosaires.wordcamp.org/2015/\" target=\"_blank\">WordCamp Buenos Aires</a>, <a href=\"https://twitter.com/eliorivero\" target=\"_blank\">Elio Rivero</a> spoke about using the customizer in plugins, and I decided to give it a try instead of entering into debate. And you know what? I loved it!&#8221;</p>
<p>Logghe was contracted to build a new WordPress site and was looking for an easy way to beautify WordPress&#8217; default emails. He thought that the customizer would be the best choice for the job. After a week of development, he created <a href=\"https://wordpress.org/plugins/email-templates/\" target=\"_blank\">Email Templates</a>, the first plugin to enhance WordPress email templates using the customizer.</p>
<p>Email Templates can be accessed under the Appearance menu. The plugin creates customizer panels for editing the template, email header, footer, and settings. It even includes the ability to send a test email.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-panels.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-panels.jpg?resize=1014%2C638\" alt=\"email-templates-panels\" class=\"aligncenter size-full wp-image-46399\" /></a></p>
<p>Adding a logo to the top of your email template is as easy as uploading an image. You can also customize the alignment, background color, and header text. The plugin includes panels for changing the &#8220;from name&#8221; and &#8220;from email&#8221;, footer text, and basic template styles.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-logo.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/email-templates-logo.jpg?resize=1025%2C643\" alt=\"email-templates-logo\" class=\"aligncenter size-full wp-image-46401\" /></a></p>
<p>After you finish your customizations, you can fire off a test email to see how the new template looks in your inbox. I tested the plugin and found that it works as advertised. Ordinarily, customizing WordPress&#8217; default email template is not something your average user would attempt to do. The <a href=\"https://wordpress.org/plugins/email-templates/\" target=\"_blank\">Email Templates</a> plugin makes this accessible to anyone.</p>
<p>Building with the Customizer API has solidified Logghe&#8217;s belief in its potential for the future of WordPress. His example of live previewing email templates is a creative use of the API in the context of a plugin.</p>
<p>&#8220;In my opinion, the customizer is the right choice for every design change,&#8221; he said. &#8220;The API is extremely easy to use and previewing changes on the fly makes it awesome for every end user.</p>
<p>&#8220;It is just matter of time until the waters get calm and everyone migrates to it. In a year or so, editing your theme without the customizer is going to feel strange.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 20:00:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Matt: 39 WordCamps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45228\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"http://ma.tt/2015/07/39-wordcamps/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:220:\"<p>There have been 39 WordCamps already so far this year, <a href=\"https://wordpress.org/news/2015/07/wordcamps-update/\">here are a bunch more interesting stats about WordCamps including a list of upcoming ones.</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 15:50:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Joseph: WordCamp SLC 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"https://josephscott.org/?p=13154\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://josephscott.org/archives/2015/07/wordcamp-slc-2015/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1045:\"<p><a href=\"https://slc.wordcamp.org/2015/\">WordCamp Salt Lake City 2015</a> is coming September 12 at Washington Square ( 451 South State Street ).  <a href=\"https://slc.wordcamp.org/2015/tickets/\">Tickets</a> are already on sale, only <a href=\"https://slc.wordcamp.org/2015/tickets/\">$18 each</a>.  The <a href=\"https://slc.wordcamp.org/2015/attendees/\">attendees page</a> has a list of some of the people who have already signed up.</p>
<p><a href=\"https://slc.wordcamp.org/2015/speakers/\">Speakers</a> are being <a href=\"https://slc.wordcamp.org/2015/news/\">announced on the news page</a>.  If you area interested in presenting fill out the <a href=\"https://slc.wordcamp.org/2015/07/01/call-for-speakers/\">call for speakers form</a>.  We are also looking for <a href=\"https://slc.wordcamp.org/2015/07/01/call-for-volunteers/\">volunteers</a> and <a href=\"https://slc.wordcamp.org/2015/07/01/call-for-sponsors/\">sponsors</a>.</p>
<div class=\"jetpack-video-wrapper\"></div>
<p>Come learn and hang out with the local Utah WordPress community.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 14:48:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Joseph Scott\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: Napoleon Champagne\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45221\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2015/07/napoleon-champagne/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:130:\"<blockquote><p>In victory you deserve champagne.</p>
<p>In defeat you need it.</p>
<p>&#8212; Napoleon Bonaparte</p></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 04:25:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: BuddySlack Plugin Sends BuddyPress Activities to a Slack Channel\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46203\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/buddyslack-plugin-sends-buddypress-activities-to-a-slack-channel\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4041:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/buddyslack.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/buddyslack.jpg?resize=656%2C300\" alt=\"buddyslack\" class=\"aligncenter size-full wp-image-46372\" /></a></p>
<p>Not long after the WordPress project adopted Slack as its primary form of communication, David Bisset started using it to help <a href=\"http://davidbisset.com/organizing-a-conference-with-slack/\" target=\"_blank\">organize WordCamp Miami 2015</a>. The application added real time communication for organizers, speakers, volunteers, sponsors, and the public. He found it to be a helpful addition to the WordCamp&#8217;s conference communication tools.</p>
<p>As a new fan of the platform, Bisset decided to build an extension for those who want to use Slack with BuddyPress. <a href=\"https://wordpress.org/plugins/buddyslack/\" target=\"_blank\">BuddySlack</a> is his first plugin released on WordPress.org. The bare bones plugin will send a notice to Slack whenever an activity stream item is generated by any of the following core components:</p>
<ul>
<li>Members</li>
<li>Profiles</li>
<li>Activity</li>
<li>Groups</li>
</ul>
<p>The plugin allows you send your selected stream of activity posts to a particular channel, private group, or as a direct message to a user on your Slack team. It also includes an optional Slack settings panel within BuddyPress user profiles, allowing them to opt out of having their activities sent to Slack.</p>
<p>In order to use the BuddySlack plugin, you&#8217;ll need to set up an incoming webhook via Slack, which can then be entered into the plugin&#8217;s settings panel.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/screenshot-1.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/screenshot-1.png?resize=1025%2C736\" alt=\"screenshot-1\" class=\"aligncenter size-full wp-image-46379\" /></a></p>
<p>Bisset doesn&#8217;t plan on officially supporting the plugin but will add more features as time permits. He recognizes that it is currently somewhat limited, as it only supports sending activities for four default BuddyPress components. In the future, Bisset plans to expand it to support custom BP components as well as allow the user to customize the message sent to Slack.</p>
<p>Ideally, the plugin would allow you to set certain trigger words so that you wouldn&#8217;t have to send the entire stream of activities from a selected component. Right now the best use for BuddySlack might be on a smaller social network that doesn&#8217;t have a constant stream of activities. For example, if the Groups component is used sparingly, sending group activity stream posts to a specific Slack channel could be useful. Being able to narrow it down to a specific group would be even better.</p>
<p>The <a href=\"http://wptavern.com/wp-slack-plugin-sends-notifications-to-slack-based-on-events-triggered-in-wordpress\" target=\"_blank\">Slack plugin for WordPress</a> allows you to set up multiple integrations for sending notices to different channels. It also allows for sending test notifications and temporarily disabling notices. These might be a few handy features that could benefit <a href=\"https://wordpress.org/plugins/buddyslack/\" target=\"_blank\">BuddySlack</a>. Bisset is accepting pull requests if anyone wishes to <a href=\"https://github.com/dimensionmedia/buddyslack\" target=\"_blank\">contribute to the plugin on GitHub</a>.</p>
<p>Slack integration via a plugin is also available for <a href=\"http://wptavern.com/bbpress-slack-integration-send-new-topics-and-replies-to-a-slack-channel\" target=\"_blank\">bbPress</a>, <a href=\"http://wordpress.org/plugins/slack-woocommerce\" target=\"_blank\">WooCommerce</a>, <a href=\"http://wordpress.org/plugins/slack-edd\" target=\"_blank\">Easy Digital Downloads</a>, <a href=\"http://wordpress.org/plugins/slack-contact-form-7\" target=\"_blank\">Contact Form 7</a>, and <a href=\"http://wordpress.org/plugins/slack-gravityforms\" target=\"_blank\">Gravity Forms</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 09 Jul 2015 01:49:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: Update Adobe Flash Immediately to Patch Critical Security Vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46361\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:91:\"http://wptavern.com/update-adobe-flash-immediately-to-patch-critical-security-vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2384:\"<p>If you have Adobe Flash installed, you&#8217;ll want to make sure it&#8217;s updated to the <a href=\"https://get.adobe.com/flashplayer/\">latest version</a> as it patches a <a href=\"https://helpx.adobe.com/security/products/flash-player/apsa15-03.html\">critical security vulnerability</a>. According <a href=\"http://www.theregister.co.uk/2015/07/07/hacking_team_zero_days_flash_windows_kernel/\">to The Register</a>, confidential source code was stolen from <a href=\"http://www.theverge.com/2015/7/6/8899861/hacking-team-hacked-security-leak\">Hacking Team</a> and <a href=\"http://www.theregister.co.uk/2015/07/06/unified_cdm_static_password/\">leaked online</a>.</p>
<p>Within the leaked source code, software vulnerabilities used by Hacking Team to break into PCs was discovered. Source code for the vulnerabilities is out in the open which means you should update as soon as possible. You&#8217;re at risk if you use the following:</p>
<table border=\"1\" width=\"100%\" cellspacing=\"0\" cellpadding=\"1\">
<tbody>
<tr>
<td width=\"120\">Adobe Flash Player Desktop Runtime</td>
<td width=\"120\">18.0.0.194 and earlier</td>
<td width=\"120\">Windows and Macintosh</td>
</tr>
<tr>
<td>Adobe Flash Player Extended Support Release</td>
<td>13.0.0.296 and earlier</td>
<td>Windows and Macintosh</td>
</tr>
<tr>
<td>Adobe Flash Player for Google Chrome</td>
<td>18.0.0.194 and earlier</td>
<td>Windows, Macintosh and Linux</td>
</tr>
<tr>
<td>Adobe Flash Player for Internet Explorer 10 and Internet Explorer 11</td>
<td>18.0.0.194 and earlier</td>
<td>Windows 8.0 and 8.1</td>
</tr>
<tr>
<td width=\"60\">Adobe Flash Player</td>
<td>11.2.202.468 and earlier</td>
<td>Linux</td>
</tr>
<tr>
<td>AIR Desktop Runtime</td>
<td>18.0.0.144 and earlier</td>
<td>Windows and Macintosh</td>
</tr>
<tr>
<td>AIR SDK</td>
<td>18.0.0.144 and earlier</td>
<td>Windows, Macintosh, Android and iOS</td>
</tr>
<tr>
<td>AIR SDK &amp; Compiler</td>
<td>18.0.0.144 and earlier</td>
<td>Windows, Macintosh, Android and iOS</td>
</tr>
</tbody>
</table>
<p>Visit Adobe&#8217;s <a href=\"https://get.adobe.com/flashplayer/\">Flash Player download page</a> to determine which version you&#8217;re using and upgrade if necessary. In recent months, Adobe has fixed a <a href=\"https://helpx.adobe.com/security.html\">series of security vulnerabilities</a> in Flash. At this point, it may be safer to uninstall Flash all together.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 22:28:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"WPTavern: Stack Exchange Blog Ditches WordPress for Jekyll\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"http://wptavern.com/stack-exchange-blog-ditches-wordpress-for-jekyll\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4747:\"<p>Last week Stack Exchange <a href=\"http://blog.stackexchange.com/2015/07/the-new-stack-exchange-blog/\" target=\"_blank\">announced</a> its new blog, revamped to publish company news and engineering posts. The first post on the blog, written by Jon Chan, Stack Overflow&#8217;s developer evangelist, made no small amount of fanfare over <a href=\"http://blog.stackexchange.com/2015/07/how-we-built-our-blog/\" target=\"_blank\">migrating from WordPress to Jekyll</a>.</p>
<p>Chan&#8217;s explanation of the team&#8217;s process cites a few curious reasons for their dissatisfaction with WordPress:</p>
<blockquote><p>During the original proposal stage for the engineering blog, we also had a conversation about what engine we would use. At the time, all of our blogs were running WordPress&#8230;which we weren&#8217;t so happy about. It was very buggy, difficult to log in to, not very performant, and has caused our SRE team more than a few headaches. If we were really going to revamp the new company blog, it seemed like a lot of work to try and wrestle with our WordPress installation.</p></blockquote>
<p>With a little bit of WordPress skill, these seem like easy complaints to resolve, especially given that Chan said the team was inspired by blogs like <a href=\"https://codeascraft.com/\" target=\"_blank\">Code as Craft</a> and <a href=\"http://oktrends.okcupid.com/\" target=\"_blank\">OkTrends</a>, both powered by WordPress. However, anti-WordPress sentiments continue to run high within the Stack Overflow community, which recently ranked the software as <a href=\"http://wptavern.com/stack-overflow-developer-survey-ranks-wordpress-as-the-3rd-most-dreaded-technology\" target=\"_blank\">the third most dreaded technology</a>.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/get-rid-of-wp.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/get-rid-of-wp.png?resize=800%2C528\" alt=\"photo credit: StackExchange Blog\" class=\"size-full wp-image-46331\" /></a>photo credit: <a href=\"http://blog.stackexchange.com/2015/07/how-we-built-our-blog/\">StackExchange Blog</a>
<p>After a great deal of consideration, the Stack Exchange team opted to use a static engine, eventually landing on <a href=\"http://jekyllrb.com/\" target=\"_blank\">Jekyll</a>. Chan outlined the advantages they perceived in the move:</p>
<ul>
<li>Posts are in Markdown, something most of our company was familiar with</li>
<li>Jekyll is just static site generation, so it&#8217;s much more performant</li>
<li>Complete flexibility for front end work, no need to wrestle with templates</li>
<li>Open source with a strong community, which we love</li>
<li>Not WordPress or PHP</li>
</ul>
<p>Chan described the migration process, an endeavor that was fraught with obstacles. There is a <a href=\"http://wptavern.com/export-your-wordpress-blog-to-jekyll-with-one-click\" target=\"_blank\">Jekyll Exporter plugin</a> available to those who want to migrate their blogs over, but Stack Exchange opted to use the <a href=\"https://github.com/thomasf/exitwp\" target=\"_blank\">exitwp</a> tool to get them most of the way there.</p>
<p>Since Jekyll doesn&#8217;t offer native support for comments, one of the biggest challenges in the migration was preserving that content and porting it into a new system. The Stack Exchange team decided to use <a href=\"https://disqus.com/\" target=\"_blank\">Disqus</a> for comments but were unable to properly migrate their existing comments and had to craft an alternative solution.</p>
<p>&#8220;The worst part of this is how unsupported we were by the Disqus team,&#8221; Chan said. &#8220;We waited on the order of weeks for support responses and for over a month they went unresolved. Sending in official support tickets, emails, and posts on their Discuss forum went unnoticed.&#8221;</p>
<p>Despite their unsatisfactory experience with Disqus and the fact that they have to sacrifice Stack Exchange login capabilities in order to use it, Chan said they will continue with it going forward.</p>
<p>If you&#8217;re running a large, high profile blog on WordPress, it requires a certain level of expertise to customize themes and plugins and to ensure a high level of performance. It&#8217;s unclear whether or not the Stack Exchange team was lacking in expertise (based on some of the complaints cited) or simply unwilling to continue with WordPress after unsatisfactory experiences. No massive migration from one platform to another is ever going to be easy and bug-free, but Chan&#8217;s <a href=\"http://blog.stackexchange.com/2015/07/how-we-built-our-blog/\" target=\"_blank\">account</a> offers some valuable insight on how difficult it currently is to move from WordPress to Jekyll while preserving all of your content.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 21:29:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WPTavern: HeroPress Ends Experiment With WPChat\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46345\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"http://wptavern.com/heropress-ends-experiment-with-wpchat\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2781:\"<p>Since March of this year, <a href=\"http://heropress.com/\">HeroPress</a> has published inspirational essays from people all over the world. Instead of allowing comments on the site itself, Topher DeRosia, founder of HeroPress, partnered with <a href=\"http://www.wpchat.com\">WPChat</a> to host conversations for each essay. Unfortunately, many of the articles received little feedback.</p>
<p>Starting this week, DeRosia is allowing contributing writers <a href=\"http://heropress.com/thoughts-on-comments/\">to decide</a> whether they want comments enabled on their essay or not. &#8220;I made the decision to have no comments because I wanted the essays to stand alone, with one voice, that being the voice of the contributor.&#8221; DeRosia told the Tavern.</p>
<p>Directing people to a third-party site is an odd way to generate a conversation around an article. DeRosia explains why he chose to host comments on WPChat, &#8220;I chose to attach WPChat to the project because it seemed like a good way for readers to express themselves without marring the surface of the essay itself.&#8221;</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/HeroPress3SurveyOnWPChat.png\"><img class=\"size-full wp-image-46347\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/HeroPress3SurveyOnWPChat.png?resize=816%2C594\" alt=\"Example of a Conversation on WPChat About a HeroPress Essay\" /></a>Example of a Conversation on WPChat
<p><em><a href=\"https://wpchat.com/t/isolated-and-intrigued-heropress-essay-3/796\">Isolated and intrigued</a></em> as well as <em><a href=\"https://wpchat.com/t/finding-stability-in-wordpress/893\">Finding stability in WordPress</a></em> are two examples where great conversations took place on WPChat. However, these conversations are few and far between. &#8220;That leads me to believe there could be more quality input out there and people are simply not interested in making an extra account to comment,&#8221; said DeRosia.</p>
<p>Contributors who choose to enable comments don&#8217;t need to worry about moderation. DeRosia will heavily moderate comments with a zero tolerance policy for trolls. As for WPChat hosting future conversations, DeRosia says, &#8220;I like WPChat but in this case, I simply don&#8217;t think it&#8217;s the tool for the job.&#8221;</p>
<p>Comments connect authors to readers and are an <a href=\"http://wptavern.com/why-comments-still-matter\">important part of the internet</a>. Sometimes, the feedback is better than the post itself. However, requiring readers to register to a forum to comment on articles hosted on a different site is too high of a roadblock. The commenting process should be as smooth and simple as possible. Enabling comments on HeroPress is a step in the right direction.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 20:29:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Customer Success?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45217\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/07/customer-success/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:225:\"<p>&#8220;Customer support, when done well, is a career.&#8221; Automattic&#8217;s support lead Andrew Spittle on <a href=\"http://andrewspittle.com/2015/07/02/customer-success/\">customer success vs customer support</a>. </p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 08 Jul 2015 03:00:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: BuiltWith Reports a 7% Increase in WordPress’ Usage from January – July 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46287\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/builtwith-reports-a-7-increase-in-wordpress-usage-from-january-july-2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4602:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/chart.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/chart.jpg?resize=1025%2C511\" alt=\"photo credit:  Luis Llerena\" class=\"size-full wp-image-46313\" /></a>photo credit:  <a href=\"https://stocksnap.io/photo/S3JE5YAMND\">Luis Llerena</a>
<p>BuiltWith, the popular service dedicated to monitoring internet technology trends and providing platform usage analytics, released its bi-annual <a href=\"http://blog.builtwith.com/2015/07/06/entire-internet-cms-usage-january-july-2015/\" target=\"_blank\">internet coverage report for CMS usage from January &#8211; July 2015</a>. The report shows that WordPress, which accounts for 48% of total CMS&#8217;s tracked, added 1.1 million domains since January.</p>
<blockquote><p>WordPress has been found on an additional 1.1 million domains since January but only accounts for a 7% increase in customer base. Whereas Ghost was added to 2,184 domain home pages and accounts for a 17% increase in their customer base.</p></blockquote>
<p>The title of the summary is &#8220;CMS Market Share Increases by Install Base,&#8221; but WordPress is the only CMS shown in the chart with an actual market share value assigned based on its place among tracked competitors.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/builtwith-cms-marketshare-june-2015-report.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/builtwith-cms-marketshare-june-2015-report.png?resize=600%2C793\" alt=\"builtwith-cms-marketshare-june-2015-report\" class=\"aligncenter size-full wp-image-46289\" /></a></p>
<p>BuiltWith indexed 328,852,063 domains during this quarter. Instead of simply showing the increase by usage numbers, the summary focuses on the percentage increase in customer base for a more interesting comparison. When commenters noted that this is not, in fact, market share data, Ghost co-founder John O&#8217;Nolan replied, &#8220;Relative growth compared to existing size is pretty much the only sane measure.&#8221;</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/JohnONolan\">@JohnONolan</a> Strange perspective. Ghost added 17% or 2,184 domains. WordPress added 7% or 1,149,956. That\'s only 535 times more sites ;)</p>
<p>&mdash; Aigars Silkalns (@AigarsSilkalns) <a href=\"https://twitter.com/AigarsSilkalns/status/618368722613497856\">July 7, 2015</a></p></blockquote>
<p></p>
<p>Oddly, the report did not share any figures for <a href=\"http://trends.builtwith.com/cms/Drupal\" target=\"_blank\">Drupal</a> or <a href=\"http://trends.builtwith.com/cms/Joomla!\" target=\"_blank\">Joomla</a>, which <a href=\"http://w3techs.com/technologies/overview/content_management/all\" target=\"_blank\">W3techs estimates as WordPress&#8217; closest CMS competitors</a> in terms of market share. BuiltWith&#8217;s summary appears to be limited to the fastest growing platforms based on percentage increase in customer base.</p>
<p>The CMS report also included some interesting stats on the WordPress versions it detected on sites indexed. These numbers roughly correspond to the project&#8217;s <a href=\"https://wordpress.org/about/stats/\" target=\"_blank\">version usage stats</a>, although WordPress doesn&#8217;t publish numbers for versions older than 3.0. BuiltWith found that 1748 websites are still running on WordPress 2.1, released eight years ago. This number is down 259 sites since the beginning of the year.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-versions.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/wordpress-versions.png?resize=600%2C545\" alt=\"photo credit: BuiltWith\" class=\"size-full wp-image-46308\" /></a>photo credit: <a href=\"http://blog.builtwith.com/2015/07/06/entire-internet-cms-usage-january-july-2015/\">BuiltWith</a>
<p>According to Gary Brewer, founder of BuiltWith, &#8220;Wix and Squarespace’s main acquisition for existing websites that are using a CMS are from WordPress sites.&#8221; He also notes that WordPress continues to dominate without the help of celebrity advertisements. <a href=\"https://www.youtube.com/watch?v=mjhZ11vGl1Q\" target=\"_blank\">Wix&#8217;s ad with Heidi Klum</a> and <a href=\"https://www.youtube.com/watch?v=BKIlfLReHyo\" target=\"_blank\">Squarespace&#8217;s Jeff Bridges commercial</a>, which aired during the Super Bowl, are evidence of both companies&#8217; massive marketing budgets. WordPress.com, the world&#8217;s leading provider of free WordPress sites, has yet to explore that route.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jul 2015 23:05:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"WPTavern: New Proposal on Trac to Remove Post Formats from WordPress Core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45949\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/new-proposal-on-trac-to-remove-post-formats-from-wordpress-core\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4154:\"<p><a href=\"http://codex.wordpress.org/Post_Formats\">Post Formats</a> is a feature introduced in WordPress 3.1 that enables themes to visually differentiate between types of content. A<a href=\"http://wptavern.com/post-format-history-and-wordpress-3-6\"> metabox with radio buttons</a> was added in WordPress 3.6 to expose the feature to users and allow them to easily select a format. Since WordPress 3.6 was released, there has been <a href=\"https://core.trac.wordpress.org/query?status=accepted&status=assigned&status=closed&status=new&status=reopened&status=reviewing&component=Post+Formats&order=priority\">little effort</a> to improve the feature.</p>
<p>Morten Rand-Hendriksen <a href=\"http://wptavern.com/wordpress-trainer-morten-rand-hendriksen-on-common-pain-points-roadblocks-and-advice-for-new-users\">teaches WordPress</a> to thousands of people through <a href=\"http://www.lynda.com/WordPress-tutorials/WordPress-Essential-Training/154417-2.html\">Lynda.com</a>. After spending time writing training materials for post formats, Hendriksen was reminded of how much post formats shouldn&#8217;t be in WordPress core.</p>
<p>He&#8217;s created a <a href=\"https://core.trac.wordpress.org/ticket/32844\">new ticket on trac</a> suggesting post formats be removed from WordPress and placed into a plugin similar to how the link manager and blogroll <a href=\"https://codex.wordpress.org/Links_Manager\">were removed</a> in WordPress 3.5.</p>
<blockquote><p>After the termination of Post Formats UI, it appears the feature has largely been left to pasture and implementation across themes is at best spotty and inconsistent. One example of this is how different Post Formats are treated in the default themes, culminating in the minimalist/absent inclusion in Twenty Fifteen.</p></blockquote>
<p>Hendriksen lists six key arguments that come up when discussing the removal of post formats from WordPress:</p>
<ul>
<li>Feature support is inconsistent across themes causing users to wonder why the panel and options appear and disappear when themes are switched.</li>
<li>When implemented, behavior is inconsistent between themes causing a perception of arbitrary or broken behavior in the eyes of the user.</li>
<li>Specification for what exactly each post format does is vague and ambiguous giving theme developers too much room to come up with arbitrary and non-standard behaviors that cause user confusion when themes are switched.</li>
<li>The use case for Post Formats seems to have gone away or have been supplanted for the larger goal of making modular, Snowfall-like post editing available.</li>
<li>Post Formats behavior can be mimicked by theme developers through the use of Categories or other custom taxonomies.</li>
</ul>
<p>Applying the <a href=\"https://en.wikipedia.org/wiki/Pareto_principle#In_software\">80/20 rule</a> to software development, Hendriksen believes post formats is in the 20% range or lower. He ends the ticket by proposing post formats be moved into a feature plugin.</p>
<p>This would allow it to be improved concurrently with WordPress and open up opportunities to experiment with different implementations and ideas. Alternatively, it could be abandoned if no interest is shown to improve it.</p>
<h2>Move Post Formats to a Plugin</h2>
<p>My opinion of Post Formats hasn&#8217;t changed since the <a href=\"http://wptavern.com/why-arent-post-formats-in-wordpress-more-popular\">last time I wrote about them</a>. They&#8217;re still unpredictable, I don&#8217;t see many sites using them, and they&#8217;re tough to explain to new users.</p>
<p>Considering post formats dramatically impact the presentation of content, it&#8217;s strange that the core team has not continually improved the feature after 3.6. By now, they should be rock solid. Instead, it&#8217;s a feature with no obvious future.</p>
<p>Although you can leave a comment on this post, the best place to leave feedback is in this <a href=\"https://core.trac.wordpress.org/ticket/32844\">trac ticket</a>. It&#8217;s time WordPress core developers got involved with the conversation to let us know what they think about the future of post formats in WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jul 2015 18:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"WPTavern: WordPress 4.3 Improves User Search and Turns Comments Off on Pages by Default\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46238\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"http://wptavern.com/wordpress-4-3-improves-user-search-and-turns-comments-off-on-pages-by-default\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4001:\"<p><a href=\"http://wptavern.com/wordpress-4-3-beta-1-now-available-for-testing\" target=\"_blank\">WordPress 4.3 beta 1</a> was put into the hands of testers last week. Those who have been following 4.3 developments are already familiar with the major features headlining this release, ie. the new <a href=\"http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this\" target=\"_blank\">site icons</a>, <a href=\"http://wptavern.com/menu-customizer-officially-approved-for-merge-into-wordpress-4-3\" target=\"_blank\">menu management in the customizer</a>, and <a href=\"https://core.trac.wordpress.org/ticket/32589\" target=\"_blank\">more secure passwords</a>. However, there are also a couple lesser-known improvements that will have a positive impact on millions of WordPress users.</p>
<h4>Improved User Search</h4>
<p>Searching for users in the admin is about to get much easier, thanks to work on a <a href=\"https://core.trac.wordpress.org/ticket/27304\" target=\"_blank\">ticket</a> opened by John Blackbourn 16 months ago. He notes that &#8220;only the user_login (username) and user_nicename (sanitized username) fields are searched,&#8221; excluding the following more likely fields:</p>
<ul>
<li>First name</li>
<li>Last name</li>
<li>Nickname</li>
<li>Display name</li>
</ul>
<p>This issue was especially problematic in large, multi-thousand member multisite installations where finding a user in the admin often meant knowing exactly what to query and then paging through results. WordPress 4.3 contributions from <a href=\"https://profiles.wordpress.org/mordauk\" target=\"_blank\">Pippin Williamson</a> and <a href=\"https://profiles.wordpress.org/wonderboymusic\" target=\"_blank\">Scott Taylor</a> make it possible to <a href=\"https://core.trac.wordpress.org/changeset/32980\" target=\"_blank\">search by the user&#8217;s email, URL, and display name</a>.</p>
<h4>Comments Turned Off on Pages by Default</h4>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/comments-off-on-pages-by-default.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/comments-off-on-pages-by-default.jpg?resize=962%2C323\" alt=\"comments-off-on-pages-by-default\" class=\"aligncenter size-full wp-image-46275\" /></a></p>
<p>WordPress 4.3 will also bring a welcome change to turn off comments on pages by default. In the future when you create pages, you won&#8217;t have to remember to go into the discussion settings to disable comments. One might think this would be a simple little thing to change, but quite a bit of discussion has gone into crafting the best solution to the <a href=\"https://core.trac.wordpress.org/ticket/31168\" target=\"_blank\">ticket</a> opened five months ago.</p>
<p>This change also applies to all custom post types. Mel Choyce outlined the new behavior in a <a href=\"https://make.wordpress.org/core/2015/07/06/comments-are-now-turned-off-on-pages-by-default/\" target=\"_blank\">post</a> on the make.wordpress.org/core blog:</p>
<blockquote><p>Post registrations that don’t explicitly add support for comments will now default to comments being off on new posts of that type (before, they defaulted to on). Up until now, post type support for comments has only affected admin UI; a developer could omit comment support on registration but still allow comments to be posted. <strong>This is a change in behavior</strong>, and we will be closely monitoring its effects during beta. Moving to explicit support will allow core behavior to be more predictable and robust in the future, but we will always consider real-world usage.</p></blockquote>
<p>The change also comes with a new function and a filter that you can use to restore the current behavior of comments to your post type, if necessary. More details and an example on how to use the filter are available on the make.wordpress.org/core announcement <a href=\"https://make.wordpress.org/core/2015/07/06/comments-are-now-turned-off-on-pages-by-default/\" target=\"_blank\">post</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jul 2015 05:07:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Matt: Why We Encrypt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45215\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"http://ma.tt/2015/07/why-we-encrypt/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:172:\"<p>From one of the best blogs on the internet, <a href=\"https://www.schneier.com/blog/archives/2015/06/why_we_encrypt.html\">Bruce Schnier writes on Why We Encrypt</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 07 Jul 2015 04:46:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"Akismet: Akismet WordPress Plugin 3.1.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=1854\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://blog.akismet.com/2015/07/06/akismet-3-1-3-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1014:\"<p>Version 3.1.3 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available.</p>
<p>This update addresses an issue causing some users to see blank Akismet settings screens. After installing this update, the settings screen should either load successfully, or it will display an error message with instructions for fixing the problem.</p>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.</p><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1854/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1854/\" /></a> <img alt=\"\" border=\"0\" src=\"http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1854&subd=akismet&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 23:49:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Christopher Finke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Jetpack 3.6 Adds the Ability to Manage Your Connections to Jetpack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46227\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"http://wptavern.com/jetpack-3-6-adds-the-ability-to-manage-your-connections-to-jetpack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3928:\"<p>Jetpack 3.6 <a href=\"http://jetpack.me/2015/07/06/jetpack-3-6-updated-social-widgets-jetpack-cli-and-more/\">is available</a> and has <a href=\"https://wordpress.org/plugins/jetpack/changelog/\">several bug fixes and enhancements</a>. <a href=\"http://jetpack.me/support/jetpack-cli/\">Jetpack CLI</a> which is a command line interface for Jetpack and extends off of <a href=\"http://wp-cli.org/\" target=\"_blank\">wp-cli</a> for WordPress, has undergone a number of improvements. There are a handful of new extra sidebar widgets, including Facebook Like Box, and Social Media Icons.</p>
<p>Existing widgets such as Top Posts are more configurable. The Top Posts and Pages widget now allows you to show or hide different page types from the widget. For example, if you only want to show post and page results, check the boxes for Posts and Pages in the widget configuration area.</p>
<p>The new Facebook Like box widget is streamlined and looks much better than its predecessor.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/NewJetpackFacebookWidget.png\"><img class=\"size-full wp-image-46248\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/NewJetpackFacebookWidget.png?resize=332%2C310\" alt=\"New Jetpack Facebook Widget is Streamlined\" /></a>New Jetpack Facebook Widget is Streamlined
<p>There&#8217;s a social media icons widget that&#8217;s great for themes that don&#8217;t already have a built-in method of displaying social networking connections. Simply place it in the sidebar and apply your username to each service you use. On the Tavern test site, the icons were a little too small for my liking but I realize this is an issue with the theme we use.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/SocialMediaIconsWidget.png\"><img class=\"size-full wp-image-46249\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/SocialMediaIconsWidget.png?resize=335%2C128\" alt=\"Social Media Icons Widget\" /></a>Social Media Icons Widget
<p>Jetpack 3.6 also introduces a connection manager where users can manage a site’s <a href=\"http://jetpack.me/support/primary-user/\">Primary User</a>, see any other connected users, and/or manage your connection to WordPress.com. The team says there are plans to add additional features to My Jetpack in future versions.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/JetpackConnectionManager.png\"><img class=\"size-full wp-image-46247\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/JetpackConnectionManager.png?resize=1025%2C383\" alt=\"Jetpack Connection Manager\" /></a>Jetpack Connection Manager
<p>In a sign of the times, <a href=\"http://www.stumbleupon.com/\">StumbleUpon</a> is no longer an option in the sharing module. Email sharing now uses <a href=\"https://developers.google.com/recaptcha/intro\">reCAPTCHA 2.0</a> to verify human behavior. Stats are more accurate as previewing posts and pages no longer count as pageviews.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/AvailableSharingButtons.png\"><img class=\"size-full wp-image-46229\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/AvailableSharingButtons.png?resize=778%2C345\" alt=\"StumbleUpon Sharing Button Retired from Jetpack\" /></a>StumbleUpon Sharing Button Retired from Jetpack
<p>Jetpack Carousel supports HTML 5 and the Slideshare shortcode is fixed. Deprecated card types for Twitter cards are removed and the Facebook share button now shows up for the Australian and Canadian locale.</p>
<p>Upgrade to <a href=\"https://wordpress.org/plugins/jetpack/\">Jetpack 3.6</a> to take advantage of the numerous bug fixes and enhancements. If you&#8217;d like to be the first to test new features and help Jetpack users experience fewer problems, consider participating in the <a href=\"http://wptavern.com/jetpack-relaunches-beta-testing-program\">Jetpack Beta testing program</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 22:58:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: Pressnomics 4 Set for March 3-4, 2016 in Phoenix, AZ\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46236\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"http://wptavern.com/pressnomics-4-set-for-march-3-4-2016-in-phoenix-az\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2822:\"<p>Pressnomics <a href=\"http://pressnomics.com/2015/07/announcing-dates-for-pressnomics-4/\">has announced</a> that the 4th iteration of the event will take place on March 3-4, 2016 at Tempe Mission Palms Hotel, Phoenix, AZ. Started in 2012 by Joshua Strebel of <a title=\"http://page.ly\" href=\"http://page.ly\">Pagely,</a> Pressnomics is a conference dedicated to the business aspects of WordPress, whether it is software as a service, commercial themes and plugins, or development agencies.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/Pressnomics4Dates.png\"><img class=\"aligncenter size-full wp-image-46243\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/Pressnomics4Dates.png?resize=655%2C240\" alt=\"Date for Pressomics 4\" /></a>When the event concluded last year, there was talk of it being moved to Europe for 2016. Despite the event taking place in the US in 2016, I asked Strebel if plans to host Pressnomics in Europe or even a branch of the conference are still on the table?</p>
<blockquote><p>We are conversing with folks in Europe to try to make something happen in 2016, in addition to, Pressnomics 4 in Phoenix. Rather than ice everything until all details are final, we decided to swing and see if we can make both happen.</p></blockquote>
<p>Tickets go on sale <strong>September 1st, 2015 at 10AM PST</strong>. Despite feedback from attendees that ticket prices should increase, event co-organizer Sally Strebel, says prices will remain roughly the same as last year.</p>
<blockquote><p>I’ve been told by numerous people that we should increase the cost of tickets for this event and that they go to other conferences that cost more and return less value.</p>
<p>Thank you for looking out for us and I truly value your opinion, however we have decided to keep costs essentially the same as last year because it’s not about the money. It’s about giving back. We look forward to growing our businesses together.</p></blockquote>
<p>Companies immediately applied to be sponsors within minutes of receiving sponsorship information. Those companies include, GoDaddy, Envato, Sucuri, iThemes, Easy Digital Downloads, and more.</p>
<p>I had the privilege <a href=\"http://wptavern.com/envato-stats-tips-for-getting-things-done-and-more-at-pressnomics-3\">to attend Pressnomics 3</a> and it was by far one of the most unique WordPress conferences I&#8217;ve attended. Compared to WordCamps, the atmosphere is much different and you can tell speakers are more open and relaxed since sessions are not recorded.</p>
<p>March is a great time of year to host a conference in Phoenix. If Pressnomics 3 is anything to go by, Pressnomics 4 will be amazing. If you have the opportunity to attend Pressnomics 4, I highly suggest doing so as it&#8217;s a memorable experience.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 22:48:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: PHP 4 Style Constructors Will Be Deprecated in WordPress 4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46222\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wptavern.com/php-4-style-constructors-will-be-deprecated-in-wordpress-4-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1730:\"<p>PHP 4 style constructors are being deprecated in WordPress 4.3 to ease the transition to support PHP 7. According to Aaron Jorbin, on the <a href=\"https://make.wordpress.org/core/2015/07/02/deprecating-php4-style-constructors-in-wordpress-4-3/\">Make WordPress Core blog post</a>, WordPress <a href=\"https://core.trac.wordpress.org/changeset/32990\">r32990</a> introduces a change so that all classes use the PHP 5 style constructors, while still retaining the PHP 4 style constructors for backwards compatibility.</p>
<p>A deprecated_constructor warning that follows the same rules as <a href=\"https://developer.wordpress.org/reference/functions/_deprecated_function/\">deprecated_function</a> will also be displayed for WordPress classes that are not external libraries</p>
<p><a href=\"http://chriscct7.com/\">Chris Christoff</a>, who contributes to WordPress core, <a href=\"https://gist.github.com/chriscct7/d7d077afb01011b1839d\">generated a list of plugins</a> on the WordPress plugin directory that have widgets calling <code>WP_Widget::WP_Widget()</code> and/or <code>parent::WP_Widget()</code> and/or <code>{object}-&gt;WP_Widget()</code>.</p>
<p>The list includes more than 4,000 plugins and contains the author, title, and slug. Plugin authors should check the list to see if your plugin is listed. Even if it&#8217;s not, you&#8217;re still encouraged to make sure you&#8217;re not using a PHP 4 style constructor in your code.</p>
<p>If you use any of the plugins listed, please create a support forum thread with a link to the <a href=\"https://make.wordpress.org/core/2015/07/02/deprecating-php4-style-constructors-in-wordpress-4-3/\">Make WordPress Core blog post</a> and politely ask them to update their plugin.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 21:11:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: Highlights of Matt Mullenweg’s Q&amp;A Session at WordCamp Europe 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46152\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/highlights-of-matt-mullenwegs-qa-session-at-wordcamp-europe-2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5818:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/mullenweg-wordcamp-europe.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/mullenweg-wordcamp-europe.jpg?resize=1025%2C518\" alt=\"Kari Leigh | Found Art Photography\" class=\"size-full wp-image-46199\" /></a>Kari Leigh | <a href=\"http://www.found-art-photography.com/\" target=\"_blank\">Found Art Photography</a>
<p>The video of <a href=\"http://wordpress.tv/2015/07/04/matt-mullenweg-keynote-qanda-wordcamp-europe-2015/\" target=\"_blank\">Matt Mullenweg&#8217;s Q&amp;A session at WordCamp Europe</a> is now published on WordPress.tv. For those who were unable to attend, this session provides a glimpse into what WordPress&#8217; co-founder sees for the future of the software and the community.</p>
<p>One of the most exciting parts of the video is where Mullenweg talks about the potential of WordPress.org to serve other languages and eventually expand avenues of core contribution to non-English speaking audiences.</p>
<p>When asked what kind of contribution can be made to improve WordPress.org for Rosetta sites, themes, and plugins, Mullenweg replied:</p>
<blockquote><p>Themes and plugins are undoubtedly the most important. To me, the next most important things are the Rosetta sites and having theme and plugin directories available on the Rosetta sites. There is actually a great example at <a href=\"https://ro.wordpress.org/\" target=\"_blank\">ro.wordpress.org</a>, which is the Romanian Rosetta site that shows both the potential and the problem:</p>
<p>Now there are themes and plugins menu items there, which none of the Rosetta sites have had prior to this. But when you click on it you see mostly English in the plugin descriptions, even things like screenshots and tutorials.</p></blockquote>
<p>He described these updates to WordPress.org as just a &#8220;hint of what could be amazing&#8221; one day. Mullenweg noted that despite Europe having 23+ recognized languages, attendees at the WordCamp were all speaking English. However, not all areas of the world are populated by people with bilingual capabilities.</p>
<blockquote><p>I think it would be amazing to open up WordPress to have a first priority experience of the thousands of plugins and themes that are available for people who do not speak a word of English. Right now WordPress is just not accessible to that group. Luckily, over half the people in Europe are bilingual&#8230; In places where that&#8217;s a possibility, WordPress can still do well even though we don&#8217;t have a native experience in someone&#8217;s mother tongue.</p>
<p>But English is only the third most popular language in the world and it&#8217;s not the fastest growing. There are huge audiences that I think would be an important part of the community. Someday I want it to be where, instead of things being translated from English to a different language, we&#8217;re getting core contributions translated from, say, Chinese or Hindi or Spanish, into English to be reviewed. We&#8217;re not looking to just how to translate plugins from English into other languages but vice versa. I think that will be when we&#8217;re successful.</p></blockquote>
<p>In the same way that better language support opens up WordPress to a wider audience, Mullenweg believes that the customizer will open up the software for more non-technical users. During the Q&amp;A he shared his thoughts on the future of the customizer:</p>
<blockquote><p>As we currently are working, the customizer is the way forward&#8230;It essentially removes the fear and disconnect between wp-admin and the front end of a site. It&#8217;s a bridge that gives people the confidence to make changes while seeing those changes in real time. The real time feedback and safety net of seeing that, and being able to undo and redo things, is incredibly empowering, particularly for non-technical users who don&#8217;t know how to dive into CSS or the code. I personally believe that the work on the customizer is some of the most important going on in the WordPress project right now.</p></blockquote>
<p>In addition to building the feature in a way that is responsive to mobile devices, Mullenweg noted that the customizer currently falls short on desktop:</p>
<blockquote><p>The customizer is, for lack of a better word, a narrow interface, because it needs to show your site in addition to the admin. I think we need to do a better job of making sure that interface scales up as well as down, meaning that if you do have the space or would like to make it fullscreen, that it is responsive, so that it enlarges into an interface that probably looks and works much like the current wp-admin interface for being a fullscreen experience for editing and modifying menus, widgets, colors, fonts, header images, site title, all the things that are key to the presentation of your site.</p></blockquote>
<p>It is curious that the customizer is being pushed through to WordPress 4.3 without the ability to scale up gracefully. If the situation were reversed, where the feature was unfriendly to mobile users, it seems less likely that it would have been deemed ready for core. This illustrates the WordPress project&#8217;s strong emphasis on being positioned to attract mobile users.</p>
<p>Mullenweg encouraged attendees to keep an eye on the customizer, because he believes it will do a much better job than Wix and Squarespace when it comes to providing a user-friendly way to customizer websites.</p>
<p>The entirety of the 66-minute long Q&amp;A session is included in the video below. In addition to languages and the customizer, Mullenweg also answers questions about security, WordPress&#8217; minimum PHP version, the possibility of multilingual features in core, and the importance of building for mobile.</p>
<p></p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 16:39:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"WPTavern: A Narrative of Using Composer in a WordPress Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"http://wptavern.com/a-narrative-of-using-composer-in-a-wordpress-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:10900:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/petersuhm.jpeg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/petersuhm.jpeg?resize=150%2C150\" alt=\"petersuhm\" class=\"alignright size-thumbnail wp-image-43613\" /></a>This piece was contributed by guest author <a href=\"https://twitter.com/petersuhm\" target=\"_blank\">Peter Suhm</a>. Peter is a web developer from the Land of the Danes. He is the creator of <a href=\"https://wppusher.com/\" target=\"_blank\">WP Pusher</a> and a huge travel addict, bringing his work along with him as he goes.<br />
&nbsp;</p>
<hr />
<p>The other day I posted <a href=\"http://blog.wppusher.com/a-warning-about-using-composer-with-wordpress/\" target=\"_blank\">a warning about using Composer in WordPress plugins</a> on the WP Pusher blog. This post got a lot of attention and I feel the need to clarify a few points that were not all clear to everyone. The article was also a bit heavy on the technical stuff, so in this post I will try to make my main point more clear by using a simple narrative to illustrate it.</p>
<h3>A narrative</h3>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/boxes.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/boxes.jpg?resize=1024%2C490\" alt=\"photo credit: Doors Open Toronto 2008 - Toronto Archives - (license)\" class=\"size-full wp-image-46150\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/25716750@N06/2527068003\">Doors Open Toronto 2008 &#8211; Toronto Archives</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>Let’s imagine for a while that you and I are both plugin authors. Both of us have a great idea for a plugin we wish to distribute via WordPress.org. We want to include a few premium features in our plugins that users of the free version can unlock by entering a license key.</p>
<p>We need some code that can handle this process. Both of us realize that this problem have probably already been solved by someone else. None of us are fans of reinventing the wheel, so we head over to Packagist and type in “license manager”. It looks like our assumption was justified. Yoast already has a package that can handle this. We both decide to do a quick <code>composer require yoast/license-manager</code>. Easy peasy. Now we can move on to work on something that really matters- the core features of our respective plugins.</p>
<p>Fast forward, ready to release your plugin, you realize something: Your user doesn’t necessarily have Composer handy when installing your plugin from WordPress.org, so how are they going to get the code for the license manager? This situation is a bit annoying, because the only solution you really see is to just commit the whole Composer generated <code>vendor</code> directory to your plugin and push it to WordPress.org. You know this is not how Composer is supposed to work, but whatever. You don’t really have other options.</p>
<p>Meanwhile, I have come to the same conclusion with my plugin. Just include the license manager code and be done with it.</p>
<p>Fast forward once more, both our plugins now live in the WordPress.org repository and once in a while, someone decides to upgrade to our premium versions. Everything seems to be fine and we are both grateful that we could just use the code that Yoast had generously open sourced, and didn’t have to reinvent the wheel.</p>
<p>One day, you receive a strange e-mail. A customer is experiencing some really strange behavior when trying to unlock your premium features. It makes no sense to you, because no one else ever reported this. After hours of debugging, you finally ask your customer to deactivate everything else, except your plugin, and then: It works! Hmm. Your plugin seems to somehow be incompatible with another plugin. My plugin.</p>
<p>You realize this after hours of going through source code of all the other plugins the customer had installed. When you realize that we both use the license manager, a bell rings. Could this really be it? If so, how come no <code>fatal errors: cannot redeclare class</code> was caused by PHP?</p>
<p>A week earlier, I had bumped the required version of the license manager in my plugin to the latest version, which included some (fictional) breaking changes. After even more debugging and <code>var_dump()</code>’ing, you realize that my version of the license manager is also the version loaded by PHP in your plugin. You find that really strange because you specifically required another version of the license manager with Composer. You don’t really know what to do about this.</p>
<p>Because there really isn’t much you can do about it.</p>
<h3>What happened here?</h3>
<p>Now that we have all seen the problem, let’s take a moment to go through what actually happened in the narrative. First of all, why didn&#8217;t PHP cause a fatal error when two classes obviously had the same name that both of us included the license manager?</p>
<p>The reason for this is that we used an autoloader generated by Composer. This autoloader scans the diretory structure of our dependencies and adds every class to the autoloader. If a class has already been added, Composer will ignore it. Silently. I have written a small code example if you want to see it for yourself. <a href=\"https://github.com/petersuhm/Illustrating-WordPress-Dependency-Issue\" target=\"_blank\">It’s on GitHub</a>.</p>
<p>Why was my version of the license manager included before yours?</p>
<p>This happened because my plugin had a name that caused it to be loaded before yours. Maybe, in the future, we will all name our plugins “Aaaaaa My Plugin” in order to be loaded first!</p>
<p>So to sum up, the main issue here is that we won’t know which version of our dependencies are available to us at which time. It simply depends on factors we can’t fully control as plugin developers.</p>
<h3>Is this a Composer specific issue?</h3>
<p>No. It really isn’t. WordPress doesn&#8217;t have a way of dealing with third party code in plugins or themes. Therein lies the problem. The reason why I’m talking about Composer is that it is gaining a lot of traction these days. If WordPress developers want to use Composer in plugins released via WordPress.org, this needs to be solved somehow. Otherwise, we will see true chaos when all plugins starts to be incompatible with each other because they use different versions. Welcome to debugging hell.</p>
<h3>What can we do about this?</h3>
<p>Someone who has been really concerned about this and has worked hard to find a potential solution is <a href=\"https://twitter.com/CoenJacobs\" target=\"_blank\">Coen Jacobs</a>. I decided to reach out to Coen and ask him if he thinks there is anything we can do about this.</p>
<p><strong>Many developers are already including 3rd party code in their plugins. Is this really a problem?</strong></p>
<p>Yes, this is already a problem in the plugins ecosystem. It will become even worse when more people figure out it&#8217;s a good idea to put common functionality in separate packages. These packages can then be bundled with multiple plugins and the issue will appear more and more. I&#8217;ve been speaking to a couple developers who have already been through debug hell trying to find out what&#8217;s causing this issue.</p>
<p><strong>Moving forward, would you suggest developers stop including 3rd party code in their plugins?</strong></p>
<p>I&#8217;m a bit torn on this subject. It makes no sense from a developers point of view to tell people to stop bundling shared packages in their plugins. On the other hand, everybody wants the best possible user experience for their users. It&#8217;s a tough decision to make for sure.</p>
<p>At this point, I want to push WordPress related development forward. I want to share libraries and use libraries shared by others. Nobody should be reinventing the wheel over and over again. So I would take the risk of running into issues like this, solving the problems as they show up.</p>
<p>This also means that I&#8217;ll be doing my damned best to find a long term solution for this issue. More people will start using Composer, more people will bundle libraries with their plugins. This problem will show up more often, so it&#8217;s time to fix it.</p>
<p><strong>What can plugin developers do to prevent this problem?</strong></p>
<p>There is a workaround that I have seen some people use already. It basically comes down to moving your dependency to the namespace of your plugin. Danny van Kooten <a href=\"https://github.com/ibericode/scroll-triggered-boxes/commit/9ceef204073e4049b82833e96c0202a5754fd230\" target=\"_blank\">did this for one of his plugins</a>. This is not ideal however. Every time he updates his dependencies, he has to go through all the files and change the namespaces again. Now this is not such a big task for a relatively small library like Pimple, but a massive undertaking for larger libraries.</p>
<p>This can only be done with namespaces though, so you&#8217;ll have to make your plugin require PHP 5.3+ as well. I&#8217;m not gonna lie, I think every plugin should start doing that sooner or later, but it&#8217;s definitely something you need to consider when you decide to do this.</p>
<p><strong>What would the ideal solution be, if there is any?</strong></p>
<p>The ideal situation would be using some sort of dependency manager. There is of course Composer, the most used dependency manager. Composer is very hard, if not impossible, to use for the vast majority of the WordPress users. It&#8217;s a developer&#8217;s tool after all.</p>
<p>WordPress should make this easier for its end users, while still enabling developers to utilize pretty much any package they want. On this thought, I have started putting together the <a href=\"https://github.com/coenjacobs/wordpress-composer-installer\" target=\"_blank\">WordPress Composer Installer</a> plugin, which does all the hard Composer work while people install plugins as they always have. As soon as I am been able to finish this up, I&#8217;ll integrate it properly into the whole plugin installer flow.</p>
<p>Now maybe one day, this can be integrated in core WordPress. It has a long way to go, but the proof of concept already works.</p>
<h3>Conclusion</h3>
<p>If you have been reading this far, first of all: Thank you. Second of all, I hope you now see how this is something that will eventually become a problem. Our current situation is very frustrating, because we simply don&#8217;t have the tools we need. Still, I think it&#8217;s important that we keep talking about this and make sure that we all, as WordPress developers, understand the potential issues caused by conflicting third party dependencies in our code.</p>
<p>Finally, I want to mention one more time that this is not a Composer issue. It&#8217;s a WordPress issue.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 12:03:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: Resonar: A Free WordPress Blog Theme Designed to Showcase Featured Images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45927\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/resonar-a-free-wordpress-blog-theme-designed-to-showcase-featured-images\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2501:\"<p><a href=\"https://wordpress.org/themes/resonar/\" target=\"_blank\">Resonar</a> is an elegant WordPress blog theme that was launched in mid-March on WordPress.com and is now available to self-hosted WordPress sites. This theme makes a big impact with its strong typography and fullscreen featured images.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/resonar-screenshot.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/resonar-screenshot.jpg?resize=660%2C495\" alt=\"resonar-screenshot\" class=\"aligncenter size-full wp-image-46158\" /></a></p>
<p>Resonar was designed by <a href=\"http://takashiirie.com/\" target=\"_blank\">Takashi Irie</a>, the same designer for the Twenty Fifteen and Twenty Fourteen default themes. Irie&#8217;s designs are also behind the popular <a href=\"http://wptavern.com/espied-a-free-wordpress-portfolio-theme-for-designers-and-photographers\" target=\"_blank\">Espied</a> and <a href=\"https://wordpress.org/themes/ryu/\" target=\"_blank\">Ryu</a> themes.</p>
<p>The homepage for Resonar is created by assigning a sticky post with a large featured image (ideally 2000px wide and 1500px high). If you frequently change this sticky post, your site will always have a fresh focal point on the homepage.</p>
<p>If you&#8217;re looking for a theme that highlights longform posts, Resonar fits the bill with its unique styling for blockquotes, pull quotes, overhanging images.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/resonar-quotes.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/resonar-quotes.jpg?resize=660%2C915\" alt=\"resonar-quotes\" class=\"aligncenter size-full wp-image-46167\" /></a></p>
<p>The centered blog layout keeps the focus on the content, but you don&#8217;t have to sacrifice widget areas to use the theme. Clicking on the ellipsis icon in the main menu will reveal a 576px-wide slide-out sidebar where you can drop in widgets and display a social links menu.</p>
<p>As Resonar revolves around fullscreen featured images, you&#8217;ll need to be prepared to have a 2000px by 1500px image for each post in order to keep the theme looking its best. Check out the <a href=\"https://resonardemo.wordpress.com/\" target=\"_blank\">live demo</a> on WordPress.com to see Resonar in action. Self-hosted WordPress blog owners can <a href=\"https://wordpress.org/themes/resonar/\" target=\"_blank\">download the theme from WordPress.org</a> or install it via the admin themes browser.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 04:41:50 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"Matt: Trevor Noah &amp; Jerry Seinfeld\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45210\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"http://ma.tt/2015/07/trevor-noah-jerry-seinfeld/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:425:\"<p>&nbsp;</p>
<p><a href=\"http://comediansincarsgettingcoffee.com/trevor-noah-thats-the-whole-point-of-apartheid-jerry\">Trevor Noah, the new host of the Daily Show, was on Jerry Seinfeld&#8217;s Comedians in Cars Getting Coffee show</a>, and it was quite interesting. I really love this show, even when it&#8217;s slow you get some fun thoughts. I would embed the video but that doesn&#8217;t seem possible.</p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 06 Jul 2015 03:24:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Matt: Automattic Challenge\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45213\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"http://ma.tt/2015/07/automattic-challenge/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:313:\"<p>&#8220;We have two interesting challenges for you – to write the shortest code possible and to write the fastest code possible.&#8221; One of the prizes is a conference ticket and three nights in a hotel. Check it out over at the <a href=\"http://automattic.paris/\">Automattic React Europe Challenge</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 05 Jul 2015 05:50:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Matt: New VideoPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45204\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"http://ma.tt/2015/07/new-videopress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:283:\"<p><a href=\"https://en.blog.wordpress.com/2015/07/01/videopress-next/\">We launched a shiny new version of VideoPress</a> that makes mobile better, is way faster, has a sleek UI, and is HTML5. This is targeted at WordPress.com users right now, but will expand for everyone soon.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Jul 2015 05:56:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"WPTavern: Automattic Overhauls VideoPress and Open Sources Technologies Used to Build It\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46073\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"http://wptavern.com/automattic-overhauls-videopress-and-open-sources-technologies-used-to-build-it\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2837:\"<p><a href=\"http://videopress.com/\">VideoPress</a>, Automattic&#8217;s video hosting service, has undergone a <a href=\"https://en.blog.wordpress.com/2015/07/01/videopress-next/\">complete overhaul</a>. The video player is now responsive and adjusts well to mobile devices. Videos can be embedded anywhere and are easier to share, thanks to permalinks.</p>
<p>There&#8217;s also a couple of neat options for sharing videos. Similar to YouTube, you can select a time stamp where the video will start playing. You can also loop and autoplay videos.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/VideoPressSharingOptions.png\"><img class=\"wp-image-46114 size-full\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/VideoPressSharingOptions.png?resize=566%2C319\" alt=\"VideoPress Sharing Options\" /></a>VideoPress Sharing Options
<p>One thing I noticed is that pasting a VideoPress permalink into the self hosted WordPress visual editor does not load the video. This is because WordPress does not have <a href=\"https://codex.wordpress.org/Embeds\">oEmbed support</a> for VideoPress.</p>
<p>To embed videos into posts, you need to copy the HTML embed code from the video and past it into the WordPress text editor. Pasting the code into the visual editor doesn&#8217;t work. Guillermo Rauch, who works on the VideoPress team at Automattic says they are <a href=\"https://en.blog.wordpress.com/2015/07/01/videopress-next/?c=221756#comment-221760\">working on adding oEmbed support</a>.</p>
<p>The new video player takes up little space and is unbranded. According to Rauch, the player’s skin and behavior is controlled by JavaScript, HTML and CSS. This opens the door for customizations by theme developers in the future. Thanks to major performance enhancements, pages with videos on them will load faster, even for those on slow internet connections. Here&#8217;s an example of a video using the new player.</p>
<p></p>
<p></p>
<p>A feature that I think a lot of people will enjoy is real-time seek which lets you skim through videos and helps you start playing at a desired point. Last but not least, the libraries used to build the new video player have been open sourced, including <a href=\"https://github.com/automattic/jpeg-stream\">jpeg-stream</a>, <a href=\"https://github.com/automattic/pixel-stack\">pixel-stack</a>, and <a href=\"https://github.com/automattic/video-thumb-grid\">video-thumb-grid</a>.</p>
<p>If you&#8217;re interested in using VideoPress, you need a <a href=\"https://wordpress.com/plans/\">Premium or Business</a> plan on WordPress.com. The premium plan is $99 per year and includes 13GB of space. Videos take up a lot of space and one has to wonder if it&#8217;s worth the cost or if YouTube is a better option. If you use VideoPress, let us know what you think of these improvements.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 03 Jul 2015 03:46:15 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Matt: Domain Anonymity and the Brilliance of Entertainment Lobbyists\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45202\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://ma.tt/2015/07/domain-anonymity-and-the-brilliance-of-entertainment-lobbyists/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1747:\"<blockquote><p>To rid the internet of piracy, entertainment companies are willing to greatly reduce privacy, at least where website registration is concerned.</p>
<p>Where the entertainment industry views proxy registration as a pirate’s tool for obfuscation, privacy advocates see identity concealment as a feature that can enable free speech and freedom from harassment.</p></blockquote>
<p>So there&#8217;s <a href=\"http://www.buzzfeed.com/hamzashaban/proposed-domain-name-rule-threatens-website-owner-anonymity\">a new proposal to force any &#8220;commercial&#8221; website, which could cover pretty much anything, to have real WHOIS/contact info</a>. This is a terrible idea, and of course there are already ample and simple means to bypass proxy services being actually abused with a court order. But they want to go a step further, so potentially a parenting blogger with ads or affiliate links on their site would be forced to put their actual home address and phone number in a public directory anyone on the internet can access, or break the law. What could go wrong? <a href=\"https://www.eff.org/deeplinks/2015/06/changes-domain-name-rules-place-user-privacy-jeopardy\">EFF has more about why this impacts user privacy</a>.</p>
<p>I think the better question here, is <em>when has the entertainment industry <strong>ever</strong> proposed something good for consumers or the internet?</em> I&#8217;m not kidding, 100% serious: have they ever been right?</p>
<p>It seems like a good approach for governing bodies like FCC, ICANN, or Congress to just blanket oppose or do the opposite of what MPAA or COA propose, and they&#8217;ll be on the right side of history and magically appear to be a very tech-savvy candidate or regulator.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 22:30:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"WPTavern: Lasso Adds Real Time Revision Restoring to WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46095\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"http://wptavern.com/lasso-adds-real-time-revision-restoring-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3491:\"<p>This week Nick Haskins launched an update to <a href=\"https://lasso.is/\" target=\"_blank\">Lasso</a>, which introduces real time revision restoring. Lasso, a plugin originally designed to improve the experience of using of <a href=\"http://aesopstoryengine.com/\" target=\"_blank\">Aesop Story Engine</a>, is currently one of the most user-friendly and well-supported attempts at bringing frontend editing to WordPress.</p>
<p>The plugin works with or without Aesop Story Engine. Lasso brings a minimal, unobtrusive approach to editing that keeps the focus on content creation. Haskins hopes to ship <a href=\"https://lasso.is/the-road-to-version-one/\" target=\"_blank\">version 1.0</a> of the plugin this fall, and the source was recently <a href=\"http://wptavern.com/lasso-frontend-editing-plugin-for-wordpress-now-available-on-github\" target=\"_blank\">made available to developers and testers on GitHub</a>.</p>
<p>&#8220;Our goal is simple: be a front-end editor that negates the use of the WordPress post editor,&#8221; Haskins said. &#8220;One of the last areas to tackle in this endeavor was revisions.&#8221;</p>
<p><a href=\"https://lasso.is/0-9-6-release-notes/\" target=\"_blank\">Lasso 0.9.6</a> allows users to restore revisions in real time while editing a post on the front end. The plugin introduces a new and unique approach to displaying revisions, removing the default &#8220;diff style&#8221; comparison in favor of a simpler sliding interface.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/lasso-revisions.gif\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/07/lasso-revisions.gif?resize=948%2C723\" alt=\"lasso-revisions\" class=\"aligncenter size-full wp-image-46097\" /></a></p>
<p>Lasso displays the last six revisions and users can click on the time to restore a revision live. It functions like a little piece of magic on the front end.</p>
<p>&#8220;Because Lasso already operates within the post_content, there wasn&#8217;t really a huge technical challenge to overcome,&#8221; Haskins said. &#8220;The biggest bottle neck was finding a way to do this that would cause no confusion.</p>
<p>&#8220;WordPress revisions use a &#8220;diff style&#8221; comparison, which I don&#8217;t think benefits 80% of WordPress users. After all they&#8217;re not coders. So we decided to restore the post as it was, and most importantly, the context that it lives in,&#8221; he said.</p>
<p>The live revisions restoring supports images, markup, and everything else that you would expect to be parsed into HTML, but Haskins has a few outstanding items he hopes to polish up.</p>
<p>&#8220;Things like shortcodes and ombeds are not processed into HTML as they need a page refresh, so finding a way to parse these live is just about the only technical challenge that we still have to overcome,&#8221; he said. &#8220;This doesn&#8217;t prevent things from working, but I think a user expects these items to show as they appear on site.&#8221;</p>
<p>This is the first time a plugin author has done anything like this with revision display and restore. It transforms the process of reviewing revisions into a visual and interactive experience. Removing the &#8220;diff style&#8221; comparison makes it much easier for the average content creator to decide on which revision to restore. If you want to test it out or take a closer look at how it works, check out <a href=\"https://github.com/AesopInteractive/lasso\" target=\"_blank\">Lasso on GitHub</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 19:19:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"WPTavern: WordPress 4.3 Beta 1 Now Available for Testing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46057\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"http://wptavern.com/wordpress-4-3-beta-1-now-available-for-testing\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3292:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/testing.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/testing.jpg?resize=960%2C474\" alt=\"testing\" class=\"aligncenter size-full wp-image-46092\" /></a></p>
<p>WordPress 4.3 is right around the corner with <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\" target=\"_blank\">beta 1</a> released and ready for testing. According to the <a href=\"https://make.wordpress.org/core/version-4-3-project-schedule/\" target=\"_blank\">4.3 project schedule</a>, there will be no more commits for new enhancements or feature requests from this point on. Contributors are now focusing on bug fixes and documentation ahead of August 18th, the target release date.</p>
<p>With all the controversy surrounding WordPress 4.3&#8217;s inclusion of <a href=\"https://core.trac.wordpress.org/ticket/32576\" target=\"_blank\">menus in the customizer</a>, you may have missed a few other lesser known features that are on track to be included and need to be put through the paces. The <a href=\"http://wptavern.com/wordpress-4-3-adds-new-site-icons-feature-and-a-text-editor-to-press-this\" target=\"_blank\">new site icons feature</a> was added to trunk this week, along with a text editor for the Press This posting interface.</p>
<p>WordPress lead developer Mark Jaquith has been working on <a href=\"https://core.trac.wordpress.org/ticket/32589\" target=\"_blank\">making passwords more secure</a>. As of 4.3, WordPress will no longer send passwords via email. The password strength meter is now more tightly integrated. It will warn users upon selection of a weak password and can also suggest a secure password.</p>
<p>One interesting new improvement added to the post editor is <a href=\"https://core.trac.wordpress.org/ticket/31441\" target=\"_blank\">recognition of some basic markdown-esque patterns inside TinyMCE</a>:</p>
<blockquote><p>Certain text patterns are automatically transformed as you type, including * and &#8211; transforming into unordered lists, 1. and 1) for ordered lists, > for blockquotes and one to six number signs (#) for headings</p></blockquote>
<p>For those who are used to formatting text this way, the post editor in WordPress 4.3. will be a more friendly place for speedy composition.</p>
<p>Admin post and page <a href=\"https://core.trac.wordpress.org/ticket/32395\" target=\"_blank\">list tables</a> will take a huge leap forward to become more responsive in this release, improving the experience of using WordPress on smaller screens. Previously, the columns that could not fit were truncated, but WordPress 4.3 will allow columns to be toggled into view.</p>
<p>Check out release lead Konstantin Obenland&#8217;s <a href=\"https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/\" target=\"_blank\">beta announcement</a> post to download a zip of the beta. If you want to help test, the easiest way is to get hooked up via the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin. Bug reports are welcome on the <a href=\"https://wordpress.org/support/forum/alphabeta\" target=\"_blank\">Alpha/Beta support forums</a> and can also be filed on <a href=\"https://make.wordpress.org/core/reports/\" target=\"_blank\">WordPress trac</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 16:39:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"WPTavern: WPWeekly Episode 197 – WordPress Theme Review Roundtable\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=46068&preview_id=46068\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/wpweekly-episode-197-wordpress-theme-review-roundtable\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2582:\"<p>In this episode of WordPress Weekly, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I are joined by <a href=\"https://profiles.wordpress.org/chipbennett\">Chip Bennett</a>, <a href=\"https://profiles.wordpress.org/jcastaneda\">Jose Castaneda</a>, <a href=\"https://profiles.wordpress.org/karmatosed\">Tammie Lister</a>, and <a href=\"https://profiles.wordpress.org/cais\"><span class=\"st\">Edward Cassie</span></a> who are members of the <a href=\"https://make.wordpress.org/themes/\">WordPress Theme Review Team</a>. We learn why the team exists, its goals, and what the process is for getting a theme into the <a href=\"https://wordpress.org/themes/\">official directory</a>.</p>
<p>The team clarified the difference between <a href=\"https://make.wordpress.org/themes/handbook/review/required/\">requirements</a> and guidelines. We discuss the results of three separate surveys that indicate users want to see improvements to the way theme demo content is displayed. Last but not least, we learn how you can <a href=\"https://make.wordpress.org/themes/handbook/get-involved/become-a-reviewer/\">get involved</a> with the team.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"https://tommcfarlin.com/the-wordpress-community-a-comedy-of-drama-ego-oligarchies-and-more/\">The WordPress Community (A Comedy of Drama, Ego, Oligarchies, and More)</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/plugin-grouper/\">Plugin Grouper</a> allows users to group plugins together to make them easier to manage.</p>
<p><a href=\"https://wordpress.org/plugins/import-liked-youtube-videos/\">WordPress Import YouTube Liked Videos</a> helps users connect to their YouTube account and import their recently liked videos.</p>
<p><a href=\"https://wordpress.org/plugins/author-chat/\">Author Chat</a> is an internal chat system that lets your authors or users with access to the dashboard chat with each other.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, June 8th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #197:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 16:35:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"WPTavern: Ship: A New App for Shipping Plugins from GitHub to WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46018\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/ship-a-new-app-for-shipping-plugins-from-github-to-wordpress-org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4863:\"<p>One of the small hurdles to hosting a plugin on WordPress.org is the fact that you have to use SVN to ship your updates. Most developers are far more familiar with Git. It&#8217;s not difficult to learn how to use SVN for the sake of WordPress.org plugins, but many find it to be inconvenient.</p>
<p><a href=\"http://ship.getherbert.com/\" target=\"_blank\">Ship</a> is a new application designed to eliminate this hassle by helping developers ship plugins directly from GitHub to WordPress.org. All you have to do is tag the release on GitHub and the app will automatically push updates to the plugin&#8217;s official SVN repo on WordPress.org.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ship.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ship.png?resize=1025%2C641\" alt=\"ship\" class=\"aligncenter size-full wp-image-46026\" /></a></p>
<p>The application was created by <a href=\"https://twitter.com/jasonagnew__\" target=\"_blank\">Jason Agnew</a> and his team at <a href=\"http://bigbitecreative.com/\" target=\"_blank\">Big Bite Creative</a>, authors of the <a href=\"http://wptavern.com/herbert-a-new-wordpress-plugin-framework\" target=\"_blank\">Herbert plugin framework</a>. The team built the app in Laravel in just five days. It&#8217;s currently hosted on Digital Ocean, but Agnew plans to move it over to AWS once Ship has gained more users.</p>
<p>&#8220;We’ve reached a point where most developers are familiar with GitHub, and as a result, Git,&#8221; Agnew said in his <a href=\"http://bigbitecreative.com/introducing-ship-publishing-your-wordpress-plugin/\" target=\"_blank\">announcement</a>. &#8220;If you plan to do anything open source you’re likely to find yourself on there &#8211; even Apple has made the move. Unfortunately WordPress.org uses SVN, which most developers don’t use daily, or are even familiar with. It’s easy enough to pick up, but why should you learn something new to update your plugin?&#8221;</p>
<p>With the help of the Ship app, developers won&#8217;t have to touch SVN at all during the process of sending updates to WordPress.org plugin repositories.</p>
<p>&#8220;For years most plugin developers have used GitHub and then shipped to WordPress.org SVN using a bash script,&#8221; Agnew said. &#8220;You’ll find plenty out there, but they require you to keep both a Git and SVN repo on your machine — plus you need to remember to run it every time you tag a new release. We thought there must be a simpler way to do this, so we put our heads together. After a few days we had put together the first version of Ship.&#8221;</p>
<p>In order to use the app you must have already <a href=\"https://wordpress.org/plugins/add/\" target=\"_blank\">submitted your plugin zip file to WordPress.org</a>. You can then sign into the <a href=\"http://ship.getherbert.com/\" target=\"_blank\">Ship</a> app with GitHub and authorize its access to your repositories.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/authorize-ship-app.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/07/authorize-ship-app.jpg?resize=716%2C434\" alt=\"authorize-ship-app\" class=\"aligncenter size-full wp-image-46044\" /></a></p>
<p>The app will then fetch your repositories and you&#8217;ll have the opportunity to select the ones you want to link up with a WordPress.org SVN address in order to start syncing updates.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ship-sync-reops.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/07/ship-sync-reops.jpg?resize=842%2C525\" alt=\"ship-sync-reops\" class=\"aligncenter size-full wp-image-46046\" /></a></p>
<p>Big Bite Creative has built many custom plugins over the years, but Agnew said they never had the time to open source them.</p>
<p>&#8220;Now with Herbert out there we want to start releasing more plugins on Github &#8211; Ship is part of making that process easier,&#8221; he said.</p>
<p>In the future, Agnew and his team would like to eliminate the need to first submit your plugin on WordPress.org and instead have that process initiated by Ship. They used &#8220;Sign in with GitHub&#8221; to save time when initially building the app but would also like to open it up for other services like BitBucket.</p>
<p>The new Ship app effectively gets around WordPress.org&#8217;s SVN requirement for plugin repos, which has long been a minor deterrent and annoyance for developers wanting to host their work in the directory. If Ship is successful in making plugin developer&#8217;s lives easier, the result will be more open source extensions available to WordPress users. Agnew and his team welcome feedback on the app and have created <a href=\"https://github.com/getherbert/ship\" target=\"_blank\">an empty repo on GiHub</a> to capture any suggestions or issues.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 01:13:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Which One of These Six Cities Should Host WordCamp US?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=46027\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/which-one-of-these-six-cities-should-host-wordcamp-us\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1498:\"<p>When Matt Mullenweg <a href=\"http://wptavern.com/wordcamp-us-2015-now-accepting-applications-for-host-city\">put out the call</a> to cities interested in hosting WordCamp US, we learned the criteria they would have to meet in order to qualify. Venues would need to seat approximately 1,000-2,00 people, have hotels within 3 miles of the venue, hotel costs for a range of budgets, and average flight costs from the West Coast, East Coast, Midwest, Mexico, and Canada.</p>
<p>Applications to host WordCamp US 2015 <a href=\"https://make.wordpress.org/community/2015/07/01/wordcamp-us-update/\">officially closed today</a>. Six cities submitted applications to host the event, they include:</p>
<ul>
<li>Chattanooga</li>
<li>Chicago</li>
<li>Detroit</li>
<li>Orlando</li>
<li>Philadelphia</li>
<li>Phoenix</li>
</ul>
<p>On the Make WordPress Community site, Cami Kaos says applications are being carefully reviewed and organizers of the host city will be contacted as soon as possible. Dates for the event won&#8217;t be given until a host city and venue is chosen.</p>
<p>Out of all the cities selected, I want WordCamp US to be in Chicago. I love Chicago and it&#8217;s a quick flight from Cleveland. The city also has awesome pizza. Take the poll below and vote for which city you think should host WordCamp US. This poll is only for fun and will not affect the outcome of the host city.</p>
Note: There is a poll embedded within this post, please visit the site to participate in this post\'s poll.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Jul 2015 00:28:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 16 Jul 2015 05:54:09 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"170182\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Thu, 16 Jul 2015 05:45:16 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("247","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1437069251","no");
INSERT INTO `arc1542_options` VALUES("248","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1437026051","no");
INSERT INTO `arc1542_options` VALUES("249","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1437069252","no");
INSERT INTO `arc1542_options` VALUES("250","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 16 Jul 2015 05:32:24 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Your WordPress, Streamlined.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"WordPress SEO by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:127:\"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"iThemes Security (formerly Better WP Security)\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/better-wp-security/#post-21738\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 22 Oct 2010 22:06:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"21738@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:150:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Chris Wiegman\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"MailChimp for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/mailchimp-for-wp/#post-54377\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Jun 2013 17:32:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"54377@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:120:\"MailChimp for WordPress, the absolute best. Add subscribers to your MailChimp lists from your WordPress site, with ease.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Danny van Kooten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Page Builder by SiteOrigin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/siteorigin-panels/#post-51888\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Apr 2013 10:36:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"51888@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"EWWW Image Optimizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/ewww-image-optimizer/#post-38780\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jun 2012 19:30:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38780@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"Reduce file sizes for images in WordPress including NextGEN, GRAND FlAGallery and more using lossless/lossy methods and image format conversion.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"nosilver4u\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"WPtouch Mobile Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wptouch/#post-5468\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 May 2008 04:58:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5468@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"Make your WordPress website mobile-friendly with just a few clicks.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"BraveNewCode Inc.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Photo Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/photo-gallery/#post-63299\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jan 2014 15:58:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"63299@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:143:\"Photo Gallery is an advanced plugin with a list of tools and options for adding and editing images for different views. It is fully responsive.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"webdorado\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"NextScripts: Social Networks Auto-Poster\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:88:\"https://wordpress.org/plugins/social-networks-auto-poster-facebook-twitter-g/#post-35439\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 02 Mar 2012 00:28:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"35439@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"Automatically re-publishes blogposts to Facebook, Twitter, Google+, Pinterest, LinkedIn, Blogger, Tumblr, Delicious, Plurk, etc profiles and/or pages\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"NextScripts\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"InfiniteWP Client\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/iwp-client/#post-36147\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 26 Mar 2012 04:21:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"36147@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:143:\"Install this plugin on unlimited sites and manage them all from a central dashboard.
This plugin communicates with your InfiniteWP Admin Panel.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"infinitewp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"WP-DB-Backup\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/wp-db-backup/#post-472\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 17 Mar 2007 04:41:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"472@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"On-demand backup of your WordPress database.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"ringmaster\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"SiteOrigin Widgets Bundle\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/so-widgets-bundle/#post-67824\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 24 May 2014 14:27:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"67824@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:128:\"A collection of all widgets, neatly bundled into a single plugin. It&#039;s also a framework to code your own widgets on top of.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Greg Priday\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Share Buttons by AddToAny\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://wordpress.org/plugins/add-to-any/#post-498\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 17 Mar 2007 23:08:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"498@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:142:\"Share buttons for WordPress including AddToAny&#039;s universal sharing button, Facebook, Twitter, Google+, Pinterest, WhatsApp and many more.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"micropat\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"WP Statistics\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-statistics/#post-25318\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 20 Mar 2011 09:03:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25318@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"Complete statistics for your WordPress site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Mostafa Soufi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Quick Page/Post Redirect Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/plugins/quick-pagepost-redirect-plugin/#post-12015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 26 Jul 2009 05:57:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"12015@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Easily redirect pages/posts or custom post types to another page/post or external URL by specifying the redirect URL and type (301, 302, 307, meta).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"prophecy2040\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"bbPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/bbpress/#post-14709\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 13 Dec 2009 00:05:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"14709@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"bbPress is forum software, made the WordPress way.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"John James Jacoby\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"The Events Calendar\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/plugins/the-events-calendar/#post-14790\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 16 Dec 2009 21:58:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"14790@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:128:\"The Events Calendar is a carefully crafted, extensible plugin that lets you easily share your events. Beautiful. Solid. Awesome.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Peter Chester\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Thu, 16 Jul 2015 05:54:09 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Thu, 16 Jul 2015 06:07:24 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Thu, 16 Jul 2015 05:32:24 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 250\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("251","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1437069252","no");
INSERT INTO `arc1542_options` VALUES("252","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1437026052","no");
INSERT INTO `arc1542_options` VALUES("253","_transient_timeout_plugin_slugs","1437112638","no");
INSERT INTO `arc1542_options` VALUES("254","_transient_plugin_slugs","a:3:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"better-wp-security/better-wp-security.php\";i:2;s:23:\"wordfence/wordfence.php\";}","no");
INSERT INTO `arc1542_options` VALUES("255","_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51","1437069252","no");
INSERT INTO `arc1542_options` VALUES("256","_transient_dash_4077549d03da2e451c8b5f002294ff51","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/07/wordpress-4-3-beta-3/\'>WordPress 4.3 Beta 3</a> <span class=\"rss-date\">July 15, 2015</span><div class=\"rssSummary\">WordPress 4.3 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.3, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/explore-the-wordpress-rest-api-with-the-new-interactive-console-plugin\'>WPTavern: Explore the WordPress REST API with the New Interactive Console Plugin</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/wordpress-theme-review-team-unanimously-approves-roadmap-to-improve-directory-and-review-process\'>WPTavern: WordPress Theme Review Team Unanimously Approves Roadmap to Improve Directory and Review Process</a></li><li><a class=\'rsswidget\' href=\'http://wptavern.com/proper-lite-a-free-and-flexible-wordpress-theme-for-creatives\'>WPTavern: Proper Lite: A Free and Flexible WordPress Theme for Creatives</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/photo-gallery/\' class=\'dashboard-news-plugin-link\'>Photo Gallery</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=photo-gallery&amp;_wpnonce=b12d2e8acc&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Photo Gallery\'>Install</a>)</span></li></ul></div>","no");
INSERT INTO `arc1542_options` VALUES("260","nav_menu_options","a:2:{i:0;b:0;s:8:\"auto_add\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("261","_site_transient_timeout_itsec_upload_dir","1438187110","yes");
INSERT INTO `arc1542_options` VALUES("262","_site_transient_itsec_upload_dir","a:6:{s:4:\"path\";s:52:\"/Users/ahayter/Sites/test/arc-assets/uploads/2015/07\";s:3:\"url\";s:42:\"http://test.dev/arc-assets/uploads/2015/07\";s:6:\"subdir\";s:8:\"/2015/07\";s:7:\"basedir\";s:44:\"/Users/ahayter/Sites/test/arc-assets/uploads\";s:7:\"baseurl\";s:34:\"http://test.dev/arc-assets/uploads\";s:5:\"error\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("263","_site_transient_timeout_itsec_random_version","1438187110","yes");
INSERT INTO `arc1542_options` VALUES("264","_site_transient_itsec_random_version","364","yes");
INSERT INTO `arc1542_options` VALUES("265","_transient_doing_cron","1438100710.1615920066833496093750","yes");
INSERT INTO `arc1542_options` VALUES("266","_site_transient_timeout_itsec_notification_running","1438104310","yes");
INSERT INTO `arc1542_options` VALUES("267","_site_transient_itsec_notification_running","1","yes");
INSERT INTO `arc1542_options` VALUES("268","itsec_local_file_list_1","a:0:{}","no");


DROP TABLE IF EXISTS `arc1542_postmeta`;

CREATE TABLE `arc1542_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_postmeta` VALUES("1","2","_wp_page_template","default");
INSERT INTO `arc1542_postmeta` VALUES("2","4","_menu_item_type","custom");
INSERT INTO `arc1542_postmeta` VALUES("3","4","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("4","4","_menu_item_object_id","4");
INSERT INTO `arc1542_postmeta` VALUES("5","4","_menu_item_object","custom");
INSERT INTO `arc1542_postmeta` VALUES("6","4","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("7","4","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("8","4","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("9","4","_menu_item_url","http://test.dev/");
INSERT INTO `arc1542_postmeta` VALUES("11","5","_menu_item_type","post_type");
INSERT INTO `arc1542_postmeta` VALUES("12","5","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("13","5","_menu_item_object_id","2");
INSERT INTO `arc1542_postmeta` VALUES("14","5","_menu_item_object","page");
INSERT INTO `arc1542_postmeta` VALUES("15","5","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("16","5","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("17","5","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("18","5","_menu_item_url","");
INSERT INTO `arc1542_postmeta` VALUES("20","6","_menu_item_type","post_type");
INSERT INTO `arc1542_postmeta` VALUES("21","6","_menu_item_menu_item_parent","0");
INSERT INTO `arc1542_postmeta` VALUES("22","6","_menu_item_object_id","2");
INSERT INTO `arc1542_postmeta` VALUES("23","6","_menu_item_object","page");
INSERT INTO `arc1542_postmeta` VALUES("24","6","_menu_item_target","");
INSERT INTO `arc1542_postmeta` VALUES("25","6","_menu_item_classes","a:1:{i:0;s:0:\"\";}");
INSERT INTO `arc1542_postmeta` VALUES("26","6","_menu_item_xfn","");
INSERT INTO `arc1542_postmeta` VALUES("27","6","_menu_item_url","");


DROP TABLE IF EXISTS `arc1542_posts`;

CREATE TABLE `arc1542_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_posts` VALUES("1","2","2015-06-15 19:42:40","2015-06-15 19:42:40","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","publish","open","open","","hello-world","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?p=1","0","post","","1");
INSERT INTO `arc1542_posts` VALUES("2","2","2015-06-15 19:42:40","2015-06-15 19:42:40","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://test.dev/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","publish","open","open","","sample-page","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?page_id=2","0","page","","0");
INSERT INTO `arc1542_posts` VALUES("3","2","2015-06-15 19:42:53","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2015-06-15 19:42:53","0000-00-00 00:00:00","","0","http://test.dev/?p=3","0","post","","0");
INSERT INTO `arc1542_posts` VALUES("4","2","2015-07-16 01:54:35","2015-07-16 05:54:35","","Home","","publish","open","open","","home","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=4","1","nav_menu_item","","0");
INSERT INTO `arc1542_posts` VALUES("5","2","2015-07-16 01:54:35","2015-07-16 05:54:35"," ","","","publish","open","open","","5","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=5","2","nav_menu_item","","0");
INSERT INTO `arc1542_posts` VALUES("6","2","2015-07-16 01:54:35","2015-07-16 05:54:35"," ","","","publish","open","open","","6","","","2015-07-16 01:54:41","2015-07-16 05:54:41","","0","http://test.dev/?p=6","3","nav_menu_item","","0");


DROP TABLE IF EXISTS `arc1542_term_relationships`;

CREATE TABLE `arc1542_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_relationships` VALUES("1","1","0");
INSERT INTO `arc1542_term_relationships` VALUES("4","2","0");
INSERT INTO `arc1542_term_relationships` VALUES("5","2","0");
INSERT INTO `arc1542_term_relationships` VALUES("6","2","0");


DROP TABLE IF EXISTS `arc1542_term_taxonomy`;

CREATE TABLE `arc1542_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_taxonomy` VALUES("1","1","category","","0","1");
INSERT INTO `arc1542_term_taxonomy` VALUES("2","2","nav_menu","","0","3");


DROP TABLE IF EXISTS `arc1542_terms`;

CREATE TABLE `arc1542_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_terms` VALUES("1","Uncategorized","uncategorized","0");
INSERT INTO `arc1542_terms` VALUES("2","Menu 1","menu-1","0");


DROP TABLE IF EXISTS `arc1542_usermeta`;

CREATE TABLE `arc1542_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_usermeta` VALUES("1","2","nickname","Andre Hayter");
INSERT INTO `arc1542_usermeta` VALUES("2","2","first_name","");
INSERT INTO `arc1542_usermeta` VALUES("3","2","last_name","");
INSERT INTO `arc1542_usermeta` VALUES("4","2","description","");
INSERT INTO `arc1542_usermeta` VALUES("5","2","rich_editing","true");
INSERT INTO `arc1542_usermeta` VALUES("6","2","comment_shortcuts","false");
INSERT INTO `arc1542_usermeta` VALUES("7","2","admin_color","fresh");
INSERT INTO `arc1542_usermeta` VALUES("8","2","use_ssl","0");
INSERT INTO `arc1542_usermeta` VALUES("9","2","show_admin_bar_front","true");
INSERT INTO `arc1542_usermeta` VALUES("10","2","arc1542_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `arc1542_usermeta` VALUES("11","2","arc1542_user_level","10");
INSERT INTO `arc1542_usermeta` VALUES("12","2","dismissed_wp_pointers","wp360_locks,wp390_widgets");
INSERT INTO `arc1542_usermeta` VALUES("13","2","show_welcome_panel","1");
INSERT INTO `arc1542_usermeta` VALUES("14","2","session_tokens","a:1:{s:64:\"0705726b286befdcd3940b64b1a07b1c56f2540aef2d49e40a95d97734690560\";a:4:{s:10:\"expiration\";i:1437198846;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36\";s:5:\"login\";i:1437026046;}}");
INSERT INTO `arc1542_usermeta` VALUES("15","2","arc1542_dashboard_quick_press_last_post_id","3");
INSERT INTO `arc1542_usermeta` VALUES("16","2","managenav-menuscolumnshidden","a:4:{i:0;s:11:\"link-target\";i:1;s:11:\"css-classes\";i:2;s:3:\"xfn\";i:3;s:11:\"description\";}");
INSERT INTO `arc1542_usermeta` VALUES("17","2","metaboxhidden_nav-menus","a:3:{i:0;s:8:\"add-post\";i:1;s:12:\"add-post_tag\";i:2;s:15:\"add-post_format\";}");


DROP TABLE IF EXISTS `arc1542_users`;

CREATE TABLE `arc1542_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_users` VALUES("2","ahayter","$P$Bv7PyMKGXpEmyukWPx7wtK5UuTwoO10","andre-hayter","andre.hayter+arc@gmail.com","","2015-06-15 19:42:40","","0","Andre Hayter");


DROP TABLE IF EXISTS `arc1542_wfBadLeechers`;

CREATE TABLE `arc1542_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfBlockedIPLog`;

CREATE TABLE `arc1542_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`unixday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocks`;

CREATE TABLE `arc1542_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocksAdv`;

CREATE TABLE `arc1542_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfConfig`;

CREATE TABLE `arc1542_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfConfig` VALUES("actUpdateInterval","");
INSERT INTO `arc1542_wfConfig` VALUES("addCacheComment","0");
INSERT INTO `arc1542_wfConfig` VALUES("advancedCommentScanning","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertEmails","andre.hayter+arc@gmail.com");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_adminLogin","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_block","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_critical","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_loginLockout","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_lostPasswdForm","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_nonAdminLogin","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_throttle","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_update","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_warnings","1");
INSERT INTO `arc1542_wfConfig` VALUES("alert_maxHourly","0");
INSERT INTO `arc1542_wfConfig` VALUES("allowHTTPSCaching","0");
INSERT INTO `arc1542_wfConfig` VALUES("apiKey","db0301f529f254dbf9220171caf7ddd101ee22964ad7cd38e529908964a2239b77621a5354eba6cd87e15b40cce0d2013dc4d1933782fba373cf1551df12afda");
INSERT INTO `arc1542_wfConfig` VALUES("autoBlockScanners","0");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdateChoice","1");
INSERT INTO `arc1542_wfConfig` VALUES("bannedURLs","");
INSERT INTO `arc1542_wfConfig` VALUES("blockedTime","300");
INSERT INTO `arc1542_wfConfig` VALUES("blockFakeBots","0");
INSERT INTO `arc1542_wfConfig` VALUES("cacheType","falcon");
INSERT INTO `arc1542_wfConfig` VALUES("cbl_restOfSiteBlocked","1");
INSERT INTO `arc1542_wfConfig` VALUES("checkSpamIP","0");
INSERT INTO `arc1542_wfConfig` VALUES("currentCronKey","");
INSERT INTO `arc1542_wfConfig` VALUES("debugOn","0");
INSERT INTO `arc1542_wfConfig` VALUES("deleteTablesOnDeact","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCodeExecutionUploads","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableConfigCaching","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCookies","0");
INSERT INTO `arc1542_wfConfig` VALUES("emailedIssuesList","a:3:{i:0;a:2:{s:7:\"ignoreC\";s:32:\"106719a1dd449e2636475e907c5f49da\";s:7:\"ignoreP\";s:32:\"106719a1dd449e2636475e907c5f49da\";}i:1;a:2:{s:7:\"ignoreC\";s:32:\"52388f270b5efc2b6d97a713c9ba5aca\";s:7:\"ignoreP\";s:32:\"52388f270b5efc2b6d97a713c9ba5aca\";}i:2;a:2:{s:7:\"ignoreC\";s:32:\"ff13dfaaceee016ccb5c2953dc03880b\";s:7:\"ignoreP\";s:32:\"ff13dfaaceee016ccb5c2953dc03880b\";}}");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_dashboard_widget_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_excluded_directories","wp-content/cache,wp-content/wfcache,wp-content/plugins/wordfence/tmp");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_interval","biweekly");
INSERT INTO `arc1542_wfConfig` VALUES("encKey","5f9cf63b16832468");
INSERT INTO `arc1542_wfConfig` VALUES("firewallEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("howGetIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("lastAdminLogin","a:6:{s:6:\"userID\";i:2;s:8:\"username\";s:7:\"ahayter\";s:9:\"firstName\";s:0:\"\";s:8:\"lastName\";s:0:\"\";s:4:\"time\";s:26:\"Thu 16th July @ 01:54:06AM\";s:2:\"IP\";s:3:\"::1\";}");
INSERT INTO `arc1542_wfConfig` VALUES("lastEmailHash","1437026047:051b3653b1f5d0f0be99aa2a74d45cb8");
INSERT INTO `arc1542_wfConfig` VALUES("lastScanCompleted","ok");
INSERT INTO `arc1542_wfConfig` VALUES("lastScheduledScanStart","1437026033");
INSERT INTO `arc1542_wfConfig` VALUES("liveTrafficEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignorePublishers","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUA","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUsers","");
INSERT INTO `arc1542_wfConfig` VALUES("loginSecurityEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_blockAdminReg","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_countFailMins","5");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_disableAuthorScan","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockInvalidUsers","0");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockoutMins","5");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maskLoginErrors","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxFailures","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxForgotPasswd","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_strongPasswds","pubs");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_userBlacklist","");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxExecutionTime","");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxMem","256");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("neverBlockBG","neverBlockVerified");
INSERT INTO `arc1542_wfConfig` VALUES("other_blockBadPOST","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_hideWPVersion","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_noAnonMemberComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_pwStrengthOnUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanOutside","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_WFNet","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_comments","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_core","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_database","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_diskSpace","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_dns","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_fileContents","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_heartbleed","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_highSense","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_malware","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_oldVersions","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_options","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_passwds","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_plugins","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_posts","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_public","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_scanImages","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_themes","0");
INSERT INTO `arc1542_wfConfig` VALUES("scan_exclude","");
INSERT INTO `arc1542_wfConfig` VALUES("scheduledScansEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("securityLevel","2");
INSERT INTO `arc1542_wfConfig` VALUES("spamvertizeCheck","0");
INSERT INTO `arc1542_wfConfig` VALUES("ssl_verify","1");
INSERT INTO `arc1542_wfConfig` VALUES("startScansRemotely","0");
INSERT INTO `arc1542_wfConfig` VALUES("totalAlertsSent","1");
INSERT INTO `arc1542_wfConfig` VALUES("totalLoginHits","2");
INSERT INTO `arc1542_wfConfig` VALUES("totalLogins","1");
INSERT INTO `arc1542_wfConfig` VALUES("totalScansRun","2");
INSERT INTO `arc1542_wfConfig` VALUES("tourClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("vulnRegex","/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i");
INSERT INTO `arc1542_wfConfig` VALUES("welcomeClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("wfKillRequested","0");
INSERT INTO `arc1542_wfConfig` VALUES("wfPeakMemory","41191760");
INSERT INTO `arc1542_wfConfig` VALUES("wfsd_engine","");
INSERT INTO `arc1542_wfConfig` VALUES("wfStatusStartMsgs","a:14:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:0:\"\";i:6;s:0:\"\";i:7;s:0:\"\";i:8;s:0:\"\";i:9;s:0:\"\";i:10;s:0:\"\";i:11;s:0:\"\";i:12;s:0:\"\";i:13;s:0:\"\";}");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsA","test.dev points to 127.0.53.53");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsCNAME","");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsLogged","1");
INSERT INTO `arc1542_wfConfig` VALUES("wf_dnsMX","your-dns-needs-immediate-attention.dev");
INSERT INTO `arc1542_wfConfig` VALUES("wf_scanRunning","");
INSERT INTO `arc1542_wfConfig` VALUES("wf_summaryItems","a:16:{s:10:\"totalUsers\";i:1;s:10:\"totalPages\";s:1:\"1\";s:10:\"totalPosts\";s:1:\"1\";s:13:\"totalComments\";s:1:\"1\";s:15:\"totalCategories\";s:1:\"1\";s:11:\"totalTables\";i:34;s:9:\"totalRows\";i:1472;s:12:\"totalPlugins\";i:3;s:10:\"lastUpdate\";i:1437026049;s:11:\"totalThemes\";i:1;s:9:\"totalData\";s:8:\"23.13 MB\";s:10:\"totalFiles\";i:1008;s:9:\"totalDirs\";i:88;s:10:\"linesOfPHP\";i:250981;s:10:\"linesOfJCH\";i:125698;s:8:\"scanTime\";d:1437026049.7301580905914306640625;}");
INSERT INTO `arc1542_wfConfig` VALUES("whitelisted","");


DROP TABLE IF EXISTS `arc1542_wfCrawlers`;

CREATE TABLE `arc1542_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfFileMods`;

CREATE TABLE `arc1542_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfFileMods` VALUES("\00��#�9���Z4�j$","wp-admin/network/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1�s�̶>��Ѕc��");
INSERT INTO `arc1542_wfFileMods` VALUES("\05g���꫔c�0�\"D","wp-includes/css/media-views-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2q_�9�5VLT");
INSERT INTO `arc1542_wfFileMods` VALUES("\0C_
��jD��@k","wp-admin/network/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�V1�r/���.���J");
INSERT INTO `arc1542_wfFileMods` VALUES("\0`Y�ϭrG����","wp-includes/SimplePie/Restriction.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*qhd�s�;�y");
INSERT INTO `arc1542_wfFileMods` VALUES("\0���;f��Q�=*Ǖ�","wp-includes/js/wp-emoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\'��ٽ�, �[�");
INSERT INTO `arc1542_wfFileMods` VALUES("\0�|9��u�e���@��","wp-admin/includes/image.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�3q��.����О���");
INSERT INTO `arc1542_wfFileMods` VALUES("NQ�\"*hz�r�w|�","wp-admin/images/media-button-other.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ƴk�|��,O�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�T�h���zP��r�","wp-admin/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˂�ב�_/h�
:");
INSERT INTO `arc1542_wfFileMods` VALUES("t]�ٟu��u���j�","wp-admin/images/menu-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q���L�,_�;1/�E�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~�w`�5;F㮮","wp-includes/js/jquery/ui/effect-size.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":I�k�C�*���]�");
INSERT INTO `arc1542_wfFileMods` VALUES("�=��q�ljA+","wp-admin/user/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*zu�c���m	J��e�");
INSERT INTO `arc1542_wfFileMods` VALUES("<)8T*.�SuS�ĺ�","wp-includes/SimplePie/Cache/MySQL.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B�C�H�xV�");
INSERT INTO `arc1542_wfFileMods` VALUES("HC���!���\"(�","wp-includes/js/tinymce/plugins/compat3x/css/dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͕�\0A��It�dH");
INSERT INTO `arc1542_wfFileMods` VALUES("u��s��y6\'v,��=","wp-includes/js/tinymce/plugins/wordpress/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�Bf��n�`��");
INSERT INTO `arc1542_wfFileMods` VALUES("����7�&��Ȁ","wp-includes/js/tinymce/skins/lightgray/content.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","oS�pZ5��Ǜ4�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���љ����\0H<_","wp-admin/includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J물�@��Y�OS�p");
INSERT INTO `arc1542_wfFileMods` VALUES("i��PÙ��ld\0��","wp-includes/css/jquery-ui-dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
��d����\\6�");
INSERT INTO `arc1542_wfFileMods` VALUES("!���@|�4��n���","wp-includes/class-http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Qc.F��B�6�l��");
INSERT INTO `arc1542_wfFileMods` VALUES("\'ڞ\0;��?�+VҪ�","wp-admin/network/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�Y�&��;^���");
INSERT INTO `arc1542_wfFileMods` VALUES("E�&��VN���\"N","wp-admin/css/ie.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F�Y\0��g�H�0��");
INSERT INTO `arc1542_wfFileMods` VALUES("�P\0\'�0l���v�#J<","wp-includes/js/jquery/ui/effect-fold.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6^�����<��DEl");
INSERT INTO `arc1542_wfFileMods` VALUES("Ȅ���xy�����","wp-includes/js/tinymce/skins/wordpress/images/embedded.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�N��y~�n\"");
INSERT INTO `arc1542_wfFileMods` VALUES("ϴ 3P`#8^��Z","wp-admin/css/colors/coffee/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2���#6��`τ}L");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��N߬jj)��\0��N","wp-admin/images/menu-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jG�����{�>�^;$��");
INSERT INTO `arc1542_wfFileMods` VALUES("tZQ��Yz0����跫","wp-admin/images/wordpress-logo.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ư�y��o�8��8S�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k�5S�H���Ы","wp-includes/SimplePie/Author.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�q�_�A�%�Nw�1");
INSERT INTO `arc1542_wfFileMods` VALUES("���e�bW�A0�d","wp-admin/images/comment-grey-bubble.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�*\'����t���F");
INSERT INTO `arc1542_wfFileMods` VALUES("Q� ��(;ؠ|~R8�b","wp-admin/includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_���zd��BO�V");
INSERT INTO `arc1542_wfFileMods` VALUES("���%bQ�bM<�x","wp-includes/js/imgareaselect/border-anim-h.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��,�ntZ^6�{Lp�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ѧ�_�4a!�F��","wp-admin/css/ie.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","IBT�\'�n�i�)P�");
INSERT INTO `arc1542_wfFileMods` VALUES("��i)33ܥ��s�*","wp-admin/includes/class-wp-ms-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��&�+�zĘ�}�İ#");
INSERT INTO `arc1542_wfFileMods` VALUES("���#����	>�7","wp-includes/js/tinymce/skins/wordpress/images/pagebreak.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I��m���LWyݓH");
INSERT INTO `arc1542_wfFileMods` VALUES("k����b��gS�","wp-includes/js/tinymce/plugins/wplink/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���`�{WﺾUi\'w");
INSERT INTO `arc1542_wfFileMods` VALUES("����g�~�w�hh","wp-admin/css/themes-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\0�wE�i�O�!��}");
INSERT INTO `arc1542_wfFileMods` VALUES("	QW���~-�\0d�","wp-includes/class-phpass.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�FDP�\0�f�G�Ƨ");
INSERT INTO `arc1542_wfFileMods` VALUES("	?������q�uM","wp-includes/js/mediaelement/mediaelementplayer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�ؗx�����[�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("	,��/Օ�!�gy�d","wp-includes/js/media-editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��$�m+�:xܔ��D");
INSERT INTO `arc1542_wfFileMods` VALUES("	P=N>��b\"j:~[Q{�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[ߢ�9��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("	X�t\\4vNI5��j��","wp-admin/async-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<Br?d�T\'��Z�0X");
INSERT INTO `arc1542_wfFileMods` VALUES("	�9��fވU�f����","wp-includes/js/tinymce/tinymce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/ZV�9��N.{�Ћ");
INSERT INTO `arc1542_wfFileMods` VALUES("	����09��-b��ͩW","wp-admin/network/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Zv\\����ǝ{�g2");
INSERT INTO `arc1542_wfFileMods` VALUES("
f���Y��4&�L�","wp-admin/images/se.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȔB�`��.}\'7:");
INSERT INTO `arc1542_wfFileMods` VALUES("
���b-�V�:��|m��","wp-admin/edit-link-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7����d�G�G�\0�G%");
INSERT INTO `arc1542_wfFileMods` VALUES("
��NNM��ۑ4;�p�4","wp-includes/js/customize-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","OK�.�q;�t��N�
");
INSERT INTO `arc1542_wfFileMods` VALUES("
��B��p̭","wp-admin/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH���wY���");
INSERT INTO `arc1542_wfFileMods` VALUES("\"w%�_��K\\��u�","wp-admin/images/wpspin_light.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("&c�YD�#�P{+��","wp-includes/js/jquery/ui/effect-blind.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<O�mA�_;OL");
INSERT INTO `arc1542_wfFileMods` VALUES("���,H(b�_F�O","wp-admin/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�G𿤂X�ΗN��");
INSERT INTO `arc1542_wfFileMods` VALUES("��HVե�d��p�Vp","wp-includes/images/media/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���4���\0T��̇?�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c\"ml� �Ǟ>o","wp-admin/images/wordpress-logo.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N�%�d���g���p");
INSERT INTO `arc1542_wfFileMods` VALUES("{�M��i�i2n��6�","wp-includes/js/jquery/ui/effect-highlight.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����*��øN���!");
INSERT INTO `arc1542_wfFileMods` VALUES("xݍ�^������<;","wp-admin/my-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W_H�3��8	����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ҧxOz���z���h","wp-includes/class-wp-customize-panel.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����v�x~;)�]��l�");
INSERT INTO `arc1542_wfFileMods` VALUES("��:�:���HH�:d","wp-admin/css/edit.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܡ�ɵI��[\'�\'��B");
INSERT INTO `arc1542_wfFileMods` VALUES("�%����%�yS�`�","wp-includes/js/crop/cropper.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����H.s�o����");
INSERT INTO `arc1542_wfFileMods` VALUES("Ѫ1s1=��`(�y","wp-admin/options-head.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֕`^m�N@
Tof~�");
INSERT INTO `arc1542_wfFileMods` VALUES("X��H奥(�:�Z��","wp-admin/admin-ajax.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����:��em�-XL$");
INSERT INTO `arc1542_wfFileMods` VALUES("go�s�V�;����
$","wp-includes/js/tinymce/plugins/compat3x/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=�\\�-����e���U");
INSERT INTO `arc1542_wfFileMods` VALUES("� ��C�Y���","wp-includes/pomo/entry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�L�ǼƢ�v�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�M�8� ٵ��|","wp-includes/images/crystal/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S������I0An�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"J\04��\'i�","wp-admin/js/password-strength-meter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�(F�Vp��#*�{�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�&�nb��i�ٷ�","wp-includes/js/mediaelement/silverlightmediaelement.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�:=C\".K�|�n\0t�");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����AV*籿","wp-includes/js/jquery/ui/slider.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}	1l4�&��QW��L�");
INSERT INTO `arc1542_wfFileMods` VALUES("\0��]�a�v���CY","wp-includes/class-wp-walker.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W#�\'����m");
INSERT INTO `arc1542_wfFileMods` VALUES("���NVԱ��z�Z","wp-includes/js/jquery/ui/effect-shake.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'JgV�̯\0�@p�");
INSERT INTO `arc1542_wfFileMods` VALUES(")��_���J�����","wp-includes/js/media-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".xd��#c�n�3{��");
INSERT INTO `arc1542_wfFileMods` VALUES("`�&��锥~K3/d","wp-admin/css/login.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f�Ad�a��FðB5");
INSERT INTO `arc1542_wfFileMods` VALUES("�~��L��*�,�<:�","wp-admin/includes/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�at{V��Qƅ�*քU");
INSERT INTO `arc1542_wfFileMods` VALUES("�Sx��4�@o�w�N","wp-admin/js/widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L,3�%�q���	���Ӑ");
INSERT INTO `arc1542_wfFileMods` VALUES("���:m��[ݢ�:#","wp-includes/l10n.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","j��!K����s87[");
INSERT INTO `arc1542_wfFileMods` VALUES("�I��\\j���x���g","wp-admin/images/date-button-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")R�,$k���)6C��c");
INSERT INTO `arc1542_wfFileMods` VALUES("���j7r[�,���Z��","wp-admin/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-&6��ۉ<g�k�6s�");
INSERT INTO `arc1542_wfFileMods` VALUES("D�8hFޛBViR�","wp-admin/css/colors/blue/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�
��`trk");
INSERT INTO `arc1542_wfFileMods` VALUES("j׻���q.�*;��2","wp-admin/css/colors/sunrise/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y�N�^�&R\"�6�a�");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�W�3���᥾V","wp-admin/css/color-picker-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z4w��l�e�$��");
INSERT INTO `arc1542_wfFileMods` VALUES(":�X��2�M���~��","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G6	=���<�%�#");
INSERT INTO `arc1542_wfFileMods` VALUES("L����8���\\�ݼ+","wp-admin/images/imgedit-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",��\'��6U�������t");
INSERT INTO `arc1542_wfFileMods` VALUES("p۞�2N<:Z�7�r�","wp-includes/js/tw-sack.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���������9>���");
INSERT INTO `arc1542_wfFileMods` VALUES("u�)8FG9�C�(���","wp-includes/js/wp-ajax-response.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bC;�s�{�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Clo�������","wp-admin/nav-menus.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x������͉���");
INSERT INTO `arc1542_wfFileMods` VALUES("��-��i>bs��1�","wp-includes/js/jquery/ui/resizable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�*��W�i�X㝶տ");
INSERT INTO `arc1542_wfFileMods` VALUES("��4r�%����j���","wp-includes/SimplePie/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���kU�6�
�+�)%�");
INSERT INTO `arc1542_wfFileMods` VALUES("��KS+�e׎A�@��","wp-admin/css/colors/light/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �V{��)\\_~��q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0��5��mk��","wp-includes/js/wp-a11y.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����z�L�u�Jg��k");
INSERT INTO `arc1542_wfFileMods` VALUES("΢�S˪�
��B�V\"","wp-includes/fonts/dashicons.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�)x䌉��[�w�");
INSERT INTO `arc1542_wfFileMods` VALUES("��ܡ9�u_\\
�9�\'","wp-admin/css/color-picker.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����}��U��F��\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("�KU�g0MU�/��ʇ","wp-admin/admin-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ga���c�3�aq�");
INSERT INTO `arc1542_wfFileMods` VALUES("4;V��\'�/����f�","wp-includes/js/jquery/ui/effect-scale.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}0e,)����+m�T");
INSERT INTO `arc1542_wfFileMods` VALUES("���C
���U���","wp-admin/js/custom-header.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2�\0X���`o���uf�");
INSERT INTO `arc1542_wfFileMods` VALUES("��0l��j�0+%�","wp-includes/SimplePie/Source.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������S{�*���");
INSERT INTO `arc1542_wfFileMods` VALUES("�)����t�,�Jڼ","wp-admin/options-permalink.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Kj�rU�54�Z�R�$");
INSERT INTO `arc1542_wfFileMods` VALUES("Ր(������@��","wp-admin/js/press-this.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h.[t�y�	��1��J");
INSERT INTO `arc1542_wfFileMods` VALUES("Wl��y:�\0Vn`�d\0�","wp-includes/js/tinymce/plugins/wpview/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f둽�塴�;����");
INSERT INTO `arc1542_wfFileMods` VALUES("�,�4#��(�#","wp-signup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���*�I
�gF�t");
INSERT INTO `arc1542_wfFileMods` VALUES("�:8�Ia��øl�m","wp-admin/includes/class-ftp-pure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�\\.B���������");
INSERT INTO `arc1542_wfFileMods` VALUES("����KqM���{���","wp-admin/css/dashboard.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����p�0��ۃ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�TB��O>�v2��}Ea","wp-includes/SimplePie/Locator.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s����;�uvf^��");
INSERT INTO `arc1542_wfFileMods` VALUES("F��e���}�(��","wp-includes/js/jquery/ui/dialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$aV�{Ԅ��,�0");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�/ᡇ_�����","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4 �\\B�i�M銋");
INSERT INTO `arc1542_wfFileMods` VALUES("�&UX�L4{����","wp-includes/js/utils.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�9����!�;�	��x�");
INSERT INTO `arc1542_wfFileMods` VALUES("�e���j!^��	��","wp-includes/js/mediaelement/bigplay.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","qd6�=�Ҟk7�b�Rgj");
INSERT INTO `arc1542_wfFileMods` VALUES("������)qtsCI9","wp-includes/functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�Q��oNw�}��$7");
INSERT INTO `arc1542_wfFileMods` VALUES("�y��8R#O�y��","wp-admin/css/nav-menus-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��@�2��Ҏb4�V_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�UE�s(���#E�p","wp-includes/images/smilies/icon_mrgreen.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J����Rw��w��");
INSERT INTO `arc1542_wfFileMods` VALUES("A�Z�哖̅L��(","wp-includes/js/mediaelement/skipback.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�m�0�E���k��o�HF");
INSERT INTO `arc1542_wfFileMods` VALUES("�y���!�\0pZ�[A","wp-includes/js/mediaelement/mediaelement-and-player.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5:���\0 vu�k�");
INSERT INTO `arc1542_wfFileMods` VALUES("ֻE
�<�B�[�,","wp-includes/class-wp-ajax-response.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r6`0}�dmĂQ���\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�m��n9�F�6�","wp-admin/css/admin-menu-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�0Wi�Qκ~�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�M��^�ûoz�","wp-admin/images/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-[��t�P���d�");
INSERT INTO `arc1542_wfFileMods` VALUES("4%�IH�O��ʰ�L","wp-includes/css/media-views.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w�0**�b6��Џ�");
INSERT INTO `arc1542_wfFileMods` VALUES("C�/�;)��ّ�o","wp-admin/js/comment.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���I���4�D�O#]");
INSERT INTO `arc1542_wfFileMods` VALUES("T�gslF���ʞ��Ly","wp-admin/js/set-post-thumbnail.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����8�կ!�1z[");
INSERT INTO `arc1542_wfFileMods` VALUES("vs�%�z�����F�","wp-admin/css/ie-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Fܣ��sȶ��?��\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
$z�X�`�1Bw","wp-includes/js/tinymce/plugins/charmap/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a���w��g��\\c�H�");
INSERT INTO `arc1542_wfFileMods` VALUES("��=b�6��hs���t","wp-admin/ms-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�K��$�IZ1�i%�");
INSERT INTO `arc1542_wfFileMods` VALUES("
��O�_��;]/^��","wp-includes/images/down_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��]:u�Wv���\"��");
INSERT INTO `arc1542_wfFileMods` VALUES("G_bc�.,]&���","wp-admin/js/image-edit.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�1���l2���z�^");
INSERT INTO `arc1542_wfFileMods` VALUES("fMx�����	�+9�U�","wp-admin/js/customize-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B\0��$�A쟠");
INSERT INTO `arc1542_wfFileMods` VALUES("�%��\\��MA�����","wp-admin/images/wordpress-logo-white.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c=Yܵ����s����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"j�ǧ`�����1�","wp-admin/css/press-this-editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�?�V���\"��\'ŝ");
INSERT INTO `arc1542_wfFileMods` VALUES("�=�}C���i��HT","wp-admin/network/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i&�Q\\Ӣ�綨");
INSERT INTO `arc1542_wfFileMods` VALUES("�g��I�!٭���_�","wp-includes/ms-blogs.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",	�-�U{�%��	 �");
INSERT INTO `arc1542_wfFileMods` VALUES("��]/~���q��XŎE","wp-includes/js/jquery/ui/button.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~���B��h�F��Vml");
INSERT INTO `arc1542_wfFileMods` VALUES("|�&;�r�Ls5��","wp-admin/includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\\�����\'3�)ާQ");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ye�.�0s��","wp-admin/includes/class-wp-comments-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�NGA��R��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'-�p�-���f�","wp-admin/css/l10n-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:8σH57cM��G");
INSERT INTO `arc1542_wfFileMods` VALUES("L��bP�-I׭1f�","wp-includes/theme-compat/header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x������vY����");
INSERT INTO `arc1542_wfFileMods` VALUES("�{��Y�\\�z錿�}c","wp-includes/images/smilies/rolleyes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ���O�2�Ofݣi�");
INSERT INTO `arc1542_wfFileMods` VALUES(" *@ADғ�=pu���E","wp-admin/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":��P�>.����M^�");
INSERT INTO `arc1542_wfFileMods` VALUES(" ��c̫)I�
p,͑��","wp-includes/css/jquery-ui-dialog-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����7���ִ�F3");
INSERT INTO `arc1542_wfFileMods` VALUES(" �p(?Qn����a��Z","wp-includes/js/plupload/plupload.silverlight.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<RGPTmᳪ�o���");
INSERT INTO `arc1542_wfFileMods` VALUES("!o���A��v7��e","wp-admin/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�$B3FOl`�8");
INSERT INTO `arc1542_wfFileMods` VALUES("!1b݅9��*���\\��","wp-admin/admin-footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bKtvoC��Nwjv�A�");
INSERT INTO `arc1542_wfFileMods` VALUES("!_��輵p3p�n��L","wp-includes/images/smilies/icon_eek.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��s���jN��_z�");
INSERT INTO `arc1542_wfFileMods` VALUES("!�R���p�nL�w�m7","wp-includes/js/tinymce/plugins/lists/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4,~I�i%E���[");
INSERT INTO `arc1542_wfFileMods` VALUES("!����Y0-z1�dm>�","wp-admin/js/plugin-install.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zb�
�d�&�o�f�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"(}G��r�	0��V(","wp-admin/ms-options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'�\0�}��:��ㆯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"IFn����@�a�}�9","wp-admin/includes/class-wp-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@̔m��`b���TyTH5");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����b9��e�|�_�","wp-includes/feed-atom-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�D1;�)��-�B?6s");
INSERT INTO `arc1542_wfFileMods` VALUES("\"�����u>1�7���","wp-includes/class-pop3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���S��|����/}");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����c���9�&","wp-includes/js/plupload/plupload.full.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�6�G��
�!:D");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��6+K{�!a","wp-admin/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�҅yE�F@$�D9�");
INSERT INTO `arc1542_wfFileMods` VALUES("$����0S�r���","wp-includes/images/smilies/icon_redface.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m��A��R!4a");
INSERT INTO `arc1542_wfFileMods` VALUES("$���C����/�9��","wp-includes/class-wp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�iG!��Q�l�3nI%�");
INSERT INTO `arc1542_wfFileMods` VALUES("%����8^�V<�t�","wp-admin/edit-tag-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F?��E���/)w%�");
INSERT INTO `arc1542_wfFileMods` VALUES("&�Sǲby\0E���5�","arc-website.zip","0","(0��	��u�k.��1","(0��	��u�k.��1");
INSERT INTO `arc1542_wfFileMods` VALUES("&*���dĆָ�	�H5","wp-admin/images/align-center.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�ݶ�4y�dY1�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("&=�+t�\"�/k\'
","wp-includes/js/jquery/jquery.form.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�À�s���E�VM�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("&ee�
3K���vZ��","wp-admin/ms-delete-site.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A��;t�?OaQvQ�");
INSERT INTO `arc1542_wfFileMods` VALUES("&t!0^g��bJ�c,>3","wp-admin/upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2\'�w�%�M�Ǽ��");
INSERT INTO `arc1542_wfFileMods` VALUES("&���Rw?~�j�hJ�D","wp-includes/Text/Diff/Renderer/inline.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�n5�P�����B\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("&��]0W��
)�=��","wp-includes/js/tinymce/plugins/directionality/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�W%<�:oJ��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("&�`�O�Q5�Q�43�","wp-admin/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NGQn�]/�A�E_��");
INSERT INTO `arc1542_wfFileMods` VALUES("(��g%\0��4��l>��","wp-includes/js/jquery/jquery.schedule.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��T�k�f؞���");
INSERT INTO `arc1542_wfFileMods` VALUES("(?���>��S�N揚�&","wp-includes/images/media/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-����I�B�h�@���b");
INSERT INTO `arc1542_wfFileMods` VALUES("([d��������BQ��","wp-admin/js/updates.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z[i�j(�N��h�\\!�");
INSERT INTO `arc1542_wfFileMods` VALUES("(~6vqV�0�{�\"","wp-includes/ID3/readme.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����Ɯ���VLN[�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���v|T�— ¥�","wp-admin/includes/screen.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B<Y����N��&ȼ�>");
INSERT INTO `arc1542_wfFileMods` VALUES("(�^�3N������3","wp-includes/wp-diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z{�&���Q����\"");
INSERT INTO `arc1542_wfFileMods` VALUES("){�jW-_�Q=?�GlҢ","wp-includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k&` ��C8�]:�t�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�Oz=�u����˷","wp-includes/rewrite.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j˨�D��~^��T�");
INSERT INTO `arc1542_wfFileMods` VALUES("* a�F���4��u�vU","wp-admin/images/menu-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J�ZY<�i�Y��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("*t$�ߋv��n��s�","wp-includes/js/swfupload/swfupload.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z%�5�e,�r��HO");
INSERT INTO `arc1542_wfFileMods` VALUES("*��-3�u��E�[�O#","wp-includes/images/down_arrow-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s���$�6(�@�a");
INSERT INTO `arc1542_wfFileMods` VALUES("*���L�m&&2��
b","wp-includes/js/tinymce/utils/form_utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�D{}��wk��k|");
INSERT INTO `arc1542_wfFileMods` VALUES("*�07ѥ1O���َ8","wp-includes/js/json2.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t������uD�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("+9���[BU�E�e","wp-admin/js/updates.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��f����\0|�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("+��G*#�������f�","wp-admin/network/site-info.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|�P�|�N�F
Ύm6");
INSERT INTO `arc1542_wfFileMods` VALUES("+���t�%R?������","wp-admin/network/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8,�4,���X���u�");
INSERT INTO `arc1542_wfFileMods` VALUES(",<�� �?C]�0A�","wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��(oT���R��a�");
INSERT INTO `arc1542_wfFileMods` VALUES(",B�c���ԛZ�4Y","wp-includes/js/swfupload/plugins/swfupload.speed.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AZ7��k���E`,*�s�");
INSERT INTO `arc1542_wfFileMods` VALUES(",���@��hj�qrޒ�","wp-includes/ID3/module.tag.id3v2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U[��,j�}jAؚ��c");
INSERT INTO `arc1542_wfFileMods` VALUES(",�hɃs?4B[�^՝","wp-includes/SimplePie/Cache/DB.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y�OU���.�b���");
INSERT INTO `arc1542_wfFileMods` VALUES("-kdϯ���X�w\\7���","wp-includes/admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.A�~E��L+,H[d�");
INSERT INTO `arc1542_wfFileMods` VALUES("-����Ǹ�%w=��","wp-admin/css/colors/ocean/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|[���l�|ٱf%h");
INSERT INTO `arc1542_wfFileMods` VALUES("-��)7�5y�8c��Wv�","wp-admin/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Xc�拇��Z<j����");
INSERT INTO `arc1542_wfFileMods` VALUES("-�_��+��Yn��S","wp-includes/js/jquery/ui/tooltip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]G҃������@EQ");
INSERT INTO `arc1542_wfFileMods` VALUES("-�f��4]�#\"u��l","wp-admin/css/colors/light/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R�[Ƴ�O�I\\");
INSERT INTO `arc1542_wfFileMods` VALUES("-��藂��Y{]ns�","wp-includes/css/wp-pointer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȡN�mH˟,3g\"��b");
INSERT INTO `arc1542_wfFileMods` VALUES(". �\0_oE�]A�_�0PJ","wp-includes/js/tinymce/plugins/wpautoresize/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","d�\0Xc�O�@p��%�");
INSERT INTO `arc1542_wfFileMods` VALUES(".IhU���3��+B��","wp-includes/images/admin-bar-sprite-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q����8��o��");
INSERT INTO `arc1542_wfFileMods` VALUES(".Z{=U�uߩAJ��*","wp-admin/css/press-this.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H
{R�`���z
�&");
INSERT INTO `arc1542_wfFileMods` VALUES("/<ا^ɼf}�\"���$�","wp-includes/images/media/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�4�8�Αy�6�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("/�s��C4��������","wp-admin/network/setup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Bm>n9z]�њ�");
INSERT INTO `arc1542_wfFileMods` VALUES("/鹠���ΰ1�iw��","wp-includes/images/uploader-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���&-��O��Õ�~");
INSERT INTO `arc1542_wfFileMods` VALUES("0<�����lڿ��J��","wp-includes/js/wp-backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i���H.�^�V!");
INSERT INTO `arc1542_wfFileMods` VALUES("0]�qK\'�f�x����","wp-includes/js/tinymce/plugins/compat3x/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����������r��");
INSERT INTO `arc1542_wfFileMods` VALUES("0���E\00���X�H","wp-includes/js/colorpicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5
���w�-g���:OH�");
INSERT INTO `arc1542_wfFileMods` VALUES("1s�)6�Ӷ���C��Η","wp-admin/user/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\'�$�U�m�x�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("1�EfQ�v#)�
�0EkQ","wp-admin/images/media-button-image.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~���WÎ�@��b�rճ");
INSERT INTO `arc1542_wfFileMods` VALUES("1��X�/�t60^Ҁ!�7","wp-includes/js/comment-reply.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���~��i_");
INSERT INTO `arc1542_wfFileMods` VALUES("2@�j�j\0�kӲ��Ә","wp-admin/includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f���*�4�d��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("2j�L,���W��W$��","wp-admin/css/colors/sunrise/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2�$
�`��5H��");
INSERT INTO `arc1542_wfFileMods` VALUES("2��^(��ʭ�-^x��","wp-includes/SimplePie/Enclosure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�B�n΍K�s]");
INSERT INTO `arc1542_wfFileMods` VALUES("3k��oW�5	k[mq","wp-admin/includes/continents-cities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","KWٛ���3��ǝ");
INSERT INTO `arc1542_wfFileMods` VALUES("3���\'���RK�Bf�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���G���7�(tt�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("3��fQ3�h�5[��W�<","wp-includes/Text/Diff/Renderer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����������菨)");
INSERT INTO `arc1542_wfFileMods` VALUES("48�Vt���+^X�","wp-includes/pomo/mo.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�h�^2�.��t��a");
INSERT INTO `arc1542_wfFileMods` VALUES("4AI�n09��7c`","wp-includes/js/tinymce/utils/validate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hf�
[�ٺ��V�}4");
INSERT INTO `arc1542_wfFileMods` VALUES("4a��[I�}���H�m)","wp-admin/css/deprecated-media.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bR\'�5�Y��t�S6");
INSERT INTO `arc1542_wfFileMods` VALUES("4ڂ��L$�,K[�u��","xmlrpc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���u�w��nƻ1��");
INSERT INTO `arc1542_wfFileMods` VALUES("5�?��y��<�2�","wp-admin/css/dashboard-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a��l�*���li&j");
INSERT INTO `arc1542_wfFileMods` VALUES("58�d�`S61K>ۮ�v","wp-admin/css/colors/blue/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4
��`C��9�Ĉ�");
INSERT INTO `arc1542_wfFileMods` VALUES("5C�)
Wu�꽝/F�cK","wp-includes/js/plupload/wp-plupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��;�2�@_e��R|");
INSERT INTO `arc1542_wfFileMods` VALUES("5Z����Sμ�v�`6�9","wp-includes/version.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-����@����S��");
INSERT INTO `arc1542_wfFileMods` VALUES("5\\h>��w	���N�","wp-includes/registration.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q�ύH^�ܲ��I��i�");
INSERT INTO `arc1542_wfFileMods` VALUES("5`�]\\ͭi\0���J�T","wp-includes/class-wp-embed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�J7د�ŏ���,");
INSERT INTO `arc1542_wfFileMods` VALUES("6����X/��HL","wp-includes/js/mediaelement/wp-playlist.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ɘY8@v��\'ٿ�");
INSERT INTO `arc1542_wfFileMods` VALUES("6;I(�H�m�%��f�","wp-admin/css/farbtastic-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�@!!�Ek�");
INSERT INTO `arc1542_wfFileMods` VALUES("6�]j�v�W�k3-�","wp-admin/load-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">7�q�\0�}�0[��0");
INSERT INTO `arc1542_wfFileMods` VALUES("6̠,��_���q���u�","wp-admin/includes/class-wp-filesystem-ftpext.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4��P�?~$�e4~");
INSERT INTO `arc1542_wfFileMods` VALUES("6٨	��:{�^D�","wp-includes/js/jquery/ui/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","asy��6�=�(�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("7|oOU���z\0Ef���","wp-admin/network/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"?}R2{8\\��?R�");
INSERT INTO `arc1542_wfFileMods` VALUES("7�%Wy~׹P?�x��","wp-includes/js/tinymce/skins/wordpress/images/playlist-video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lzV6`wmZBs���");
INSERT INTO `arc1542_wfFileMods` VALUES("7��O+�����ǋ\'n","wp-includes/js/mediaelement/bigplay.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	qm�^@$��ȍ");
INSERT INTO `arc1542_wfFileMods` VALUES("7�c�¢)��S�eb�","wp-includes/js/jquery/ui/menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�Y����-�9|�l�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("8=�I��a�%��k�~�","wp-admin/js/editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�#�h�3;��q�Fq");
INSERT INTO `arc1542_wfFileMods` VALUES("8�R6�DH��q�-{�:`","wp-admin/includes/translation-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a�
]��r6�o�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("8�@)��6yg[y�sQR","wp-admin/css/deprecated-media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U��R�ڹy��C���");
INSERT INTO `arc1542_wfFileMods` VALUES("9�5\'X���>?�","wp-includes/js/customize-preview-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z{�Y}q�y�ڴ�");
INSERT INTO `arc1542_wfFileMods` VALUES("9ψ[�1d{���@","wp-includes/class.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4� �?�M�nI��t�");
INSERT INTO `arc1542_wfFileMods` VALUES("9:��d�o
��p`Ry��","wp-includes/js/tinymce/langs/wp-langs-en.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f�tS�uc�.k�7a7");
INSERT INTO `arc1542_wfFileMods` VALUES("9�} B^��?	�\"�","wp-includes/script-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<l
ԟW:L#㐢");
INSERT INTO `arc1542_wfFileMods` VALUES("9ՍҢ��9��d�Y","wp-includes/ID3/license.commercial.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�GD �.}�c�H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("9��s�3�SZ,p�8g","wp-includes/images/media/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z��s��0�ȝ�Q�K");
INSERT INTO `arc1542_wfFileMods` VALUES(":{���{7�9����","wp-admin/link.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c���Na�b���d");
INSERT INTO `arc1542_wfFileMods` VALUES(":�|L�H6(��c�g��","wp-includes/ID3/module.audio.ogg.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���v�N�5�O۬��");
INSERT INTO `arc1542_wfFileMods` VALUES(":<�$��0,w\"&e({","wp-includes/class-feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<��Byْ���");
INSERT INTO `arc1542_wfFileMods` VALUES(":���%H`!����Z","wp-admin/js/media-gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2��� Ғ�����n");
INSERT INTO `arc1542_wfFileMods` VALUES(":�Xqݝ�J\\�5P�4","wp-includes/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES(":�n̣RM�ti#��=","wp-includes/images/media/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�taCA����.��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES(";�b�fȖ0����x","wp-admin/css/colors/midnight/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x(���V�?OD�{��`");
INSERT INTO `arc1542_wfFileMods` VALUES(";1ы#�Y_N��t�","wp-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ���r(�l2}+��");
INSERT INTO `arc1542_wfFileMods` VALUES(";R�yh���RxK�","wp-admin/js/farbtastic.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�T�2Aq]����4�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�Wct���*+��Br�","wp-includes/images/smilies/icon_surprised.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")�r�����i�^@8��");
INSERT INTO `arc1542_wfFileMods` VALUES(";����*1n��4�","wp-includes/js/wp-emoji-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�i��׽-}�_��{)l");
INSERT INTO `arc1542_wfFileMods` VALUES("<F���Pz�22��~","wp-includes/js/imgareaselect/imgareaselect.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}(��()��3���󵕯");
INSERT INTO `arc1542_wfFileMods` VALUES("<��9�u�j����!�$","wp-admin/css/install.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B��$\0���D��9j�");
INSERT INTO `arc1542_wfFileMods` VALUES("<�hj�	�4���4a�2�","wp-includes/js/utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����o���o,Ê");
INSERT INTO `arc1542_wfFileMods` VALUES("<��u꿖ܜ��Y�^","wp-includes/js/tinymce/plugins/wpeditimage/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c<�{��!���o");
INSERT INTO `arc1542_wfFileMods` VALUES("=f�u�A><Th���@","wp-includes/js/jquery/ui/progressbar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�{��˚q��t	�");
INSERT INTO `arc1542_wfFileMods` VALUES("=��k�[4��� ��=�","wp-includes/comment-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$j���M6��Yb�x}Q");
INSERT INTO `arc1542_wfFileMods` VALUES(">hЩ�XX*�v1���","wp-includes/theme-compat/comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�Q�K?G��}�1");
INSERT INTO `arc1542_wfFileMods` VALUES(">ql�+�m�\05Ħ\"�^","wp-includes/js/customize-preview.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��%Hh�������T�");
INSERT INTO `arc1542_wfFileMods` VALUES(">��X��b��ڟ�$W","wp-includes/class-wp-image-editor-gd.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��3��\0P\0C6�o");
INSERT INTO `arc1542_wfFileMods` VALUES("?]�P�.��1����2b","wp-includes/js/tinymce/plugins/textcolor/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ޔ��]|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("@V�$�K���<�1*��","wp-includes/css/jquery-ui-dialog.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�(}��eB{xS	");
INSERT INTO `arc1542_wfFileMods` VALUES("@b�Hf�Q�\"$��S","wp-admin/js/press-this.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:�q��⭊%�sR~");
INSERT INTO `arc1542_wfFileMods` VALUES("@k/�����I�?T,","wp-includes/js/jquery/ui/datepicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I�N�u��QA�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("@��̘9�#�L�y(��","wp-includes/images/arrow-pointer-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w��b�·*L���[��");
INSERT INTO `arc1542_wfFileMods` VALUES("@�XD
�
RN��t���","wp-admin/images/menu.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��9#�d�Y`	���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�;5�X��V��O�Z","wp-admin/images/mask.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���g~�\"��J��䩎�");
INSERT INTO `arc1542_wfFileMods` VALUES("@�m����O��W","wp-admin/admin-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��I�:s,Ί���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�s�Z��^����q�v","wp-admin/images/media-button-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�WI��\\��?��");
INSERT INTO `arc1542_wfFileMods` VALUES("@��+�T΄\'����٤","wp-includes/ID3/module.audio.flac.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,�g�\0.���i�");
INSERT INTO `arc1542_wfFileMods` VALUES("AE���[�`����","wp-includes/js/thickbox/thickbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���C�eR���wS�%");
INSERT INTO `arc1542_wfFileMods` VALUES("Aa�@J������Ł�","wp-includes/js/tinymce/plugins/colorpicker/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�{�\'sVnш�ӹ|�");
INSERT INTO `arc1542_wfFileMods` VALUES("A{&� ��V>��Νs","wp-admin/css/login-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�?�(6�zү��sz");
INSERT INTO `arc1542_wfFileMods` VALUES("B��j�)��q�D�S","wp-admin/install-helper.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T����R�~����R3Z");
INSERT INTO `arc1542_wfFileMods` VALUES("Dm�
��z�H��S���","wp-includes/images/crystal/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'^c�s���D��3T\\");
INSERT INTO `arc1542_wfFileMods` VALUES("D.���:�\0��S�R8","wp-includes/ID3/module.audio-video.asf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��H�!�0�� �s�W");
INSERT INTO `arc1542_wfFileMods` VALUES("D6m�e�r{pK�O�","wp-includes/locale.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��~h]:�T�1��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("D����)ba�k��{��","wp-admin/includes/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T\"AR��hy�ۺCQ)");
INSERT INTO `arc1542_wfFileMods` VALUES("Dչ������$Oa����","wp-admin/css/colors/ectoplasm/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o�qjGY|UI���\'");
INSERT INTO `arc1542_wfFileMods` VALUES("D��5
\'�\\��~W��","wp-includes/category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�*ˀ�j��5 e�");
INSERT INTO `arc1542_wfFileMods` VALUES("E4��fu#R:k!jgh","wp-includes/js/wp-list-revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��OBy��MK�/�l");
INSERT INTO `arc1542_wfFileMods` VALUES("Eh���������@aq��","wp-includes/session.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")|o�.;eX�+}N�");
INSERT INTO `arc1542_wfFileMods` VALUES("E�V���,�%��,SM=","wp-admin/ms-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/�Ħý��:E�");
INSERT INTO `arc1542_wfFileMods` VALUES("F�Hȝl�e��#�","wp-includes/js/tinymce/skins/wordpress/images/more-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l,��r�%�^x�%");
INSERT INTO `arc1542_wfFileMods` VALUES("FF�v��V;v�8/���","wp-includes/SimplePie/Misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���y�-���^�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("FH���30m�:��s��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-edit.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","xR�	�Y�X���ݤ���");
INSERT INTO `arc1542_wfFileMods` VALUES("F���Ã\\�O�fg�","wp-includes/js/tinymce/skins/wordpress/images/gallery-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1����v��R");
INSERT INTO `arc1542_wfFileMods` VALUES("F�\'�B�/�4{J�{w","wp-admin/js/edit-comments.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�������u��");
INSERT INTO `arc1542_wfFileMods` VALUES("F���?�C;$��H","wp-admin/css/color-picker.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-M�_�h���lf/");
INSERT INTO `arc1542_wfFileMods` VALUES("G6U�2\01R������J","wp-admin/js/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";���q���S���$�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gm��:�MľV��LЉ","wp-includes/js/tinymce/utils/editable_selects.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��\0!�e�f��");
INSERT INTO `arc1542_wfFileMods` VALUES("Gq�@����gm屪","wp-includes/js/mediaelement/controls.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@�oZsm������ۊR�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gu�^�/1��ՁS�7","wp-includes/atomlib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�e�.���[�\0
f�A");
INSERT INTO `arc1542_wfFileMods` VALUES("G�9q���=ʥ[3?a�","wp-admin/images/bubble_bg-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R=[����;��c��");
INSERT INTO `arc1542_wfFileMods` VALUES("G�7��I&:�x","wp-admin/edit-form-comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%��8H�p�?H2�x�");
INSERT INTO `arc1542_wfFileMods` VALUES("H+�E~�}�1Q���","wp-includes/js/wp-util.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9�f1��bQ
�ʭ&2");
INSERT INTO `arc1542_wfFileMods` VALUES("Hý��i�Z�U,H�L","wp-admin/includes/meta-boxes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w>��+%+�%��_ڟ");
INSERT INTO `arc1542_wfFileMods` VALUES("If@n����;c>�8","wp-includes/js/tinymce/wp-mce-help.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�G;e�������Eq�\'");
INSERT INTO `arc1542_wfFileMods` VALUES("I��:Bs�#����@�","wp-blog-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��n:�����5�S�5�");
INSERT INTO `arc1542_wfFileMods` VALUES("I�V/��6�s���","wp-admin/js/editor-expand.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x��]p1(� bΎP");
INSERT INTO `arc1542_wfFileMods` VALUES("Jf�3?���_r�C�","wp-admin/images/w-logo-white.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*�,K��i�l��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("J��E[�7U���~","wp-includes/js/plupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��WPIʿ���F�Ug)");
INSERT INTO `arc1542_wfFileMods` VALUES("J{�ֹZi^ùx�I","wp-admin/media-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���x�\"������[��");
INSERT INTO `arc1542_wfFileMods` VALUES("J򾁬��Oh���sDؾ","wp-includes/js/zxcvbn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�;��uc���<��");
INSERT INTO `arc1542_wfFileMods` VALUES("K��W�&\0\0K�\06�G�","wp-admin/js/set-post-thumbnail.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","+QSWm�@�~��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("L<#�������}","wp-includes/js/tinymce/skins/lightgray/img/loader.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9K���M�:�Tf�9");
INSERT INTO `arc1542_wfFileMods` VALUES("L#��/۰*��3���","wp-admin/includes/class-wp-terms-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�<&y�!�A���\\");
INSERT INTO `arc1542_wfFileMods` VALUES("L(���n�9[2�C6�","wp-includes/js/zxcvbn-async.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��p9	�9�~��");
INSERT INTO `arc1542_wfFileMods` VALUES("LsЇś
�c}>�K��","wp-includes/css/editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","JE�0I	,l�95�y");
INSERT INTO `arc1542_wfFileMods` VALUES("L��e�t\"pc(	�e�","wp-includes/wp-db.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1�� ���q\\�j�");
INSERT INTO `arc1542_wfFileMods` VALUES("L�>t���N�����","wp-admin/css/colors/blue/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5Iה�g,)Z�YM�");
INSERT INTO `arc1542_wfFileMods` VALUES("L��)��a$�D-�Ӯ�J","wp-includes/js/tinymce/plugins/wplink/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.\"C��b>��K�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("M?,5�*�����K*�f","wp-admin/js/post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}���N�CR���Yp�");
INSERT INTO `arc1542_wfFileMods` VALUES("MW�	���:��ي","wp-admin/images/align-none.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�eqd2���u����");
INSERT INTO `arc1542_wfFileMods` VALUES("MР\0�A���9Q�+��","wp-includes/js/admin-bar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�Oas�{�-v\'�&#");
INSERT INTO `arc1542_wfFileMods` VALUES("M�;C�����8Yyﲏ","wp-includes/js/twemoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|A\0^ֆl�,·MF");
INSERT INTO `arc1542_wfFileMods` VALUES("M���I�M����rD��-","wp-includes/post-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b��
�U\'���(�{�m�");
INSERT INTO `arc1542_wfFileMods` VALUES("N|�Jв�zn��sw","wp-includes/pluggable-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۠���v�!l\"Ȥ�-");
INSERT INTO `arc1542_wfFileMods` VALUES("N�3�j@pu5����^��","wp-includes/js/tinymce/skins/wordpress/images/more.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
�
m\0;�˫�z");
INSERT INTO `arc1542_wfFileMods` VALUES("N���HV����}�4G","wp-admin/css/customize-widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�Aʹ]����j9�");
INSERT INTO `arc1542_wfFileMods` VALUES("O	��S����#��Yi�v","wp-admin/includes/class-wp-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������>�[L�shB");
INSERT INTO `arc1542_wfFileMods` VALUES("OlqCcێ���������","wp-admin/css/forms-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ShAe��{\0�\0�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("O��\\���P5���{�R�","wp-admin/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j������");
INSERT INTO `arc1542_wfFileMods` VALUES("O����&�r�蓏�� ","wp-admin/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e������SvLXy¸");
INSERT INTO `arc1542_wfFileMods` VALUES("O����R�r����D�?�","wp-admin/js/postbox.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#��$�-�!i>");
INSERT INTO `arc1542_wfFileMods` VALUES("O�hu�G���&\0�L�","wp-includes/Text/Diff/Engine/native.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'*�����*�x");
INSERT INTO `arc1542_wfFileMods` VALUES("PE۫�7r|oI�6��>","wp-includes/js/backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���z�����)�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("P\'�(���?+�z��$�","wp-admin/js/postbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����o%�zb|䨎�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("P73o�	��\0�=��","wp-admin/js/word-count.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f%i�@Q��1��N");
INSERT INTO `arc1542_wfFileMods` VALUES("P��iz�t�a�}�a","wp-admin/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�ep<\'��ݖ�?5��");
INSERT INTO `arc1542_wfFileMods` VALUES("P�1$���\\*�C","wp-admin/images/stars-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A���#�S�Me.^");
INSERT INTO `arc1542_wfFileMods` VALUES("P��0��a��R�z= ","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�|hּk8ʙ");
INSERT INTO `arc1542_wfFileMods` VALUES("QT���*�f�P��.�","wp-admin/includes/file.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��D�|#_x5�Y�Wh�");
INSERT INTO `arc1542_wfFileMods` VALUES("QY��1�Tl��Vr<","wp-includes/js/customize-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��;�z��	�YM�#y�");
INSERT INTO `arc1542_wfFileMods` VALUES("QuoPX��\0��Sڞ","wp-admin/images/bubble_bg.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=,����(��2cV� 8");
INSERT INTO `arc1542_wfFileMods` VALUES("Q�`���8�M�8","wp-admin/press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:U�/��vřc�K�J");
INSERT INTO `arc1542_wfFileMods` VALUES("Q������l��g�-��","wp-admin/js/comment.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8�i/y��}��*�C��");
INSERT INTO `arc1542_wfFileMods` VALUES("R3�Us�3��}T���","wp-includes/js/autosave.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�i|}f���C�S�/");
INSERT INTO `arc1542_wfFileMods` VALUES("RQ�b7f�� |~ۓ�(","wp-admin/js/widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H]�mH�W9H\'�����");
INSERT INTO `arc1542_wfFileMods` VALUES("R�x�4Mp@�9u
֊ p","wp-includes/images/wpspin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("R��|Rx/�bzn9\0*�J","wp-admin/includes/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">�8��aK�M�P�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("R�\\SC�|ju�9��A","wp-includes/js/media-grid.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<fl� � �~\\����");
INSERT INTO `arc1542_wfFileMods` VALUES("R¥�����Le�q	�&�","wp-admin/js/user-suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3)��()ݰ4}
�");
INSERT INTO `arc1542_wfFileMods` VALUES("S.FȫA�j���(�:","wp-includes/js/hoverIntent.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�P
ޅL1A�Wb��\0");
INSERT INTO `arc1542_wfFileMods` VALUES("S0�־��K/17u���","wp-includes/js/jquery/ui/selectmenu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}�˪2�9Zhxi\"6�");
INSERT INTO `arc1542_wfFileMods` VALUES("SX+7��1?����-","wp-includes/js/jcrop/Jcrop.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��7e�����Q�%K");
INSERT INTO `arc1542_wfFileMods` VALUES("S����p�>��Wr�YE","wp-comments-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����Х�l��%�f�");
INSERT INTO `arc1542_wfFileMods` VALUES("S��&�az8�Jض9�","wp-includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z6����̒��$2�p");
INSERT INTO `arc1542_wfFileMods` VALUES("T^Ih�����Ύ���(","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v����W`?�I_����=");
INSERT INTO `arc1542_wfFileMods` VALUES("T�.o@Ψ2�w�v��X�","wp-includes/js/jcrop/jquery.Jcrop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/a��Lru�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("T���vm?,�a���T4�","wp-includes/ID3/module.audio-video.quicktime.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�`��f�.�0�F˼");
INSERT INTO `arc1542_wfFileMods` VALUES("U�\\p{J��O�Q�&","wp-includes/SimplePie/Cache/Base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�C�����2]�]#|j");
INSERT INTO `arc1542_wfFileMods` VALUES("U���$i\"u��&���9","wp-includes/images/crystal/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����l��ڤ�;�=");
INSERT INTO `arc1542_wfFileMods` VALUES("V
��U`�_�5���8","wp-includes/js/customize-base.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".��ҖX�`�5A");
INSERT INTO `arc1542_wfFileMods` VALUES("VL6�7G^l%D5z3��","wp-includes/default-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%�ܴ�l�Z��)��");
INSERT INTO `arc1542_wfFileMods` VALUES("Vne!�z0u1?��","wp-includes/shortcodes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","(�+�#1m�ҫ�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("Vrm�KE�p�j��6�","wp-admin/images/w-logo-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�[N�W��_p�w�0");
INSERT INTO `arc1542_wfFileMods` VALUES("V�����댏$�x","wp-admin/js/post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_��K�g�{=q�rbI�");
INSERT INTO `arc1542_wfFileMods` VALUES("W{�g- X���\'=n8","wp-admin/moderation.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","TB���YR��\"4�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("W})Ӗ7���e�}5�9,","wp-admin/load-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��E��0VO��r����");
INSERT INTO `arc1542_wfFileMods` VALUES("X,�E�Cj$_��8I��0","wp-includes/images/smilies/icon_cool.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F~��ߢ.���>t8");
INSERT INTO `arc1542_wfFileMods` VALUES("X�:8+˓2>V]��8�","wp-admin/images/sort-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","nQ&�] �0�-����");
INSERT INTO `arc1542_wfFileMods` VALUES("X���G������z�X","wp-admin/includes/class-wp-upgrader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ݏ2e�q���
��");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�La���h�(","wp-admin/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ၢ�8�q�}u���");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�,�e�A��w�`���","wp-includes/images/media/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9����h�\0��ì�u");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�68�H;%,�_c
�","wp-includes/css/wp-auth-check.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�`�4j@9��Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("Y����]���ŞI���","wp-includes/js/jquery/ui/effect-slide.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#G_��MVژ�y�");
INSERT INTO `arc1542_wfFileMods` VALUES("Y֝��U����}�r/","wp-includes/SimplePie/Cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y���:�oMh�vL�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ZҌ�[��
v���	F","wp-includes/SimplePie/gzdecode.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8��a��al�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("Z����� %/�Z�z9��","wp-admin/includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E���6��|J��Ჵ");
INSERT INTO `arc1542_wfFileMods` VALUES("Z�\0��Y���� æfg","wp-includes/js/crop/marqueeVert.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\0���9��R���");
INSERT INTO `arc1542_wfFileMods` VALUES("[��#ܧ>]��<�","wp-admin/css/colors/ectoplasm/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ӓ�J�׺��S�b�H");
INSERT INTO `arc1542_wfFileMods` VALUES("[�>�x�;�wn/t�H","wp-includes/js/wp-emoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":;���8�%G�/ws ");
INSERT INTO `arc1542_wfFileMods` VALUES("[���1�YAdk�,","wp-includes/SimplePie/Sanitize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Bظ��F�إ�H��u");
INSERT INTO `arc1542_wfFileMods` VALUES("[ꠏ�|K�o�یb7�","wp-admin/user/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������-x���Nb��");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����9������","wp-admin/ms-upgrade-network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��&\"�S�m��8h�m");
INSERT INTO `arc1542_wfFileMods` VALUES("\\[��i%Ͱ<��e�>�","wp-includes/css/wp-pointer-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͆���j_�L�J");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�т�?$�̈́8����","wp-admin/includes/dashboard.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","wU�s��dĂۯG");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�\0��>�+���Fb��","wp-admin/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����f��#�=�|�B�");
INSERT INTO `arc1542_wfFileMods` VALUES("](R�&!��1;�3��","wp-includes/js/wp-ajax-response.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��#Pv�\\��p��");
INSERT INTO `arc1542_wfFileMods` VALUES("]B#�2�z���bU��/","wp-includes/Text/Diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��gkj@b�%���\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("]��P���Tkvt��8A","wp-admin/network/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=S[�fx�������");
INSERT INTO `arc1542_wfFileMods` VALUES("]�����\"}[�Y�R�","wp-admin/css/edit-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���s������3g�$");
INSERT INTO `arc1542_wfFileMods` VALUES("^9(-(Ų�y ���0q*","wp-admin/user/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\0ڍ�KN� ���N�-");
INSERT INTO `arc1542_wfFileMods` VALUES("^@ղ{\'��_���92","wp-admin/upgrade-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^����uP�qX\\e��");
INSERT INTO `arc1542_wfFileMods` VALUES("^�Ð����+�y|�","wp-includes/images/crystal/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�9�Т1�T��n��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�\0��d �MP~��D","wp-includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{)8\'\'���8���u");
INSERT INTO `arc1542_wfFileMods` VALUES("_*�⽞L�0�>","wp-includes/feed-rss2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��`\'r}��b� QG");
INSERT INTO `arc1542_wfFileMods` VALUES("_j���_��/���yӱ","wp-includes/load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T�fuJ�\0�G�G0");
INSERT INTO `arc1542_wfFileMods` VALUES("_�|��T�M^���J","wp-includes/css/editor.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����m-o>�q��");
INSERT INTO `arc1542_wfFileMods` VALUES("_���4�3���=��","wp-includes/images/uploader-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\\M�����m��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�(�C���M6�9�","wp-admin/includes/class-wp-links-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pP�����{4W�EW");
INSERT INTO `arc1542_wfFileMods` VALUES("_�����8}���?�","wp-includes/css/media-views-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t[kn�i�+�/���j�I");
INSERT INTO `arc1542_wfFileMods` VALUES("`���S�`NI�^G�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a5Dn��r-m�@5P");
INSERT INTO `arc1542_wfFileMods` VALUES("`%�ֽ�j��\'��P��","wp-admin/js/edit-comments.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{(Æ�c|�љģ*3");
INSERT INTO `arc1542_wfFileMods` VALUES("`���;�\"�-���+~;","wp-includes/js/tinymce/plugins/media/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�\"��ʧ�Z�¥v
");
INSERT INTO `arc1542_wfFileMods` VALUES("a)�TMW�Oo��Q�|�","wp-admin/images/media-button.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6@p�z^ye��");
INSERT INTO `arc1542_wfFileMods` VALUES("a\\c,I\"5T��#̋�","wp-admin/images/media-button-music.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��]�2\\Z�/��ޕ");
INSERT INTO `arc1542_wfFileMods` VALUES("a�?��_�ˢ��6j��X","readme.html","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��O��ڂs�B��");
INSERT INTO `arc1542_wfFileMods` VALUES("a�����(m�EB�l�","wp-includes/media-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������K��Y�?�");
INSERT INTO `arc1542_wfFileMods` VALUES("a�c�CH��=l@ĸ","wp-admin/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~��`3��}@�[V�P");
INSERT INTO `arc1542_wfFileMods` VALUES("bY�,��ϥY�r۝�;�","wp-includes/js/crop/cropper.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ky5�ni*M(��");
INSERT INTO `arc1542_wfFileMods` VALUES("b�����Ҍ &�?�{","wp-includes/js/customize-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<�ܽL-�Im");
INSERT INTO `arc1542_wfFileMods` VALUES("c,���[xޫ�3�
�@","wp-includes/js/jquery/jquery.masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����R�(��e^");
INSERT INTO `arc1542_wfFileMods` VALUES("d��:w���O�І","wp-includes/ID3/getid3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"�
Q�Q.���b�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("d��1�쵓-�;O��","wp-admin/js/custom-background.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j�)N���ˈ¨iv#");
INSERT INTO `arc1542_wfFileMods` VALUES("d�(��%J���@�G�","wp-admin/options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�o�sn���]�T�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�hħ{q4�2�K\"�","wp-includes/SimplePie/Rating.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=p�m	�K�دat�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�4�j�2U�V��$�P","wp-admin/css/wp-admin.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�RF��)�m");
INSERT INTO `arc1542_wfFileMods` VALUES("e.PȴNB�Sx[�&��","wp-admin/includes/class-wp-plugin-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i1*\\E�`r����C");
INSERT INTO `arc1542_wfFileMods` VALUES("e��__�%��x���","wp-includes/class-snoopy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mMz�Mr�;v��");
INSERT INTO `arc1542_wfFileMods` VALUES("e�^#|ۍ�TЩ��z","wp-includes/Text/Diff/Engine/xdiff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ֹ�b�t�X8�GX");
INSERT INTO `arc1542_wfFileMods` VALUES("f�u3
�M\\�}6*0�","wp-includes/class-wp-customize-setting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=t��$Q����I");
INSERT INTO `arc1542_wfFileMods` VALUES("f�霰f؟|h��U�L","wp-admin/includes/ms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�*H[�s@��");
INSERT INTO `arc1542_wfFileMods` VALUES("f�����e��R�)�","wp-includes/SimplePie/Item.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�!�Cz�\0�c<ܧ");
INSERT INTO `arc1542_wfFileMods` VALUES("g#�,vM������:��","wp-includes/js/jquery/jquery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N*ht��(�#Y�(JC");
INSERT INTO `arc1542_wfFileMods` VALUES("g+yr���q����D��/","wp-includes/vars.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'���8u���Ƶ8;");
INSERT INTO `arc1542_wfFileMods` VALUES("g|y_�o4\"��X�N���","wp-includes/images/smilies/mrgreen.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-5��^����J�j���");
INSERT INTO `arc1542_wfFileMods` VALUES("g�$G\\��;�r���1X","wp-includes/images/wpicons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","dS��uq��V_���a�");
INSERT INTO `arc1542_wfFileMods` VALUES("g��]bR%� Z��E�","wp-includes/js/shortcode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2\0`y��L8�*�");
INSERT INTO `arc1542_wfFileMods` VALUES("g�Ed��1��D}�����","wp-includes/js/jquery/ui/autocomplete.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���PصC��8�zj�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("hOhl��_��Lm/�","wp-includes/class-wp-customize-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G����.��F���ά(");
INSERT INTO `arc1542_wfFileMods` VALUES("h d��껅2��_�r","wp-includes/functions.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|{�D�v��	��:B");
INSERT INTO `arc1542_wfFileMods` VALUES("h0X-�i����^�G`8","wp-includes/pluggable.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�Y�C��eF��H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("h4���#3�`�-݈�\"�","wp-admin/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���?���>z�ͩ��z&");
INSERT INTO `arc1542_wfFileMods` VALUES("h@Z�%�R�F�;ti\\m","wp-admin/css/login-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V<���/(�{�z�ݨQ");
INSERT INTO `arc1542_wfFileMods` VALUES("h|hE��f:Ʊ2��~","wp-admin/network/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&շ�1Up�%��1=$�");
INSERT INTO `arc1542_wfFileMods` VALUES("iAh{���M(�|J,��","wp-admin/js/wp-fullscreen.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f��A�o��\0)`�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("i�-��X�8V[~E�","wp-admin/css/install-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���5�n���J� ");
INSERT INTO `arc1542_wfFileMods` VALUES("i�\\����=X�h$","wp-admin/js/language-chooser.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�P�V0��tJ�J");
INSERT INTO `arc1542_wfFileMods` VALUES("jQ���e���;�e","wp-includes/css/wp-pointer-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l>SR1�i�Y�7��");
INSERT INTO `arc1542_wfFileMods` VALUES("jmE��AX�uw�>܆","wp-admin/css/colors/ectoplasm/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Ѳ��E��ϡuI�");
INSERT INTO `arc1542_wfFileMods` VALUES("j�䱋����%���]�","wp-includes/class-wp-xmlrpc-server.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WUT��W��r��͜");
INSERT INTO `arc1542_wfFileMods` VALUES("j�����5F+���o","wp-includes/images/crystal/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�R�m`���`�9��");
INSERT INTO `arc1542_wfFileMods` VALUES("k���$6O��-N�x�","wp-includes/js/tinymce/plugins/charmap/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��c������ni�?K%");
INSERT INTO `arc1542_wfFileMods` VALUES("kM�������̙Ysp","wp-admin/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m`$�����Y�J");
INSERT INTO `arc1542_wfFileMods` VALUES("k��B˞�b=y��","wp-includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q��*�;\'�ep");
INSERT INTO `arc1542_wfFileMods` VALUES("mD��T�ms���A�}","wp-includes/certificates/ca-bundle.crt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��vǻ��!�o
�f��o");
INSERT INTO `arc1542_wfFileMods` VALUES("mA��Y�����Rb|�S�","wp-includes/ms-default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NM�������9�b�%");
INSERT INTO `arc1542_wfFileMods` VALUES("mE������\\�)��o�","wp-includes/js/jquery/ui/spinner.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ש�/k&HQ��;j��");
INSERT INTO `arc1542_wfFileMods` VALUES("mY����}ɽ��?","wp-includes/js/jquery/jquery.ui.touch-punch.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�m�Q4փ��]�");
INSERT INTO `arc1542_wfFileMods` VALUES("m��-m1�����w��","wp-includes/js/jquery/ui/sortable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Xw���k^�");
INSERT INTO `arc1542_wfFileMods` VALUES("n]�j7<3ISsQ�","wp-admin/images/post-formats32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t.E���5G�N��v");
INSERT INTO `arc1542_wfFileMods` VALUES("n#�t=�\'�����b]{�","wp-includes/js/tinymce/themes/modern/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL]�����Tg2%�");
INSERT INTO `arc1542_wfFileMods` VALUES("nZ/1T:{&^�/n���","wp-admin/js/media-gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��f����8�}+&");
INSERT INTO `arc1542_wfFileMods` VALUES("nef���A@���R�?��","wp-includes/js/jquery/ui/position.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}��{:�pKv�ht�");
INSERT INTO `arc1542_wfFileMods` VALUES("n����@��A��F�","wp-admin/network/sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��bd�Y.|��K�");
INSERT INTO `arc1542_wfFileMods` VALUES("oP��c����o�.�r","wp-includes/js/tinymce/skins/lightgray/img/object.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�rdP�E}u
/M�A�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("oZ0�������<c�0","wp-includes/SimplePie/IRI.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n� �憒�;a{�_6�");
INSERT INTO `arc1542_wfFileMods` VALUES("o㮚-�;?X:��pҡ","wp-trackback.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��d���#k�l");
INSERT INTO `arc1542_wfFileMods` VALUES("o�[��n3u��ʹ�P5","wp-admin/options-general.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�����7֔�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��7u�L�_{2Û�","wp-includes/js/jquery/ui/draggable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","PV�d��@��Y��");
INSERT INTO `arc1542_wfFileMods` VALUES("pUy�a	�b��va�;�8","wp-includes/js/comment-reply.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�(e=N�(ZMV{�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��.а��[ÍD�","wp-includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v��_�S��^Yv�");
INSERT INTO `arc1542_wfFileMods` VALUES("q\"�co���>�2Rh�]","wp-admin/includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e�\\y����:�8");
INSERT INTO `arc1542_wfFileMods` VALUES("qh�665�y|�=�?S	","wp-includes/js/jquery/jquery.serialize-object.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\)������J�l<�\"");
INSERT INTO `arc1542_wfFileMods` VALUES("r��h��v��Lk/��","wp-admin/network/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#9091N���d�H");
INSERT INTO `arc1542_wfFileMods` VALUES("r+zk;� 4��WI","wp-includes/js/tinymce/themes/modern/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<ڎ\'�,s�bP�;S�");
INSERT INTO `arc1542_wfFileMods` VALUES("r�(n՞���j��b\"","wp-admin/js/media.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","υ�^p0LB�uSŅ");
INSERT INTO `arc1542_wfFileMods` VALUES("r�_�/��HG=�%�<�","wp-includes/images/arrow-pointer-blue-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%m�rތ]4�9c�");
INSERT INTO `arc1542_wfFileMods` VALUES("r��r�(J�g�(�y�t","wp-includes/js/mce-view.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ���W�0`��G̪摟");
INSERT INTO `arc1542_wfFileMods` VALUES("r��
��b��#��","wp-admin/css/media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��?ً�./+#S�G_�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�ŏU\'���e@�d�","wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�y�_1u�݇�bo�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�C4M�*��*B�)�","wp-includes/css/wp-pointer.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=|t��r`�֖}|?�");
INSERT INTO `arc1542_wfFileMods` VALUES("t6��O�a��Ȇ�f","wp-admin/js/plugin-install.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XR7�5�1:]��S�");
INSERT INTO `arc1542_wfFileMods` VALUES("t8����p�̋�z{jDp","wp-includes/css/buttons-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1>�����:�z^��");
INSERT INTO `arc1542_wfFileMods` VALUES("tU�/Ds�Iڤ�st�","wp-includes/js/wp-auth-check.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�	�8��_oDdJy��s");
INSERT INTO `arc1542_wfFileMods` VALUES("tm6ۗ�q���.��=j","wp-admin/css/colors/blue/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��-K�e��:8�");
INSERT INTO `arc1542_wfFileMods` VALUES("ue�,\"
	�h�g.","wp-admin/css/colors/_mixins.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S�_���|�\'4.o\'6�");
INSERT INTO `arc1542_wfFileMods` VALUES("u��3!pA�f�)R�M�","wp-includes/js/tinymce/plugins/wpgallery/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���A�#j�d�&�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("u�qg\0�8�hԭ�\0�","wp-admin/custom-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��.��08�#�z&�");
INSERT INTO `arc1542_wfFileMods` VALUES("vڴ����V���K��P","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��6�_¸�f���");
INSERT INTO `arc1542_wfFileMods` VALUES("vK;@�s�aU1;�	^�","wp-config.php","0","�;����8�f���o","�;����8�f���o");
INSERT INTO `arc1542_wfFileMods` VALUES("vw��@�H��z�F�","wp-admin/ms-admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���@�ͯE�b6�");
INSERT INTO `arc1542_wfFileMods` VALUES("v]�z������3�tB","wp-admin/includes/class-wp-importer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ky�lCK��W.���5");
INSERT INTO `arc1542_wfFileMods` VALUES("v��ޣ��R�","wp-includes/js/jquery/jquery-migrate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7��5�X��QN�z");
INSERT INTO `arc1542_wfFileMods` VALUES("v�G�.�g�A��#�r�","wp-admin/images/align-right-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h�l�>r�]�lW��x");
INSERT INTO `arc1542_wfFileMods` VALUES("v����4�|>�<����","wp-admin/js/xfn.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����t�+��n�(k");
INSERT INTO `arc1542_wfFileMods` VALUES("v�{#��l��b\0}��B","wp-admin/css/colors/light/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��ʒw�����^�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("v�Ҹ);�D��~J\"��q","wp-includes/js/jquery/jquery.form.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.�,�+��
q");
INSERT INTO `arc1542_wfFileMods` VALUES("wu�l|��p��Q","wp-includes/js/autosave.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�,@��g�h/7");
INSERT INTO `arc1542_wfFileMods` VALUES("w���L��0���]r.","wp-includes/images/crystal/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�1������1�9");
INSERT INTO `arc1542_wfFileMods` VALUES("w������:}V��P","wp-admin/js/common.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܞ/���X�FoH2.2");
INSERT INTO `arc1542_wfFileMods` VALUES("x	G!N�$�.�d�Tb�","wp-includes/ID3/module.audio-video.flv.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ֈ?�d�h�@�D��");
INSERT INTO `arc1542_wfFileMods` VALUES("xIH�.�9�Y��BO","wp-admin/css/colors/coffee/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9~8 �z#C0�^%a�");
INSERT INTO `arc1542_wfFileMods` VALUES("x�^m�]̲�/��L4vU","wp-admin/includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ǒU�+zm��\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("x덂��@}Y��i�+","wp-includes/js/tinymce/plugins/tabfocus/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j��dFЂ�\"Ex�");
INSERT INTO `arc1542_wfFileMods` VALUES("y���E�a��:�[\0","wp-includes/class.wp-dependencies.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T_[@j��j�\\?ou");
INSERT INTO `arc1542_wfFileMods` VALUES("y���G�\\`����MR�","wp-admin/network/site-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q��y����(�l�#nK");
INSERT INTO `arc1542_wfFileMods` VALUES("z;j2WD�6��[�V","wp-admin/js/accordion.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^V�
�8.7p�Ct�7:");
INSERT INTO `arc1542_wfFileMods` VALUES("z����JX�w{!F���","wp-admin/includes/class-wp-upgrader-skins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<]��:�PGV5]f�");
INSERT INTO `arc1542_wfFileMods` VALUES("{��a�t�
\">��S","wp-includes/js/mediaelement/flashmediaelement.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{�l9�N���	�");
INSERT INTO `arc1542_wfFileMods` VALUES("{N���2�Q�u��=	�","wp-admin/network/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�F��dm����j");
INSERT INTO `arc1542_wfFileMods` VALUES("{t�E~��P�A�1��","wp-admin/js/tags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�Bf�Z��<���/s");
INSERT INTO `arc1542_wfFileMods` VALUES("{�)�4e4p:�fW�","wp-includes/js/jquery/jquery.query.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�Xz�ǰ����wC");
INSERT INTO `arc1542_wfFileMods` VALUES("{�RC���.*\"�Q","wp-includes/feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\3!/���)Tj");
INSERT INTO `arc1542_wfFileMods` VALUES("{��-��}�^��","wp-includes/images/smilies/frownie.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q���������");
INSERT INTO `arc1542_wfFileMods` VALUES("{��P8���5x��-�","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","݃�r\\�+zJ���");
INSERT INTO `arc1542_wfFileMods` VALUES("{���?������
\'","wp-admin/images/imgedit-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K�\\2���}�G�i;O");
INSERT INTO `arc1542_wfFileMods` VALUES("|j��x7�(Q}�0�\'�","wp-admin/css/list-tables.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D�J�$���e벚�");
INSERT INTO `arc1542_wfFileMods` VALUES("|/ڒ�\0[*4��x��","wp-includes/js/admin-bar.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�o�\0�H�[�H");
INSERT INTO `arc1542_wfFileMods` VALUES("|��Y�>���	�Ɔ�","wp-admin/link-add.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�G�D�/�ϥ�W��");
INSERT INTO `arc1542_wfFileMods` VALUES("}ĉ=�t�����","wp-includes/images/toggle-arrow-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���\\����CDr�");
INSERT INTO `arc1542_wfFileMods` VALUES("}`��g\"P�2��V��","wp-includes/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("}���>/���+i�V","wp-admin/js/wp-fullscreen.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","֨���9�Z%�S=2�");
INSERT INTO `arc1542_wfFileMods` VALUES("}�7 ޘ�DHD�Pl","wp-includes/SimplePie/Registry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ȣ����1v9�d\0�ٸ");
INSERT INTO `arc1542_wfFileMods` VALUES("}�Ȑ�\\L��`���i)","wp-includes/ID3/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�����jQ���#1�");
INSERT INTO `arc1542_wfFileMods` VALUES("}���{RҢ����\"","wp-includes/default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j����vj�$��%��+");
INSERT INTO `arc1542_wfFileMods` VALUES("~79�h�g$+�=���\\0","wp-admin/js/bookmarklet.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`8����#���\03");
INSERT INTO `arc1542_wfFileMods` VALUES("~?�J�I�b*׺�e�C","wp-admin/images/resize.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�D�$��Xv����a");
INSERT INTO `arc1542_wfFileMods` VALUES("~F��㫎>dy��j�","wp-includes/css/jquery-ui-dialog-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2iy6�v���&]�2��");
INSERT INTO `arc1542_wfFileMods` VALUES("~ť�s\0�1y�$�L}h","wp-config-sample.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o\"M�p��q��$vB");
INSERT INTO `arc1542_wfFileMods` VALUES("j&��^����b����","wp-includes/ms-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��sv�ɂhz�*�e��");
INSERT INTO `arc1542_wfFileMods` VALUES("�K�Q�}U&;&���Q","wp-includes/meta.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�؏�oS�Byy}�;�");
INSERT INTO `arc1542_wfFileMods` VALUES("�tr�εF_� ���","wp-includes/js/wp-emoji-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ԩ�?�WJ���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�R�*�����������",".htaccess","0","\'蘖][�!9��=q�","\'蘖][�!9��=q�");
INSERT INTO `arc1542_wfFileMods` VALUES("��ں�u���M���[","wp-admin/images/wpspin_light-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("����e��97�aJS","wp-includes/images/smilies/icon_smile.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��G)ö��u��\\
M");
INSERT INTO `arc1542_wfFileMods` VALUES("�el�5�s��E�úQ�","wp-admin/js/media-upload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a�p�3� 
�^$e&z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��,CUU����9i-","wp-includes/css/wp-auth-check.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�G7���_�h�Q�^");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȉV?	��]�)A","wp-includes/js/media-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�@�<d4�z��1��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\'>�[��·�","wp-admin/js/user-profile.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","(		!�{��*�=�&�\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�3��Ƈe�(ú9�","wp-includes/js/jquery/suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!����^�~k�ۥ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\�(��wB��I�","wp-admin/network/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E�^�!��u��)�u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�(tTlDά7&��MP.�","wp-includes/js/tinymce/tiny_mce_popup.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B3�)7�{U�/�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�B��ه�v<Sv稳","wp-includes/SimplePie/Parse/Date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
2m0�H�����n\'`");
INSERT INTO `arc1542_wfFileMods` VALUES("�F� �GJ��B��s7�","wp-includes/js/media-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u|z���kNئ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0���+OW+�","index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%0;��s��Dm\\�:[");
INSERT INTO `arc1542_wfFileMods` VALUES("�����A���1�;�","wp-includes/rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VYhƤ�3����u	�");
INSERT INTO `arc1542_wfFileMods` VALUES("���ʆ��n�D㮖�(","wp-admin/css/install.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3?�zP��&O�<R�9`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�:+[��g��CZ���","wp-includes/template-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s�~ǹ��Q9�Zl�=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�B%v6�I\"Jb��4ӡT","wp-admin/link-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AlN.���+Qc��и�");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�A�B�7�Sz!�e","wp-admin/includes/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�o=a�*A���Td�");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�eU��MV��^��","wp-admin/includes/misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","҆F�T���?�;�Հ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0�>#����z(","wp-includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���F��a*�s�<�7");
INSERT INTO `arc1542_wfFileMods` VALUES("���������}��","wp-admin/media-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��J@�����!���");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�w���0�h�9","wp-includes/js/tinymce/plugins/fullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x�2����]�D�yZC");
INSERT INTO `arc1542_wfFileMods` VALUES("�J�&_#��3S�q���","wp-admin/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\:��ڈ��)g,\\","wp-includes/images/smilies/icon_twisted.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b���.�8|`�Q�LF");
INSERT INTO `arc1542_wfFileMods` VALUES("���3v�U�3�P�^O ","wp-admin/css/widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c�}�q�)\\ZB��
�");
INSERT INTO `arc1542_wfFileMods` VALUES("��L �U����f��u�<","wp-admin/images/icons32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�P*���{>v��Uf");
INSERT INTO `arc1542_wfFileMods` VALUES("��`��kYL_��h%\'","wp-includes/theme-compat/comments-popup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�U/����aڌ.u<.");
INSERT INTO `arc1542_wfFileMods` VALUES("�:=�%�����M�۵","wp-includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_���Q��G������");
INSERT INTO `arc1542_wfFileMods` VALUES("�I�{�?��r�]��7","wp-admin/images/resize-rtl.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ےc�ZY�6��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7*���\"{��
�K<","wp-admin/includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/bmO��dNL	i��X");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�8������Z��N�","wp-includes/ID3/module.tag.lyrics3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�׬㑎��0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j��I���<꟟��iU","wp-includes/category-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v�uW����dai");
INSERT INTO `arc1542_wfFileMods` VALUES("��B]nȄ�8�7g��","wp-includes/images/smilies/icon_rolleyes.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȼ�_�Ҹ*>,�!j");
INSERT INTO `arc1542_wfFileMods` VALUES("�Mj�A�M��O�\"If","wp-includes/SimplePie/Net/IPv6.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Fy!j�ـ�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��$��xM1>�_8P\0","wp-includes/js/swfupload/swfupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�E%ρz���s~");
INSERT INTO `arc1542_wfFileMods` VALUES("���6�d��x�D��","wp-includes/js/mediaelement/background.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","p<e�K�c�\\c8�r~\0l");
INSERT INTO `arc1542_wfFileMods` VALUES("�n97�I.O�ҝ޿�","wp-includes/js/heartbeat.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��톙�@��Cm");
INSERT INTO `arc1542_wfFileMods` VALUES("����h+��B����","wp-includes/js/tw-sack.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'��7�ē��n�̄");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�\"��vh�$Lb��","wp-includes/js/imgareaselect/border-anim-v.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �z!�<�7������*�");
INSERT INTO `arc1542_wfFileMods` VALUES("��yc�0O�g)ρ�Mf�","wp-admin/network/site-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j@�~%�����xs");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�
5��H�?������","wp-admin/css/customize-controls.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4��ٻF���$4���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����juGCtO����","wp-admin/css/colors/coffee/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"rü�+��w����\'");
INSERT INTO `arc1542_wfFileMods` VALUES("��l�.H|S���{��","wp-includes/js/jquery/ui/effect-transfer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ި\0w}����n�");
INSERT INTO `arc1542_wfFileMods` VALUES("���an���V=Ty X�","wp-includes/SimplePie/Copyright.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�T��	Ù���j");
INSERT INTO `arc1542_wfFileMods` VALUES("�} �yT��Z�H�cDJ","wp-admin/js/custom-background.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#Y>W� �����e�");
INSERT INTO `arc1542_wfFileMods` VALUES("��{�0l(Ʋu9,wS�u","wp-includes/js/media-audiovideo.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ur�������F\'&�");
INSERT INTO `arc1542_wfFileMods` VALUES("� �A$ۤfC�N��37","wp-includes/query.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�qN��
��b��");
INSERT INTO `arc1542_wfFileMods` VALUES("�(���ה�W�h@=a","wp-includes/images/smilies/icon_mad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","׾�iec�{��0");
INSERT INTO `arc1542_wfFileMods` VALUES("����v���ό�Y9�","wp-includes/ID3/getid3.lib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�sQ�F����0");
INSERT INTO `arc1542_wfFileMods` VALUES("��֗]NR���S{qv?�","wp-admin/css/wp-admin-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"�ew@3�u��|˻");
INSERT INTO `arc1542_wfFileMods` VALUES("��+�Ϳ�#Ft�EǍ7","wp-includes/js/mediaelement/froogaloop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*�B����#�D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�����j�X�])D:","wp-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!�i�A��>\'����ж�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j%M�ɍ��p)Z��","wp-admin/images/generic.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�[#98!�");
INSERT INTO `arc1542_wfFileMods` VALUES("��;(Xp`ҙ��pݷ","wp-includes/js/plupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<�`a*6Y$�qpM�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("��t�0�g�a�/���","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%���ցl R
1�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
�qo�qZVyX��9","wp-admin/includes/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X&Jʅ�q.�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ư	\'CԻ��ګ","wp-includes/images/admin-bar-sprite.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S���:�W����^");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"�Z0\0ؿe�Ԧp�","wp-admin/css/admin-menu.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�>d�\0?�h��/���!");
INSERT INTO `arc1542_wfFileMods` VALUES("����x8[!>�X","wp-admin/includes/class-wp-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o���z��4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("�S����KK2iɈ","wp-includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�D�ǅ<�}F�>UJ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y�g��zaU\"�	XKG","wp-includes/js/hoverIntent.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʳY�C��c�On�כ");
INSERT INTO `arc1542_wfFileMods` VALUES("�v{L�Jlō�Yz�`�(","wp-includes/js/thickbox/thickbox.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%R��j��o�AYx�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X�VטO|8}���","wp-includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�T�u�޷����<#O");
INSERT INTO `arc1542_wfFileMods` VALUES("�V}�P���m�/�|I*�","wp-includes/js/customize-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!0�&�q���\0�~�");
INSERT INTO `arc1542_wfFileMods` VALUES("��.��v8-rJŕ�qQ","wp-includes/js/wp-auth-check.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����]k���Z!V");
INSERT INTO `arc1542_wfFileMods` VALUES("��7��E#�wŧj���","wp-admin/includes/image-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o	z�*����R����");
INSERT INTO `arc1542_wfFileMods` VALUES("��v���|�-��","wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6������t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�!HUN&�\"����z��","wp-admin/css/widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","MǛ��H����3�");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�tU�q�^!�0ƣl�","wp-includes/post-formats.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�M�ґ�VȔ$L;Cd�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k���zߣ����bo�R","wp-admin/post-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z�6>!?~E����De�");
INSERT INTO `arc1542_wfFileMods` VALUES("��@��{�J��5䷴X","wp-includes/js/tinymce/skins/wordpress/images/playlist-audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U,�:)��؋\"�QqY");
INSERT INTO `arc1542_wfFileMods` VALUES("����L��6	���׳","wp-includes/ID3/module.audio.ac3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��E�p:�A��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES("��T��V�����\\��","wp-admin/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n8�]<�Ĕr��W7�@W");
INSERT INTO `arc1542_wfFileMods` VALUES("�ܵ[Ҳm%�6�S8:D","wp-includes/images/toggle-arrow.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��·�a��;�d��*�");
INSERT INTO `arc1542_wfFileMods` VALUES("����!ެ��߳���p","wp-includes/images/crystal/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�>)*/��!�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�h�����FuQe� �","wp-includes/images/wlw/wp-comments.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�6]P����.s���");
INSERT INTO `arc1542_wfFileMods` VALUES("��f0��ͭ��~�)","wp-includes/fonts/dashicons.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�����a�I�~t~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�|;�;8�Q�4�k��","wp-admin/install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH��H�.�Ӧ��%��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9�e�E��bݾl�3�","wp-includes/js/wp-lists.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t|r��5��xŇ�ґ");
INSERT INTO `arc1542_wfFileMods` VALUES("��5o��#R\'/��l","wp-includes/fonts/dashicons.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","΢6d����HD��Qك");
INSERT INTO `arc1542_wfFileMods` VALUES("����E�?��Юᾠ","wp-includes/js/media-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ԣ~蜿���gį�");
INSERT INTO `arc1542_wfFileMods` VALUES("��Cg����}|�E��","wp-admin/js/word-count.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮�E��^�:��/_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�	v�O.�|ߤҵ�","wp-includes/js/tinymce/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�t\"ٞ3��[�t�|");
INSERT INTO `arc1542_wfFileMods` VALUES("��b�������|e~�","wp-admin/css/customize-widgets.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�����?[���<�");
INSERT INTO `arc1542_wfFileMods` VALUES("����8(�j�Z]}","wp-includes/js/jquery/ui/effect-pulsate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&`������f��");
INSERT INTO `arc1542_wfFileMods` VALUES("�X����g5����(�=c","wp-includes/js/tinymce/skins/lightgray/img/trans.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7I �1F�Gu�j^");
INSERT INTO `arc1542_wfFileMods` VALUES("�pt_ Y����7L�Kt","wp-admin/css/deprecated-media-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{aPt�X?�A���IY");
INSERT INTO `arc1542_wfFileMods` VALUES("����T��D��F�K1�","wp-admin/css/media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x��{�%���U�");
INSERT INTO `arc1542_wfFileMods` VALUES("��/GΞӶ[�ǜ��C","wp-admin/js/gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K~�l���");
INSERT INTO `arc1542_wfFileMods` VALUES("���[�/�9}�`:w�P","license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","98��v���hP֡�>q");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0�����.}�fwA","wp-includes/date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u���<��OI");
INSERT INTO `arc1542_wfFileMods` VALUES("�[���QH\"pS1Ȫ�c","wp-admin/images/arrows-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Q��}��ydb#6�");
INSERT INTO `arc1542_wfFileMods` VALUES("��[ixT�q��~Wv�e","wp-admin/network/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�͚�GM�XZi=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�-��x7��(A�4���","wp-includes/js/swfupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�`�^�-�o�QWz");
INSERT INTO `arc1542_wfFileMods` VALUES("�1W;c�����N��\"�u","wp-includes/pomo/streams.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q;�}���,ʠ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��B�GT�;,l��T","wp-includes/images/smilies/icon_exclaim.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�qE�!HY__=�{_�");
INSERT INTO `arc1542_wfFileMods` VALUES("���7�M3�$��","wp-includes/images/smilies/icon_question.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'u��&E�qA���mN�");
INSERT INTO `arc1542_wfFileMods` VALUES("����2@�k�w>K�2","wp-includes/feed-atom.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q5B���4���D
W");
INSERT INTO `arc1542_wfFileMods` VALUES("�����H\0ۙ��h�C��","wp-admin/css/colors/ectoplasm/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8�K���࿬8��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("��wt�H���-s�\0�n","wp-includes/js/wplink.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�$m��y�l�e���");
INSERT INTO `arc1542_wfFileMods` VALUES("����=֬H�@-i��","wp-includes/css/admin-bar-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��`��
L�&6;");
INSERT INTO `arc1542_wfFileMods` VALUES("���^��\'�q���0��","wp-links-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c���v��Il�mf�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%n��Tߒ	^�gXΰ","wp-admin/js/inline-edit-post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Vӎ���}�_��
�)�");
INSERT INTO `arc1542_wfFileMods` VALUES("�5������k��","wp-admin/js/color-picker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����2dMM��T���");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�������P5aĨ�	","wp-includes/images/smilies/icon_wink.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�Z���g9�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y85���æb�","wp-admin/css/colors/sunrise/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Cp��L�I��tv}���T");
INSERT INTO `arc1542_wfFileMods` VALUES("����PQ�E|E}7+","wp-admin/includes/class-wp-filesystem-ftpsockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�<Rр��D�Fv���");
INSERT INTO `arc1542_wfFileMods` VALUES("��U���$�\\*�1^�S�","wp-includes/js/jquery/ui/effect-clip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ǔ�W�#�GZas");
INSERT INTO `arc1542_wfFileMods` VALUES("��P��/���l%�","wp-includes/js/jquery/jquery.hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","┃��&�݋Fư��");
INSERT INTO `arc1542_wfFileMods` VALUES("�
%f[!aE�r�tg�i","wp-includes/images/media/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����u�h����q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�S짿o�$��0�n","wp-includes/author-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l�@Ñ��P>�itz\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�G�|$p֠+(�","wp-admin/js/tags-box.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t��f����  ��#�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Q����ԁ�2�7u��L","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��W�)�˩��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ѻ�\"�P5��^U�i","wp-admin/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",u��J�%yZ.�");
INSERT INTO `arc1542_wfFileMods` VALUES("��m���z4�L��K","wp-admin/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("����A�G,��<���","wp-includes/js/jquery/ui/effect-fade.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�OO_��;{r�5$m");
INSERT INTO `arc1542_wfFileMods` VALUES("���<��po@S�q��","wp-admin/includes/class-wp-press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���ī��MJ�(6Q");
INSERT INTO `arc1542_wfFileMods` VALUES("� �n�$��q��^qf��","wp-includes/images/smilies/icon_lol.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M�Z8|����,���");
INSERT INTO `arc1542_wfFileMods` VALUES("�*T�u�����~�m","wp-admin/css/colors/ocean/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� 8��J4Z�Jf{
");
INSERT INTO `arc1542_wfFileMods` VALUES("�E-j��1j���E�","wp-includes/registration-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_?<���&T�xH�X�CL");
INSERT INTO `arc1542_wfFileMods` VALUES("��p?E^�@�\'��PE�","wp-admin/edit-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")O��I=4�]VyK�");
INSERT INTO `arc1542_wfFileMods` VALUES("�<��(����*A]�O��","wp-admin/css/colors/ocean/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2Pjģ�$��f�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�bv��E��H���΄","wp-includes/js/wp-lists.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�.�+#/*إ�I08o");
INSERT INTO `arc1542_wfFileMods` VALUES("���&��N�,���6P","wp-admin/images/icons32-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*04�G4F�	&Z�i}\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�h���Bc�92��","wp-admin/network/site-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�!l|�2��V_��");
INSERT INTO `arc1542_wfFileMods` VALUES("��d]\0F�mŲp�D","wp-includes/js/tinymce/plugins/media/moxieplayer.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NY�N�-���3Yj���");
INSERT INTO `arc1542_wfFileMods` VALUES("���v��\\Q���-��","wp-includes/js/tinymce/plugins/hr/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\#%Z����,3�I�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��і�q��SGKy(�","wp-includes/kses.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�+�\\`��s�	");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�Hn[P�.~���FU|","wp-includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7h�ޝ�:޿�-�7");
INSERT INTO `arc1542_wfFileMods` VALUES("����Z�xcy�d��\'","wp-admin/js/language-chooser.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h\"8Jq	t���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:x��=�}�","wp-includes/js/jquery/ui/mouse.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8\']��!��Iٲ��");
INSERT INTO `arc1542_wfFileMods` VALUES("� a\"KwT�bc1S","wp-admin/css/revisions.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��tp��p��P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4g��e���>���ߝ","wp-admin/images/list-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hջIS�2��i�g�");
INSERT INTO `arc1542_wfFileMods` VALUES("�fkj��N�Uei4=%�","wp-admin/js/tags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/I�@�!{�hL�R�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y%���Ǻ~�ne\"V","wp-admin/css/list-tables-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K �@���W�<");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�o%��q�A��","wp-admin/js/inline-edit-post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~{&�di�Y�0�\\�*z");
INSERT INTO `arc1542_wfFileMods` VALUES("��E����Q?��	(�","wp-includes/class-oembed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-fO������Ó�f��|");
INSERT INTO `arc1542_wfFileMods` VALUES("�.݁B��xK�Y�","wp-includes/ms-default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ӱ���eu`�.@7");
INSERT INTO `arc1542_wfFileMods` VALUES("�*O-�Lτ���[�u","wp-admin/css/about-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��/��v�R)�`�E!Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�??n������_2g��j","wp-includes/js/wp-util.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
��%;�I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R;lzO�8m<3�Nie","wp-admin/user/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˹��޳H�t��i.");
INSERT INTO `arc1542_wfFileMods` VALUES("�afh=F���T�:��6�","wp-admin/includes/class-ftp-sockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��[���6��+��\'<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����;~ӷR�>��","wp-includes/class.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��
s? Ei9{�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("���nvp�e������}�","wp-admin/js/customize-controls.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�T�ח
�%��c");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�|n���sARF�+","wp-includes/js/crop/marqueeHoriz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮����;���Lo
");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:[&b�[�hY��","wp-includes/images/smilies/icon_razz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��˭��=��J�@��");
INSERT INTO `arc1542_wfFileMods` VALUES("����8`9��?Bb�Б","wp-includes/js/jquery/ui/effect-puff.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Iml�c�G�@�ȳ� �");
INSERT INTO `arc1542_wfFileMods` VALUES("�c�̎��$
\'@���","wp-admin/setup-config.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�K�[D+^����/");
INSERT INTO `arc1542_wfFileMods` VALUES("���J1��M�F��<�","wp-admin/js/tags-box.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Kn���<ס�x٩");
INSERT INTO `arc1542_wfFileMods` VALUES("���?ڟ�E���$PF","wp-includes/pomo/translations.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fWۥ�\"�\0Dwf��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����6��b�g�>_�","wp-includes/images/wlw/wp-watermark.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��uMmܭD|�w���D");
INSERT INTO `arc1542_wfFileMods` VALUES("� �(T5!��h�u","wp-admin/css/press-this-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���~�+� \"<�bj");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�?���Gc	¯l1e","wp-includes/class-wp-theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6���qߒAz`!�d");
INSERT INTO `arc1542_wfFileMods` VALUES("�H�����Pw��%8��","wp-includes/images/smilies/icon_sad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'=��Oj�?�uA|��");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�n�G{��\'��q:�","wp-includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_Y+�W��+Ŗ Lp�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ȁ�~_q�I��S�","wp-admin/js/password-strength-meter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��|��=��m�U��");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\�D �>�F,���","wp-admin/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��z�ehV��
�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("��=CѠ��*TX���4","wp-admin/css/colors/_variables.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":�	k	r�L���Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�� ��It13&","wp-admin/js/nav-menu.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ˊ������@��*");
INSERT INTO `arc1542_wfFileMods` VALUES("�&F�g��25xm��J&","robots.txt","0","��m�`��=F^+(","��m�`��=F^+(");
INSERT INTO `arc1542_wfFileMods` VALUES("�;?2��S��\0��p","wp-admin/customize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T���xv9|5H3x ");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�.�1PXL�","wp-admin/includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D
��mz/��:���");
INSERT INTO `arc1542_wfFileMods` VALUES("������|� ��","wp-includes/js/masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iq}Eigo@���T��");
INSERT INTO `arc1542_wfFileMods` VALUES("��p�$^���d�Z","wp-admin/network/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��Oy_��4�)����");
INSERT INTO `arc1542_wfFileMods` VALUES("��[K���b���28�","wp-includes/pomo/po.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6+\0��n�_HSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("�o����l>��x~I� �","wp-admin/network/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��=���SV��V���");
INSERT INTO `arc1542_wfFileMods` VALUES("���0j�l�S��K�","wp-includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z/��4��+Zclc�iv[");
INSERT INTO `arc1542_wfFileMods` VALUES("�«��-j=�u�N\\q\'","wp-admin/css/farbtastic.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��8)���}{��C�h2U");
INSERT INTO `arc1542_wfFileMods` VALUES("���ᗏ�3�-��4�","wp-admin/css/colors/midnight/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","FӍ���W�����&%�");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"ڕK[@�G����9�","wp-admin/includes/class-wp-theme-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��u�g��������4");
INSERT INTO `arc1542_wfFileMods` VALUES("�3!9�=�6�ݡ","wp-admin/images/resize-rtl-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ɞ�@��T0:��}");
INSERT INTO `arc1542_wfFileMods` VALUES("�)[\"J�H��|�jk��$","wp-admin/js/customize-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q�*N��>�˘�");
INSERT INTO `arc1542_wfFileMods` VALUES("�JTV0D��oTA［@�","wp-admin/options-discussion.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c{��7��ֺX��.tR�");
INSERT INTO `arc1542_wfFileMods` VALUES("����S�h���S�%Tz�","wp-includes/js/mediaelement/wp-mediaelement.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ؒj�F�5ρ�acR�");
INSERT INTO `arc1542_wfFileMods` VALUES("���\"ܒ����nzD","wp-includes/SimplePie/Caption.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����BjM��g[����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Z
u�oK� ��T;e","wp-admin/images/list.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">��*��ӳ�S��");
INSERT INTO `arc1542_wfFileMods` VALUES("���Uy/�*%���;","wp-admin/includes/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��|*�\'�UC��a��c");
INSERT INTO `arc1542_wfFileMods` VALUES("�E��U���̈́��","wp-includes/images/wpspin-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("�������sp���e�","wp-admin/includes/class-wp-ms-sites-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i�6���|�K�{h");
INSERT INTO `arc1542_wfFileMods` VALUES("�-1�8�;�T�/X�]","wp-admin/ms-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]b$�����q����h");
INSERT INTO `arc1542_wfFileMods` VALUES("����(5�aH�yo,X�","wp-includes/js/jquery/ui/tabs.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�gUZ���D�����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�͓�bHn��,\0-","wp-includes/images/smilies/icon_confused.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�sYFPZ6��,��");
INSERT INTO `arc1542_wfFileMods` VALUES("�L���yE�{��f�","wp-includes/css/dashicons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U�Y��V=}W(}�.N");
INSERT INTO `arc1542_wfFileMods` VALUES("�k�UL��ǡ�$���","wp-admin/ms-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H#�f{#ʃ��	6G�");
INSERT INTO `arc1542_wfFileMods` VALUES("����{^��W����C�","wp-admin/css/colors/ocean/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lv,|����\"��O");
INSERT INTO `arc1542_wfFileMods` VALUES("�_f��;w�a��ځ�","wp-includes/js/tinymce/skins/wordpress/images/gallery.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_���Pw��PU�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�u��<e�x��@ֈ>","wp-includes/js/underscore.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����T��Hk�zd..");
INSERT INTO `arc1542_wfFileMods` VALUES("��q?%��rp��0�7�q","wp-admin/css/colors/coffee/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H<�S�-�g�����");
INSERT INTO `arc1542_wfFileMods` VALUES("����x�Й�)DC��<","wp-includes/js/customize-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Һ�zCp�OE�a�V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�~����U�\"�&��","wp-includes/images/wpicons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��n�V�o�$��Of~7");
INSERT INTO `arc1542_wfFileMods` VALUES("��W2��D��G�7�V","wp-admin/css/common-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��������J<��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Vb(kt�W\"�6(;ƴ�","wp-admin/includes/class-wp-media-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�K��]$��V����");
INSERT INTO `arc1542_wfFileMods` VALUES("�tfF	�r{�܇�_I�x","wp-includes/SimplePie/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�.�b���~����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("��߲;��0����","wp-includes/feed-rss2-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<����7Uv9Q�7");
INSERT INTO `arc1542_wfFileMods` VALUES("��3�T.^�ƙ<���","wp-mail.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R:�߱5�$6��");
INSERT INTO `arc1542_wfFileMods` VALUES("��K���OȖ9�3|<�","wp-admin/maint/repair.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�#\0�24P2�pe�4");
INSERT INTO `arc1542_wfFileMods` VALUES("��I����.$U0]\'�S_","wp-admin/includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J#�%sժ��ka.R�");
INSERT INTO `arc1542_wfFileMods` VALUES("��+D�FܿTZ[H7","wp-admin/images/post-formats-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�l��H\\�������");
INSERT INTO `arc1542_wfFileMods` VALUES("�GV\\z��#���!;��","wp-includes/js/media-audiovideo.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�#�Iu�n?���I�X");
INSERT INTO `arc1542_wfFileMods` VALUES("�O�r#���T�G��!","wp-includes/js/swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���,�I}p�e~2�q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�l&�*�������&","wp-includes/SimplePie/Content/Type/Sniffer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|r��i�Ub�lw����3");
INSERT INTO `arc1542_wfFileMods` VALUES("���$(�g�(���P��/","wp-admin/css/wp-admin-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6`2��f����:*");
INSERT INTO `arc1542_wfFileMods` VALUES("�������kM��?�uX","wp-admin/css/ie-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	wʢ���5յSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("���q�K�U�j��","wp-includes/SimplePie/Category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~��?��.
ܯd�*");
INSERT INTO `arc1542_wfFileMods` VALUES("��-Z���:E�:","wp-admin/js/image-edit.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@ɡ�mz���4n�/GX");
INSERT INTO `arc1542_wfFileMods` VALUES("���|�jX����|�fb","wp-admin/css/login.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����HtU���R��");
INSERT INTO `arc1542_wfFileMods` VALUES("�MR��l�B�F�u","wp-includes/option.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��!+��1,�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�\\�j�����A$�","wp-includes/js/customize-base.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�0�g���ν����");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\"Sέ`t@","wp-admin/network/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��|��MM0\0���");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��.1��-��:","wp-admin/options-media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7�3�1T�w&;��");
INSERT INTO `arc1542_wfFileMods` VALUES("��ΝH�*��*.ځS","wp-admin/includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V��._%B)�j�A��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ul1�ȕD�bmg�","wp-includes/css/buttons-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z�e��=�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
fv�8���1���-I","wp-includes/SimplePie/Exception.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	K�v&���<\\ڏ�S5");
INSERT INTO `arc1542_wfFileMods` VALUES("���ZQ4��\\(�܇","wp-admin/network/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N��5Cs��	�");
INSERT INTO `arc1542_wfFileMods` VALUES("����l����3Ȋ�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���Ѕ�k��#M��");
INSERT INTO `arc1542_wfFileMods` VALUES("�J|6}�P�,ٛ","wp-admin/css/colors/_admin.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W耢��hL��%");
INSERT INTO `arc1542_wfFileMods` VALUES("�����[��:�����q","wp-admin/includes/class-wp-plugins-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�m[ދ���`
jܸ");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�Of;���/��","wp-includes/SimplePie/Decode/HTML/Entities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�^/�B���Z#�%/a");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\ ��Iѻ���,","wp-includes/class-simplepie.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ys�r�	�m���D;��.");
INSERT INTO `arc1542_wfFileMods` VALUES("�/&�����2�ѡgDs","wp-includes/http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��w��$~�r�4T$");
INSERT INTO `arc1542_wfFileMods` VALUES("��?�0|���5uơ��","wp-admin/custom-background.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�إO��\0Q�-��");
INSERT INTO `arc1542_wfFileMods` VALUES("���qh�n�J�j�","wp-admin/css/nav-menus.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&cDݱ��t�q��a");
INSERT INTO `arc1542_wfFileMods` VALUES("�ÏuL�,�&Ǒ�1","wp-admin/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2=KB������H��B");
INSERT INTO `arc1542_wfFileMods` VALUES("��$�<@�Řa���c\"","wp-includes/js/swfupload/plugins/swfupload.swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","̵q�V7�T\\���s");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�@o��\'��kb���","wp-includes/js/jquery/jquery-migrate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q+�(0�BY�<�4:��");
INSERT INTO `arc1542_wfFileMods` VALUES("����^[X��i�	�","wp-admin/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Lg8pt.����ץn");
INSERT INTO `arc1542_wfFileMods` VALUES("��4T�(�\\9\'��3�)","wp-admin/css/customize-widgets-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��PO?$�L�~�U��j�");
INSERT INTO `arc1542_wfFileMods` VALUES("��k{��&��x
��","wp-includes/class-wp-error.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4ĸ\'��3��Bd
���");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��%3[$x\0��.��(","wp-admin/images/marker.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�*O2/�3I2���");
INSERT INTO `arc1542_wfFileMods` VALUES("�	���Em[�����l�<","wp-includes/js/tinymce/plugins/image/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�6_�� ��N�#�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("�������\"�R�Ŝ","wp-includes/images/crystal/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�� Ѳ��#�d�%�[�");
INSERT INTO `arc1542_wfFileMods` VALUES("�v%���S�[�̪�Ѿ","wp-includes/ms-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�zn��GNpܯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("���X\"�-{��$48sx","wp-admin/css/deprecated-media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
ڌe�6|�����Ʀ");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��9�ѕ�F�w�","wp-admin/js/revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�F�{�~��\'Y�i");
INSERT INTO `arc1542_wfFileMods` VALUES("����N����@�(�3�","wp-includes/ID3/module.audio.mp3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#��~e�����J�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��h���)UG@�x��v	","wp-admin/edit-tags.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�{#kb����ao�~");
INSERT INTO `arc1542_wfFileMods` VALUES("��(�[3?�H/�[�e]","wp-includes/js/tinymce/skins/lightgray/fonts/readme.md","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zd��+���E@�1�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�AuI.F��/���","wp-includes/js/wp-pointer.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ˋ8�.�r:ě���");
INSERT INTO `arc1542_wfFileMods` VALUES("�<{����,-�![M��","wp-includes/js/tinymce/skins/lightgray/skin.ie7.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���m_ҐsԥG");
INSERT INTO `arc1542_wfFileMods` VALUES("�@��,�n\\���+k�","wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�,s�M������Pm");
INSERT INTO `arc1542_wfFileMods` VALUES("���=V;�����N.K","wp-includes/js/wp-list-revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","GQu`�*�L��n$��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Κ,�Q�a�gl���","wp-includes/class-smtp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P�����ʄb�.");
INSERT INTO `arc1542_wfFileMods` VALUES("��dA#���*�Źo7","wp-admin/js/customize-controls.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��B�؏�f��@��.");
INSERT INTO `arc1542_wfFileMods` VALUES("��3\"�(z�a�4�8�","wp-includes/images/media/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-o��Uʓ��U�U_");
INSERT INTO `arc1542_wfFileMods` VALUES("��5��[,	j�(�ƪ�","wp-includes/js/mediaelement/controls.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$�\"�Ӭ����?�Ȥ");
INSERT INTO `arc1542_wfFileMods` VALUES("���2zs��4x�EB","wp-includes/ID3/module.tag.id3v1.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h؜�ٱal��w�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Obc��\" ���|J(","wp-includes/images/smilies/icon_evil.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c����VM<�\"!�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�1��WV(2��6����","wp-admin/images/icons32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۬[�m9��J�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("��1���|�}���dQ","wp-admin/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-s�t���?_�_J");
INSERT INTO `arc1542_wfFileMods` VALUES("��	1��А々�S:(","wp-includes/js/thickbox/loadingAnimation.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"h�c�����&�");
INSERT INTO `arc1542_wfFileMods` VALUES("�.�B�|xӳ��E�","wp-admin/css/press-this-editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P`d�L�-#wM!�_");
INSERT INTO `arc1542_wfFileMods` VALUES("�C�3�!0Q�o�J�e `","wp-includes/js/plupload/plupload.flash.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����g�}F�9�\"�~S");
INSERT INTO `arc1542_wfFileMods` VALUES("�_���jSX�2�QQ=","wp-includes/ms-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ӎ�p�?k,�H��");
INSERT INTO `arc1542_wfFileMods` VALUES("��tnR�ؔ����%^�","wp-admin/images/align-right.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B���Oe#�l@:P+\"v");
INSERT INTO `arc1542_wfFileMods` VALUES("���5�V\"�$$�_��","wp-admin/includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","؉�,\'����wKt");
INSERT INTO `arc1542_wfFileMods` VALUES("��iY����\0
R)��","wp-includes/post-thumbnail-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e�1L5R���Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("��u�X�ݼ#�-����","wp-includes/class-wp-http-ixr-client.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","tJr�P�?��bU��a");
INSERT INTO `arc1542_wfFileMods` VALUES("Ĉ^A��+l���o�d��","wp-includes/js/tinymce/skins/wordpress/images/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7~!���\0�����\"w");
INSERT INTO `arc1542_wfFileMods` VALUES("ĔԼ���pP�Z	H��","wp-includes/images/smilies/icon_cry.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E>z?��Ap�mWlA�`");
INSERT INTO `arc1542_wfFileMods` VALUES("��ʙ\0}��甠K��.�","wp-includes/js/jquery/jquery.color.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���E�G����>vJ");
INSERT INTO `arc1542_wfFileMods` VALUES("��{A��mm��*�K","wp-includes/nav-menu-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{y�E�-�2�Q�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�`#��G�b�C��֊�","wp-includes/js/swfupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y,k?�X�N�0G�;");
INSERT INTO `arc1542_wfFileMods` VALUES("��-�p�lE���k�/�","wp-includes/js/jquery/jquery.hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S!}EU�\\b�g�h��=");
INSERT INTO `arc1542_wfFileMods` VALUES("�+���g���q6�^\0�","wp-admin/images/wheel.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E0� q0m��Y%V�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("ƅ����|_�i/y��	","wp-includes/js/tinymce/plugins/media/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�/~.SM�6L�5\\");
INSERT INTO `arc1542_wfFileMods` VALUES("Ƭ+���I�d^i <\0","wp-includes/js/jquery/suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�k�7*헸Hޞ");
INSERT INTO `arc1542_wfFileMods` VALUES("ǂ-i)�.�\\���z�^a","wp-includes/Text/Diff/Engine/shell.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�Aܑ�~J�^t����");
INSERT INTO `arc1542_wfFileMods` VALUES("ǅ�9��9:����","wp-includes/cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��G�-��E���B�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ǥ>z�Ԅ��!J]>","wp-includes/css/wp-auth-check-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6&B���Kb�");
INSERT INTO `arc1542_wfFileMods` VALUES("ǫ�=��m�/���^","wp-admin/includes/schema.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��W��y�$��G��m�@");
INSERT INTO `arc1542_wfFileMods` VALUES("ǳ\\��_L-Y�Ō%$","wp-includes/ID3/module.audio.dts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lA��E��O87�$(");
INSERT INTO `arc1542_wfFileMods` VALUES("�{g��?�3gڢ�","wp-admin/images/icons32-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%�*�����g����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"u@��T��S��5�","wp-includes/images/smilies/icon_idea.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"m%h�����S��r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y$\'����o���","wp-includes/css/wp-auth-check-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Gn+��i�7���b�$");
INSERT INTO `arc1542_wfFileMods` VALUES("ȍP�� �3����
��","wp-includes/class-wp-customize-control.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ͩ�t��!rl��{~");
INSERT INTO `arc1542_wfFileMods` VALUES("�����~K4(#��","wp-admin/user/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ����ǀ[K}�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�A7�\'�C#�w�S�s�","wp-admin/css/about.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ɵ���^Xl�|��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����2D�i�e�","wp-admin/css/l10n.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�T�����=�!�T");
INSERT INTO `arc1542_wfFileMods` VALUES("�!&�i�)^�W���R�","wp-includes/js/jquery/ui/widget.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�5��~�%�]c���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�q�4P�}�5Oz�k","wp-admin/js/inline-edit-tax.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� q�8^uၓ�)?��<");
INSERT INTO `arc1542_wfFileMods` VALUES("�R���ш�޿�0","wp-admin/css/themes.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�7�Ջ�b�LI�+w�");
INSERT INTO `arc1542_wfFileMods` VALUES("�hFM<@`%q-��","wp-admin/includes/class-wp-filesystem-direct.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|h@{Q}5�c!�K0Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�xjP�����!c�x","wp-admin/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/�Q�٩̪}5,
");
INSERT INTO `arc1542_wfFileMods` VALUES("��	b���8�[����y","wp-includes/js/wp-emoji-release.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��)\'RL��N�IN�");
INSERT INTO `arc1542_wfFileMods` VALUES("�!��#��I|���F�","wp-includes/js/tinymce/plugins/directionality/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��V���ʬ� Hy�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�<��C�﮿�V:(r","wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J¾U�a��g���");
INSERT INTO `arc1542_wfFileMods` VALUES("�U<�?Y,����ػ(","wp-admin/js/svg-painter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����fu���");
INSERT INTO `arc1542_wfFileMods` VALUES("ˍ�G䯀oe���o�","wp-includes/js/shortcode.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� z�>1���J�92�");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�E,�-O�{���","wp-includes/link-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\\�\\�i�/�:��I");
INSERT INTO `arc1542_wfFileMods` VALUES("�!�LT�3��i��x�","wp-admin/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�w�C�!_H�;D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�M�Tq&[?��>칊�
","wp-admin/css/colors/ectoplasm/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q�9+�\"��+��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V�ڮ����M��jӁ","wp-includes/js/plupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u&
�TI�z����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ê5ff�;,G!\'��\'-","wp-admin/css/colors/ocean/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Oe����\"&�����~");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǌ�E�v�c,�صyS^","wp-includes/images/crystal/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]�Lc�iG�fQ���");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�j֛`��w","wp-admin/css/customize-controls-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'���-��k��;!�");
INSERT INTO `arc1542_wfFileMods` VALUES("�d���lP�O��I�","wp-admin/network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��9�{e�,Yj��
");
INSERT INTO `arc1542_wfFileMods` VALUES("�w�9=�_\"h%��v","wp-admin/css/install-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��CM:�������");
INSERT INTO `arc1542_wfFileMods` VALUES("͓�Y�36��l�Y��","wp-includes/js/tinymce/plugins/textcolor/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��
�������}�W0�");
INSERT INTO `arc1542_wfFileMods` VALUES("ͽ3��=��O�G�|~�","wp-includes/SimplePie/Credit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M猋*>
�|");
INSERT INTO `arc1542_wfFileMods` VALUES("����j(g��~jU#��","wp-admin/includes/class-wp-filesystem-ssh2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=酅�c�o��<�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�_)-�]�ˌkO	���","wp-includes/ID3/module.tag.apetag.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7��l,�iwF�Q�ql");
INSERT INTO `arc1542_wfFileMods` VALUES("�œ���ϔ�=��#6","wp-admin/images/post-formats32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WY~�O��{�+_L�kE;");
INSERT INTO `arc1542_wfFileMods` VALUES("�-�+�e���m�u\"��x","wp-admin/css/colors/sunrise/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E6G�QSU�E�a�B�8");
INSERT INTO `arc1542_wfFileMods` VALUES("�uF��^G��E+��c","wp-admin/network/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�O~+�~�1");
INSERT INTO `arc1542_wfFileMods` VALUES("π�tGȩ�����D","wp-includes/js/tinymce/plugins/image/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�r�J\0�3��\\�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("ϊ=��X���bBz\' �","wp-includes/js/jquery/ui/effect-explode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`YU����Q}X�Q�0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����HԹ��f�k�","wp-includes/js/tinymce/wp-tinymce.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b
��0pr���Hv");
INSERT INTO `arc1542_wfFileMods` VALUES("�ݙ�P(���O\'E��e","wp-includes/js/jquery/ui/effect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A֢�pi��u+`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�鋭��{^�MU*�_","wp-includes/js/twemoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��37�[:.i Ĵ|t�");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�s�l�WD7�M�","wp-includes/bookmark-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���!m<������O4");
INSERT INTO `arc1542_wfFileMods` VALUES("Т�펹�|����@","wp-includes/images/smilies/icon_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ʵ	�������(");
INSERT INTO `arc1542_wfFileMods` VALUES("��^�\\�X�PvS�\\�{","wp-admin/js/media-upload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_f����b�f��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("�/��0��
*7�f(��","wp-includes/js/wp-a11y.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�9s�%o����V<4");
INSERT INTO `arc1542_wfFileMods` VALUES("�_\\c9mL�v��1���","wp-includes/compat.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ڲ@;h_�yu]�H���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Jh|��0�`Zp�E","wp-admin/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fϧ=�iw�U���x�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҟ����ǟ�	Ks���","wp-includes/images/icon-pointer-flag-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�b��&�Z�r");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҫ*���H���
;t��","wp-admin/includes/ajax-actions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&,s$y$E?��$u�");
INSERT INTO `arc1542_wfFileMods` VALUES("ҲE5|�ѵ�C�d闼","wp-admin/options-reading.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V�qu��}��-.�Ja");
INSERT INTO `arc1542_wfFileMods` VALUES("��Lt593�u^���)��","wp-admin/images/comment-grey-bubble-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TY�ŝ2�s,�m��");
INSERT INTO `arc1542_wfFileMods` VALUES("�E#l��L��_&ܪ���","wp-admin/images/arrows.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�v�$�>����>�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�{ڭd3T�Xy����7;","wp-includes/css/admin-bar-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֥]��_C?��+]�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�].�oo�ȦM-n	�","wp-admin/images/align-none-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XC�)[���-�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ȇp���]4��L��q�","wp-includes/css/admin-bar.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U(X,�3tB��_");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��S��`�]T]D�","wp-includes/css/dashicons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}\0�c���\'ޒà�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X��$�a��B��^","wp-admin/js/user-suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T\\���\\|��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("����ͤ6�\0/��k���","wp-includes/js/imgareaselect/jquery.imgareaselect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\00ԺLB�wm#��wu�:");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z��	r!ޏf���	�","wp-includes/images/icon-pointer-flag.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,���E^�j`\'");
INSERT INTO `arc1542_wfFileMods` VALUES("�oҨ*K��o�7{� <","wp-includes/ID3/module.audio-video.matroska.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�!�Z0zDj&Cp�");
INSERT INTO `arc1542_wfFileMods` VALUES("�rY�S�xwDY˚J�[","wp-includes/images/media/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R׬˂���ôŉh�H");
INSERT INTO `arc1542_wfFileMods` VALUES("ֶ��9؞f�po3t","wp-includes/class-wp-admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","YS�y�Ρ����Q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Gȩ��6����\0Y","wp-admin/includes/class-wp-posts-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��La��FH[��a\'��");
INSERT INTO `arc1542_wfFileMods` VALUES("מ�y�7mE5���O_�","wp-admin/js/media.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".���$!&��^$�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("��j0���w�E}®R�","wp-admin/css/wp-admin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"]��Z���ӕ)g�&�");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�I:wm�\'~K-","wp-includes/ID3/module.audio-video.riff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TfbpGO�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�Zh�$�Éo�","wp-includes/class-json.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�SA���̈́���%");
INSERT INTO `arc1542_wfFileMods` VALUES("�8/B��$8���`m�","wp-includes/js/imgareaselect/jquery.imgareaselect.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U���K(t���0���");
INSERT INTO `arc1542_wfFileMods` VALUES("�A�h)I�]Gr���E","wp-admin/includes/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ޱ�wCrݩA�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�M&�3��3CMaQ{","wp-admin/images/yes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�+��7܉�qZ�Qk");
INSERT INTO `arc1542_wfFileMods` VALUES("�o�ǣ�	ף�f0�Y","wp-includes/SimplePie/Core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���#���������");
INSERT INTO `arc1542_wfFileMods` VALUES("�v�������&X��","wp-includes/js/jquery/ui/selectable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q�\"�{�B�M���");
INSERT INTO `arc1542_wfFileMods` VALUES("�,(�i7:^�^�#","wp-includes/js/tinymce/plugins/paste/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)>�|�K*bH�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k��/y�����&��G","wp-includes/images/rss-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ya[�Q�����rj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��!}�=�`*�gZ=","wp-admin/network/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����y|��C");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�~�!�g�q��","wp-includes/js/tinymce/skins/lightgray/skin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�uw*S������-�]");
INSERT INTO `arc1542_wfFileMods` VALUES("��w�=Ţ�O�&�F�","wp-admin/css/colors/midnight/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&܍���|DW��!E�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�|�#�԰#�{�����","wp-admin/js/link.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��0�;���3�%-");
INSERT INTO `arc1542_wfFileMods` VALUES("��!�(t��<Թ","wp-includes/js/heartbeat.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� �	�1�]�d*D�G");
INSERT INTO `arc1542_wfFileMods` VALUES("��_�JL�#�@B��","wp-admin/css/colors/midnight/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H�]�Q�T�kܤc");
INSERT INTO `arc1542_wfFileMods` VALUES("� �I�_X�����?","wp-admin/js/gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o����m���dOo");
INSERT INTO `arc1542_wfFileMods` VALUES("۪���	.�ո�\\���","wp-includes/js/tinymce/skins/wordpress/wp-content.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ٞ�R��F1oj�3�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("��r�����؁=�Ԓ�","wp-includes/images/rss.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�(�.��*NZ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��
p���Gnu:���","wp-includes/js/colorpicker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��V g�����-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȼ�؟�\'`����","wp-includes/feed-rdf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<C���H�,D\'��7i");
INSERT INTO `arc1542_wfFileMods` VALUES("�2G�?�_��\\���-B","wp-includes/canonical.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<!
�4?ζ6�O�Q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�F|
�MN,8�ݪ�\'�","wp-admin/css/press-this.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܡ�����{�d�>S");
INSERT INTO `arc1542_wfFileMods` VALUES("��ջZml��4�ˮU","wp-includes/images/smilies/simple-smile.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K��{��f�w�h");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0FJ��B��e�","wp-login.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Q�S��Y���st�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J0����j�Yg�h�","wp-includes/js/tinymce/plugins/lists/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��1�����I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�[6�5��+�	�n9�","wp-admin/images/sort.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�ˍ���lHj�]");
INSERT INTO `arc1542_wfFileMods` VALUES("�f��y���ħ�*!","wp-admin/js/nav-menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�������.g;u��+#");
INSERT INTO `arc1542_wfFileMods` VALUES("�3^��PM�Y���H�D�","wp-includes/js/tinymce/skins/wordpress/images/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�¶��B�=z��3j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�N�\\�|�`*�,)@4","wp-includes/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'g!�:�H��),�","wp-includes/SimplePie/XML/Declaration/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���p(Å��B��s#b");
INSERT INTO `arc1542_wfFileMods` VALUES("����\"�����c)j�\"","wp-includes/js/wplink.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Μ�^g�o]Dq�`JMi");
INSERT INTO `arc1542_wfFileMods` VALUES("�q����%ű� m+","wp-admin/css/colors/light/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʘ_�
JT�¹���J");
INSERT INTO `arc1542_wfFileMods` VALUES("ߌ��(������2���","wp-includes/js/quicktags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z\0�j��7%�� 4");
INSERT INTO `arc1542_wfFileMods` VALUES("ߗ�Q��u�!ٶx�[","wp-includes/js/wpdialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���\0�g�Fġ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%�f\\+,���\0\\Y","wp-admin/includes/class-wp-filesystem-base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=>q��$����_�p");
INSERT INTO `arc1542_wfFileMods` VALUES("��^��bR��SI�!�?","wp-includes/class-wp-image-editor-imagick.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��,h2�԰�ڙ�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z���(>(�1bޫ�Z�","wp-includes/js/tinymce/skins/lightgray/content.inline.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[Θ|.zlˏ.�}լ");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�@/��ꦑٞ-M�","wp-admin/network/site-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ڄ\"�\'��.���");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\9ã>���Iz4�c","wp-includes/js/tinymce/plugins/hr/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��<�<{LU798�ۆ");
INSERT INTO `arc1542_wfFileMods` VALUES("�L�>�ٟ�#{6p}Y��","wp-admin/options-writing.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��H��J1dk����");
INSERT INTO `arc1542_wfFileMods` VALUES("��ĸ:�,p�1��Hr","wp-admin/js/dashboard.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܯOh|lR<���QR4��");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��וoxi3%+]kg","wp-admin/images/post-formats.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���\0���%3���");
INSERT INTO `arc1542_wfFileMods` VALUES("�0�;�-,�A�Ey�","wp-includes/theme-compat/sidebar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">���\"}Wuo���.H");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�Oj\'�ŻD*ցV4","wp-cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����hc�����p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��q�82��v�&#M","wp-includes/js/tinymce/plugins/wpview/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q������Xv�r&�`");
INSERT INTO `arc1542_wfFileMods` VALUES("���<kUJv%��1��","wp-includes/fonts/dashicons.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ez{�C7|�2�");
INSERT INTO `arc1542_wfFileMods` VALUES("�w����V���!�","wp-admin/includes/class-wp-ms-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����&��ʠ��|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("����zpKC�{\\>��","wp-admin/js/dashboard.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9�sE�/�<S�(�ş�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\00��q�ĊNy)��","wp-includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�#���i�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��5?�- S�^H��","wp-admin/js/editor-expand.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\0�2���=��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��b\\��ɍ���","wp-admin/edit-form-advanced.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:���?�k�b6;��");
INSERT INTO `arc1542_wfFileMods` VALUES("�G��5�@����07��","wp-includes/images/blank.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H�+��51	��f]��9");
INSERT INTO `arc1542_wfFileMods` VALUES("��W���\"���Sk:�","wp-admin/images/align-center-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���-�r�5*J7�If");
INSERT INTO `arc1542_wfFileMods` VALUES("�⣣�M�O����U�","wp-admin/js/editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Aı��P��������");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"�ơ���7vs+�","wp-admin/includes/class-pclzip.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","67(�C���ki��8�");
INSERT INTO `arc1542_wfFileMods` VALUES("�b`K�\'��컜���K","wp-includes/functions.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x?!�bc�Q��*B36n");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��ёe�Xd��$�","wp-includes/class-wp-customize-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","p�Ryǣ�K���9�ͯ");
INSERT INTO `arc1542_wfFileMods` VALUES("�l�XNEM�CgVsA:","wp-includes/js/swfupload/plugins/swfupload.queue.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�SR/�J��5�-v͏");
INSERT INTO `arc1542_wfFileMods` VALUES("���K�g���o#�0","wp-activate.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pUȪ�N�ੌ�{eG�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ŉ�	i����/Э","wp-includes/formatting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��wSY�N�ڢ*�֗");
INSERT INTO `arc1542_wfFileMods` VALUES("��H���l��{!D#�!","wp-admin/js/color-picker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}\"[}����P-�)");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�ZY��C8��3E","wp-admin/css/colors/blue/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ѱ�^pJ��G�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�%y�>}H�o���(6","wp-includes/js/jquery/ui/core.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," Ms����a���{");
INSERT INTO `arc1542_wfFileMods` VALUES("�f�i�`�=@T��o�","wp-admin/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES("�J���y��0m�`�/","wp-includes/class-IXR.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n�V�8��0�P\"yP_");
INSERT INTO `arc1542_wfFileMods` VALUES("�F�j!Y�{.J=,��","wp-admin/images/stars.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[����><�k�{��(�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�W/>�}<8� VF�","wp-admin/includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/��k�Tb�Kx�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�^.�jT}�<��I��","wp-admin/js/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ϡ�M\0���GÁ]��");
INSERT INTO `arc1542_wfFileMods` VALUES("�\' ��#s��߾U|","wp-includes/js/mediaelement/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�&��B\"o�!e���");
INSERT INTO `arc1542_wfFileMods` VALUES("頻�yN<���9�o<","wp-admin/js/xfn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�\'�(�.�J9^");
INSERT INTO `arc1542_wfFileMods` VALUES("��m�Mt���W�B","wp-admin/images/align-left.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�y0��d�Z�o.h��");
INSERT INTO `arc1542_wfFileMods` VALUES("����t���Z�O\'� 
","wp-includes/js/thickbox/macFFBgHack.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȱg�W�,/u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����V,E@�X���y","wp-includes/SimplePie/Cache/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=�@��B[	S�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4���2�)A.;4�","wp-includes/js/customize-preview.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","C2������,ھ");
INSERT INTO `arc1542_wfFileMods` VALUES("ꍥ��2jEbg؈W�x�","wp-includes/css/editor-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�o��\"�K��PzJ��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǉ���4˓T`�k","wp-includes/js/wp-pointer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6��|dMpX\0��fɐ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0���R�J�{y�ˣ��","wp-includes/general-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�G;Y=.����T1!");
INSERT INTO `arc1542_wfFileMods` VALUES("�F �8�+�)��r�P�","wp-admin/images/no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k�d�$��ܟV7���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Oӿ�;�=\\J�zy","wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)F.jT&����I�O");
INSERT INTO `arc1542_wfFileMods` VALUES("뭷�!z}ML�K�E","wp-includes/ms-files.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�yï�<�r �L�F|");
INSERT INTO `arc1542_wfFileMods` VALUES("��Sڰp��GMǯ�l�","wp-includes/css/media-views.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[52*�6���V�");
INSERT INTO `arc1542_wfFileMods` VALUES("��vA�ds�����K�]","wp-admin/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!hLy�:��\"E��");
INSERT INTO `arc1542_wfFileMods` VALUES("��YC��o�oR�亞�","wp-includes/capabilities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���+�!��L�	�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�ڧ��s}��ն�Ni","wp-includes/class-phpmailer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","BqO7W��vai4c");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�����h�����;","wp-includes/js/quicktags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��:<���T��ʭ");
INSERT INTO `arc1542_wfFileMods` VALUES("�Dh}�����!
","wp-includes/js/jquery/ui/effect-drop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W�V��ǥ�Y��F2��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Pط��悇̺ƴ$@�","wp-includes/SimplePie/HTTP/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W%���4�6���6	");
INSERT INTO `arc1542_wfFileMods` VALUES("��c��.D�r� |��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R����Z�?f.��8��	");
INSERT INTO `arc1542_wfFileMods` VALUES("츃�v��6��;�~�","wp-includes/js/tinymce/utils/mctabs.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x$��
d��,�P��");
INSERT INTO `arc1542_wfFileMods` VALUES("��-x�(�E�oI�=�","wp-includes/class-wp-customize-section.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!������	�pP~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]��@�
��>ĺ�Yn","wp-admin/admin-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"�l�E�)�E�A");
INSERT INTO `arc1542_wfFileMods` VALUES("��QR\"��@3��v�S","wp-admin/js/link.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��5ϳt�{��z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a�]]�A��\'h���","wp-admin/network/settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Y����{D=l�e");
INSERT INTO `arc1542_wfFileMods` VALUES("����=��c�ه���","wp-admin/includes/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����裡 �����zh");
INSERT INTO `arc1542_wfFileMods` VALUES("���eC����Di!��","wp-admin/css/colors/coffee/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�yb)�O�](�a�r��z");
INSERT INTO `arc1542_wfFileMods` VALUES("���f�%u�P���","wp-includes/js/mce-view.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O���p�?v�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("�D=Jǅ/	6ރa�","wp-includes/js/swfupload/plugins/swfupload.cookies.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~�ڈ�k\\ 7̴��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y^~5~��p�G-���","wp-includes/js/customize-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��%cݹ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�z�������|�z�xv","wp-includes/js/jquery/ui/droppable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\"q�H�d����~A�P");
INSERT INTO `arc1542_wfFileMods` VALUES("���P��a`Xu","wp-admin/css/color-picker-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[��q4G։��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��X=U�pfp���Z","wp-includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/���ِ��9J1");
INSERT INTO `arc1542_wfFileMods` VALUES("�㯩�	\'��ި��V","wp-includes/images/smilies/icon_biggrin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�YpR�+�0}k�N{�k");
INSERT INTO `arc1542_wfFileMods` VALUES("����9��r�Mԧ��","wp-includes/js/customize-preview-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q~���6�a���");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�ī�I�^��3���","wp-admin/menu-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w\"\0R�|YrI��ׂR�");
INSERT INTO `arc1542_wfFileMods` VALUES("�з&�L۽¨��VN�","wp-includes/css/buttons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I@�3�#������");
INSERT INTO `arc1542_wfFileMods` VALUES("�������6$[���O�","wp-admin/css/customize-widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�?�!�`���j��x");
INSERT INTO `arc1542_wfFileMods` VALUES("���rp.u�3zx�","wp-admin/includes/class-ftp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2V�u�\\I�L��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7s�\\]�}�AA�we1�","wp-admin/tools.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�8�.�g���_\\+U");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z/���{Lt�ծF$�","wp-admin/js/svg-painter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����/�|ĩ���z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?��E_�)�xڅ$��","wp-admin/includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f[A���˷xg�K");
INSERT INTO `arc1542_wfFileMods` VALUES("�po���X0%������","wp-includes/css/editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u�]X)�*��﬋��");
INSERT INTO `arc1542_wfFileMods` VALUES("��M�٦M�/`�","wp-includes/js/swfupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Oۅ��߲�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("򱠭��B�R�z��Y","wp-includes/js/jquery/jquery.table-hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�go����~i�I	�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?{o_���\'�n�","wp-admin/images/resize-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e?�&h.��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("���_f $�O<o","wp-admin/js/common.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ӣ�؆p���KoR?g�(");
INSERT INTO `arc1542_wfFileMods` VALUES("��%�\0��z�f�N�pS","wp-includes/js/tinymce/plugins/wpemoji/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y2\0׳���<�r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#\\���/�vXR","wp-admin/js/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��b���
]]��\"0");
INSERT INTO `arc1542_wfFileMods` VALUES("�lF����c뒕�L���","wp-admin/js/iris.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�5`�@Ħ�Ue߰�");
INSERT INTO `arc1542_wfFileMods` VALUES("��V��k9۴�s���ֿ","wp-admin/css/customize-controls-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]����m�`$�M");
INSERT INTO `arc1542_wfFileMods` VALUES("���;�^𩸴8c�","wp-includes/css/buttons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1R�1��!��\\=P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J\'#��rN�0a�","wp-includes/images/crystal/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�nV�:�ω�G��-#k");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y��R�Yi/��l@HX�","wp-includes/js/media-grid.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�R�G�zpȟ�n��K");
INSERT INTO `arc1542_wfFileMods` VALUES("��j�8���ď����","wp-includes/js/wp-backbone.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���S��Y�|�פ�j)p");
INSERT INTO `arc1542_wfFileMods` VALUES("�-\"D��ʹD�5a�/","wp-includes/cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b�.*�r�T:~�t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�A4e���{�^����Z","wp-includes/js/wpdialog.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r�9_�M@9\0�S�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�u�N���.A_�_�","wp-includes/js/media-editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ��w��\"Wl���c6");
INSERT INTO `arc1542_wfFileMods` VALUES("������>+ܞL[�m","wp-includes/js/tinymce/skins/lightgray/img/anchor.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a5q��ȑ_4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("����(���%�#�9yn","wp-admin/css/forms.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������Eoa��)&��I");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y��\0�\"��Q","wp-admin/user/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)��»�g��E�p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~������r�C��","wp-admin/link-parse-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Dm����䁐�f�8��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V9��K���goX��7�","wp-admin/images/align-left-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","i�8�O�����^��c");
INSERT INTO `arc1542_wfFileMods` VALUES("������H�S!;� �","wp-admin/js/user-profile.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","j@#�wP<Pw��2�");
INSERT INTO `arc1542_wfFileMods` VALUES("���+���q�pW��","wp-includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_�W�\\F�D�$�,0");
INSERT INTO `arc1542_wfFileMods` VALUES("���`�&X<�aQ�Vh\\","wp-admin/user/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0yݤ�&-");
INSERT INTO `arc1542_wfFileMods` VALUES("����Pq-�t�@l�","wp-includes/images/wlw/wp-icon.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1	�ʚ�7w3K��*");
INSERT INTO `arc1542_wfFileMods` VALUES("� @�;��*��|��","wp-includes/Text/Diff/Engine/string.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^��x@�R�ƙ=���");
INSERT INTO `arc1542_wfFileMods` VALUES("�@���sB0<�{l�3��","wp-includes/wlwmanifest.xml","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ԑ����i�^��");
INSERT INTO `arc1542_wfFileMods` VALUES("�k����e<F��4","wp-admin/js/revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2S�l��R;�]2�Lj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��6K1���(���}/AX","wp-admin/network/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6�\'G��g$�");
INSERT INTO `arc1542_wfFileMods` VALUES("��H�Mz�@�A��","wp-admin/css/press-this-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","+(y�*�@���p���");
INSERT INTO `arc1542_wfFileMods` VALUES("��ɱ%��a{Z�j	%�","wp-includes/class-wp-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�;~^$���w�");
INSERT INTO `arc1542_wfFileMods` VALUES("����I�:4P�U���","wp-includes/SimplePie/Cache/Memcache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��JU���1SQ��?�");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�l4[���e���","wp-admin/js/inline-edit-tax.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J����`$?\0=>�G���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��=��*�d��n�","wp-admin/includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�RI\"��u�}��[da");
INSERT INTO `arc1542_wfFileMods` VALUES("�.ն���Zg{�=��","wp-admin/css/customize-controls.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J�|`����(���4");
INSERT INTO `arc1542_wfFileMods` VALUES("���~��a%��!�P","wp-includes/js/tinymce/skins/wordpress/images/pagebreak-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�6�#UQ:��|>#��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����L?@��.~O�","wp-admin/css/colors/midnight/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s���^�r\'\'8��n�I");
INSERT INTO `arc1542_wfFileMods` VALUES("����T
����e.(��","wp-includes/class-wp-image-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:T��Xd�L��ܕg");
INSERT INTO `arc1542_wfFileMods` VALUES("��}���PÛ�P\\�","wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL��	�gS\'����i");
INSERT INTO `arc1542_wfFileMods` VALUES("��R�,�A����GJ\'-","wp-includes/default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",}�\'�!��J�v�");
INSERT INTO `arc1542_wfFileMods` VALUES("���
\\��ɶ.5���","wp-includes/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("�D����]�|߼�$�","wp-includes/js/mediaelement/wp-mediaelement.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8؟\"{�պ��u�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ph�����rV�","wp-admin/css/revisions-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2����.�ĕx`x�a*");
INSERT INTO `arc1542_wfFileMods` VALUES("�\'������}����0","wp-includes/js/tinymce/wp-tinymce.js.gz","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}���M��3/��m\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�])��	���{�?R}","wp-includes/feed-rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�kY���>�]DtH/");
INSERT INTO `arc1542_wfFileMods` VALUES("�0<Ps��מH���22","wp-includes/js/jquery/jquery.table-hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��֔#t�gP�g��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9(F�Rj2�n6]��","wp-admin/css/colors/light/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Cxڄx43�*Cn��/y");
INSERT INTO `arc1542_wfFileMods` VALUES("�g�\"�}_�7����J5","wp-includes/js/jcrop/jquery.Jcrop.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V̞��/K�x����");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��9�6è�R�","wp-admin/css/common.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iB���D�&�8Y���");
INSERT INTO `arc1542_wfFileMods` VALUES("�����ƪq�悳��","wp-includes/js/tinymce/plugins/paste/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�BU@��8�<ba");
INSERT INTO `arc1542_wfFileMods` VALUES("��<l�a��,�bX,��","wp-admin/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("�G���!#h�9	��&","wp-includes/js/tinymce/plugins/wordpress/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6B���û�yם");
INSERT INTO `arc1542_wfFileMods` VALUES("���\'�B���7S�","wp-includes/js/zxcvbn-async.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0�V]u#3");
INSERT INTO `arc1542_wfFileMods` VALUES("������)�(��<��","wp-includes/js/json2.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�A��`� �ȡ�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a��\'@T瑓����","wp-admin/images/date-button.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��I��V�ď�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����)z]!?��a�","wp-admin/images/media-button-video.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������r�x�4Q���");
INSERT INTO `arc1542_wfFileMods` VALUES("�I\"�p��t�Q��[Z6x","wp-includes/css/admin-bar.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mk�x�Hk�1q�W�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c��wk�(���4�3�","wp-admin/includes/list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����T8��>��_߂");
INSERT INTO `arc1542_wfFileMods` VALUES("�Qֿ6��yq�88","wp-includes/theme-compat/footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ~C~�M������=");
INSERT INTO `arc1542_wfFileMods` VALUES("���w��\'�6)","wp-includes/rss-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","g�����l]�4j0l=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�L����e5x?e=�&","wp-includes/js/plupload/wp-plupload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�y�,lf@�@");
INSERT INTO `arc1542_wfFileMods` VALUES("��a5[4�5�Me�pC","wp-includes/js/jquery/ui/effect-bounce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ؖ�0TQ�5����S");
INSERT INTO `arc1542_wfFileMods` VALUES("���T����Ç=w���","wp-admin/js/bookmarklet.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y��ἿvoFg\"��k");
INSERT INTO `arc1542_wfFileMods` VALUES("��S�CRC��l��","wp-admin/css/colors/sunrise/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V���z�	h���=�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k��i��.���\\��","wp-includes/images/smilies/icon_neutral.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������	����Z�");


DROP TABLE IF EXISTS `arc1542_wfHits`;

CREATE TABLE `arc1542_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `is404` tinyint(4) NOT NULL,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfHoover`;

CREATE TABLE `arc1542_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` binary(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfIssues`;

CREATE TABLE `arc1542_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfIssues` VALUES("1","1437026049","new","wfPluginUpgrade","1","106719a1dd449e2636475e907c5f49da","106719a1dd449e2636475e907c5f49da","The Plugin \"Akismet\" needs an upgrade.","You need to upgrade \"Akismet\" to the newest version to ensure you have any security fixes the developer has released.","a:13:{s:4:\"Name\";s:7:\"Akismet\";s:9:\"PluginURI\";s:19:\"http://akismet.com/\";s:7:\"Version\";s:5:\"3.1.2\";s:11:\"Description\";s:516:\"Used by millions, Akismet is quite possibly the best way in the world to <strong>protect your blog from comment and trackback spam</strong>. It keeps your site protected from spam even while you sleep. To get started: 1) Click the &#8220;Activate&#8221; link to the left of this description, 2) <a href=\"http://akismet.com/get/\">Sign up for an Akismet API key</a>, and 3) Go to your Akismet configuration page, and save your API key. <cite>By <a href=\"http://automattic.com/wordpress-plugins/\">Automattic</a>.</cite>\";s:6:\"Author\";s:65:\"<a href=\"http://automattic.com/wordpress-plugins/\">Automattic</a>\";s:9:\"AuthorURI\";s:40:\"http://automattic.com/wordpress-plugins/\";s:10:\"TextDomain\";s:7:\"akismet\";s:10:\"DomainPath\";s:0:\"\";s:7:\"Network\";b:0;s:5:\"Title\";s:41:\"<a href=\"http://akismet.com/\">Akismet</a>\";s:10:\"AuthorName\";s:10:\"Automattic\";s:10:\"pluginFile\";s:64:\"/Users/ahayter/Sites/test/arc-assets/plugins/akismet/akismet.php\";s:10:\"newVersion\";s:5:\"3.1.3\";}");
INSERT INTO `arc1542_wfIssues` VALUES("2","1437026049","new","wfPluginUpgrade","1","52388f270b5efc2b6d97a713c9ba5aca","52388f270b5efc2b6d97a713c9ba5aca","The Plugin \"iThemes Security\" needs an upgrade.","You need to upgrade \"iThemes Security\" to the newest version to ensure you have any security fixes the developer has released.","a:13:{s:4:\"Name\";s:16:\"iThemes Security\";s:9:\"PluginURI\";s:28:\"https://ithemes.com/security\";s:7:\"Version\";s:6:\"4.6.13\";s:11:\"Description\";s:239:\"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting attack attempts and more. <cite>By <a href=\"https://ithemes.com\">iThemes.com</a>.</cite>\";s:6:\"Author\";s:45:\"<a href=\"https://ithemes.com\">iThemes.com</a>\";s:9:\"AuthorURI\";s:19:\"https://ithemes.com\";s:10:\"TextDomain\";s:26:\"it-l10n-better-wp-security\";s:10:\"DomainPath\";s:10:\"/languages\";s:7:\"Network\";b:1;s:5:\"Title\";s:59:\"<a href=\"https://ithemes.com/security\">iThemes Security</a>\";s:10:\"AuthorName\";s:11:\"iThemes.com\";s:10:\"pluginFile\";s:86:\"/Users/ahayter/Sites/test/arc-assets/plugins/better-wp-security/better-wp-security.php\";s:10:\"newVersion\";s:5:\"4.8.0\";}");
INSERT INTO `arc1542_wfIssues` VALUES("3","1437026049","new","wfPluginUpgrade","1","ff13dfaaceee016ccb5c2953dc03880b","ff13dfaaceee016ccb5c2953dc03880b","The Plugin \"Wordfence Security\" needs an upgrade.","You need to upgrade \"Wordfence Security\" to the newest version to ensure you have any security fixes the developer has released.","a:13:{s:4:\"Name\";s:18:\"Wordfence Security\";s:9:\"PluginURI\";s:25:\"http://www.wordfence.com/\";s:7:\"Version\";s:5:\"6.0.6\";s:11:\"Description\";s:135:\"Wordfence Security &#8211; Anti-virus, Firewall and High Speed Cache <cite>By <a href=\"http://www.wordfence.com/\">Wordfence</a>.</cite>\";s:6:\"Author\";s:49:\"<a href=\"http://www.wordfence.com/\">Wordfence</a>\";s:9:\"AuthorURI\";s:25:\"http://www.wordfence.com/\";s:10:\"TextDomain\";s:0:\"\";s:10:\"DomainPath\";s:0:\"\";s:7:\"Network\";b:0;s:5:\"Title\";s:58:\"<a href=\"http://www.wordfence.com/\">Wordfence Security</a>\";s:10:\"AuthorName\";s:9:\"Wordfence\";s:10:\"pluginFile\";s:68:\"/Users/ahayter/Sites/test/arc-assets/plugins/wordfence/wordfence.php\";s:10:\"newVersion\";s:6:\"6.0.11\";}");


DROP TABLE IF EXISTS `arc1542_wfLeechers`;

CREATE TABLE `arc1542_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfLockedOut`;

CREATE TABLE `arc1542_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfLocs`;

CREATE TABLE `arc1542_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfLocs` VALUES("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1437026047","1","","","","","0.0000000","0.0000000");


DROP TABLE IF EXISTS `arc1542_wfLogins`;

CREATE TABLE `arc1542_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfLogins` VALUES("1","1437026046.617100","0","loginOK","ahayter","2","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.134 Safari/537.36");


DROP TABLE IF EXISTS `arc1542_wfNet404s`;

CREATE TABLE `arc1542_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfReverseCache`;

CREATE TABLE `arc1542_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `arc1542_wfReverseCache` VALUES("\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","localhost","1437026046");


DROP TABLE IF EXISTS `arc1542_wfScanners`;

CREATE TABLE `arc1542_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfStatus`;

CREATE TABLE `arc1542_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfStatus` VALUES("1","1434399538.055669","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("2","1434399538.059547","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("3","1434399540.061248","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("4","1434399542.064531","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("5","1434399544.068995","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("6","1434399546.073104","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("7","1434399546.076709","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("8","1434399547.096744","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("9","1434399547.101950","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("10","1434399547.103554","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("11","1434399547.105148","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("12","1434399547.108786","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("13","1434399549.944095","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("14","1434399549.948542","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("15","1434399554.640653","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("16","1434399554.644697","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("17","1434399554.645044","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("18","1434399554.645342","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("19","1434399554.647089","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("20","1434399555.746919","2","info","Analyzed 100 files containing 1.1 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("21","1434399555.941838","2","info","Analyzed 200 files containing 2.25 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("22","1434399556.219059","2","info","Analyzed 300 files containing 4.41 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("23","1434399556.371454","2","info","Analyzed 400 files containing 5.03 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("24","1434399556.568863","2","info","Analyzed 500 files containing 6.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("25","1434399556.822304","2","info","Analyzed 600 files containing 9.75 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("26","1434399556.935451","2","info","Analyzed 700 files containing 10.05 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("27","1434399557.110897","2","info","Analyzed 800 files containing 11.57 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("28","1434399557.259347","2","info","Analyzed 900 files containing 12.63 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("29","1434399557.482302","2","info","Analyzed 1000 files containing 15.47 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("30","1434399557.492406","2","info","Analyzed 1007 files containing 15.56 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("31","1434399557.493069","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("32","1434399557.494961","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("33","1434399557.516416","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("34","1434399557.518823","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("35","1434399557.623882","2","error","Scan terminated with error: There was an error connecting to the the Wordfence scanning servers: Failed to connect to noc1.wordfence.com port 443: Connection refused");
INSERT INTO `arc1542_wfStatus` VALUES("36","1434399557.624289","10","info","SUM_KILLED:Previous scan terminated with an error. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("37","1437026033.654710","1","info","Scheduled Wordfence scan starting at Thursday 16th of July 2015 01:53:53 AM");
INSERT INTO `arc1542_wfStatus` VALUES("38","1437026034.563137","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("39","1437026034.568249","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("40","1437026036.570460","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("41","1437026038.574119","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("42","1437026040.581354","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("43","1437026041.172146","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("44","1437026041.176124","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("45","1437026041.606124","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("46","1437026041.612177","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("47","1437026041.614592","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("48","1437026041.616585","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("49","1437026041.628367","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("50","1437026042.263976","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("51","1437026042.267244","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("52","1437026043.176870","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("53","1437026043.182201","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("54","1437026043.182659","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("55","1437026043.183025","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("56","1437026043.184780","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("57","1437026043.555045","2","info","Analyzed 100 files containing 8.65 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("58","1437026043.693428","2","info","Analyzed 200 files containing 9.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("59","1437026043.901311","2","info","Analyzed 300 files containing 11.98 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("60","1437026044.037007","2","info","Analyzed 400 files containing 12.58 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("61","1437026044.253772","2","info","Analyzed 500 files containing 14.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("62","1437026044.525427","2","info","Analyzed 600 files containing 17.3 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("63","1437026044.659289","2","info","Analyzed 700 files containing 17.62 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("64","1437026044.838869","2","info","Analyzed 800 files containing 19.14 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("65","1437026045.043948","2","info","Analyzed 900 files containing 20.2 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("66","1437026045.332099","2","info","Analyzed 1000 files containing 23.04 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("67","1437026045.351588","2","info","Analyzed 1008 files containing 23.13 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("68","1437026045.352340","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("69","1437026045.354147","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("70","1437026045.373559","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("71","1437026045.375937","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("72","1437026045.812382","2","info","Starting scan of file contents");
INSERT INTO `arc1542_wfStatus` VALUES("73","1437026046.858738","2","info","Scanned contents of 1 additional files at 0.96 per second");
INSERT INTO `arc1542_wfStatus` VALUES("74","1437026046.875259","2","info","Scanned contents of 4 additional files at 3.77 per second");
INSERT INTO `arc1542_wfStatus` VALUES("75","1437026046.875813","2","info","Asking Wordfence to check URL\'s against malware list.");
INSERT INTO `arc1542_wfStatus` VALUES("76","1437026046.876607","2","info","Checking 3 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("77","1437026047.293976","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("78","1437026047.295815","2","info","Done file contents scan");
INSERT INTO `arc1542_wfStatus` VALUES("79","1437026047.296621","10","info","SUM_ENDOK:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("80","1437026047.298471","10","info","SUM_ENDOK:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("81","1437026047.301768","10","info","SUM_START:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("82","1437026047.733355","2","info","Starting scan of database");
INSERT INTO `arc1542_wfStatus` VALUES("83","1437026048.743311","2","info","Done database scan");
INSERT INTO `arc1542_wfStatus` VALUES("84","1437026048.744654","10","info","SUM_ENDOK:Scanning database for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("85","1437026048.747999","10","info","SUM_START:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("86","1437026048.751548","2","info","Examining URLs found in posts we scanned for dangerous websites");
INSERT INTO `arc1542_wfStatus` VALUES("87","1437026048.752177","2","info","Done examining URLs");
INSERT INTO `arc1542_wfStatus` VALUES("88","1437026048.753778","10","info","SUM_ENDOK:Scanning posts for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("89","1437026048.758344","10","info","SUM_START:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("90","1437026048.761594","2","info","Checking 1 host keys against Wordfence scanning servers.");
INSERT INTO `arc1542_wfStatus` VALUES("91","1437026049.190769","2","info","Done host key check.");
INSERT INTO `arc1542_wfStatus` VALUES("92","1437026049.196518","10","info","SUM_ENDOK:Scanning comments for URL\'s in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("93","1437026049.200594","10","info","SUM_START:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("94","1437026049.201485","2","info","Starting password strength check on 1 users.");
INSERT INTO `arc1542_wfStatus` VALUES("95","1437026049.226990","10","info","SUM_ENDOK:Scanning for weak passwords");
INSERT INTO `arc1542_wfStatus` VALUES("96","1437026049.230671","10","info","SUM_START:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("97","1437026049.231348","2","info","Starting DNS scan for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("98","1437026049.319034","2","info","Scanning DNS A record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("99","1437026049.345831","2","info","Scanning DNS MX record for test.dev");
INSERT INTO `arc1542_wfStatus` VALUES("100","1437026049.348638","10","info","SUM_ENDOK:Scanning DNS for unauthorized changes");
INSERT INTO `arc1542_wfStatus` VALUES("101","1437026049.352585","10","info","SUM_START:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("102","1437026049.353259","2","info","Total disk space: 231.7394GB -- Free disk space: 22.7601GB");
INSERT INTO `arc1542_wfStatus` VALUES("103","1437026049.353714","2","info","The disk has 23306.36 MB space available");
INSERT INTO `arc1542_wfStatus` VALUES("104","1437026049.354505","10","info","SUM_ENDOK:Scanning to check available disk space");
INSERT INTO `arc1542_wfStatus` VALUES("105","1437026049.357546","10","info","SUM_START:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("106","1437026049.705358","10","info","SUM_ENDBAD:Scanning for old themes, plugins and core files");
INSERT INTO `arc1542_wfStatus` VALUES("107","1437026049.722632","1","info","-------------------");
INSERT INTO `arc1542_wfStatus` VALUES("108","1437026049.723149","1","info","Scan Complete. Scanned 1008 files, 3 plugins, 1 themes, 2 pages, 1 comments and 1431 records in 15 seconds.");
INSERT INTO `arc1542_wfStatus` VALUES("109","1437026049.723630","10","info","SUM_FINAL:Scan complete. You have 3 new issues to fix. See below.");
INSERT INTO `arc1542_wfStatus` VALUES("110","1437026049.771163","2","info","Wordfence used 11.38MB of memory for scan. Server peak memory usage was: 39.28MB");


DROP TABLE IF EXISTS `arc1542_wfThrottleLog`;

CREATE TABLE `arc1542_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfVulnScanners`;

CREATE TABLE `arc1542_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





