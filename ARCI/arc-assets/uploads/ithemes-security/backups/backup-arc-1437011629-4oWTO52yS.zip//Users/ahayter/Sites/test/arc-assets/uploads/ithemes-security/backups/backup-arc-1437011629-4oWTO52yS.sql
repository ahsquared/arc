DROP TABLE IF EXISTS `arc1542_commentmeta`;

CREATE TABLE `arc1542_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_comments`;

CREATE TABLE `arc1542_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_comments` VALUES("1","1","Mr WordPress","","https://wordpress.org/","","2015-06-15 19:42:40","2015-06-15 19:42:40","Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.","0","1","","","0","0");


DROP TABLE IF EXISTS `arc1542_itsec_lockouts`;

CREATE TABLE `arc1542_itsec_lockouts` (
  `lockout_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lockout_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lockout_start` datetime NOT NULL,
  `lockout_start_gmt` datetime NOT NULL,
  `lockout_expire` datetime NOT NULL,
  `lockout_expire_gmt` datetime NOT NULL,
  `lockout_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_user` bigint(20) unsigned DEFAULT NULL,
  `lockout_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lockout_active` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`lockout_id`),
  KEY `lockout_expire_gmt` (`lockout_expire_gmt`),
  KEY `lockout_host` (`lockout_host`),
  KEY `lockout_user` (`lockout_user`),
  KEY `lockout_username` (`lockout_username`),
  KEY `lockout_active` (`lockout_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_log`;

CREATE TABLE `arc1542_itsec_log` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `log_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_function` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `log_priority` int(2) NOT NULL DEFAULT '1',
  `log_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `log_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_user` bigint(20) unsigned DEFAULT NULL,
  `log_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_referrer` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`log_id`),
  KEY `log_type` (`log_type`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_itsec_temp`;

CREATE TABLE `arc1542_itsec_temp` (
  `temp_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `temp_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `temp_date` datetime NOT NULL,
  `temp_date_gmt` datetime NOT NULL,
  `temp_host` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `temp_user` bigint(20) unsigned DEFAULT NULL,
  `temp_username` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`temp_id`),
  KEY `temp_date_gmt` (`temp_date_gmt`),
  KEY `temp_host` (`temp_host`),
  KEY `temp_user` (`temp_user`),
  KEY `temp_username` (`temp_username`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_links`;

CREATE TABLE `arc1542_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;



DROP TABLE IF EXISTS `arc1542_options`;

CREATE TABLE `arc1542_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=231 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_options` VALUES("1","siteurl","http://test.dev","yes");
INSERT INTO `arc1542_options` VALUES("2","home","http://test.dev","yes");
INSERT INTO `arc1542_options` VALUES("3","blogname","ARC","yes");
INSERT INTO `arc1542_options` VALUES("4","blogdescription","Just another WordPress site","yes");
INSERT INTO `arc1542_options` VALUES("5","users_can_register","0","yes");
INSERT INTO `arc1542_options` VALUES("6","admin_email","andre.hayter@gmail.com","yes");
INSERT INTO `arc1542_options` VALUES("7","start_of_week","1","yes");
INSERT INTO `arc1542_options` VALUES("8","use_balanceTags","0","yes");
INSERT INTO `arc1542_options` VALUES("9","use_smilies","1","yes");
INSERT INTO `arc1542_options` VALUES("10","require_name_email","1","yes");
INSERT INTO `arc1542_options` VALUES("11","comments_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("12","posts_per_rss","10","yes");
INSERT INTO `arc1542_options` VALUES("13","rss_use_excerpt","0","yes");
INSERT INTO `arc1542_options` VALUES("14","mailserver_url","mail.example.com","yes");
INSERT INTO `arc1542_options` VALUES("15","mailserver_login","login@example.com","yes");
INSERT INTO `arc1542_options` VALUES("16","mailserver_pass","password","yes");
INSERT INTO `arc1542_options` VALUES("17","mailserver_port","110","yes");
INSERT INTO `arc1542_options` VALUES("18","default_category","1","yes");
INSERT INTO `arc1542_options` VALUES("19","default_comment_status","open","yes");
INSERT INTO `arc1542_options` VALUES("20","default_ping_status","open","yes");
INSERT INTO `arc1542_options` VALUES("21","default_pingback_flag","0","yes");
INSERT INTO `arc1542_options` VALUES("22","posts_per_page","10","yes");
INSERT INTO `arc1542_options` VALUES("23","date_format","F j, Y","yes");
INSERT INTO `arc1542_options` VALUES("24","time_format","g:i a","yes");
INSERT INTO `arc1542_options` VALUES("25","links_updated_date_format","F j, Y g:i a","yes");
INSERT INTO `arc1542_options` VALUES("26","comment_moderation","0","yes");
INSERT INTO `arc1542_options` VALUES("27","moderation_notify","1","yes");
INSERT INTO `arc1542_options` VALUES("28","permalink_structure","/%year%/%monthnum%/%day%/%postname%/","yes");
INSERT INTO `arc1542_options` VALUES("29","gzipcompression","0","yes");
INSERT INTO `arc1542_options` VALUES("30","hack_file","0","yes");
INSERT INTO `arc1542_options` VALUES("31","blog_charset","UTF-8","yes");
INSERT INTO `arc1542_options` VALUES("32","moderation_keys","","no");
INSERT INTO `arc1542_options` VALUES("33","active_plugins","a:2:{i:0;s:41:\"better-wp-security/better-wp-security.php\";i:1;s:23:\"wordfence/wordfence.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("34","category_base","","yes");
INSERT INTO `arc1542_options` VALUES("35","ping_sites","http://rpc.pingomatic.com/","yes");
INSERT INTO `arc1542_options` VALUES("36","advanced_edit","0","yes");
INSERT INTO `arc1542_options` VALUES("37","comment_max_links","2","yes");
INSERT INTO `arc1542_options` VALUES("38","gmt_offset","","yes");
INSERT INTO `arc1542_options` VALUES("39","default_email_category","1","yes");
INSERT INTO `arc1542_options` VALUES("40","recently_edited","","no");
INSERT INTO `arc1542_options` VALUES("41","template","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("42","stylesheet","ut-thehill","yes");
INSERT INTO `arc1542_options` VALUES("43","comment_whitelist","1","yes");
INSERT INTO `arc1542_options` VALUES("44","blacklist_keys","","no");
INSERT INTO `arc1542_options` VALUES("45","comment_registration","0","yes");
INSERT INTO `arc1542_options` VALUES("46","html_type","text/html","yes");
INSERT INTO `arc1542_options` VALUES("47","use_trackback","0","yes");
INSERT INTO `arc1542_options` VALUES("48","default_role","subscriber","yes");
INSERT INTO `arc1542_options` VALUES("49","db_version","31535","yes");
INSERT INTO `arc1542_options` VALUES("50","uploads_use_yearmonth_folders","1","yes");
INSERT INTO `arc1542_options` VALUES("51","upload_path","","yes");
INSERT INTO `arc1542_options` VALUES("52","blog_public","0","yes");
INSERT INTO `arc1542_options` VALUES("53","default_link_category","2","yes");
INSERT INTO `arc1542_options` VALUES("54","show_on_front","posts","yes");
INSERT INTO `arc1542_options` VALUES("55","tag_base","","yes");
INSERT INTO `arc1542_options` VALUES("56","show_avatars","1","yes");
INSERT INTO `arc1542_options` VALUES("57","avatar_rating","G","yes");
INSERT INTO `arc1542_options` VALUES("58","upload_url_path","","yes");
INSERT INTO `arc1542_options` VALUES("59","thumbnail_size_w","150","yes");
INSERT INTO `arc1542_options` VALUES("60","thumbnail_size_h","150","yes");
INSERT INTO `arc1542_options` VALUES("61","thumbnail_crop","1","yes");
INSERT INTO `arc1542_options` VALUES("62","medium_size_w","300","yes");
INSERT INTO `arc1542_options` VALUES("63","medium_size_h","300","yes");
INSERT INTO `arc1542_options` VALUES("64","avatar_default","mystery","yes");
INSERT INTO `arc1542_options` VALUES("65","large_size_w","1024","yes");
INSERT INTO `arc1542_options` VALUES("66","large_size_h","1024","yes");
INSERT INTO `arc1542_options` VALUES("67","image_default_link_type","file","yes");
INSERT INTO `arc1542_options` VALUES("68","image_default_size","","yes");
INSERT INTO `arc1542_options` VALUES("69","image_default_align","","yes");
INSERT INTO `arc1542_options` VALUES("70","close_comments_for_old_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("71","close_comments_days_old","14","yes");
INSERT INTO `arc1542_options` VALUES("72","thread_comments","1","yes");
INSERT INTO `arc1542_options` VALUES("73","thread_comments_depth","5","yes");
INSERT INTO `arc1542_options` VALUES("74","page_comments","0","yes");
INSERT INTO `arc1542_options` VALUES("75","comments_per_page","50","yes");
INSERT INTO `arc1542_options` VALUES("76","default_comments_page","newest","yes");
INSERT INTO `arc1542_options` VALUES("77","comment_order","asc","yes");
INSERT INTO `arc1542_options` VALUES("78","sticky_posts","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("79","widget_categories","a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("80","widget_text","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("81","widget_rss","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("82","uninstall_plugins","a:1:{s:41:\"better-wp-security/better-wp-security.php\";a:2:{i:0;s:10:\"ITSEC_Core\";i:1;s:12:\"on_uninstall\";}}","no");
INSERT INTO `arc1542_options` VALUES("83","timezone_string","America/New_York","yes");
INSERT INTO `arc1542_options` VALUES("84","page_for_posts","0","yes");
INSERT INTO `arc1542_options` VALUES("85","page_on_front","0","yes");
INSERT INTO `arc1542_options` VALUES("86","default_post_format","0","yes");
INSERT INTO `arc1542_options` VALUES("87","link_manager_enabled","0","yes");
INSERT INTO `arc1542_options` VALUES("88","initial_db_version","31535","yes");
INSERT INTO `arc1542_options` VALUES("89","arc1542_user_roles","a:6:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:62:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:9:\"add_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}s:13:\"UT_site_admin\";a:2:{s:4:\"name\";s:13:\"UT Site Admin\";s:12:\"capabilities\";a:39:{s:19:\"delete_others_pages\";b:1;s:19:\"delete_others_posts\";b:1;s:12:\"delete_pages\";b:1;s:12:\"delete_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:20:\"delete_private_posts\";b:1;s:22:\"delete_published_pages\";b:1;s:22:\"delete_published_posts\";b:1;s:17:\"edit_others_pages\";b:1;s:17:\"edit_others_posts\";b:1;s:10:\"edit_pages\";b:1;s:10:\"edit_posts\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"edit_private_posts\";b:1;s:20:\"edit_published_pages\";b:1;s:20:\"edit_published_posts\";b:1;s:18:\"edit_theme_options\";b:1;s:24:\"gravityforms_create_form\";b:1;s:27:\"gravityforms_delete_entries\";b:1;s:25:\"gravityforms_delete_forms\";b:1;s:25:\"gravityforms_edit_entries\";b:1;s:29:\"gravityforms_edit_entry_notes\";b:1;s:23:\"gravityforms_edit_forms\";b:1;s:27:\"gravityforms_export_entries\";b:1;s:17:\"gravityforms_feed\";b:1;s:25:\"gravityforms_view_entries\";b:1;s:29:\"gravityforms_view_entry_notes\";b:1;s:10:\"list_users\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:17:\"moderate_comments\";b:1;s:13:\"publish_pages\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:18:\"read_private_pages\";b:1;s:18:\"read_private_posts\";b:1;s:12:\"upload_files\";b:1;s:10:\"view_stats\";b:1;s:14:\"show_admin_bar\";b:1;}}}","yes");
INSERT INTO `arc1542_options` VALUES("90","widget_search","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("91","widget_recent-posts","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("92","widget_recent-comments","a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("93","widget_archives","a:2:{i:2;a:3:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("94","widget_meta","a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}","yes");
INSERT INTO `arc1542_options` VALUES("95","sidebars_widgets","a:11:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:4:{i:0;s:14:\"recent-posts-2\";i:1;s:17:\"recent-comments-2\";i:2;s:10:\"archives-2\";i:3;s:12:\"categories-2\";}s:11:\"sidebar-404\";N;s:9:\"sidebar-3\";N;s:9:\"sidebar-4\";N;s:9:\"sidebar-5\";N;s:9:\"sidebar-6\";N;s:9:\"sidebar-7\";N;s:9:\"sidebar-8\";N;s:9:\"sidebar-9\";N;s:13:\"array_version\";i:3;}","yes");
INSERT INTO `arc1542_options` VALUES("97","cron","a:16:{i:1434417126;a:1:{s:28:\"wordfence_update_blocked_IPs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434417481;a:1:{s:21:\"wordfence_hourly_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1434440560;a:3:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434441180;a:1:{s:20:\"wp_maybe_auto_update\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1434446242;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434483878;a:1:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434483934;a:2:{s:16:\"itsec_purge_logs\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:20:\"itsec_purge_lockouts\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434485881;a:1:{s:20:\"wordfence_daily_cron\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1434531862;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434618826;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434707250;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434791197;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434879086;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1434964944;a:1:{s:30:\"wordfence_start_scheduled_scan\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}i:1435608000;a:1:{s:31:\"wordfence_email_activity_report\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:2:{s:8:\"schedule\";b:0;s:4:\"args\";a:0:{}}}}s:7:\"version\";i:2;}","yes");
INSERT INTO `arc1542_options` VALUES("99","rewrite_rules","a:59:{s:12:\"robots\\.txt$\";s:18:\"index.php?robots=1\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:58:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:68:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:88:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:83:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$\";s:85:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1\";s:77:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]\";s:65:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]\";s:72:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$\";s:98:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$\";s:97:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]\";s:47:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:57:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:77:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:72:\"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]\";s:51:\"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]\";s:38:\"([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&cpage=$matches[2]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:20:\"(.?.+?)(/[0-9]+)?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";}","yes");
INSERT INTO `arc1542_options` VALUES("101","_site_transient_update_core","O:8:\"stdClass\":4:{s:7:\"updates\";a:1:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:6:\"latest\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-4.2.2.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-4.2.2-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-4.2.2-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"4.2.2\";s:7:\"version\";s:5:\"4.2.2\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"4.1\";s:15:\"partial_version\";s:0:\"\";}}s:12:\"last_checked\";i:1434399470;s:15:\"version_checked\";s:5:\"4.2.2\";s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("106","_site_transient_update_themes","O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1434399471;s:7:\"checked\";a:1:{s:10:\"ut-thehill\";s:3:\"0.1\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("108","_transient_random_seed","359cc26d4195eeb7b368c9d94a695184","yes");
INSERT INTO `arc1542_options` VALUES("109","_site_transient_timeout_browser_3a9721c33f29438e21880b312d32e7bb","1435002173","yes");
INSERT INTO `arc1542_options` VALUES("110","_site_transient_browser_3a9721c33f29438e21880b312d32e7bb","a:9:{s:8:\"platform\";s:9:\"Macintosh\";s:4:\"name\";s:6:\"Chrome\";s:7:\"version\";s:13:\"43.0.2357.124\";s:10:\"update_url\";s:28:\"http://www.google.com/chrome\";s:7:\"img_src\";s:49:\"http://s.wordpress.org/images/browsers/chrome.png\";s:11:\"img_src_ssl\";s:48:\"https://wordpress.org/images/browsers/chrome.png\";s:15:\"current_version\";s:2:\"18\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("111","can_compress_scripts","1","yes");
INSERT INTO `arc1542_options` VALUES("112","_transient_timeout_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","1434440576","no");
INSERT INTO `arc1542_options` VALUES("113","_transient_feed_ac0b00fe65abe10e0c5b588f3ed8c7ca","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:49:\"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:3:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"https://wordpress.org/news\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WordPress News\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:13:\"lastBuildDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 May 2015 10:01:33 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://wordpress.org/?v=4.3-alpha-32784\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:10:{i:0;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WordPress 4.2.2 Security and Maintenance Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 07 May 2015 02:24:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3718\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:355:\"WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3194:\"<p>WordPress 4.2.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>Version 4.2.2 addresses two security issues:</p>
<ul>
<li>The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site scripting attack. All affected themes and plugins hosted on <a href=\"https://wordpress.org/\">WordPress.org</a> (including the Twenty Fifteen default theme) have been updated today by the WordPress security team to address this issue by removing this nonessential file. To help protect other Genericons usage, WordPress 4.2.2 proactively scans the wp-content directory for this HTML file and removes it. Reported by Robert Abela of <a href=\"http://netsparker.com\">Netsparker</a>.</li>
<li>WordPress versions 4.2 and earlier are affected by a <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\">critical cross-site scripting vulnerability</a>, which could enable anonymous users to compromise a site. WordPress 4.2.2 includes a comprehensive fix for this issue. Reported separately by Rice Adu and Tong Shi.</li>
</ul>
<p>The release also includes hardening for a potential cross-site scripting vulnerability when using the visual editor. This issue was reported by Mahadev Subedi.</p>
<p>Our thanks to those who have practiced <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of security issues.</p>
<p>WordPress 4.2.2 also contains fixes for 13 bugs from 4.2. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32418&amp;stop_rev=32324\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.2</a> or venture over to Dashboard → Updates and simply click “Update Now.” Sites that support automatic background updates are already beginning to update to WordPress 4.2.2.</p>
<p>Thanks to everyone who contributed to 4.2.2:</p>
<p><a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>, <a href=\"https://profiles.wordpress.org/nbachiyski\">Nikolay Bachiyski</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, and <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/05/wordpress-4-2-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 4.2.1 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Apr 2015 18:34:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3706\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:366:\"WordPress 4.2.1 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by Jouko Pynnönen. [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:1010:\"<p>WordPress 4.2.1 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>A few hours ago, the WordPress team was made aware of a cross-site scripting vulnerability, which could enable commenters to compromise a site. The vulnerability was discovered by <a href=\"http://klikki.fi/\">Jouko Pynnönen</a>.</p>
<p>WordPress 4.2.1 has begun to roll out as an automatic background update, for sites that <a href=\"https://wordpress.org/plugins/background-update-tester/\">support</a> those.</p>
<p>For more information, see the <a href=\"https://codex.wordpress.org/Version_4.2.1\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.2?rev=32311&amp;stop_rev=32300\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.2.1</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now&#8221;.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-2-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:45:\"
		
		
		
		
		
				
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"WordPress 4.2 “Powell”\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"https://wordpress.org/news/2015/04/powell/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/powell/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Apr 2015 18:35:29 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:2:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3642\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:343:\"Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist Bud Powell, is available for download or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally. An easier way to share content Clip it, edit it, publish it. Get familiar with the new and improved Press This. From [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:29435:\"<p>Version 4.2 of WordPress, named &#8220;Powell&#8221; in honor of jazz pianist <a href=\"https://en.wikipedia.org/wiki/Bud_Powell\">Bud Powell</a>, is available for <a href=\"https://wordpress.org/download/\">download</a> or update in your WordPress dashboard. New features in 4.2 help you communicate and share, globally.</p>
<div id=\"v-e9kH4FzP-1\" class=\"video-player\"><embed id=\"v-e9kH4FzP-1-video\" src=\"https://v0.wordpress.com/player.swf?v=1.04&amp;guid=e9kH4FzP&amp;isDynamicSeeking=true\" type=\"application/x-shockwave-flash\" width=\"692\" height=\"388\" title=\"Introducing WordPress 4.2 &quot;Powell&quot;\" wmode=\"direct\" seamlesstabbing=\"true\" allowfullscreen=\"true\" allowscriptaccess=\"always\" overstretch=\"true\"></embed></div>
<hr />
<h2 style=\"text-align: center\">An easier way to share content</h2>
<p><img class=\"alignnone size-full wp-image-3677\" src=\"https://wordpress.org/news/files/2015/04/4.2-press-this-2.jpg\" alt=\"Press This\" width=\"1000\" height=\"832\" />Clip it, edit it, publish it. Get familiar with the new and improved Press This. From the Tools menu, add Press This to your browser bookmark bar or your mobile device home screen. Once installed you can share your content with lightning speed. Sharing your favorite videos, images, and content has never been this fast or this easy.</p>
<hr />
<h2 style=\"text-align: center\">Extended character support</h2>
<p><img class=\"alignnone size-full wp-image-3676\" src=\"https://wordpress.org/news/files/2015/04/4.2-characters.png\" alt=\"Character support for emoji, special characters\" width=\"1000\" height=\"832\" />Writing in WordPress, whatever your language, just got better. WordPress 4.2 supports a host of new characters out-of-the-box, including native Chinese, Japanese, and Korean characters, musical and mathematical symbols, and hieroglyphs.</p>
<p>Don’t use any of those characters? You can still have fun — emoji are now available in WordPress! Get creative and decorate your content with <img src=\"https://s.w.org/images/core/emoji/72x72/1f499.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f438.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f412.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, <img src=\"https://s.w.org/images/core/emoji/72x72/1f355.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" />, and all the many other <a href=\"https://codex.wordpress.org/Emoji\">emoji</a>.</p>
<hr />
<div><img class=\"alignright size-medium wp-image-3656\" src=\"https://wordpress.org/news/files/2015/04/4.2-theme-switcher-300x230.png\" alt=\"Customizer theme switcher\" width=\"288\" height=\"221\" /></p>
<h3>Switch themes in the Customizer</h3>
<p>Browse and preview your installed themes from the Customizer. Make sure the theme looks great with your content, before it debuts on your site.</p>
</div>
<div style=\"clear: both\"></div>
<div><img class=\"alignright size-medium wp-image-3653\" src=\"https://wordpress.org/news/files/2015/04/4.2-embeds-300x230.png\" alt=\"Tumbr.com oEmbed example\" width=\"288\" height=\"221\" /></p>
<h3>Even more embeds</h3>
<p>Paste links from Tumblr.com and Kickstarter and watch them magically appear right in the editor. With every release, your publishing and editing experience get closer together.</p>
</div>
<div style=\"clear: both\"></div>
<div>
<p><img class=\"alignright size-medium wp-image-3654\" src=\"https://wordpress.org/news/files/2015/04/4.2-plugins-300x230.png\" alt=\"Inline plugin updates\" width=\"288\" height=\"221\" /></p>
<h3>Streamlined plugin updates</h3>
<p>Goodbye boring loading screen, hello smooth and simple plugin updates. Click <em>Update Now</em> and watch the magic happen.</p>
</div>
<div style=\"clear: both\"></div>
<hr />
<h2 style=\"text-align: center\">Under the Hood</h2>
<h5>utf8mb4 support</h5>
<p>Database character encoding has changed from utf8 to utf8mb4, which adds support for a whole range of new 4-byte characters.</p>
<h5>JavaScript accessibility</h5>
<p>You can now send audible notifications to screen readers in JavaScript with <code>wp.a11y.speak()</code>. Pass it a string, and an update will be sent to a dedicated ARIA live notifications area.</p>
<h5>Shared term splitting</h5>
<p>Terms shared across multiple taxonomies will be split when one of them is updated. Find out more in the <a href=\"https://developer.wordpress.org/plugins/taxonomy/working-with-split-terms-in-wp-4-2/\">Plugin Developer Handbook</a>.</p>
<h5>Complex query ordering</h5>
<p><code>WP_Query</code>, <code>WP_Comment_Query</code>, and <code>WP_User_Query</code> now support complex ordering with named meta query clauses.</p>
<hr />
<h2 style=\"text-align: center\">The Team</h2>
<p><a class=\"alignleft\" href=\"https://profiles.wordpress.org/drewapicture\"><img src=\"https://www.gravatar.com/avatar/95c934fa2c3362794bf62ff8c59ada08?d=mm&amp;s=150&amp;r=G\" alt=\"Drew Jaynes\" width=\"90\" height=\"90\" /></a>This release was led by <a href=\"http://werdswords.com\">Drew Jaynes</a>, with the help of these fine individuals. There are 283 contributors with props in this release, a new high. Pull up some Bud Powell on your music service of choice, and check out some of their profiles:</p>
<a href=\"https://profiles.wordpress.org/mercime\">@mercime</a>, <a href=\"https://profiles.wordpress.org/a5hleyrich\">A5hleyRich</a>, <a href=\"https://profiles.wordpress.org/aaroncampbell\">Aaron D. Campbell</a>, <a href=\"https://profiles.wordpress.org/jorbin\">Aaron Jorbin</a>, <a href=\"https://profiles.wordpress.org/abhishekfdd\">abhishekfdd</a>, <a href=\"https://profiles.wordpress.org/adamsilverstein\">Adam Silverstein</a>, <a href=\"https://profiles.wordpress.org/mrahmadawais\">Ahmad Awais</a>, <a href=\"https://profiles.wordpress.org/alexkingorg\">Alex King</a>, <a href=\"https://profiles.wordpress.org/viper007bond\">Alex Mills (Viper007Bond)</a>, <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/collinsinternet\">Allan Collins</a>, <a href=\"https://profiles.wordpress.org/afercia\">Andrea Fercia</a>, <a href=\"https://profiles.wordpress.org/awbauer\">Andrew Bauer</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/norcross\">Andrew Norcross</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/ankitgadertcampcom\">Ankit Gade</a>, <a href=\"https://profiles.wordpress.org/ankit-k-gupta\">Ankit K Gupta</a>, <a href=\"https://profiles.wordpress.org/atimmer\">Anton Timmermans</a>, <a href=\"https://profiles.wordpress.org/aramzs\">Aram Zucker-Scharff</a>, <a href=\"https://profiles.wordpress.org/arminbraun\">ArminBraun</a>, <a href=\"https://profiles.wordpress.org/ashfame\">Ashfame</a>, <a href=\"https://profiles.wordpress.org/filosofo\">Austin Matzko</a>, <a href=\"https://profiles.wordpress.org/avryl\">avryl</a>, <a href=\"https://profiles.wordpress.org/barrykooij\">Barry Kooij</a>, <a href=\"https://profiles.wordpress.org/beaulebens\">Beau Lebens</a>, <a href=\"https://profiles.wordpress.org/bendoh\">Ben Doherty (Oomph, Inc)</a>, <a href=\"https://profiles.wordpress.org/bananastalktome\">Billy Schneider</a>, <a href=\"https://profiles.wordpress.org/boonebgorges\">Boone B. Gorges</a>, <a href=\"https://profiles.wordpress.org/kraftbj\">Brandon Kraft</a>, <a href=\"https://profiles.wordpress.org/krogsgard\">Brian Krogsgard</a>, <a href=\"https://profiles.wordpress.org/bswatson\">Brian Watson</a>, <a href=\"https://profiles.wordpress.org/calevans\">CalEvans</a>, <a href=\"https://profiles.wordpress.org/carolinegeven\">carolinegeven</a>, <a href=\"https://profiles.wordpress.org/caseypatrickdriscoll\">Casey Driscoll</a>, <a href=\"https://profiles.wordpress.org/caspie\">Caspie</a>, <a href=\"https://profiles.wordpress.org/cdog\">Catalin Dogaru</a>, <a href=\"https://profiles.wordpress.org/chipbennett\">Chip Bennett</a>, <a href=\"https://profiles.wordpress.org/chipx86\">chipx86</a>, <a href=\"https://profiles.wordpress.org/chrico\">ChriCo</a>, <a href=\"https://profiles.wordpress.org/cbaldelomar\">Chris Baldelomar</a>, <a href=\"https://profiles.wordpress.org/c3mdigital\">Chris Olbekson</a>, <a href=\"https://profiles.wordpress.org/cfoellmann\">Christian Foellmann</a>, <a href=\"https://profiles.wordpress.org/cfinke\">Christopher Finke</a>, <a href=\"https://profiles.wordpress.org/clifgriffin\">Clifton Griffin</a>, <a href=\"https://profiles.wordpress.org/codix\">Code Master</a>, <a href=\"https://profiles.wordpress.org/corphi\">Corphi</a>, <a href=\"https://profiles.wordpress.org/couturefreak\">Courtney Ivey</a>, <a href=\"https://profiles.wordpress.org/craig-ralston\">Craig Ralston</a>, <a href=\"https://profiles.wordpress.org/cweiske\">cweiske</a>, <a href=\"https://profiles.wordpress.org/extendwings\">Daisuke Takahashi</a>, <a href=\"https://profiles.wordpress.org/timersys\">Damian</a>, <a href=\"https://profiles.wordpress.org/danielbachhuber\">Daniel Bachhuber</a>, <a href=\"https://profiles.wordpress.org/redsweater\">Daniel Jalkut (Red Sweater)</a>, <a href=\"https://profiles.wordpress.org/dkotter\">Darin Kotter</a>, <a href=\"https://profiles.wordpress.org/nerrad\">Darren Ethier (nerrad)</a>, <a href=\"https://profiles.wordpress.org/dllh\">Daryl L. L. Houston (dllh)</a>, <a href=\"https://profiles.wordpress.org/dmchale\">Dave McHale</a>, <a href=\"https://profiles.wordpress.org/davidakennedy\">David A. Kennedy</a>, <a href=\"https://profiles.wordpress.org/davidanderson\">David Anderson</a>, <a href=\"https://profiles.wordpress.org/dlh\">David Herrera</a>, <a href=\"https://profiles.wordpress.org/folletto\">Davide \'Folletto\' Casali</a>, <a href=\"https://profiles.wordpress.org/davideugenepratt\">davideugenepratt</a>, <a href=\"https://profiles.wordpress.org/davidhamiltron\">davidhamiltron</a>, <a href=\"https://profiles.wordpress.org/denis-de-bernardy\">Denis de Bernardy</a>, <a href=\"https://profiles.wordpress.org/valendesigns\">Derek Herman</a>, <a href=\"https://profiles.wordpress.org/dsmart\">Derek Smart</a>, <a href=\"https://profiles.wordpress.org/designsimply\">designsimply</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/dipeshkakadiya\">dipesh.kakadiya</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/doublesharp\">doublesharp</a>, <a href=\"https://profiles.wordpress.org/dzerycz\">DzeryCZ</a>, <a href=\"https://profiles.wordpress.org/kucrut\">Dzikri Aziz</a>, <a href=\"https://profiles.wordpress.org/emazovetskiy\">e.mazovetskiy</a>, <a href=\"https://profiles.wordpress.org/oso96_2000\">Eduardo Reveles</a>, <a href=\"https://profiles.wordpress.org/cais\">Edward Caissie</a>, <a href=\"https://profiles.wordpress.org/eliorivero\">Elio Rivero</a>, <a href=\"https://profiles.wordpress.org/iseulde\">Ella Iseulde Van Dorpe</a>, <a href=\"https://profiles.wordpress.org/elliottcarlson\">elliottcarlson</a>, <a href=\"https://profiles.wordpress.org/enej\">enej</a>, <a href=\"https://profiles.wordpress.org/ericlewis\">Eric Andrew Lewis</a>, <a href=\"https://profiles.wordpress.org/ebinnion\">Eric Binnion</a>, <a href=\"https://profiles.wordpress.org/ethitter\">Erick Hitter</a>, <a href=\"https://profiles.wordpress.org/evansolomon\">Evan Solomon</a>, <a href=\"https://profiles.wordpress.org/fab1en\">Fabien Quatravaux</a>, <a href=\"https://profiles.wordpress.org/fhwebcs\">fhwebcs</a>, <a href=\"https://profiles.wordpress.org/floriansimeth\">Florian Simeth</a>, <a href=\"https://profiles.wordpress.org/bueltge\">Frank Bueltge</a>, <a href=\"https://profiles.wordpress.org/frankpw\">Frank P. Walentynowicz</a>, <a href=\"https://profiles.wordpress.org/f-j-kaiser\">Franz Josef Kaiser</a>, <a href=\"https://profiles.wordpress.org/garyc40\">Gary Cao</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/geertdd\">Geert De Deckere</a>, <a href=\"https://profiles.wordpress.org/genkisan\">genkisan</a>, <a href=\"https://profiles.wordpress.org/georgestephanis\">George Stephanis</a>, <a href=\"https://profiles.wordpress.org/grahamarmfield\">Graham Armfield</a>, <a href=\"https://profiles.wordpress.org/webord\">Gustavo Bordoni</a>, <a href=\"https://profiles.wordpress.org/hakre\">hakre</a>, <a href=\"https://profiles.wordpress.org/harishchaudhari\">Harish Chaudhari</a>, <a href=\"https://profiles.wordpress.org/hauvong\">hauvong</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/herbmillerjr\">herbmillerjr</a>, <a href=\"https://profiles.wordpress.org/hew\">Hew</a>, <a href=\"https://profiles.wordpress.org/hnle\">Hinaloe</a>, <a href=\"https://profiles.wordpress.org/horike\">horike</a>, <a href=\"https://profiles.wordpress.org/hlashbrooke\">Hugh Lashbrooke</a>, <a href=\"https://profiles.wordpress.org/hugobaeta\">Hugo Baeta</a>, <a href=\"https://profiles.wordpress.org/iandunn\">Ian Dunn</a>, <a href=\"https://profiles.wordpress.org/ianmjones\">ianmjones</a>, <a href=\"https://profiles.wordpress.org/idealien\">idealien</a>, <a href=\"https://profiles.wordpress.org/imath\">imath</a>, <a href=\"https://profiles.wordpress.org/ipstenu\">Ipstenu (Mika Epstein)</a>, <a href=\"https://profiles.wordpress.org/jdgrimes\">J.D. Grimes</a>, <a href=\"https://profiles.wordpress.org/jacklenox\">Jack Lenox</a>, <a href=\"https://profiles.wordpress.org/jamescollins\">James Collins</a>, <a href=\"https://profiles.wordpress.org/janhenckens\">janhenckens</a>, <a href=\"https://profiles.wordpress.org/jfarthing84\">Jeff Farthing</a>, <a href=\"https://profiles.wordpress.org/cheffheid\">Jeffrey de Wit</a>, <a href=\"https://profiles.wordpress.org/jeremyfelt\">Jeremy Felt</a>, <a href=\"https://profiles.wordpress.org/jesin\">Jesin A</a>, <a href=\"https://profiles.wordpress.org/jipmoors\">jipmoors</a>, <a href=\"https://profiles.wordpress.org/jartes\">Joan Artes</a>, <a href=\"https://profiles.wordpress.org/joedolson\">Joe Dolson</a>, <a href=\"https://profiles.wordpress.org/joemcgill\">Joe McGill</a>, <a href=\"https://profiles.wordpress.org/yo-l1982\">Joel Bernerman</a>, <a href=\"https://profiles.wordpress.org/joen\">Joen Asmussen</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, <a href=\"https://profiles.wordpress.org/johneckman\">John Eckman</a>, <a href=\"https://profiles.wordpress.org/johnjamesjacoby\">John James Jacoby</a>, <a href=\"https://profiles.wordpress.org/jlevandowski\">John Levandowski</a>, <a href=\"https://profiles.wordpress.org/desrosj\">Jonathan Desrosiers</a>, <a href=\"https://profiles.wordpress.org/joostdekeijzer\">joost de keijzer</a>, <a href=\"https://profiles.wordpress.org/joostdevalk\">Joost de Valk</a>, <a href=\"https://profiles.wordpress.org/jcastaneda\">Jose Castaneda</a>, <a href=\"https://profiles.wordpress.org/joshlevinson\">Josh Levinson</a>, <a href=\"https://profiles.wordpress.org/jphase\">jphase</a>, <a href=\"https://profiles.wordpress.org/juliobox\">Julio Potier</a>, <a href=\"https://profiles.wordpress.org/kopepasah\">Justin Kopepasah</a>, <a href=\"https://profiles.wordpress.org/jtsternberg\">Justin Sternberg</a>, <a href=\"https://profiles.wordpress.org/justincwatt\">Justin Watt</a>, <a href=\"https://profiles.wordpress.org/kadamwhite\">K.Adam White</a>, <a href=\"https://profiles.wordpress.org/trepmal\">Kailey (trepmal)</a>, <a href=\"https://profiles.wordpress.org/ryelle\">Kelly Dwan</a>, <a href=\"https://profiles.wordpress.org/kevdotbadger\">Kevin Ruscoe</a>, <a href=\"https://profiles.wordpress.org/kpdesign\">Kim Parsell</a>, <a href=\"https://profiles.wordpress.org/ixkaito\">Kite</a>, <a href=\"https://profiles.wordpress.org/kovshenin\">Konstantin Kovshenin</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/lancewillett\">Lance Willett</a>, <a href=\"https://profiles.wordpress.org/mindrun\">Leonard</a>, <a href=\"https://profiles.wordpress.org/leopeo\">Leonardo Giacone</a>, <a href=\"https://profiles.wordpress.org/lgladdy\">Liam Gladdy</a>, <a href=\"https://profiles.wordpress.org/maimairel\">maimairel</a>, <a href=\"https://profiles.wordpress.org/mako09\">Mako</a>, <a href=\"https://profiles.wordpress.org/funkatronic\">Manny Fleurmond</a>, <a href=\"https://profiles.wordpress.org/marcelomazza\">marcelomazza</a>, <a href=\"https://profiles.wordpress.org/marcochiesi\">Marco Chiesi</a>, <a href=\"https://profiles.wordpress.org/mkaz\">Marcus Kazmierczak</a>, <a href=\"https://profiles.wordpress.org/tyxla\">Marin Atanasov</a>, <a href=\"https://profiles.wordpress.org/nofearinc\">Mario Peshev</a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius (Clorith)</a>, <a href=\"https://profiles.wordpress.org/markjaquith\">Mark Jaquith</a>, <a href=\"https://profiles.wordpress.org/senff\">Mark Senff</a>, <a href=\"https://profiles.wordpress.org/markoheijnen\">Marko Heijnen</a>, <a href=\"https://profiles.wordpress.org/mgibbs189\">Matt Gibbs</a>, <a href=\"https://profiles.wordpress.org/sivel\">Matt Martz</a>, <a href=\"https://profiles.wordpress.org/matt\">Matt Mullenweg</a>, <a href=\"https://profiles.wordpress.org/mattwiebe\">Matt Wiebe</a>, <a href=\"https://profiles.wordpress.org/mzak\">Matt Zak</a>, <a href=\"https://profiles.wordpress.org/mboynes\">Matthew Boynes</a>, <a href=\"https://profiles.wordpress.org/mattheweppelsheimer\">Matthew Eppelsheimer</a>, <a href=\"https://profiles.wordpress.org/mattheu\">Matthew Haines-Young</a>, <a href=\"https://profiles.wordpress.org/mattyrob\">mattyrob</a>, <a href=\"https://profiles.wordpress.org/maxcutler\">Max Cutler</a>, <a href=\"https://profiles.wordpress.org/mehulkaklotar\">mehulkaklotar</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/meloniq\">meloniq</a>, <a href=\"https://profiles.wordpress.org/mdawaffe\">Michael Adams (mdawaffe)</a>, <a href=\"https://profiles.wordpress.org/michael-arestad\">Michael Arestad</a>, <a href=\"https://profiles.wordpress.org/tw2113\">Michael Beckwith</a>, <a href=\"https://profiles.wordpress.org/michalzuber\">michalzuber</a>, <a href=\"https://profiles.wordpress.org/mdgl\">Mike Glendinning</a>, <a href=\"https://profiles.wordpress.org/mikehansenme\">Mike Hansen</a>, <a href=\"https://profiles.wordpress.org/thaicloud\">Mike Jordan</a>, <a href=\"https://profiles.wordpress.org/mikeschinkel\">Mike Schinkel</a>, <a href=\"https://profiles.wordpress.org/mikengarrett\">MikeNGarrett</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinic</a>, <a href=\"https://profiles.wordpress.org/mmn-o\">mmn-o</a>, <a href=\"https://profiles.wordpress.org/batmoo\">Mohammad Jangda</a>, <a href=\"https://profiles.wordpress.org/momdad\">MomDad</a>, <a href=\"https://profiles.wordpress.org/morganestes\">Morgan Estes</a>, <a href=\"https://profiles.wordpress.org/morpheu5\">Morpheu5</a>, <a href=\"https://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/nathan_dawson\">nathan_dawson</a>, <a href=\"https://profiles.wordpress.org/neil_pie\">Neil Pie</a>, <a href=\"https://profiles.wordpress.org/celloexpressions\">Nick Halsey</a>, <a href=\"https://profiles.wordpress.org/nicnicnicdevos\">nicnicnicdevos</a>, <a href=\"https://profiles.wordpress.org/nikv\">Nikhil Vimal</a>, <a href=\"https://profiles.wordpress.org/ninnypants\">ninnypants</a>, <a href=\"https://profiles.wordpress.org/nitkr\">nitkr</a>, <a href=\"https://profiles.wordpress.org/nunomorgadinho\">Nuno Morgadinho</a>, <a href=\"https://profiles.wordpress.org/originalexe\">OriginalEXE</a>, <a href=\"https://profiles.wordpress.org/pareshradadiya-1\">Paresh Radadiya</a>, <a href=\"https://profiles.wordpress.org/pathawks\">Pat Hawks</a>, <a href=\"https://profiles.wordpress.org/pbearne\">Paul Bearne</a>, <a href=\"https://profiles.wordpress.org/paulschreiber\">Paul Schreiber</a>, <a href=\"https://profiles.wordpress.org/paulwilde\">Paul Wilde</a>, <a href=\"https://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/sirbrillig\">Payton Swick</a>, <a href=\"https://profiles.wordpress.org/petemall\">Pete Mall</a>, <a href=\"https://profiles.wordpress.org/gungeekatx\">Pete Nelson</a>, <a href=\"https://profiles.wordpress.org/peterwilsoncc\">Peter Wilson</a>, <a href=\"https://profiles.wordpress.org/mordauk\">Pippin Williamson</a>, <a href=\"https://profiles.wordpress.org/podpirate\">podpirate</a>, <a href=\"https://profiles.wordpress.org/postpostmodern\">postpostmodern</a>, <a href=\"https://profiles.wordpress.org/nprasath002\">Prasath Nadarajah</a>, <a href=\"https://profiles.wordpress.org/prasoon2211\">prasoon2211</a>, <a href=\"https://profiles.wordpress.org/cyman\">Primoz Cigler</a>, <a href=\"https://profiles.wordpress.org/r-a-y\">r-a-y</a>, <a href=\"https://profiles.wordpress.org/rachelbaker\">Rachel Baker</a>, <a href=\"https://profiles.wordpress.org/rahulbhangale\">rahulbhangale</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/lamosty\">Rastislav Lamos</a>, <a href=\"https://profiles.wordpress.org/ravindra-pal-singh\">Ravindra Pal Singh</a>, <a href=\"https://profiles.wordpress.org/rianrietveld\">Rian Rietveld</a>, <a href=\"https://profiles.wordpress.org/ritteshpatel\">Ritesh Patel</a>, <a href=\"https://profiles.wordpress.org/miqrogroove\">Robert Chapin</a>, <a href=\"https://profiles.wordpress.org/rodrigosprimo\">Rodrigo Primo</a>, <a href=\"https://profiles.wordpress.org/magicroundabout\">Ross Wintle</a>, <a href=\"https://profiles.wordpress.org/ryan\">Ryan Boren</a>, <a href=\"https://profiles.wordpress.org/rmarks\">Ryan Marks</a>, <a href=\"https://profiles.wordpress.org/sagarjadhav\">Sagar Jadhav</a>, <a href=\"https://profiles.wordpress.org/solarissmoke\">Samir Shah</a>, <a href=\"https://profiles.wordpress.org/samo9789\">samo9789</a>, <a href=\"https://profiles.wordpress.org/samuelsidler\">Samuel Sidler</a>, <a href=\"https://profiles.wordpress.org/sgrant\">Scott Grant</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/wonderboymusic\">Scott Taylor</a>, <a href=\"https://profiles.wordpress.org/scottgonzalez\">scott.gonzalez</a>, <a href=\"https://profiles.wordpress.org/greglone\">ScreenfeedFr</a>, <a href=\"https://profiles.wordpress.org/scribu\">scribu</a>, <a href=\"https://profiles.wordpress.org/seanchayes\">Sean Hayes</a>, <a href=\"https://profiles.wordpress.org/sergejmueller\">Sergej Muller</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/sevenspark\">sevenspark</a>, <a href=\"https://profiles.wordpress.org/simonwheatley\">Simon Wheatley</a>, <a href=\"https://profiles.wordpress.org/siobhan\">Siobhan</a>, <a href=\"https://profiles.wordpress.org/sippis\">sippis</a>, <a href=\"https://profiles.wordpress.org/slobodanmanic\">Slobodan Manic</a>, <a href=\"https://profiles.wordpress.org/stephdau\">Stephane Daury</a>, <a href=\"https://profiles.wordpress.org/sillybean\">Stephanie Leary</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/stevegrunwell\">Steve Grunwell</a>, <a href=\"https://profiles.wordpress.org/stevehickeydesign\">stevehickeydesign</a>, <a href=\"https://profiles.wordpress.org/stevenkword\">Steven Word</a>, <a href=\"https://profiles.wordpress.org/taka2\">taka2</a>, <a href=\"https://profiles.wordpress.org/iamtakashi\">Takashi Irie</a>, <a href=\"https://profiles.wordpress.org/hissy\">Takuro Hishikawa</a>, <a href=\"https://profiles.wordpress.org/themiked\">theMikeD</a>, <a href=\"https://profiles.wordpress.org/thomaswm\">thomaswm</a>, <a href=\"https://profiles.wordpress.org/ipm-frommen\">Thorsten Frommen</a>, <a href=\"https://profiles.wordpress.org/tillkruess\">Till</a>, <a href=\"https://profiles.wordpress.org/timothyblynjacobs\">Timothy Jacobs</a>, <a href=\"https://profiles.wordpress.org/tiqbiz\">tiqbiz</a>, <a href=\"https://profiles.wordpress.org/tmatsuur\">tmatsuur</a>, <a href=\"https://profiles.wordpress.org/tmeister\">tmeister</a>, <a href=\"https://profiles.wordpress.org/tschutter\">Tobias Schutter</a>, <a href=\"https://profiles.wordpress.org/tobiasbg\">TobiasBg</a>, <a href=\"https://profiles.wordpress.org/tomdxw\">tomdxw</a>, <a href=\"https://profiles.wordpress.org/travisnorthcutt\">Travis Northcutt</a>, <a href=\"https://profiles.wordpress.org/trishasalas\">trishasalas</a>, <a href=\"https://profiles.wordpress.org/tywayne\">Ty Carlson</a>, <a href=\"https://profiles.wordpress.org/uamv\">UaMV</a>, <a href=\"https://profiles.wordpress.org/desaiuditd\">Udit Desai</a>, <a href=\"https://profiles.wordpress.org/sorich87\">Ulrich Sossou</a>, <a href=\"https://profiles.wordpress.org/veritaserum\">Veritaserum</a>, <a href=\"https://profiles.wordpress.org/voldemortensen\">voldemortensen</a>, <a href=\"https://profiles.wordpress.org/volodymyrc\">VolodymyrC</a>, <a href=\"https://profiles.wordpress.org/vortfu\">vortfu</a>, <a href=\"https://profiles.wordpress.org/welcher\">welcher</a>, <a href=\"https://profiles.wordpress.org/westonruter\">Weston Ruter</a>, <a href=\"https://profiles.wordpress.org/earnjam\">William Earnhardt</a>, <a href=\"https://profiles.wordpress.org/willstedt\">willstedt</a>, and <a href=\"https://profiles.wordpress.org/wordpressorru\">WordPressor</a>.
<p style=\"margin-top: 22px\">Special thanks go to <a href=\"http://siobhanmckeown.com/\">Siobhan McKeown</a> for producing the release video and <a href=\"http://camikaos.com/\">Cami Kaos</a> for the voice-over.</p>
<p>Finally, thanks to all of the contributors who provided subtitles for the release video, which at last count had been translated into 30 languages!</p>
<p><a href=\"https://profiles.wordpress.org/adrianpop\">Adrian Pop</a>, <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/bagerathan\">Bagerathan Sivarajah</a>, <a href=\"https://profiles.wordpress.org/besnik\">Besnik</a>, <a href=\"https://profiles.wordpress.org/bjornjohansen\">Bjørn Johansen</a>, Chantal Coolsma, <a href=\"https://profiles.wordpress.org/cubells\">cubells</a>, Daisuke Takahashi, <a href=\"https://profiles.wordpress.org/dianakc\">Diana K. Cury</a>, <a href=\"https://profiles.wordpress.org/djzone\">DjZoNe</a>, <a href=\"https://profiles.wordpress.org/dyrer\">dyrer</a>, <a href=\"https://profiles.wordpress.org/semblance\">Elzette Roelofse</a>, <a href=\"https://profiles.wordpress.org/wordpress-tr\">Emre Erkan</a>, <a href=\"https://profiles.wordpress.org/fxbenard\">fxbenard</a>, <a href=\"https://profiles.wordpress.org/tacoverdo\">TacoVerdo</a>, <a href=\"https://profiles.wordpress.org/gabriel-reguly\">Gabriel Reguly</a>, <a href=\"https://profiles.wordpress.org/miss_jwo\">Jenny Wong</a>, <a href=\"https://profiles.wordpress.org/garyj\">Gary Jones</a>, <a href=\"https://profiles.wordpress.org/hgmb\">Håvard Grimelid</a>, <a href=\"https://profiles.wordpress.org/intoxstudio\">Joachim Jensen</a>, <a href=\"https://profiles.wordpress.org/jimmyxu\">Jimmy Xu</a>, <a href=\"https://profiles.wordpress.org/nukaga\">Junko Nukaga</a>, <a href=\"https://profiles.wordpress.org/pokeraitis\">Justina</a>, <a href=\"https://profiles.wordpress.org/kenan3008/\">Kenan Dervisevic</a>, <a href=\"https://profiles.wordpress.org/kosvrouvas\">Kostas Vrouvas</a>, <a href=\"https://profiles.wordpress.org/eclare\">Krzysztof Trynkiewicz</a>, <a href=\"https://profiles.wordpress.org/goblindegook\">Luís Rodrigues</a>, <a href=\"https://profiles.wordpress.org/luisrull\">Luis Rull</a>, <a href=\"https://profiles.wordpress.org/culturemark\">Mark Thomas Gazel </a>, <a href=\"https://profiles.wordpress.org/clorith\">Marius Jensen</a>, <a href=\"https://profiles.wordpress.org/matthee\">matthee</a>, <a href=\"https://profiles.wordpress.org/damst\">Mattias Tengblad</a>, Matúš Záhradník, Mayuko Moriyama, <a href=\"https://profiles.wordpress.org/michalvittek\">Michal Vittek</a>, <a href=\"https://profiles.wordpress.org/dimadin\">Milan Dinić</a>, <a href=\"https://profiles.wordpress.org/mrshemek\">MrShemek</a>, <a href=\"https://profiles.wordpress.org/Nao\">Naoko Takano</a>, <a href=\"https://profiles.wordpress.org/pavelevap\">pavelevap</a>, <a href=\"https://profiles.wordpress.org/peterhoob\">Peter Holme Obrestad</a>, <a href=\"https://profiles.wordpress.org/petya\">Petya Raykovska</a>, Przemysław Mirota, <a href=\"https://profiles.wordpress.org/qraczek\">qraczek</a>, <a href=\"https://profiles.wordpress.org/bi0xid\">Rafa Poveda</a>, <a href=\"https://profiles.wordpress.org/ramiy\">Rami Yushuvaev</a>, <a href=\"https://profiles.wordpress.org/rasheed\">Rasheed Bydousi</a>, <a href=\"https://profiles.wordpress.org/gwgan\">Rhoslyn Prys</a>, <a href=\"https://profiles.wordpress.org/robee\">Robert Axelsen</a>, <a href=\"https://profiles.wordpress.org/sergeybiryukov\">Sergey Biryukov</a>, <a href=\"https://profiles.wordpress.org/siobhyb\">Siobhan Bamber</a>, <a href=\"https://profiles.wordpress.org/netweb\">Stephen Edgar</a>, <a href=\"https://profiles.wordpress.org/tohave\">ک To Have داشتن</a>, <a href=\"https://profiles.wordpress.org/zodiac1978\">Torsten Landsiedel</a>, <a href=\"https://profiles.wordpress.org/egalego\">Victor J. Quesada</a>, <a href=\"https://profiles.wordpress.org/wolly\">Wolly</a>, <a href=\"https://profiles.wordpress.org/xavivars\">Xavi Ivars</a>, <a href=\"https://profiles.wordpress.org/xibe\">Xavier Borderie</a></p>
<p>If you want to follow along or help out, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/core/\">core development blog</a>. Thanks for choosing WordPress. See you soon for version 4.3!</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"https://wordpress.org/news/2015/04/powell/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"WordPress 4.1.2 Security Release\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 21 Apr 2015 13:44:58 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3628\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:383:\"WordPress 4.1.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by Cedric Van Bockhaven and fixed by [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Gary Pendergast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:3913:\"<p>WordPress 4.1.2 is now available. This is a <strong>critical security release</strong> for all previous versions and we strongly encourage you to update your sites immediately.</p>
<p>WordPress versions 4.1.1 and earlier are affected by a critical cross-site scripting vulnerability, which could enable anonymous users to compromise a site. This was reported by <a href=\"https://cedricvb.be\">Cedric Van Bockhaven</a> and fixed by <a href=\"http://pento.net/\">Gary Pendergast</a>, <a href=\"http://blogwaffe.com/\">Mike Adams</a>, and <a href=\"http://nacin.com/\">Andrew Nacin</a> of the WordPress security team.</p>
<p>We also fixed three other security issues:</p>
<ul>
<li>In WordPress 4.1 and higher, files with invalid or unsafe names could be uploaded. Discovered by <a href=\"http://HSASec.de\">Michael Kapfer and Sebastian Kraemer of HSASec</a>.</li>
<li>In WordPress 3.9 and higher, a very limited cross-site scripting vulnerability could be used as part of a social engineering attack. Discovered by <a href=\"http://zoczus.blogspot.com/\">Jakub Zoczek</a>.</li>
<li>Some plugins were vulnerable to an SQL injection vulnerability. Discovered by Ben Bidner of the WordPress security team.</li>
</ul>
<p>We also made four hardening changes, discovered by <a href=\"http://codesymphony.co/\">J.D. Grimes</a>, Divyesh Prajapati, <a href=\"http://www.allancollins.net/\">Allan Collins</a>, <a href=\"https://sucuri.net/\">Marc-Alexandre Montpas</a> and <a href=\"https://profiles.wordpress.org/jblz\">Jeff Bowen</a>.</p>
<p>We appreciated the <a href=\"https://make.wordpress.org/core/handbook/reporting-security-vulnerabilities/\">responsible disclosure</a> of these issues directly to our security team. For more information, see the <a href=\"https://codex.wordpress.org/Version_4.1.2\">release notes</a> or consult the <a href=\"https://core.trac.wordpress.org/log/branches/4.1?rev=32234&amp;stop_rev=32144\">list of changes</a>.</p>
<p><a href=\"https://wordpress.org/download/\">Download WordPress 4.1.2</a> or venture over to <strong>Dashboard → Updates</strong> and simply click &#8220;Update Now.&#8221; Sites that support automatic background updates are already beginning to update to WordPress 4.1.2.</p>
<p>Thanks to everyone who contributed to 4.1.2: <a href=\"https://profiles.wordpress.org/collinsinternet\">Allan Collins</a>, <a href=\"https://profiles.wordpress.org/xknown\">Alex Concha</a>, <a href=\"https://profiles.wordpress.org/nacin\">Andrew Nacin</a>, <a href=\"https://profiles.wordpress.org/azaozz\">Andrew Ozz</a>, <a href=\"https://profiles.wordpress.org/vortfu\">Ben Bidner</a>, <a href=\"https://profiles.wordpress.org/boonbgorges\">Boone Gorges</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/DrewAPicture\">Drew Jaynes</a>, <a href=\"https://profiles.wordpress.org/pento\">Gary Pendergast</a>, <a href=\"https://profiles.wordpress.org/helen\">Helen Hou-Sandí</a>, <a href=\"https://profiles.wordpress.org/johnbillion\">John Blackbourn</a>, and <a href=\"https://profiles.wordpress.org/mdawaffe\">Mike Adams</a>.</p>
<p>A number of plugins also released security fixes yesterday. Keep everything updated to stay secure. If you’re a plugin author, please read <a href=\"https://make.wordpress.org/plugins/2015/04/20/fixing-add_query_arg-and-remove_query_arg-usage/\">this post</a> to confirm that your plugin is not affected by the same issue. Thank you to all of the plugin authors who worked closely with our security team to ensure a coordinated response.</p>
<p><em>Already testing WordPress 4.2? The third release candidate is now available (<a href=\"https://wordpress.org/wordpress-4.2-RC3.zip\">zip</a>) and it contains these fixes. For more on 4.2, see <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/\">the RC 1 announcement post</a>.</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-1-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"WordPress 4.2 Release Candidate\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 15 Apr 2015 19:07:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3609\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:334:\"The release candidate for WordPress 4.2 is now available. We&#8217;ve made more than 140 changes since releasing Beta 4 a week and a half ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.2 on Wednesday, [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2328:\"<p>The release candidate for WordPress 4.2 is now available.</p>
<p>We&#8217;ve made more than <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=32136&amp;stop_rev=31996&amp;limit=100\">140 changes</a> since releasing Beta 4 a week and a half ago. RC means we think we’re done, but with millions of users and thousands of plugins and themes, it’s possible we’ve missed something. We hope to ship WordPress 4.2 on <strong>Wednesday, April 22</strong>, but we need your help to get there.</p>
<p>If you haven’t tested 4.2 yet, now is the time! (Please though, not on your live site unless you’re adventurous.)</p>
<p><strong>Think you&#8217;ve found a bug?</strong> Please post to the <a href=\"https://wordpress.org/support/forum/alphabeta/\">Alpha/Beta support forum</a>. If any known issues come up, you&#8217;ll be able to <a href=\"https://core.trac.wordpress.org/report/5\">find them here</a>.</p>
<p>To test WordPress 4.2 RC1, you can use the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin or you can <a href=\"https://wordpress.org/wordpress-4.2-RC1.zip\">download the release candidate here</a> (zip). </p>
<p>For more information about what’s new in version 4.2, check out the <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/\">Beta 2</a>, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/\">Beta 3</a>, and <a href=\"https://wordpress.org/news/2015/04/wordpress-4-2-beta-4/\">Beta 4</a> blog posts.</p>
<p><strong>Developers</strong>, please test your plugins and themes against WordPress 4.2 and update your plugin&#8217;s <em>Tested up to</em> version in the readme to 4.2 before next week. If you find compatibility problems, we never want to break things, so please be sure to post to the support forums so we can figure those out before the final release.</p>
<p>Be sure to <a href=\"https://make.wordpress.org/core/\">follow along the core development blog</a>, where we&#8217;ll continue to post <a href=\"https://make.wordpress.org/core/tag/4-2-dev-notes/\">notes for developers</a> for 4.2.</p>
<p><em>Im-Press-ive saving</em><br />
<em>Achievement unlocked: RC</em><br />
<em>Release here we come</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"https://wordpress.org/news/2015/04/wordpress-4-2-release-candidate/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:42:\"
		
		
		
		
		
				

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Improvements to WordPress.org\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 04 Apr 2015 20:19:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Meta\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3494\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:335:\"If you visit WordPress.org regularly you might have noticed some changes around the place. If you don’t, now’s the time to check them out! We’ve been working hard to improve the site to make it more useful to everyone, both developers and users, and we hope you like what we’ve done. New Theme and Plugin Directories [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Samuel Sidler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:5551:\"<p>If you visit WordPress.org regularly you might have noticed some changes around the place. If you don’t, now’s the time to check them out! We’ve been working hard to improve the site to make it more useful to everyone, both developers and users, and we hope you like what we’ve done.</p>
<h2>New Theme and Plugin Directories</h2>
<p>Since WordPress 3.8, you’ve been enjoying improved theme management in your WordPress admin, and in WordPress 4.0 plugin management was refined. We’ve brought these experiences from your admin and re-created them right here on WordPress.org.</p>
<h3>Theme Directory</h3>
<p>The <a href=\"https://wordpress.org/themes/\">Theme Directory</a> has a better browsing experience, with handy tabs where you can view featured, popular, and the latest themes. As with the theme experience in your admin, you can use the feature filter to browse for just the right theme for your WordPress website.</p>
<p><img class=\"alignnone size-large wp-image-3572\" src=\"https://wordpress.org/news/files/2015/04/theme-directory-1024x768.png\" alt=\"theme-directory\" width=\"692\" height=\"519\" /></p>
<p>Click on a theme to get more information about it, including shiny screenshots, ratings, and statistics.</p>
<p><img class=\"alignnone size-large wp-image-3573\" src=\"https://wordpress.org/news/files/2015/04/theme-directory-individual-1024x768.png\" alt=\"theme-directory-individual\" width=\"692\" height=\"519\" /></p>
<p>Konstantin Obenland <a href=\"https://make.wordpress.org/meta/2015/03/10/new-theme-directory/\">posted a good overview</a> of everything involved with the theme directory overhaul and followed up with <a href=\"https://make.wordpress.org/meta/2015/03/31/theme-directory-stats/\">a post on improved statistics</a>.</p>
<h3>Plugin Directory</h3>
<p>The <a href=\"https://wordpress.org/plugins/\">Plugin Directory</a> has a brand new theme that mirrors the experience in your WordPress admin, with a more visual experience, and better search and statistics.</p>
<p><img class=\"alignnone size-large wp-image-3594\" src=\"https://wordpress.org/news/files/2015/04/plugin-directory-1024x768.png\" alt=\"plugin-directory\" width=\"692\" height=\"519\" /></p>
<p>As well as a facelift, there are some great new features for you to play around with:</p>
<ul>
<li>Favorites – when you’re logged in to you WordPress.org account, this page gives you direct access to the plugins that you have favorited.</li>
<li>Beta Testing – try out plugins where developers are experimenting with new features for WordPress.</li>
<li>Search by plugin author – you can search for a plugin author using their username.</li>
<li>Better statistics – listings now display the number of active installs so you can see how many people are actually using a plugin.</li>
</ul>
<p>An <a href=\"https://make.wordpress.org/meta/2015/03/04/new-plugin-directory-theme/\">overview of the new theme</a> was posted by Scott Reilly.</p>
<h2>Better Statistics</h2>
<p>We’ve made huge improvements to <a href=\"https://wordpress.org/about/stats/\">our statistics</a>. This gives us more useful information about the WordPress versions people are using, their PHP version, and their MySQL version.</p>
<p>Already these new statistics have provided us with useful insights into WordPress usage.</p>
<ul>
<li>More than 43% of all sites are running the latest version of WordPress. Previously, we thought only 10% of sites were up-to-date. By excluding sites that are no longer online we were able to improve these statistics.</li>
<li>We were able to clear up the data around WordPress 3.0, bringing it more in line with expectations. This anomaly was a by-product of spammers.</li>
<li>Only 15.9% of sites are using PHP 5.2, which is better than we thought.</li>
</ul>
<p>Over the coming months we’ll be able to use these statistics to bring you new tools and improvements, and to make more informed decisions across the board. Read <a href=\"https://make.wordpress.org/meta/2015/03/01/major-update-to-our-version-stats-for-php-mysql-and-wordpress/\">Andrew Nacin&#8217;s post about these changes</a> for more background.</p>
<h2>Thanks!</h2>
<p>Thanks to everyone who contributed to the theme directory redesign, the plugin directory refresh, and improved statistics: <a href=\"https://profiles.wordpress.org/deconf\">Alin Marcu</a>, <a href=\"https://profiles.wordpress.org/colorful-tones/\">Damon Cook</a>, <a href=\"https://profiles.wordpress.org/dd32\">Dion Hulse</a>, <a href=\"https://profiles.wordpress.org/ocean90\">Dominik Schilling</a>, <a href=\"https://profiles.wordpress.org/mj12982\">Jan Cavan Boulas</a>, <a href=\"https://profiles.wordpress.org/obenland\">Konstantin Obenland</a>, <a href=\"https://profiles.wordpress.org/BrashRebel\">Kyle Maurer</a>, <a href=\"https://profiles.wordpress.org/matveb\">Matías Ventura</a>, <a href=\"https://profiles.wordpress.org/melchoyce\">Mel Choyce</a>, <a href=\"https://profiles.wordpress.org/nataliemac\">Natalie MacLees</a>, <a href=\"https://profiles.wordpress.org/pauldewouters\">Paul de Wouters</a>, <a href=\"https://profiles.wordpress.org/samuelsidler\">Samuel Sidler</a>, <a href=\"https://profiles.wordpress.org/Otto42\">Samuel Wood (Otto)</a>, <a href=\"https://profiles.wordpress.org/coffee2code\">Scott Reilly</a>, <a href=\"https://profiles.wordpress.org/siobhan\">Siobhan McKeown</a>.</p>
<p>If you want to help out or follow along with future WordPress.org projects, check out <a href=\"https://make.wordpress.org/\">Make WordPress</a> and our <a href=\"https://make.wordpress.org/meta/\">meta development blog</a>.</p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"https://wordpress.org/news/2015/04/improvements-to-wordpress-org/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.2 Beta 4\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/04/wordpress-4-2-beta-4/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/04/wordpress-4-2-beta-4/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 03 Apr 2015 13:05:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3566\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.2 Beta 4 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2694:\"<p>WordPress 4.2 Beta 4 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.2-beta4.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.2, check out the <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\">Beta 1</a>, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/\">Beta 2</a>, and <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/\">Beta 3</a> blog posts. Some of the changes in Beta 4 include:</p>
<ul>
<li>Incrementally improved the experience when <strong>accessing the Customizer on mobile</strong>. Please test on your mobile devices and let us know if anything seems wonky.</li>
<li>Added the ability to make <strong>admin notices dismissible</strong>. Plugin and theme authors: adding <code>.notice</code> and <code>.is-dismissible</code> as adjacent classes to your notice containers should automatically make them dismissible. Please test.</li>
<li>Fixed some reported issues with <strong>backward-compatibility issues</strong> caused by the modularization of core JS files.</li>
<li>Removed the <strong>ability to swipe the admin menu open and closed</strong> on touch devices due to reports of some issues with built-in history navigation on certain platforms.</li>
<li>Improved <strong>accessibility of the WordPress admin</strong> by adding landmark roles. Screen reader users: please test in any core admin screens.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=31996&amp;stop_rev=31902&amp;limit=100\">more than 90 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.2\">everything we’ve fixed</a>.</p>
<p><em>Dismiss notices</em><br />
<em>Customizer on mobile</em><br />
<em>RC nearly here</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/04/wordpress-4-2-beta-4/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.2 Beta 3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 26 Mar 2015 18:32:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3522\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.2 Beta 3 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2986:\"<p>WordPress 4.2 Beta 3 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.2-beta3.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.2, check out the <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\">Beta 1</a> and <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/\">Beta 2</a> blog posts. Some of the changes in Beta 3 include:</p>
<ul>
<li>Removed <strong>Shiny Installs</strong> functionality due to concerns about the activation workflow. Please test the remaining &#8220;Shiny Updates&#8221; functionality from both the Plugins &gt; Add New and Plugins screens to ensure in-line updating still works as well as before.</li>
<li>Fixed an issue with the <strong>Comments Quick Edit</strong> layout breaking on smaller screens. Please test on your mobile devices.</li>
<li>Improved <strong>accessibility of login screen errors</strong>. Screen reader users: please let us know if you encounter any issues.</li>
<li>Refined the <strong>emoji compatibility</strong> script to only load on the front- and back-end if the browser requires it. If you&#8217;re using a legacy web browser, please test.</li>
<li>Fixed several issues in <strong>Press This</strong> with inserted images being improperly linked to locations other than the source site. Go ahead, &#8220;press&#8221; a site with images on the page and tell us if the image links aren&#8217;t working as you&#8217;d expect.</li>
<li>Standardized the <strong>time display format</strong> in a variety of admin screens, switching to 24-hour notation where a.m. or p.m. are not specified. Please let us know if you notice you notice anything amiss!</li>
<li><strong>Various other bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=31901&amp;stop_rev=31835&amp;limit=100\">more than 65 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.2\">everything we’ve fixed</a>.</p>
<p><em>Emoji loader</em><br />
<em>&#8220;Shiny Updates&#8221; still stand firm</em><br />
<em>Beta 3, please test!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-3/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.2 Beta 2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 19 Mar 2015 19:30:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3498\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:337:\"WordPress 4.2 Beta 2 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:2326:\"<p>WordPress 4.2 Beta 2 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want &#8220;bleeding edge nightlies&#8221;). Or you can <a href=\"https://wordpress.org/wordpress-4.2-beta2.zip\">download the beta here</a> (zip).</p>
<p>For more information about what’s new in version 4.2, <a href=\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\">check out the Beta 1 blog post</a>. Some of the changes in Beta 2 include:</p>
<ul>
<li>Added support for entering FTP and SSH credentials when <strong>updating plugins in-place</strong>. FTP and SSH users, please test!</li>
<li><strong>Improved cross-browser support for emoji</strong> throughout WordPress. If you&#8217;re using an older web browser, please tell us if you have problems using emoji.</li>
<li>Further <strong>refined Press This authoring</strong> with auto-embedded media and better content scanning. We&#8217;d love to know how auto-embeds work for you.</li>
<li>Added a constructor and improved method consistency in <code>WP_Comment_Query</code>. Developers: if you&#8217;re extending <code>WP_Comment_Query</code>, please let us know if you run into any issues.</li>
<li><strong>Various bug fixes</strong>. We&#8217;ve made <a href=\"https://core.trac.wordpress.org/log?action=stop_on_copy&amp;mode=stop_on_copy&amp;rev=31834&amp;stop_rev=31763&amp;limit=100\">more than 70 changes</a> in the last week.</li>
</ul>
<p>If you think you’ve found a bug, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. Or, if you’re comfortable writing a bug report, <a href=\"https://core.trac.wordpress.org/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.2\">everything we’ve fixed</a>.</p>
<p><em>Test some emoji</em><br />
<em>FTP and SSH</em><br />
<em>Let&#8217;s &#8220;Press&#8221; some embeds!</em></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-2/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:48:\"
		
		
		
		
		
				
		
		

		
		
				
			
		
		\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:5:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"WordPress 4.2 Beta 1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:65:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/#comments\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 12 Mar 2015 23:22:52 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"category\";a:3:{i:0;a:5:{s:4:\"data\";s:11:\"Development\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:1;a:5:{s:4:\"data\";s:8:\"Releases\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}i:2;a:5:{s:4:\"data\";s:3:\"4.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"http://wordpress.org/news/?p=3446\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:329:\"WordPress 4.2 Beta 1 is now available! This software is still in development, so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the WordPress Beta Tester plugin (you’ll want “bleeding edge nightlies”). Or you can [&#8230;]\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Drew Jaynes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:40:\"http://purl.org/rss/1.0/modules/content/\";a:1:{s:7:\"encoded\";a:1:{i:0;a:5:{s:4:\"data\";s:4275:\"<p>WordPress 4.2 Beta 1 is now available!</p>
<p><strong>This software is still in development,</strong> so we don’t recommend you run it on a production site. Consider setting up a test site just to play with the new version. To test WordPress 4.2, try the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\">WordPress Beta Tester</a> plugin (you’ll want “bleeding edge nightlies”). Or you can <a href=\"https://wordpress.org/wordpress-4.2-beta1.zip\">download the beta here</a> (zip).</p>
<p>4.2 is due out next month, but to get there, we need your help testing what we&#8217;ve been working on:</p>
<ul>
<li><strong>Press This</strong> has been completely revamped to make sharing content from around the web easier than ever. The new workflow is mobile friendly, and we&#8217;d love for you to try it out on all of your devices. Navigate to the Tools screen in your WordPress backend to get started (<a href=\"https://core.trac.wordpress.org/ticket/31373\">#31373</a>). </li>
<li><strong>Browsing and switching installed themes</strong> has been added to the Customizer to make switching faster and more convenient. We&#8217;re especially interested to know if this helps streamline the process of setting up your site (<a href=\"https://core.trac.wordpress.org/ticket/31303\">#31303</a>).</li>
<li>The workflow for <strong>updating and installing plugins</strong> just got more intuitive with the ability to install or update in-place from the Plugins screens. Try it out and let us know what you think! (<a href=\"https://core.trac.wordpress.org/ticket/29820\">#29820</a>)</li>
<li>If you felt like <strong>emoji</strong> were starkly missing from your content toolbox, worry no more. We&#8217;ve added emoji support nearly everywhere, even post slugs <img src=\"https://s.w.org/images/core/emoji/72x72/1f44d.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /> (<a href=\"https://core.trac.wordpress.org/ticket/31242\">#31242</a>).</li>
</ul>
<p><strong>Developers</strong>: There have been a lot of changes for you to test as well, including:</p>
<ul>
<li><strong>Taxonomy Roadmap:</strong> Terms shared across multiple taxonomies will <a href=\"https://make.wordpress.org/core/2015/02/16/taxonomy-term-splitting-in-4-2-a-developer-guide/\">now be split</a> into separate terms when one of them is updated. Please let us know if you hit any snags (<a href=\"https://core.trac.wordpress.org/ticket/5809/\">#5809</a>).</li>
<li>New <code>wp.a11y.speak()</code> functionality helps your JavaScript talk to screen readers to better inform impaired users what&#8217;s happening on-screen. Try it out in your plugin or theme and let us know if you notice any adverse affects (<a href=\"https://core.trac.wordpress.org/ticket/31368/\">#31368</a>).</li>
<li>Named clause support has been added to <code>WP_Query</code>, <code>WP_Comment_Query</code>, and <code>WP_User_Query</code>, allowing specific <code>meta_query</code> clauses to be used with <code>orderby</code>. If you have any complex queries, please test them (<a href=\"https://core.trac.wordpress.org/ticket/31045/\">#31045</a>, <a href=\"https://core.trac.wordpress.org/ticket/31265/\">#31265</a>).</li>
</ul>
<p>If you want a more in-depth view of what changes have made it into 4.2, <a href=\"https://make.wordpress.org/core/tag/week-in-core/\">check out the weekly review posts</a> on the main development blog.</p>
<p><strong>If you think you’ve found a bug</strong>, you can post to the <a href=\"https://wordpress.org/support/forum/alphabeta\">Alpha/Beta area</a> in the support forums. We’d love to hear from you! If you’re comfortable writing a reproducible bug report, <a href=\"https://make.wordpress.org/core/reports/\">file one on the WordPress Trac</a>. There, you can also find <a href=\"https://core.trac.wordpress.org/tickets/major\">a list of known bugs</a> and <a href=\"https://core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.2\">everything we’ve fixed</a> so far.</p>
<p>Happy testing!</p>
<p><em>Press This: switch a theme</em><br />
<em>Save time installing plugins</em><br />
<em>Testing makes us</em> <img src=\"https://s.w.org/images/core/emoji/72x72/1f603.png\" alt=\"????\" class=\"wp-smiley\" style=\"height: 1em; max-height: 1em;\" /></p>
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:36:\"http://wellformedweb.org/CommentAPI/\";a:1:{s:10:\"commentRss\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/news/2015/03/wordpress-4-2-beta-1/feed/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:38:\"http://purl.org/rss/1.0/modules/slash/\";a:1:{s:8:\"comments\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"0\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:32:\"https://wordpress.org/news/feed/\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:44:\"http://purl.org/rss/1.0/modules/syndication/\";a:2:{s:12:\"updatePeriod\";a:1:{i:0;a:5:{s:4:\"data\";s:6:\"hourly\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:15:\"updateFrequency\";a:1:{i:0;a:5:{s:4:\"data\";s:1:\"1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:9:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Mon, 15 Jun 2015 19:42:56 GMT\";s:12:\"content-type\";s:34:\"application/rss+xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:10:\"x-pingback\";s:37:\"https://wordpress.org/news/xmlrpc.php\";s:13:\"last-modified\";s:29:\"Thu, 28 May 2015 13:55:13 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("114","_transient_timeout_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1434440576","no");
INSERT INTO `arc1542_options` VALUES("115","_transient_feed_mod_ac0b00fe65abe10e0c5b588f3ed8c7ca","1434397376","no");
INSERT INTO `arc1542_options` VALUES("116","_transient_timeout_feed_d117b5738fbd35bd8c0391cda1f2b5d9","1434440581","no");
INSERT INTO `arc1542_options` VALUES("117","_transient_feed_d117b5738fbd35bd8c0391cda1f2b5d9","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"


\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:61:\"
	
	
	
	




















































\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"WordPress Planet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:2:\"en\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"WordPress Planet - http://planet.wordpress.org/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:50:{i:0;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"WPTavern: o2 is Now Available on GitHub\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45188\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"http://wptavern.com/o2-is-now-available-on-github\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3618:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/o2-on-github.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/o2-on-github.png?resize=1025%2C536\" alt=\"o2-on-github\" class=\"aligncenter size-full wp-image-45205\" /></a></p>
<p>This weekend at WordCamp Denver, <a href=\"https://twitter.com/alternatekev\" target=\"_blank\">Kevin Conboy</a> announced that Automattic&#8217;s <a href=\"http://wptavern.com/o2-wordpress-plugin-expected-to-be-available-in-early-2014\" target=\"_blank\">long-awaited O2 project</a> is now publicly <a href=\"https://github.com/Automattic/o2\" target=\"_blank\">available on GitHub</a>. In a recent interview with WP Tavern, Matt Mullenweg confirmed that the o2 development team is <a href=\"http://wptavern.com/o2-development-team-shifts-focus-to-wordpress-coms-core-products\" target=\"_blank\">shifting its focus to WordPress.com&#8217;s core products</a> but that the o2 code would be public for anyone to use.</p>
<p>o2 was is the successor to <a href=\"https://wordpress.org/themes/p2/\" target=\"_blank\">P2</a>, the innovative group blogging theme created to power communications at Automattic. P2 was <a href=\"http://wptavern.com/p2-officially-on-the-theme-repository\" target=\"_blank\">released in 2009</a> with the tagline &#8220;Blogging at the speed of thought.&#8221; It introduced quick posting from the front page and real-time updates.</p>
<p>o2 shares P2&#8217;s tagline but, unlike its predecessor, it was created to be a plugin that is not dependent on a specific theme.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/devinsays\">@devinsays</a> <a href=\"https://twitter.com/michaelarestad\">@michaelarestad</a> that\'s the theory!</p>
<p>&mdash; Kevin Conboy (@alternatekev) <a href=\"https://twitter.com/alternatekev/status/610413606446825473\">June 15, 2015</a></p></blockquote>
<p></p>
<p>However, it&#8217;s not guaranteed to work with any theme, so if you want the best experience you should test it out with the <a href=\"https://wpcom-themes.svn.automattic.com/p2-breathe\" target=\"_blank\">p2-breathe theme</a>, as recommended in the GitHub installation instructions. o2 requires the <a href=\"https://wordpress.org/plugins/genericond/\" target=\"_blank\">Genericon&#8217;d</a> plugin and if you want the ability to insert code blocks, it requires the <a href=\"https://wordpress.org/plugins/syntaxhighlighter/\" target=\"_blank\">SyntaxHighlighter Evolved</a> plugin.</p>
<p>The readme.txt on GitHub cautions that &#8220;multisite self-hosted installs have not yet been tested and may not work.&#8221; Although the plugin was written to shine within a network environment with cross-site search and cross-site posting, the network features are not guaranteed to work for self-hosted users. However, the improved real-time commenting, drag-and-drop media upload, and other enhancements may make using O2 worthwhile on single site WordPress installations.</p>
<p>A cursory look at the issues queue indicates that some of the features that work on WordPress.com may still be buggy for self-hosted installations, such as <a href=\"https://github.com/Automattic/o2/issues/3\" target=\"_blank\">@mentions in posts in comments</a>. The good news for those who were eagerly awaiting o2&#8217;s release is that the code, while not completely polished and bug-free, is now <a href=\"https://github.com/Automattic/o2\" target=\"_blank\">public on GitHub</a>. Even though Automattic is shifting its focus away from the project, anyone who wants to help improve it can submit a pull request or fork o2 for their own use.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 15 Jun 2015 17:30:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"Matt: Priceless Words\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45151\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"http://ma.tt/2015/06/priceless-words/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:405:\"<blockquote><p>“It&#8217;s easy to be very busy but not get anything done that you&#8217;ll look back a year from now and say was worthwhile.”</p>
<p>“You&#8217;ll get a lot of contradictory advice, and often neither side is wrong.”</p></blockquote>
<p>Entrepreneur.com <a href=\"http://www.entrepreneur.com/article/246745\">collected a few quotes from me and blogged some context for each</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 15 Jun 2015 01:25:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:37:\"Matt: How Tesla Will Change The World\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45149\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"http://ma.tt/2015/06/how-tesla-will-change-the-world/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:149:\"<p><a href=\"http://waitbutwhy.com/2015/06/how-tesla-will-change-your-life.html\">How Tesla Will Change The World</a> from the great Wait But Why.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 13 Jun 2015 23:25:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Matt: Munchery Eating the World\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45143\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:47:\"http://ma.tt/2015/06/munchery-eating-the-world/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"<p>Shervin has an amazing write-up on <a href=\"https://medium.com/@shervin/how-munchery-is-literally-eating-the-world-218c6520dc99\">how Munchery is literally eating the world</a>, and Sherpa&#8217;s continuing investment there. If you haven&#8217;t tried <a href=\"https://munchery.com/\">Munchery</a> yet they&#8217;re now in San Francisco, Los Angeles, Seattle, and New York.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 13 Jun 2015 03:31:21 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:26:\"Post Status: What is Code?\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=13013\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"https://poststatus.com/what-is-code/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:16332:\"<p>Today I read perhaps the single best article I&#8217;ve ever read on programming.</p>
<p><a href=\"http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/\">Paul Ford has written the definitive guide</a> for explaining a profession that employs 11 million people and occupies 7 million more hobbyists&#8217; time by answering the question, &#8220;What is code?&#8221;</p>
<p>He wrote the article for everyone, he says, but specifically he wrote it for the editor of Bloomberg. Whether you&#8217;re a programmer already, in a business where you work with programmers, or just want to learn a bit more about the thousands of frameworks for 0s and 1s that run our world, I think the article is for you.</p>
<p>It&#8217;s not fair to attempt a summary of the many points Paul makes, but I&#8217;ll highlight some of my favorite passages and also summarize some of the topics he covers. However, I can not offer each point the justice they deserve, so honestly if you really want the best experience, read the original and not this.</p>
<p>The <em>only</em> benefit of my article is that at just over 2,000 words it&#8217;s 5% of the length of the original. I&#8217;d encourage everyone to read the entire article. I&#8217;m sure I&#8217;ll share it individually hundreds of times in my future.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Here is MY three-word summary of my article for busy people: Reevaluate your life.</p>
<p>&mdash; Paul Ford (@ftrain) <a href=\"https://twitter.com/ftrain/status/609374405727268864\">June 12, 2015</a></p></blockquote>
<p></p>
<p>Are you still not convinced to commit to it? Okay, fine. Here are my favorite parts:</p>
<h3>Where is code?</h3>
<p>While the entire article answers, &#8220;What is code?&#8221;, he starts by answering, &#8220;Where is code?&#8221; Code is much broader than the web. It&#8217;s pervasive. Everywhere.</p>
<blockquote><p>Most programmers aren’t working on building a widely recognized application like Microsoft Word. Software is everywhere. It’s gone from a craft of fragile, built-from-scratch custom projects to an industry of standardized parts, where coders absorb and improve upon the labors of their forebears (even if those forebears are one cubicle over). Software is there when you switch channels and your cable box shows you what else is on. You get money from an ATM—software. An elevator takes you up five stories—the same. Facebook releases software every day to something like a billion people, and that software runs inside Web browsers and mobile applications. Facebook looks like it’s just pictures of your mom’s crocuses or your son’s school play—but no, it’s software.</p></blockquote>
<h3>Computers are dumb</h3>
<p><a href=\"http://waitbutwhy.com/2015/01/artificial-intelligence-revolution-1.html\">Until they&#8217;re not</a>. But today, computers really don&#8217;t know anything; they return things based on what we put in them, and they can do so many things faster than we can.</p>
<blockquote><p>Every character truly, truly matters. Every single stupid misplaced semicolon, space where you meant tab, bracket instead of a parenthesis—mistakes can leave the computer in a state of panic. The trees don’t know where to put their leaves. Their roots decay. The boxes don’t stack neatly. For not only are computers as dumb as a billion marbles, they’re also positively Stradivarian in their delicacy.</p></blockquote>
<h3>Programming languages</h3>
<p>Paul spends a ton of time talking about various programming languages, their origins, their styles, their adoptions, their usefulness, and how they&#8217;ve evolved.</p>
<p>He primarily focuses on C (and how it&#8217;s fast but not object oriented) and Java (and how it&#8217;s object oriented but not fast, relatively). Amazingly, he manages to talk about many, many languages, their attributes, and yet explain them in a way that nearly anyone can understand.</p>
<p>I have to admit something: I am so far from a classically trained developer that I found this focus of the article to be incredibly educational. I learned the wrong way, from the tip of the pyramid down. If you consider markup and styles the very tip, and then WordPress is a bit below that as a framework for PHP &#8212; and you are still only part way down the pyramid. PHP is built with C and C compiles to machine code. His article helped me understand the pyramid from the other direction much better.</p>
<h3>Programmer culture</h3>
<p>An important piece of the article was around culture. He spends time both on programmer attitudes and broader programming culture, such as conferences.</p>
<blockquote><p>Languages have agendas. People glom onto them. Blunt talk is seen as a good quality in a developer, a sign of an “engineering mindset”—spit out every opinion as quickly as possible, the sooner to reach a technical consensus. Expect to be told you’re wrong; expect to tell other people they’re wrong. (Masculine anger, bluntly expressed, is part of the industry.)</p>
<p>Coding is a culture of blurters. This can yield fast decisions, but it penalizes people who need to quietly compose their thoughts, rewarding fast-twitch thinkers who harrumph efficiently. Programmer job interviews, which often include abstract and meaningless questions that must be answered immediately on a whiteboard, typify this culture. Regular meetings can become sniping matches about things that don’t matter. The shorthand term for that is “bikeshedding.” (Who cares what color the bike shed is painted? Well …)</p>
<p>Code culture is very, very broad, but the geographic and cultural core is the Silicon Valley engine of progress. The Valley mythologizes young geniuses with vast sums. To its credit, this culture works; to its shame, it doesn’t work for everyone.</p>
<p>At any moment some new thing could catch fire and disrupt the tribal ebb and flow. Instagram was written in Python and sold for $2 billion, so Python had a moment of glory. The next mind-blowing app could show up, written in some new language—and start everyone taking that more seriously. Within 18 months your skills could be, if not quite valueless, suspect.</p>
<p>I was in a meeting once where someone said, “How long will it take to fix that?” One person, who’d been at the company for years, said, “Three months.” A new person, who’d just come from a world of rapidly provisioned cloud microservices, said, “Three minutes.” They were both correct. That’s how change enters into this world. Slowly at first, then on the front page of Hacker News.</p>
<p>Programmers carve out a sliver of cognitive territory for themselves and go to conferences, and yet they know their position is vulnerable. They get defensive when they hear someone suggest that Python is better than Ruby, because [insert 500-comment message thread here]. Is the next great wave swelling somewhere, and will it wash away Java when it comes? Will Go conquer Python? Do I need to learn JavaScript to remain profitable? Programmers are often angry because they’re often scared. We are, most of us, stumbling around with only a few candles to guide the way. We can’t always see the whole system, so we need to puzzle it out, bit by bit, in the dark.</p></blockquote>
<p>And his passage on the decreasing percentages of female coders is pure perfection:</p>
<blockquote><p>The average programmer is moderately diligent, capable of basic mathematics, has a working knowledge of one or more programming languages, and can communicate what he or she is doing to management and his or her peers. Given that a significant number of women work as journalists and editors, perform surgery, run companies, manage small businesses, and use spreadsheets, that a few even serve on the Supreme Court, and that we are no longer surprised to find women working as accountants, professors, statisticians, or project managers, it’s hard to imagine that they can’t write JavaScript. Programming, despite the hype and the self-serving fantasies of programmers the world over, isn’t the most intellectually demanding task imaginable.</p>
<p>Which leads one to the inescapable conclusion: The problem with women in technology isn’t the women.</p></blockquote>
<h3>PHP and (sorta) WordPress</h3>
<p>Of everything discussed in the article, the one thing I really could tell he didn&#8217;t appreciate much was PHP.</p>
<blockquote><p>You can get a site up and running in PHP in a few minutes, and that’s the problem. It used to be the terrible choice you made when you needed to get something done on the Web, but increasingly JavaScript has replaced it as the default terrible choice.</p>
<p>PHP stands for Personal Home Page/Forms Interpreter. The idea was that when you loaded your Web pages, the PHP code would run before the page went out to the Internet. And PHP could, say, check whether you were logged in. If you were, it could show you your top secret account details; and if you weren’t, it could say, “Please log in.”</p>
<p>I know a lot of people who program in PHP, and they are smart, good people. PHP powers Etsy and Facebook. It powers Wikipedia, for God’s sake. WordPress. Out of all the Web’s pages, an enormous percentage is created with PHP.</p>
<p>Coding in PHP for a living is not a death sentence. Lots of people have gotten rich off PHP. It just means a lot of cutting and pasting, and a lot of trips to Google to figure out why things aren’t working.</p>
<p>Poor, sad, misbegotten, incredibly effective, massively successful PHP. Reading PHP code is like reading poetry, the poetry you wrote freshman year of college.</p>
<p>I spent so many hundreds, maybe thousands, of hours programming in PHP, back when I didn’t know what I was doing and neither did PHP. Reloading Web pages until my fingers were sore. (I can hear your sympathetic sobs.) Everything was always broken, and people were always hacking into my sites.</p>
<p>PHP. I don’t wish it any harm. I’m glad to see how well it’s done for itself. We had some good times together. I just don’t ever want to go back there.</p></blockquote>
<p>He also uses WordPress as the punching bag for the story in the story. The fictional story within the article is of a company that&#8217;s replacing their current website with a new website. It&#8217;s a big corporate environment and they&#8217;re, &#8220;at the limits with WordPress.&#8221; Of course, <a href=\"http://ma.tt/2015/06/paul-ford-what-is-code-bloomberg/\">Matt Mullenweg took issue</a> with that one aspect on his own blog.</p>
<h3>Debugging, testing, and version control</h3>
<p>Paul gives some of the best layman&#8217;s descriptions for debugging, testing, and version control I&#8217;ve ever read. He closes the section with this:</p>
<blockquote><p>See, tests and version control are now the trigger for actually shipping code. If you can follow a process like this, you can release software several times a day—which in the days of shrink-wrapped software would have been folly. (Often builds were done nightly, by big “build servers,” and one would come in the next morning to get the score.) But now that software can be released via the Web or an app store, why wait? Why not continually release software, every day, whenever you have something that’s ready to go?</p></blockquote>
<h3>Actually picking a language</h3>
<p>It&#8217;s hard to limit this one and it was one of my favorite parts, so I&#8217;m just going to toss it in in bulk.</p>
<blockquote><p>Beware of arguments related to programming speed. All things being equal, faster is better. But all things are never equal. Do you need the kind of speed that lets you get a website up and running quickly? Or the kind that allows you to rotate a few thousand polygons in 3D in real time? Do you need to convert 10,000 PDFs into text per hour? Or 10 million PDFs into text once? These are different problems. What do we need to do, how many times do we need to do it, and what existing code can we use to help us do it that many times? Ask those questions.</p>
<p>It’s possible to spend productive months preparing for a project without deciding on a language. It may be the sign of a fine manager, someone who assumes his people can learn new things, someone who’s built an agile team capable of experimenting with new technologies and getting ideas into production. It could also be that this person is totally useless. You’ll find out!</p>
<p>Let’s say your programmers are developing a huge website that serves 5 million people who each visit five times a month. Do you use Python, which is slower, or Go, which is fast, or Node.js, which is something in-between? Trick question! Twenty-five million Web page visits isn’t that big a deal, unless they involve some deep wizardry or complex database queries that are very different for each page (good example: Facebook).</p>
<p>Now, that number isn’t trivial; if it takes a minute to make a page, you’d need 48 years to make that many, which is way too slow. If it takes a second to make a page, that’s still too slow—there are only 2.6 million seconds in a month. So you need to figure out how to serve about 10 pages per second. You’ll probably want more than one computer, a little redundancy, some good server setup. It will take some doing and planning. But it can be done in any language.</p>
<p>What if you are going to serve only a few hundred thousand pages a month? Then you’ve got tremendous breathing room. You don’t need too many engineers to create the system architecture. You still need to plan, but in general you can read some blog posts and follow along with what others have done. You can be pretty sloppy, to be honest. Again, any language will do.</p>
<p>What if you want to include a live, person-to-person chat on those pages, and you expect thousands of people to use that chat at once, all speaking to each other? Now you’re dipping your hand into that godforsaken river. But that is exactly the problem that Go was designed to solve. It’s a language for creating highly available servers that use as much of the computer’s processor as possible. It has other features as well, but this is where Go shines. Actually, Node.js works pretty well for that sort of server, too, and Clojure certainly has the capacity. Oh, right, Java works, too. If you really needed to, you could even do it in PHP.</p>
<p>This is why the choice is so hard. Everything can do everything, and people will tell you that you should use everything to do everything. So you need to figure out for yourself what kind of team you have, what kind of frameworks you like using, where people can be most productive, so they will stick around through the completion of the project. This is hard. Most places can’t do this. So they go with the lowest common denominator—Java, PHP—because they know that when people leave, they’ll be able to get more of them.</p>
<p>And that’s OK. The vast majority of technology projects don’t require original research, nor do they require amazing technological discoveries. All the languages under discussion work just fine. There are great coders in all of them.</p></blockquote>
<h3>Should you learn to code?</h3>
<p>I&#8217;ve only highlighted some of my favorite parts. I will likely re-read this article many times.</p>
<p>You can also check out a <a href=\"https://github.com/BloombergMedia/whatiscode/\">GitHub repo for the article</a>, which is super cool. You can also catch a <a href=\"http://gawker.com/what-is-code-a-q-a-with-writer-and-programmer-paul-fo-1710884170\">Q&amp;A with Paul Ford</a>, about the article and process, on Gawker. Oh, and <a href=\"http://paulford.kinja.com/for-the-love-of-content-management-1593678966\">his test last year of the Kinja CMS</a> &#8212; a debacle that is reminiscent of the Bloomberg article more than a little bit &#8212; is hilarious.</p>
<p>In the end, he poses the question: &#8220;should you learn to code?&#8221; You&#8217;ll have to <a href=\"http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/\">read to the end to find out</a>.</p>
<p>Seriously, thank you <a href=\"https://twitter.com/ftrain\">Paul Ford</a> for this piece, and Bloomberg for funding it.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jun 2015 20:46:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"WPTavern: WP Featherlight: A New Lightbox Plugin for WordPress Images and Galleries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44795\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:92:\"http://wptavern.com/wp-featherlight-a-new-lightbox-plugin-for-wordpress-images-and-galleries\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3942:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/featherlight.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/featherlight.jpg?resize=1020%2C505\" alt=\"photo credit: neverland... - (license)\" class=\"size-full wp-image-45148\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/91565478@N00/3292572871\">neverland&#8230;</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>WP Site Care recently launched its new <a href=\"https://wordpress.org/plugins/wp-featherlight/\" target=\"_blank\">WP Featherlight</a> plugin on WordPress.org. While there are already hundreds of lightbox plugins available for WordPress, this one may prove to be the &#8220;lightest&#8221; of them all.</p>
<p>The plugin is essentially a wrapper for the <a href=\"http://noelboss.github.io/featherlight/\" target=\"_blank\">Featherlight jQuery lightbox script</a> created by Noel Bossart. Featherlight.js was designed to be very lightweight and is just 400 lines of JavaScript, 100 of CSS, and less than 6kB combined. It works on IE8+, all modern browsers, and on mobile platforms. The script is responsive and supports images, ajax, and iframes out of the box.</p>
<p>WP Featherlight solves a number of problems that WordPress users often encounter with lightbox plugins, many of which contain a load of heavy-handed styling that is difficult to override.</p>
<p>&#8220;We were having a really hard time finding a lightbox plugin that was simple to customize, but that was also lightweight, flexible, and didn’t add a bunch of bloat to our website,&#8221; WP Site Care founder Ryan Sullivan said in his <a href=\"http://www.wpsitecare.com/wp-featherlight/\" target=\"_blank\">post</a> introducing the plugin.</p>
<p>The WP Site Care team opted to build their own solution on top of Featherlight.js. The resulting plugin provides a fast, minimalist style popup for images and galleries.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/wp-featherlight-screenshot.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/wp-featherlight-screenshot.png?resize=1025%2C786\" alt=\"wp-featherlight-screenshot\" class=\"aligncenter size-full wp-image-45168\" /></a></p>
<p>The plugin includes built-in support for native WordPress galleries and <a href=\"http://jetpack.me/support/tiled-galleries/\" target=\"_blank\">Jetpack galleries</a>. When you install it, there are no options to configure. It will automatically display all images and galleries in a lightbox. If you <a href=\"https://github.com/noelboss/featherlight/#usage\" target=\"_blank\">add some extra data attributes to your content</a>, it&#8217;s also possible to display videos, iframes, and ajax content with WP Featherlight.</p>
<p>The demo video below shows how the plugin works with galleries to click from one image to the next while in the lightbox.</p>
<p><span class=\"embed-youtube\"></span></p>
<p>One common problem with WordPress lightbox plugins is that they usually load their scripts and styles on every page, whether you need the lightbox there or not. WP Featherlight gives you the option in the post editor to disable the lightbox. It&#8217;s a handy option to have in case you don&#8217;t want to load a larger version of your images on that particular post/page, but I&#8217;m not sure why you wouldn&#8217;t just conditionally load the scripts on pages that have images.</p>
<p>I tested WP Featherlight on a demo site and found that it works as advertised. You would be hard pressed to find a leaner lightbox plugin for WordPress. The style is super minimal and the fact that there are no options to configure makes it a pleasure to use. Many thanks to <a href=\"https://profiles.wordpress.org/fatmedia/\" target=\"_blank\">Robert Neu</a> and the folks at WP Site Care for making it freely <a href=\"https://wordpress.org/plugins/wp-featherlight/\" target=\"_blank\">available on WordPress.org</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jun 2015 19:36:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"WPTavern: WordPress Plugin Developers Need to Communicate Better in Change Logs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45107\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"http://wptavern.com/wordpress-plugin-developers-need-to-communicate-better-in-change-logs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4839:\"<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/01/CommunicationFeaturedImage.jpg\"><img class=\"size-full wp-image-15569\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2014/01/CommunicationFeaturedImage.jpg?resize=637%2C200\" alt=\"Communication Featured Image\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/elycefeliz/3224486233/\">elycefeliz</a> &#8211; <a href=\"http://creativecommons.org/licenses/by-nc-nd/2.0/\">cc</a>
<p>One of the habits I developed when I started using WordPress is to <strong>always</strong> read a plugin&#8217;s changelog before updating. The changelog is a communication channel that bridges the gap between me and the developer.</p>
<p>It tells me what&#8217;s changed, what to expect, and any other information the developer thinks I should know. The most important information a developer can tell me is that a security vulnerability has been addressed.</p>
<p>Security vulnerabilities in WordPress plugins generally receive a decent amount of media coverage. If I read a story that mentions a plugin I use containing a vulnerability, the first thing I do is visit that plugin&#8217;s changelog on the WordPress plugin directory to see if it&#8217;s fixed. However, some plugin authors don&#8217;t do a very good job of informing users that a security patch has been applied.</p>
<h2>WooCommerce and VaultPress</h2>
<p>WooCommerce recently <a href=\"http://wptavern.com/woocommerce-2-3-11-patches-object-injection-vulnerability\">released an update</a> to fix an object injection vulnerability. If you look at the changelog for 2.3.11 which has the patch, there is no mention of a security vulnerability being fixed.</p>
<h4>2.3.11 &#8211; 10/06/2015</h4>
<ul>
<li>Fix &#8211; Check if rating is enabled before check if rating is required to a review.</li>
<li>Fix &#8211; get_discounted_price needs to check if taxes are enabled.</li>
<li>Fix &#8211; Fixed filetype check for digital downloads.</li>
<li>Fix &#8211; Newfoundland and Labrador state rename.</li>
<li>Fix &#8211; Escaped js in widget layered nav when use the dropdown option.</li>
<li>Fix &#8211; Switch the permissions check for json_search_products to use the read_product capability.</li>
<li>Fix &#8211; Fixed the addition of variable products using the Order API.</li>
<li>Fix &#8211; Sale item exclusion logic for variations.</li>
<li>Fix &#8211; Clear correct variation stock transients when setting stock.</li>
<li>Fix &#8211; Switch to JSON to avoid unserializing untrusted data when handling responses from PayPal.</li>
<li>Fix &#8211; API &#8211; Fixed the sanitization for downloadable files on products endpoint.</li>
<li>Tweak &#8211; woocommerce_downloadable_file_exists filter.</li>
</ul>
<p>To the untrained eye, 2.3.11 is just a regular maintenance release. Security fixes should be front and center and command attention.</p>
<p><a href=\"https://wordpress.org/plugins/vaultpress/changelog/\">VaultPress</a>, a security monitoring plugin by Automattic, also fails to provide clear information in its changelog. Determining security patches with VaultPress is confusing because security hotfixes are labeled as though they are patches for the plugin itself. Instead, security hotfixes are patches to protect from known security vulnerabilities.</p>
<h4>1.7.5 &#8211; 11 Jun 2015</h4>
<ul>
<li>Security: Add a new security hotfix.</li>
</ul>
<h4>1.7.4 &#8211; 28 Apr 2015</h4>
<ul>
<li>Bugfix: Don&#8217;t allow openssl signing unless the public key exists.</li>
</ul>
<h4>1.7.3 &#8211; 27 Apr 2015</h4>
<ul>
<li>Security: Add a new security hotfix.</li>
</ul>
<p>To add to the confusion, there&#8217;s no explanation as to what the hotfixes protect against. You have to read the <a href=\"https://plugins.trac.wordpress.org/changeset/1178685/vaultpress\">inline comment on GitHub</a> to know what the latest hotfix does.</p>
<blockquote><p>// Protect WooCommerce from object injection via PayPal IPN notifications. Affects 2.0.20 -&gt; 2.3.10</p></blockquote>
<p>If VaultPress developers added the comment from GitHub to the changelog on WordPress.org, it would have made things a lot clearer.</p>
<h2>Users Read Change Logs</h2>
<p>When we <a href=\"http://wptavern.com/poll-how-often-do-you-read-a-wordpress-plugins-changelog-before-updating\">asked readers</a> how often do they read a plugin&#8217;s changelog before updating, 705 out of 1,152 voters said they <strong>always</strong> read it while 338 people said they <strong>sometimes</strong> read it. Whether they understand the changes or not, users read change logs.</p>
<p>If you&#8217;re a plugin developer, please consider adding context and clear explanations to your change logs. Clearly state what is a security patch, bug fix, or tweak. I don&#8217;t need to know the fine details, just enough information to make a good decision.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jun 2015 19:12:35 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:81:\"WPTavern: HHVM Demonstrated to be 18.7% Faster Than PHP 7 on a WordPress Workload\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45062\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"http://wptavern.com/hhvm-demonstrated-to-be-18-7-faster-than-php-7-on-a-wordpress-workload\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4072:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/hhvmhack.png\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2014/05/hhvmhack.png?resize=700%2C175\" alt=\"hhvmhack\" class=\"aligncenter size-full wp-image-22751\" /></a></p>
<p>This week HHVM developers shared the results of their first ever <a href=\"http://hhvm.com/blog/9293/lockdown-results-and-hhvm-performance\" target=\"_blank\">open source performance lockdown</a>. HHVM is Facebook&#8217;s <a href=\"https://github.com/facebook/hhvm\" target=\"_blank\">open source</a> PHP execution engine, originally created to help make its infrastructure more efficient. WordPress managed hosts, including <a href=\"http://wptavern.com/wp-engine-partners-with-10up-to-launch-enterprise-hhvm-wordpress-hosting-platform\" target=\"_blank\">WP Engine</a>, <a href=\"https://pagely.com/blog/2014/06/run-hhvm-pagely/\" target=\"_blank\">Pagely</a>, and <a href=\"https://www.siteground.com/blog/hhvm/\" target=\"_blank\">SiteGround</a>, have added HHVM hosting options within the last year to cater to customers who require better PHP performance.</p>
<p>During the HHVM team&#8217;s two week lockdown, developers focused on optimizing builtin functions, dynamic properties, string concatenation, and the file cache. The goal was to maximize requests per second (RPS) with WordPress, Drupal 7, and MediaWiki, using their <a href=\"https://github.com/hhvm/oss-performance\" target=\"_blank\">oss-performance</a> benchmarking tool.</p>
<p>&#8220;During lockdown we achieved a 19.4% RPS improvement for MediaWiki workloads, and a 1.8% RPS improvement for WordPress,&#8221; Facebook developer Paul Bissonnette reported. &#8220;We demonstrated that HHVM is 55.5% faster than PHP 7 on a MediaWiki workload, <strong>18.7% faster on a WordPress workload</strong>, and 10.2% faster on a Drupal 7 workload.&#8221;</p>
<p>These results were based on configuring each framework with a sample dataset designed to approximate an average installation. In order to create the WordPress workload, the HHVM team used URLs from the hhvm.com access logs to extract data.</p>
<p>The <a href=\"http://hhvm.com/blog/9293/lockdown-results-and-hhvm-performance\" target=\"_blank\">report</a> contains a walkthrough of how the benchmarking tool works to approximate the maximum possible RPS of a server under a high load. Some of the most notable performance differences were summarized in the results of the engine comparison chart, which demonstrates the difference between PHP 5, PHP 7, and HHVM.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/engine-comparison.png\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/engine-comparison.png?resize=1025%2C429\" alt=\"engine-comparison\" class=\"aligncenter size-full wp-image-45141\" /></a></p>
<p>During the lockdown, the team also experimented with introducing asynchronous query execution to WordPress, the results of which the team plans to write about in the near future.</p>
<blockquote><p>As an exercise, we evaluated the benefits of <a href=\"https://github.com/facebook/hhvm/tree/master/hphp/runtime/ext/async_mysql\" target=\"_blank\">async MySQL</a> in the WordPress environment. By modifying portions of WordPress to take advantage of the async capabilities offered by Hack and HHVM, we were able to examine the potential for performance gains through async execution. In our test environment we separated the MySQL and PHP hosting to separate machines within the same datacenter to approximate a realistic WordPress stack. The introduction of asynchronous query execution can demonstrate performance gains in both RPS and response time.</p></blockquote>
<p>It will be interesting to see a more detailed report of the benefits they found from introducing async capabilities to WordPress. Overall, the lockdown provided an opportunity for collaboration across open source projects, resulting in a host of optimizations that will help OS frameworks perform better with HHVM in the future. The HHVM team plans to ship these improvements with the next release.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jun 2015 17:47:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:42:\"Matt: Paul Ford: What is Code? | Bloomberg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45145\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"http://ma.tt/2015/06/paul-ford-what-is-code-bloomberg/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:376:\"<blockquote><p>We are here because the editor of this magazine asked me, “Can you tell me what code is?”</p></blockquote>
<p><a href=\"http://www.bloomberg.com/graphics/2015-paul-ford-what-is-code/\">Paul Ford&#8217;s amazing What is Code? for Bloomberg</a>. I only spotted one mistake, of course from the Taupe Blazer guy: you&#8217;re never at the limits of WordPress.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 12 Jun 2015 00:29:57 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: StackExchange is Testing a Proposed Q&amp;A Site for WooCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44683\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"http://wptavern.com/stackexchange-is-testing-a-proposed-qa-site-for-woocommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4111:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/woocommerce-qa-staging-site.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/woocommerce-qa-staging-site.jpg?resize=1025%2C428\" alt=\"woocommerce-qa-staging-site\" class=\"aligncenter size-full wp-image-45118\" /></a></p>
<p>StackExchange community members have <a href=\"http://area51.stackexchange.com/proposals/80132/woocommerce\" target=\"_blank\">proposed</a> a new Q&amp;A site for users and developers of <a href=\"http://www.woothemes.com/woocommerce/\" target=\"_blank\">WooCommerce</a>. The proposal is currently in the <a href=\"http://area51.stackexchange.com/faq\" target=\"_blank\">&#8220;Definition&#8221; phase</a>, which means that participants are working to design the community by proposing hypothetical questions that embody the topic&#8217;s scope.</p>
<p>So far for WooCommerce, popular hypothetical questions include:</p>
<ul>
<li>How do I handle the EU VATMOSS regulations in Woocommerce?</li>
<li>How do I create an Order using WC REST API in my application?</li>
<li>How to hide “add to cart” on free products?</li>
<li>How to implement multiple versions of one digital product with different buyers&#8217; customizations?</li>
</ul>
<p>In order to move on to the next milestone, the site must have at least 40 questions that have a score of at least ten net votes (up minus down). The WooCommerce staging site needs the following:</p>
<ul>
<li>5 more followers</li>
<li>33 more questions with a score of 10 or more</li>
<li>People to max out upvoting quality questions already in the proposal (users can only vote 5 times)</li>
</ul>
<p>The <a href=\"http://wordpress.stackexchange.com/\" target=\"_blank\">StackExchange for general WordPress Development</a> is thriving with <a href=\"http://wptavern.com/wordpress-stackexchange-thrives-in-2014-with-17-million-page-views-and-14k-new-questions\" target=\"_blank\">17 million page views and 14K new questions</a> in 2014. However, questions regarding third party plugins are considered off-topic and will be closed by moderators, hence the need for a separate WooCommerce Q&amp;A site.</p>
<p>Alex Miller, one of the supporters of the WooCommerce StackExchange proposal, believes that the WooCommerce community needs a place where developers can quickly get answers to questions.</p>
<p>&#8220;The WooCommerce Community Forums seemed like a decent place but was shut down months ago for unknown reasons,&#8221; he said. &#8220;My experience with the Woo Community Forums is that it was too broad and the upvote downvote system was poorly handled &#8211; good questions got buried too quickly with the large influx of new questions.&#8221;</p>
<p>In contrast, the StackExchange model pushes questions that have activity (edits, comments, answers) to the top of the frontpage and lower quality questions (downvoted, flagged) receive less attention.</p>
<p>&#8220;Having a WooCommerce StackExchange site is also a great place for people with a great understanding of WooCommerce to document their knowledge for search engines to easily find,&#8221; Miller said. You can see an example of this by <a href=\"http://wordpress.stackexchange.com/questions?sort=votes\" target=\"_blank\">sorting the WPSE questions by votes</a> and reading the first few questions and answers.</p>
<p>&#8220;I can only hope that with <a href=\"http://wptavern.com/automattic-acquires-woocommerce\" target=\"_blank\">Automattic&#8217;s acquisition of WooCommerce</a>, the forums will be reopened (WooCommunity forums have been shutdown for a few months now),&#8221; Miller said. &#8220;But either way I don&#8217;t think there is a much better platform than what the StackExchange offers.&#8221;</p>
<p>As StackExchange Q&amp;A sites are entirely community driven, WooCommerce community members who are interested in seeing it succeed are encouraged to <a href=\"http://area51.stackexchange.com/users/login?returnurl=%2fproposals%2f80132%2fwoocommerce%3ftab%3dvotes\" target=\"_blank\">log into StackExchange</a> and create/upvote quality questions that represent the community&#8217;s interests.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Jun 2015 21:23:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:86:\"WPTavern: Customizer Typography: A Proof-of-Concept Plugin for WordPress Theme Authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45017\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"http://wptavern.com/customizer-typography-a-proof-of-concept-plugin-for-wordpress-theme-authors\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3644:\"<p>One option that users often appreciate in themes is the ability to control typography without having to modify any code. Justin Tadlock has been experimenting with <a href=\"http://justintadlock.com/archives/2015/06/08/customizer-typography-project\" target=\"_blank\">adding a typography control class for the WordPress customizer</a>.</p>
<p>Instead of writing a lengthy tutorial, he opted to create a a proof-of-concept plugin that demonstrates how theme authors might accomplish this. <a href=\"https://github.com/justintadlock/customizer-typography\" target=\"_blank\">Customizer Typography</a> is currently being developed on GitHub and Tadlock said it is &#8220;only meant for development purposes and to show one method of executing the idea.&#8221;</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/customize-typography-screen.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/customize-typography-screen.png?resize=1025%2C568\" alt=\"customize-typography-screen\" class=\"aligncenter size-full wp-image-45019\" /></a></p>
<p>The plugin was created to provide testing for two things:</p>
<ul>
<li>Testing a customizer control class to handle typography</li>
<li>Tying multiple customize settings to a single control</li>
</ul>
<p>&#8220;The most important was not having to add tons of code while still providing the developer complete control over each setting,&#8221; Tadlock said. &#8220;Fortunately, the Customization API in WordPress is pretty powerful and allows you to tie multiple settings to a single control.&#8221;</p>
<p>The plugin currently provides controls for live previewing both paragraph and headings with various font family, font weight, font style, font size, and line height options. <a href=\"https://github.com/justintadlock/customizer-typography/blob/master/customize/control-typography.php#L207\" target=\"_blank\">Integrating Google Fonts</a> is on Tadlock&#8217;s to-do list, but at the moment he&#8217;s not working to build out the plugin as the ultimate solution.</p>
<p>&#8220;Just to be clear, this is a proof of concept that I put together in an afternoon, not a polished solution,&#8221; he said. &#8220;The idea, for me at least, would be to eventually extract it and put it into themes.&#8221;</p>
<p>I installed the plugin to play around with Twenty Fifteen and found that the experience of live previewing typography changes is very satisfying from a user standpoint. Although many custom theme options panels include basic typography controls, you often have to refresh the page to see how your changes applied. This kind of control is a prime candidate for integrating into the customizer.</p>
<p>Tadlock&#8217;s example typography control class gives you a glimpse of what&#8217;s possible for theme authors who elect to build their options using the customizer. It&#8217;s these kinds of controls that truly solve a frustration and make it easier to personalize themes. The Customizer Typography plugin exemplifies the purpose of the customizer.</p>
<p>You can <a href=\"https://github.com/justintadlock/customizer-typography\" target=\"_blank\">check out the plugin on GitHub</a> and install it to see the live previews in action. If you&#8217;re interested to learn more about building with the <a href=\"https://developer.wordpress.org/themes/advanced-topics/customizer-api/\" target=\"_blank\">Customizer API</a>, Tadlock published a post on the Make.WordPress.org/Themes blog that contains a long list of <a href=\"https://make.wordpress.org/themes/2015/05/07/customizer-tutorials-and-documentation/\" target=\"_blank\">customizer tutorials and documentation</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Jun 2015 18:00:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: WooCommerce 2.3.11 Patches Object Injection Vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45099\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/woocommerce-2-3-11-patches-object-injection-vulnerability\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:884:\"<p><a href=\"http://develop.woothemes.com/woocommerce/2015/06/woocommerce-2-3-11-security-and-maintenance-release/\">WooCommerce 2.3.11</a> patches an object injection vulnerability <a href=\"https://blog.sucuri.net/2015/06/security-advisory-object-injection-vulnerability-in-woocommerce.html\">discovered by Sucuri</a>. According to the security research company, the vulnerability is only present when the <strong>PayPal Identity Token </strong>option is set in WooCommerce.</p>
<p>Researchers used a combination of WordPress and WooCommerce components with a known PHP bug and were able to download critical files, including wp-config.php which has sensitive information. Versions <strong>2.0.20 &#8211; 2.3.10</strong> are considered vulnerable.</p>
<p>In addition to the patch, the release also has a number of bug fixes. If you haven&#8217;t already, update as soon as possible.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Jun 2015 17:14:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"WPTavern: WPWeekly Episode 195 – Recap of WordCamp Orange County 2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://wptavern.com?p=45094&preview_id=45094\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/wpweekly-episode-195-recap-of-wordcamp-orange-county-2015\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2775:\"<p>In this episode, <a href=\"http://marcuscouch.com/\">Marcus Couch</a> and I recap <a href=\"https://oc.wordcamp.org/2015/\">WordCamp Orange County 2015</a> held in Costa Mesa, CA. We share our favorite sessions, highlights of the weekend, and I explain why I spent day two of the conference in my hotel room. During the second half of the show, we cover the news of the week, including the controversy surrounding the menu customizer plugin.</p>
<h2>Stories Discussed:</h2>
<p><a href=\"http://wptavern.com/wordcamp-us-2015-now-accepting-applications-for-host-city\">WordCamp US 2015 Now Accepting Applications for Host City</a><br />
<a href=\"https://make.wordpress.org/community/2015/06/10/ive-been-approached-by-a-couple-of-people/\">Clarification on WordCamp US Applications</a><br />
<a href=\"http://wptavern.com/wordpress-core-contributors-call-for-user-testing-on-the-menu-customizer-plugin\">WordPress Core Contributors Call for User Testing on the Menu Customizer Plugin</a><br />
<a href=\"https://apps.wordpress.org/2015/06/09/wordpress-for-ios-version-5-2/\">WordPress Mobile 5.2 Update Drops with added media capabilities</a><br />
<a href=\"http://wptavern.com/woothemes-fixes-xss-vulnerability-in-products-using-the-prettyphoto-library\">WooThemes Fixes XSS Vulnerability in Products Using the prettyPhoto Library</a><br />
<a href=\"http://develop.woothemes.com/woocommerce/2015/06/woocommerce-2-3-11-security-and-maintenance-release/\">WooCommerce 2.3.11 Security and Maintenance Release</a></p>
<h2>Plugins Picked By Marcus:</h2>
<p><a href=\"https://wordpress.org/plugins/daily-logo/\">Daily Logo</a> is a simple and flexible plugin which allow users to display a different header or logo on their site every day.</p>
<p><a href=\"https://wordpress.org/plugins/scheduled-stickiness/\">Scheduled Stickiness</a> sets and unsets the sticky flag on specified dates for a certain post based on meta fields.</p>
<p><a href=\"https://wordpress.org/plugins/learnpress/\">LearnPress</a> is a comprehensive learning management system plugin for WordPress. It can be used to easily create and sell courses online.</p>
<h2>WPWeekly Meta:</h2>
<p><strong>Next Episode:</strong> Wednesday, June 24th 9:30 P.M. Eastern</p>
<p><strong>Subscribe To WPWeekly Via Itunes: </strong><a href=\"https://itunes.apple.com/us/podcast/wordpress-weekly/id694849738\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via RSS: </strong><a href=\"http://www.wptavern.com/feed/podcast\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Subscribe To WPWeekly Via Stitcher Radio: </strong><a href=\"http://www.stitcher.com/podcast/wordpress-weekly-podcast?refid=stpr\" target=\"_blank\">Click here to subscribe</a></p>
<p><strong>Listen To Episode #195:</strong><br />
</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 11 Jun 2015 15:56:46 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"WPTavern: WooThemes Fixes XSS Vulnerability in Products Using the prettyPhoto Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45080\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:95:\"http://wptavern.com/woothemes-fixes-xss-vulnerability-in-products-using-the-prettyphoto-library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2531:\"<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/WooThemesFeaturedImage2.png\"><img class=\"aligncenter size-full wp-image-45083\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/WooThemesFeaturedImage2.png?resize=648%2C196\" alt=\"WooThemesFeaturedImage2\" /></a>Jeff Ikus of WooThemes, <a href=\"http://develop.woothemes.com/themes/2015/06/09/prettyphoto-xss-theme-updates/\">announced</a> on the company&#8217;s themes development blog, that it has pushed out updates to all of its products that use the <a href=\"http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/\">prettyPhoto library</a>. The update fixes a <a href=\"https://github.com/scaron/prettyphoto/issues/149\">DOM based cross-site scripting vulnerability </a>discovered in 2014.</p>
<p><a href=\"http://www.no-margin-for-errors.com/projects/prettyphoto-jquery-lightbox-clone/\">prettyPhoto</a> is a jQuery lightbox clone used in a potentially large number of WordPress products. If you use a WordPress plugin or theme that relies on prettyPhoto, please get in touch with the author to make sure they&#8217;re aware of this security vulnerability. If you use the <a href=\"https://wordpress.org/plugins/prettyphoto/\">prettyPhoto WordPress plugin</a>, make sure it&#8217;s running version 1.2 as it contains the patched library.</p>
<h2>Risky Business</h2>
<p>In 2011, <a title=\"http://www.binarymoon.co.uk/2011/08/timthumb-2/\" href=\"http://www.binarymoon.co.uk/2011/08/timthumb-2/\">TimThumb made headlines</a> when a major security vulnerability was discovered and used to hack into several websites. At the time, Ben Gillbanks, the library&#8217;s maintainer, estimated 95% of all commercial WordPress themes supported TimThumb.</p>
<p>At the end of 2014, a <a href=\"http://wptavern.com/100000-wordpress-sites-compromised-using-the-slider-revolution-security-vulnerability\">security vulnerability was discovered</a> in the Slider Revolution plugin that allowed more than 100k websites to be compromised.</p>
<p>Using third-party scripts and libraries is not a bad thing. The practice however, comes with a set of risks. It&#8217;s up to developers to be vigilant and accept the responsibilities that come with relying on a third-party. It&#8217;s also imperative that developers do everything they can to update their products and users when a security vulnerability is discovered.</p>
<p>If you&#8217;re a developer, let us know the criteria in determining which third-party scripts, libraries, and tools you use.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jun 2015 20:31:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"Post Status: Quick tip: Disconnect Jetpack from the WordPress.com side\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=12963\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"https://poststatus.com/quick-tip-disconnect-jetpack-from-the-wordpress-com-side/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2528:\"<p>About sixteen months ago, I wrote a post noting that it is <a href=\"https://poststatus.com/managing-jetpack-enabled-blogs-wordpress-com/\">really annoying to disconnect a WordPress.com account from a Jetpack install</a>. More annoying yet, is that you could not get rid of nonexistent Jetpack enabled websites from the WordPress.com &#8220;My Sites&#8221; section at all without contacting support.</p>
<p>Over the years I collected quite a few Jetpack enabled websites connected to my WordPress.com username. Whether I was connecting a staging site or was too lazy to get a friend to setup their own account on WordPress.com, I ended up with a couple of dozen websites connected to my account that were not in my control.</p>
<p>The traditional way to disconnect Jetpack from WordPress.com was via the site admin in the Jetpack settings. But over time, many of the sites I managed have went stagnant or completely offline, and there was no way to disconnect them anymore. But finally, you can disconnect Jetpack from the WordPress.com side.</p>
<p>You can disconnect sites from the main &#8220;My Site&#8221; link (shown above) or the individual site (pictured below). Errored sites show up with a red warning side, and when you click the icon, the ability to permanently disconnect the site appears.</p>
<p><img class=\"alignnone size-large wp-image-12965\" src=\"https://poststatus.com/wp-content/uploads/2015/06/wp-com-disconnect-solo-752x385.png\" alt=\"wp-com-disconnect-solo\" width=\"752\" height=\"385\" /></p>
<p>This has been a near daily annoyance of mine for years. I&#8217;m happy to see it finally get resolution. Special thanks to Automattician <a href=\"https://twitter.com/jeherve/status/606369302216728576\">Jeremy Herve</a> for never forgetting about me.</p>
<p>One more tip: if you go to your WordPress.com homepage often, and it doesn&#8217;t open up the page you want to be default for stats, you can set your default site under your <a href=\"https://wordpress.com/me/account\">account settings</a>. This is another annoyance of mine that I didn&#8217;t know had a solution until just now.</p>
<p><img class=\"alignnone size-large wp-image-12966\" src=\"https://poststatus.com/wp-content/uploads/2015/06/wp-com-account-752x377.jpg\" alt=\"wp-com-account\" width=\"752\" height=\"377\" /></p>
<p>I know creating really effective user interfaces and account management tools is really hard. But attention to small details is awesome. I&#8217;m glad the WordPress.com team took care of this one, even if it took a while.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jun 2015 18:18:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Matt: Peter Thiel on MBAs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45140\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"http://ma.tt/2015/06/peter-thiel-on-mbas/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:877:\"<blockquote><p>I think one challenge a lot of the business schools have is they end up attracting students who are very extroverted and have very low conviction, and they put them in this hot house environment for a few years — at the end of which, a large number of people go into whatever was the last trendy thing to do. They’ve done studies at Harvard Business School where they’ve found that the largest cohort always went into the wrong field. So in 1989, they all went to work for Michael Milken, a year or two before he went to jail. They were never interested in Silicon Valley except for 1999, 2000. The last decade their interest was housing and private equity.</p></blockquote>
<p><a href=\"http://www.washingtonpost.com/blogs/on-leadership/wp/2014/10/10/peter-thiel-on-what-works-at-work/\">This entire interview with Peter Thiel is pretty interesting</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 10 Jun 2015 17:18:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: WordPress Core Contributors Call for User Testing on the Menu Customizer Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=45034\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:99:\"http://wptavern.com/wordpress-core-contributors-call-for-user-testing-on-the-menu-customizer-plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:7228:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/menu-customizer-feature1.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/menu-customizer-feature1.jpg?resize=670%2C318\" alt=\"menu-customizer-feature\" class=\"aligncenter size-full wp-image-45053\" /></a></p>
<p>Ryan Boren published a post to the Make/WordPress Core blog this afternoon, titled <a href=\"https://make.wordpress.org/core/2015/06/09/trust-live-preview-and-menus-in-the-customizer/\" target=\"_blank\">Trust, Live Preview, and Menus in the Customizer</a>. In it he clarified the reasons why he and several other core contributors are committed to iterating the customizer and identified the feature as a means of building user trust through live previews.</p>
<blockquote><p>Being able to make non-destructive changes and preview them is an important component of building that trust. This is perhaps most noticeable in the “save and surprise” approach of the widgets admin screen – every time you add a new widget, modify its settings, or move one around, the changes are saved and appear live on your site, even if you’re not ready yet. The customizer is our framework for live previewing changes. We are committed to providing live preview for all aspects of site customization and making it usable on all devices from phones to large screens.</p></blockquote>
<p>Boren briefly summarized the history of the customizer and alluded to a few possibilities the framework may offer in the future:</p>
<blockquote><p>The customizer has come a long way, but it still lacks some features and needs time to mature. We have many improvements planned and in progress, including transactions, partial refresh, theme installation, speedier loading, scaling to large screens, and possibly even integration with front end editing. Our live preview framework offers many possibilities.</p></blockquote>
<p>The Menu Customizer plugin was <a href=\"http://wptavern.com/menu-customizer-tentatively-approved-for-wordpress-4-3\" target=\"_blank\">tentatively approved for merge</a> during last week&#8217;s core development meeting. In order for the it to be officially approved for merge on June 17th, the plugin will need to meet the <a href=\"https://make.wordpress.org/core/handbook/how-the-release-cycle-works/features-as-plugins/\" target=\"_blank\">feature plugin criteria</a> outlined in the core handbook.</p>
<p>&#8220;We have eight days to get the Menu Customizer plugin ready for merge,&#8221; Boren said. During this time the <a href=\"https://make.wordpress.org/flow/\" target=\"_blank\">flow team</a> will be testing and documenting the flow and visuals for the menu customizer.</p>
<p>Boren invited anyone who wants to contribute to this effort to create flow comparisons of the existing flow through Appearance > Menus versus flow through the customizer. This essentially involves walking through the experience of setting up menus, taking screenshots of the flow, and publishing them as a captioned gallery.</p>
<p>&#8220;Please help us capture the flows through Appearance > Menus used by you and your clients,&#8221; he said. &#8220;We need this information to ensure our new interfaces are mindful and aware of how WordPress is actually used.&#8221;</p>
<p>Anyone can contribute to WordPress in this way, as it doesn&#8217;t require any coding. The core team is looking for people to capture real user scenarios to help in making the final decision.</p>
<h3>There is No Timeline for Removing the Appearance > Menus Screen</h3>
<p>In the original <a href=\"https://make.wordpress.org/core/2015/06/03/feature-plugin-merge-proposal-menu-customizer/\" target=\"_blank\">merge proposal</a> for the Menu Customizer the plugin&#8217;s author, Nick Halsey, outlined what he called a &#8220;fairly aggressive&#8221; plan for the removal of the old menus admin screen. As contributor resources are scarce when it comes to the Menus component, Halsey favored focusing all new development on the UI in the customizer.</p>
<p>The timeline he outlined was for WordPress 4.3 to point the Menus link in the admin bar to Menus in the customizer and later releases (WordPress 4.5 or 4.6) would remove all core links to the Menus admin screen.</p>
<p>WordPress users reacted strongly to this aggressive timeline for removing the old menus screen, but the timeline was merely a suggestion as part of the proposal. Halsey was not keen on merging the plugin without a definitive timeline for removing the old menus, a factor which he considered a &#8220;<a href=\"https://wordpress.slack.com/archives/core/p1433384682001602\" target=\"_blank\">dealbreaker</a>&#8221; for merge.</p>
<p>However, WordPress 4.3 release lead Konstantin Obenland confirmed that no official timeline has been set.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/pollyplummer\">@pollyplummer</a> There is no timeline either way.</p>
<p>&mdash; Konstantin Obenland (@obenland) <a href=\"https://twitter.com/obenland/status/608377778933743616\">June 9, 2015</a></p></blockquote>
<p></p>
<p>Ryan Boren also confirmed that WordPress will continue to maintain the Appearance > Menus screen should the plugin be officially approved for merge in the coming days:</p>
<blockquote><p>Meanwhile, the Appearance screens will remain and will be maintained. Appearance > Menus recently received some attention in the form of a few fixes. More attention is needed and will be given. There are still differences in the flows each approach best enables, whether it’s new site/theme setup, small maintenance tasks, or dedicated content managers for heavy usage of widgets, menus, or other pieces of content that benefit from having a preview mechanism. We should gather quantifiable metrics when it comes to performance and time to completion for a given flow, as well as evaluating the less-objectively-quantifiable perceived performance. <strong>There may come a time where the worlds converge; however, that time is not now.</strong></p></blockquote>
<p>This confirmation should assuage those whose opposition to the Menu Customizer was solely based on the aggressive timeline proposed for removing the old menus screen.</p>
<p>The great divide on the Menu Customizer revolves around one aspect of improvement that Boren mentioned in his paragraph about the future of the customizer: <strong>scaling to large screens</strong>. The vast majority of WordPress users and developers who are following this debate are those who would be more likely to configure a menu in a desktop environment and not via mobile (where the customizer is currently designed to shine).</p>
<p>Many who oppose the merge of the plugin have identified the cramped UI as the primary reason that it does not provide a better experience for users. You would be hard pressed to find anyone who is opposed to live previews or better usability on mobile devices.</p>
<p>Those who manage WordPress sites via desktop are not willing to sacrifice the old menus screen for a new UI that currently caters primarily to smaller devices. Until the Menu Customizer can adequately provide a UI that fully adapts to all screen sizes, resistance to the feature is likely to continue.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2015 22:34:19 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Trust but Preview\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45138\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/06/trust-but-preview/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:273:\"<p>If you&#8217;re following along with the customizer and menu work for the next version of WordPress, check out <a href=\"https://make.wordpress.org/core/2015/06/09/trust-live-preview-and-menus-in-the-customizer/\">Trust, Live Preview, and Menus in the Customizer</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2015 20:00:12 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:41:\"WPTavern: Introducing the WP Tavern Wapuu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44960\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"http://wptavern.com/introducing-the-wp-tavern-wapuu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6761:\"<p>The <a href=\"http://wapuu.jp/\">Wapuu craze</a> has spread far and wide. From its <a href=\"http://wptavern.com/community-translation-and-wapuu-how-japan-is-shaping-wordpress-history\">origin in Japan</a>, to <a href=\"http://wptavern.com/scott-evans-on-designing-the-punk-wapuu-for-wordcamp-london-2015\">WordCamp London</a>, and across the US, Wapuu has become quite the traveler. While the mascot has mostly represented WordCamps, site owners are creating a custom version of the mascot to represent their sites.</p>
<p><a href=\"http://www.mynameismichelle.com/\">Michelle Schulp</a>, a graphic designer who runs <a href=\"http://marktimemedia.com/\">Marktimemedia, </a>has created a number of Wapuu&#8217;s for WordCamps and websites. She was gracious enough to create one specifically for the Tavern.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/wapuu-wptavern.png\"><img class=\"size-large wp-image-45028\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/wapuu-wptavern.png?resize=418%2C500\" alt=\"WP Tavern Wapuu\" /></a>WP Tavern Wapuu
<p>Schulp created the mascot with Adobe Illustrator using the original .svg files provided on the original <a href=\"https://github.com/jawordpressorg/wapuu\">Wapuu Github repository</a>. She doesn&#8217;t plan on writing tutorials to modify the base Wapuu. Instead, she is creating <a href=\"https://github.com/marktimemedia/my-wapuu\">a base Wapuu</a> that will have separated pieces so its easier to modify.</p>
<p>She often sketches and re-draws Wapuus that are not in their normal position.</p>
<p>&#8220;Actually, most of the Wapuus are slightly modified to make it easier for them to hold or interact with their elements. I thought of him like a cartoon character (fluid) more so than a logo or icon (rigid),&#8221; Schulp told the Tavern.</p>
<p>Schulp has always had an interest in sketching cartoons. For WordCamp Miami 2015, she created a variety of custom-made My Little Pony stickers.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/MyLittlePonyStickers.jpg\"><img class=\"wp-image-44978 size-large\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/MyLittlePonyStickers.jpg?resize=309%2C500\" alt=\"My Little Pony Stickers\" /></a>My Little Pony Stickers
<p>She also uses her skills to create <a href=\"https://speakerdeck.com/marktimemedia/developer-collaboration\">unique slide decks</a> filled with colorful illustrations.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/CustomSlideDeck.png\"><img class=\"wp-image-44983 size-large\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/CustomSlideDeck.png?resize=500%2C415\" alt=\"Custom Slide Deck\" /></a>Custom Slide Deck
<h2>From WordCamps to Websites and Eventually Companies</h2>
<p>Wapuu is considered the official mascot character of WordPress and was designed by Kazuko Kaneuchi in 2011. It’s <a href=\"https://github.com/jawordpressorg/wapuu\" target=\"_blank\">distributed under the GPLv2 or later</a> and can be modified by anyone. The character is used to represent different cultures and regions of the world.</p>
<p>Now that Wapuu is showing up as a mascot for sites that focus on WordPress, the question is, when will it be used to represent companies in the WordPress ecosystem?</p>
<p>Shortly after <a href=\"http://wptavern.com/automattic-acquires-woocommerce\">Automattic acquired WooThemes</a>, Nick Hamze was criticized on the Advanced WordPress Facebook group for creating a <a href=\"http://blog.nickhamze.com/2015/05/19/hiro-wapuu-bffs/\">Wapuu dressed up like a ninja</a>.</p>
<blockquote><p>If the graphic was created by WooThemes and independently of the acquisition I&#8217;d think oh cute, WooTheme&#8217;s mascot is teaching WordPress&#8217; mascot how to be a ninja, best friends forever for sure.</p>
<p>Instead, it came from an Automattician and in the context of Automattic acquiring WooThemes, to me it reads that Automattic is using Wapuu, which just bugs me.</p></blockquote>
<p>At WordCamp Miami 2015, Rocketgenius came under fire for creating swag that features Wapuu wearing a space suit with a rocket patch on its arm.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/carlhancock\">@carlhancock</a> Wapuu is for promoting WordPress. It promotes a open source project and not a company.</p>
<p>&mdash; Marko Heijnen (@markoheijnen) <a href=\"https://twitter.com/markoheijnen/status/605072873586356224\">May 31, 2015</a></p></blockquote>
<p></p>
<p>This is what the swag looks like. The logo is subtle in nature and if you didn&#8217;t already know it represents Rocketgenius, it would fit naturally into the design.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/SpaceWapuu.jpg\"><img class=\"wp-image-44989 size-large\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/SpaceWapuu.jpg?resize=375%2C500\" alt=\"Space Wapuu With Rocket Patch\" /></a>Space Wapuu With Rocket Patch
<p>It&#8217;s important to note that there are no rules in how Wapuu can be used. The only guideline is maintaining Kaneuchi&#8217;s copyright. The mascot has appeared on physical products such as nails, cakes, and stuffed animals.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wapuu-everywhere.jpg\"><img class=\"size-full wp-image-43945\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/05/wapuu-everywhere.jpg?resize=1025%2C703\" alt=\"photo credit:  Naoko Takano - Learnings from Growing Local WordPress Communities\" /></a>photo credit:<br />Naoko Takano &#8211; <a href=\"http://www.slideshare.net/naokomc/wordcamp-europe2013/47\">Learnings from Growing Local WordPress Communities</a>
<p>Schulp says she plans to create more Wapuus when the inspiration strikes. &#8220;I like to imagine Wapuu in a ton of different circumstances and my plan is to create more <em>slice of life</em> Wapuus as the inspiration strikes, maybe similar to how you can express things with Facebook stickers.&#8221;</p>
<p>&#8220;Though Wapuu is open source and we can all use him and I&#8217;ve got good intentions, he isn&#8217;t mine so I&#8217;ll always defer to and respect the community that created it.&#8221;</p>
<h2>Community Protection</h2>
<p>The use of Wapuu is open for interpretation but I don&#8217;t see a problem with companies participating in the craze and creating one of their own. Unlike the WordPress logo, which is trademarked, Wapuu is free of such restrictions meaning anyone can use it for anything, including commercial endeavors.</p>
<p>The community needs to protect Wapuu from enterprises that want to claim it as their own. We must respect its origins and give credit where credit is due. Other than that, the more Wapuus the better!</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2015 18:31:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:111:\"WPTavern: Prescription for a Stalled WordPress Agency: Mario Peshev’s Advice for Growing Development Services\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44596\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:117:\"http://wptavern.com/prescription-for-a-stalled-wordpress-agency-mario-peshevs-advice-for-growing-development-services\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2629:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/clients.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/clients.jpg?resize=1025%2C504\" alt=\"photo credit: Alejandro Escamilla\" class=\"size-full wp-image-45014\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/96E1A8F1CB\">Alejandro Escamilla</a>
<p>WordPress agencies provide a critical connection point between users and the software by building custom solutions and guiding some of the more complex implementations. Yet client work is challenging, and many developers who work in it are concurrently planning their escape into product businesses.</p>
<p>Growing an agency reliably is one of the more difficult business endeavors one can embark upon in the WordPress ecosystem. That&#8217;s why many attempts linger at one or two person shops, and very few grow to become the powerhouse agencies that can accommodate enterprise level clients.</p>
<p><a href=\"http://devwp.eu/\" target=\"_blank\">Mario Peshev</a>, an agency owner specializing in SaaS solutions, wrote an excellent piece on <a href=\"http://devwp.eu/outsourcing-and-hiring-remote-talent/\" target=\"_blank\">Outsourcing and Hiring Remote Talent</a>. As strategic hiring is the lifeblood of any agency, it&#8217;s a skill that owners are eager to refine.</p>
<p>&#8220;Small businesses are not easy to run,&#8221; he said. &#8220;Growing from a one man show to two people is really hard.&#8221; Peshev&#8217;s article includes a wealth of advice from the trenches on topics that every WordPress agency owner has struggled with, especially in the beginning. He covers the following topics in depth:</p>
<ul>
<li>Tips on hiring technical people remotely</li>
<li>Strategies for hiring experts, junior developers, and trainees</li>
<li>Scaling a business and growing a team via outsourcing</li>
<li>When and why you might hire a consultant</li>
<li>The benefits of leasing employees</li>
<li>Outsourcing to another agency</li>
<li>When it makes sense to hire a freelancer</li>
<li>How to find WordPress talent</li>
</ul>
<p>Peshev blogs regularly on WordPress development and business topics, and this <a href=\"http://devwp.eu/outsourcing-and-hiring-remote-talent/\" target=\"_blank\">post</a> is a must read for any business owner who is struggling to grow a stalled agency. There&#8217;s no simple recipe for success when you&#8217;re in the business of helping clients harness the power of WordPress. Peshev&#8217;s post doesn&#8217;t offer a single magic formula for growing your agency but instead outlines various strategies and scenarios where they might be beneficial.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2015 15:06:40 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: Online Privacy Lie\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45136\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2015/06/online-privacy-lie/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:469:\"<p>Techcrunch has a really great essay by Natasha Lomas that I think got missed, <a href=\"http://techcrunch.com/2015/06/06/the-online-privacy-lie-is-unraveling/\">The Online Privacy Lie Is Unraveling</a>.</p>
<blockquote><p>Americans believe it is futile to manage what companies can learn about them. Our study reveals that more than half do not want to lose control over their information but also believe this loss of control has already happened.</p></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 09 Jun 2015 04:57:56 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"WPTavern: Brighton, UK to Host Europe’s First BuddyCamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44932\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"http://wptavern.com/brighton-uk-to-host-europes-first-buddycamp\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3385:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/buddycamp-brighton.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/buddycamp-brighton.jpg?resize=670%2C318\" alt=\"buddycamp-brighton\" class=\"aligncenter size-full wp-image-44976\" /></a></p>
<p>BuddyPress fans, mark your calendars! <a href=\"http://brighton.buddycamp.org/2015/\" target=\"_blank\">BuddyCamp Brighton</a>, Europe’s very first BuddyPress conference, is just two months away. The event will be held at Clearleft’s 68 Middle Street venue on August 8, 2015. This venue has a maximum capacity of 60 people, so tickets are likely to sell out fast.</p>
<p>BuddyPress lead developer <a href=\"https://twitter.com/pgibbs\" target=\"_blank\">Paul Gibbs</a> and contributor <a href=\"https://twitter.com/karmatosed\" target=\"_blank\">Tammie Lister</a> are teaming up to organize the event and put out the <a href=\"http://brighton.buddycamp.org/2015/call-for-speakers/\" target=\"_blank\">call for speakers</a> and <a href=\"http://brighton.buddycamp.org/2015/call-for-sponsors/\" target=\"_blank\">sponsors</a> today.</p>
<p>&#8220;The really exciting thing is that this is going to be the first BuddyCamp outside North America/Canada &#8211; the first in Europe,&#8221; Gibbs said. &#8220;From my role in the BuddyPress project, I know we have many fans across the continent, and it&#8217;s those people we want to come to BuddyCamp, so we&#8217;re going to focus on making the event as accessible as possible for all those visitors.&#8221;</p>
<p>Brighton has a thriving <a href=\"http://www.meetup.com/WordUp-Brighton/\" target=\"_blank\">local WordPress community</a> and BuddyPress interest runs deep throughout the UK, making it a strategic location for hosting Europe&#8217;s first BuddyCamp.</p>
<p>&#8220;Brighton itself has a great tech community, as does London obviously (which is just over an hour away on train), so there&#8217;s a lot of potential,&#8221; Gibbs said.</p>
<p>Organizers are hoping to receive a wide range of presentation subjects from potential speakers, including both beginner and technical topics.</p>
<p>&#8220;We&#8217;re pretty keen on beginners content, mixed with a range of showcases and great examples of the potential of BuddyPress,&#8221; he said.</p>
<p>Gibbs confirmed that peripheral bbPress topics are also welcome among speaker submissions, even though the event will focus primarily on BuddyPress.</p>
<p>&#8220;I think there&#8217;s a lot of overlap, especially around community management and development,&#8221; he said. &#8220;We&#8217;d be happy to receive talk proposals in these areas.&#8221;</p>
<p>BuddyCamp Brighton is a historic event for the European BuddyPress community and will be formatted as an intimate gathering where attendees of all skill levels are welcome. BuddyPress enthusiasts will learn more about the varied uses of the plugin and will also have the opportunity to get connected to core contributors in the region.</p>
<p>&#8220;If people go home happy and inspired to use BuddyPress to help them grow a community, then I&#8217;ll be very happy,&#8221; Gibbs said.</p>
<p>Those interested to attend can <a href=\"http://brighton.buddycamp.org/\" target=\"_blank\">subscribe to email updates</a> or follow <a href=\"https://twitter.com/BuddyCampUK\" target=\"_blank\">@BuddyCampUK</a> on Twitter to be notified when tickets go on sale.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 08 Jun 2015 22:06:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"WPTavern: WordPress Theme Review Team Seeks Feedback on the Review Process, Themes, and the Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44912\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:109:\"http://wptavern.com/wordpress-theme-review-team-seeks-feedback-on-the-review-process-themes-and-the-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5390:\"<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/survey.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/survey.jpg?resize=1025%2C507\" alt=\"photo credit: Lukasz Kowalewski\" class=\"size-full wp-image-44957\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/FI3UYVGNFD\">Lukasz Kowalewski</a>
<p>The WordPress Theme Review Team (TRT) is currently seeking feedback via three separate surveys on the <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-review-process-survey/\" target=\"_blank\">review process</a>, <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-usability-survey/\" target=\"_blank\">themes</a>, and the <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-directory-survey/\" target=\"_blank\">directory</a>. After weathering several months of increasingly negative community feedback, the team is now looking to users and theme authors to help shape its <a href=\"https://make.wordpress.org/themes/2015/06/05/suggested-roadmap/\" target=\"_blank\">roadmap</a> for the future.</p>
<p>The team&#8217;s controversial decision to <a href=\"http://wptavern.com/wordpress-org-now-requires-theme-authors-to-use-the-customizer-to-build-theme-options\" target=\"_blank\">require theme authors to use the customizer for building theme options</a> ignited a heated debate, which continued as more guidelines came up for consideration. Community members expressed concern that more rules and regulations might limit the future of WordPress themes. The conversation surrounding violations of the &#8220;<a href=\"http://wptavern.com/wordpress-theme-review-team-is-cracking-down-on-violations-of-the-presentation-vs-functionality-guideline\" target=\"_blank\">Presentation vs. Functionality</a>&#8221; guideline contributed to the team&#8217;s decision to reevaluate the general direction of the official directory and the process of getting a theme approved.</p>
<p>Following a brainstorming session with Matt Mullenweg on May 28th, the TRT decided to step back and look at the process and the directory in a new way. This opened up many new avenues for the team to explore, and the three user surveys are a response to the new direction.</p>
<p>TRT member Tammie Lister opened up the feedback channels with an <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-directory-survey/\" target=\"_blank\">overview</a> of the purpose behind the surveys:</p>
<blockquote><p>As a part of our <a href=\"https://make.wordpress.org/themes/2015/06/05/suggested-roadmap/\" target=\"_blank\">Theme Directory Roadmap</a>, we are going to be taking a good look at every aspect of the theme submission, review, and browsing experience on WordPress.org.</p>
<p>To kick off the research phase of our roadmap, we’re issuing a series of surveys targeting theme authors, theme reviewers, and WordPress users. In addition to surveying users, we’ll also be analyzing other theme directories on the web, and reviewing other theme submission processes to see what we can bring back to WordPress.</p></blockquote>
<p>The <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-usability-survey/\" target=\"_blank\">Usability survey</a> is an opportunity for anyone who has ever used a WordPress.org-hosted theme to voice an opinion on that experience. The survey briefly touches on whether the user views a demo before downloading the theme. The quality of theme demos is currently a hot topic of discussion, as many believe that the current demos are woefully inadequate at showing a theme&#8217;s potential.</p>
<p>The <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-review-process-survey/\" target=\"_blank\">Theme Review Process survey</a> is specifically for theme authors and includes open-ended questions regarding the process and obstacles to getting a theme launched.</p>
<p>The <a href=\"http://13233232.polldaddy.com/s/what-is-it-like-to-have-your-theme-reviewed\" target=\"_blank\">Finding a WordPress Theme</a> survey concerns the directory, but it is the most limited in scope. The survey includes just one question about where users look for a theme when starting a new site.</p>
<p>One WordPress theme developer <a href=\"https://make.wordpress.org/themes/2015/06/05/theme-directory-survey/#comment-41962\" target=\"_blank\">commented on the survey</a>, suggesting a few more detailed questions that could be helpful, but Lister indicated that the TRT is examining the first round of responses before moving on to further research.</p>
<blockquote><p>At this stage we should not get into too much detail as we want to get an over-view. We also have some stats we can use in conjunction. This is not something we’re going to change format wise this time around.</p></blockquote>
<p>The three surveys are a unique opportunity for users to voice their opinions on the experience of using WordPress.org themes, and take just minutes to complete. Hopefully, when the next stage of research is launched they will survey users on more specific concerns.</p>
<p>The TRT&#8217;s request for feedback marks the beginning of a radical shift in the direction of the team. Instead of instituting more guidelines, TRT is looking at better ways to encourage creativity among theme authors and improve the process of submitting themes. The directory should also be receiving some useful improvements in the near future as the result of user feedback.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 08 Jun 2015 19:02:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"Akismet: Akismet WordPress Plugin 3.1.2\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"http://blog.akismet.com/?p=1849\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"http://blog.akismet.com/2015/06/08/akismet-3-1-2-wordpress/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1209:\"<p>Version 3.1.2 of <a href=\"http://wordpress.org/plugins/akismet/\">the Akismet plugin for WordPress</a> is now available.</p>
<p>This update includes seventeen fixes and enhancements; they&#8217;re summarized in the <a href=\"https://wordpress.org/plugins/akismet/changelog/\">changelog</a> (or for all of the details, the <a href=\"https://plugins.trac.wordpress.org/log/akismet/trunk\">revision log</a>), but notably, Akismet will be easier to set up, use less space in your database, and be better protected against security holes &#8212; specifically ones in other plugins.</p>
<p>To upgrade, visit the Updates page of your WordPress dashboard and follow the instructions. If you need to download the plugin zip file directly, links to all versions are available in <a href=\"http://wordpress.org/plugins/akismet/\">the WordPress plugins directory</a>.</p><br />  <a rel=\"nofollow\" href=\"http://feeds.wordpress.com/1.0/gocomments/akismet.wordpress.com/1849/\"><img alt=\"\" border=\"0\" src=\"http://feeds.wordpress.com/1.0/comments/akismet.wordpress.com/1849/\" /></a> <img alt=\"\" border=\"0\" src=\"http://pixel.wp.com/b.gif?host=blog.akismet.com&blog=116920&post=1849&subd=akismet&ref=&feed=1\" width=\"1\" height=\"1\" />\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 08 Jun 2015 02:50:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"Christopher Finke\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:32:\"Matt: The Agency – NYTimes.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://ma.tt/2015/06/the-agency-nytimes-com/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:372:\"<blockquote><p>From a nondescript office building in St. Petersburg, Russia, an army of well-paid “trolls” has tried to wreak havoc all around the Internet — and in real-life American communities.</p></blockquote>
<p>This story of Adrian Chen in Russian <a href=\"http://www.nytimes.com/2015/06/07/magazine/the-agency.html\">definitely turns weird at the end</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 07 Jun 2015 14:52:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:30:\"Matt: Aca-Awesome : Kay Cannon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45130\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:44:\"http://ma.tt/2015/06/aca-awesome-kay-cannon/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:380:\"<p>Pitch Perfect and its sequel, which I saw a few weekends ago, are the best geeky kind of fun (though I thought there were some jokes that fell flat in the latest). Longreads has an interview with Kay Cannon, the Pitch Perfect screenwriter, <a href=\"http://blog.longreads.com/2015/05/27/how-to-be-aca-awesome/\">How to Be Aca-Awesome and the changing definition of cool</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 07 Jun 2015 05:21:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Matt: Favorite Rappers\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45120\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:38:\"http://ma.tt/2015/06/favorite-rappers/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"<p>Someone asked me the other day who my favorite rappers were, here they are in no particular order:</p>
<p>Pre-2000: Big Pun, Jay Z, Nas, Ludacris, Method Man.</p>
<p>Post-2000: Kendrick Lamar, Kanye, Childish Gambino, J Cole, Drake.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 06 Jun 2015 04:02:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"WPTavern: A Primer on Writing Good Documentation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44807\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"http://wptavern.com/a-primer-on-writing-good-documentation\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8612:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2015/06/JeffMatsonThumbnail.jpg\"><img class=\"alignright size-thumbnail wp-image-44911\" src=\"http://wptavern.com/wp-content/uploads/2015/06/JeffMatsonThumbnail-150x150.jpg\" alt=\"JeffMatsonThumbnail\" width=\"150\" height=\"150\" /></a>This post was contributed by guest author <a href=\"http://jeffmatson.net/\">Jeff Matson</a>. Jeff is the head of documentation for <a href=\"http://www.gravityforms.com/\">GravityForms</a>. He is the creator of the <a href=\"https://wordpress.org/plugins/heartbeat-control/\">Heartbeat Control</a> WordPress plugin and is a fan of the 90s.</p>
<hr />
<p>Often times, documentation is the most underrated piece of the development process. When we look at rockstars in the WordPress community, we typically look at developers, designers, and marketers. Little is known about the documentation writers out there who shed their blood, sweat, and tears to ensure everything runs smoothly.</p>
<p>This post is about those who day in, and day out stare at endless lines of code to decipher what the developer was thinking, and the true meaning behind the code that exists.</p>
<h2>Good Documentation is More Than Words</h2>
<a href=\"http://wptavern.com/wp-content/uploads/2015/06/DocumentationWords.png\"><img class=\"size-full wp-image-44914\" src=\"http://wptavern.com/wp-content/uploads/2015/06/DocumentationWords.png\" alt=\"Documentation Words\" width=\"730\" height=\"295\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/80719942@N00/4733367729\">Variatie &#8211; Tekst</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>Good documentation writers provide more than an instruction manual, they provide an experience. I have known excellent documenters, coached beginners, and the largest difference between them is understanding the brain of those reading it. Just like a novel, documentation has a flow that keeps the reader interested and ingesting more information than they realize.</p>
<p>Quality documentation targets the users that are most likely to read it. It also provides a point of reference for those who are more unlikely to read it. For example, if documenting a particular hook, it’s typically assumed that a developer will be reading it, but what about those who have little development experience?</p>
<p>A good documentation writer will provide a point of reference for those who need more of a push in the right direction, without the need to contact support to spell it out for them.</p>
<h2>Documentation Has a Larger Impact Than You Think</h2>
<a href=\"http://wptavern.com/wp-content/uploads/2015/06/ImpactImage.png\"><img class=\"size-full wp-image-44916\" src=\"http://wptavern.com/wp-content/uploads/2015/06/ImpactImage.png\" alt=\"Impact Image\" width=\"585\" height=\"298\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/24113168@N03/3891599149\">Eruption</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>Most simply ignore documentation, pushing it off into the endless abyss until they can’t take it anymore. I’m guilty of the same thing in some cases. What those people don’t realize, is that every moment their plugin or theme is left undocumented, user experience suffers.</p>
<p>Let’s take a look at your most common support ticket. If you better documented that issue, would those tickets go away entirely? Probably not. Would you get fewer tickets regarding the issue as well as increase you or your support agent&#8217;s productivity? I guarantee it. I think we could all use fewer support tickets.</p>
<p>As I mentioned previously, documentation makes a dramatic impact on user experience. If the user is able to locate the information easily and efficiently, they have saved their own time as well as yours. The average world life expectancy is 66.57 years and your users would rather be doing something else with their lives than fiddling around with poorly written documentation.</p>
<p>If a customer sees that you have put quite a bit of time and effort into your documentation, they will, whether consciously or not, better appreciate you. Good documentation shows you care about them after the initial sale.</p>
<p>Have you ever been left high and dry after spending hard-earned money and soon regretted the purchase? I think we all have. With proper documentation, you can avoid passing that feeling off to your customers.</p>
<h2>How Can You Write Better Documentation?</h2>
<p>The first step is to stop avoiding it. Once you&#8217;re good at it, writing documentation is more of a pleasurable experience than you think. In fact, it will become second nature. Just like everything else in the world, practice makes perfect.</p>
<p>One of the first steps you want to take when deciding to take your documentation to the next level is to determine your pain points. What are you being contacted about? If you start blindly writing about things, you may find that what you’re writing about isn’t making as much of an impact you would like it to.</p>
<p>One of the best techniques I have discovered is to track the number of tickets that are documented vs. those that are not, and break those that are not into categories. This way, you can better target your pain points, and revise the parts that may not be as helpful as they should be.</p>
<p>After you have determined what documentation you should write, you should determine your target audience, and break it down into developers, users, and power users. This helps you cater to that particular audience. We’ll go over how to target those users a bit later.</p>
<p>Next, you want to break down the document. For developers, you’ll want to break it down into raw information (accepted arguments, return values, etc.), specific examples and use-cases. For users, the best course of action is a walkthrough. Every step they will need to take, regardless of how trivial it may seem, is critical.</p>
<p>Spell it out to them every step of the way. Documenting for power users is very similar to a user scenario, but more structured and scannable. Be clear, but allow them to easily jump to where they need to go without reading the previous step first.</p>
<h2>The Art of Writing Better Documentation</h2>
<a href=\"http://wptavern.com/wp-content/uploads/2015/06/DocumentationArt.png\"><img class=\"size-full wp-image-44917\" src=\"http://wptavern.com/wp-content/uploads/2015/06/DocumentationArt.png\" alt=\"Documentation Art\" width=\"497\" height=\"249\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/41455403@N00/458033123\">Space invader. Paris. Gare de lyon</a> &#8211; <a href=\"https://creativecommons.org/licenses/by-sa/2.0/\">(license)</a>
<p>When it comes to the art of writing your documentation, write in a way that best targets your audience, but also use simple language that you know they will understand. One of the best reasons for this is due to translations. While Google translate does an excellent job, it’s much easier to translate the simple vocabulary of a 5th grader than that contained within a post-grad thesis.</p>
<p>Within your content, don’t be afraid to link to relevant content. This will allow you to avoid repeating yourself through multiple documents, as well as allow the reader to back-track if they need more information about a particular subject. After all, your main goals are to make the user happy, and save yourself time.</p>
<p>The documentation process doesn’t stop after you press the <strong>publish</strong> button. Go back and revise every document as needed. Almost immediately after the document is published, go back and see if the support tickets you tracked have declined, and traffic to that particular article has increased. Usually, if you’re getting more traffic to an article, it’s helping. If you’re getting more traffic but the same number of support tickets, you may want to look into that article to see why.</p>
<h2>What We Have Learned</h2>
<p>First, I hope that after making it this far, you have a better appreciation for those in the trenches writing the documentation that most of us take for granted. It truly is an art form that many of us who write documentation for a living truly enjoy and put many, many hours into.</p>
<p>I also hope that you come away from this article thinking more about your existing documentation and how it can be improved. Proper documentation can be extremely rewarding and once in practice, can actually be quite fun to write.</p>
<p>Document early, document often. A great product is more than great code, it’s also beautifully documented.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 05 Jun 2015 21:26:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"WPTavern: Menu Customizer Tentatively Approved for WordPress 4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44894\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"http://wptavern.com/menu-customizer-tentatively-approved-for-wordpress-4-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2520:\"<p>WordPress 4.3 release lead Konstantin Obenland posted <a href=\"https://make.wordpress.org/core/2015/06/05/dev-chat-summary-june-3/\" target=\"_blank\">notes</a> from this week&#8217;s core development chat, confirming that the <a href=\"http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3\" target=\"_blank\">Menu Customizer</a> plugin has been conditionally approved to merge. The approval is pending a few conditions that will be required before officially merging it:</p>
<ul>
<li>Complete a11y audit.</li>
<li>Address possible blockers.</li>
<li>Merge php tests.</li>
<li>Add JS tests.</li>
</ul>
<p>One of the most controversial aspects of the <a href=\"https://make.wordpress.org/core/2015/06/03/feature-plugin-merge-proposal-menu-customizer/\" target=\"_blank\">proposal</a> submitted by project leader Nick Halsey was the timeline he outlined for removing all core links to the old Menus admin screen in future releases. Commenters on the proposal reacted strongly to this approach as well as this particular use of the customizer.</p>
<p>Discussion continued following the meeting, as Halsey wanted to address the critical issue of the timeline for removing removing the menus screen from the admin. He <a href=\"https://wordpress.slack.com/archives/core/p1433388261001615\" target=\"_blank\">attributes</a> the resistance to the customizer to a lack of education on the feature and strongly <a href=\"https://wordpress.slack.com/archives/core/p1433384388001601\" target=\"_blank\">advocates</a> &#8220;focusing on the new UI as the primary (and in terms of development, only) menus admin interface.&#8221;</p>
<blockquote><p>For Menu Customizer, this idea has been part of the project from the very beginning. My GSoC proposal (3/20/14) states &#8216;If the Menu Customizer provides all of the features of the existing menu management screen, while clearly demonstrating that it is a better solution than the existing screen in user tests, it could potentially replace the existing screen entirely for users that can access the Customizer,&#8217; and there has never been indication that this isn&#8217;t the direction we should move in, other than the general and ongoing resistance to the Customizer as a whole that we&#8217;ve seen from many community members (which I think is more of an educational issue).</p></blockquote>
<p>Discussion continues on the matter and work will move forward on the plugin to ensure that it meets the conditions outlined for its merge into WordPress 4.3.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 05 Jun 2015 13:35:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: BuddyDrive 1.3 Utilizes the New BP Attachments API\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44417\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"http://wptavern.com/buddydrive-1-3-utilizes-the-new-bp-attachments-api\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3160:\"<a href=\"http://wptavern.com/wp-content/uploads/2015/06/paperclips.jpg\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/paperclips.jpg\" alt=\"photo credit: Paperclips - (license)\" width=\"1024\" height=\"515\" class=\"size-full wp-image-44887\" /></a>photo credit: <a href=\"http://www.flickr.com/photos/45953381@N05/5539562805\">Paperclips</a> &#8211; <a href=\"https://creativecommons.org/licenses/by/2.0/\">(license)</a>
<p>One of the most exciting features added in <a href=\"http://wptavern.com/buddypress-2-3-livio-released-features-the-new-bp-attachments-api\" target=\"_blank\">BuddyPress 2.3</a> is the new <a href=\"https://codex.buddypress.org/plugindev/bp_attachment/\" target=\"_blank\">BP Attachments API</a>. It provides a BP core-supported method of managing user-submitted files and opens up a world of possibilities for plugin developers.</p>
<p>The API powers the new avatar uploads UI, but it can also be used to extend BuddyPress to add media sharing capabilities. If you want to see a good example of this in the wild, check out BuddyDrive version <a href=\"https://github.com/imath/buddydrive/tree/1.3\" target=\"_blank\">1.3.0</a>. The plugin was created by BP core developer <a href=\"http://imathi.eu/\" target=\"_blank\">Mathieu Viet</a>, who led the effort to get the BP Attachments API into the latest release.</p>
<p><a href=\"https://wordpress.org/plugins/buddydrive/\" target=\"_blank\">BuddyDrive</a> allows members to share a file or a list of files with the community and includes various settings for restricting access. It&#8217;s essentially like a Dropbox clone for BuddyPress, designed to enhance collaboration between members. The plugin was a prime candidate for adapting the BP Attachments API to power community file sharing in a simpler, more elegant way.</p>
<p>You can see it active in the new &#8220;BuddyDrive Editor&#8221; included in version 1.3, demonstrated in the video below:</p>
<p></p>
<p>Viet posted an <a href=\"https://github.com/imath/buddydrive/wiki/The-BuddyDrive-Editor\" target=\"_blank\">example function</a> in the plugin&#8217;s wiki to show how the BuddyDrive Editor can be placed anywhere. The feature is a good example of how easy it is for developers to leverage the API to manage user-generated media from the frontend.</p>
<p>BuddyDrive 1.3 is currently in beta and on track to be released soon. If you&#8217;d like to help test the beta or inspect the code to see how it works, you can download a zip file from Viet&#8217;s <a href=\"http://imathi.eu/2015/06/02/buddydrive-1-3-0/\" target=\"_blank\">preview post</a>. The unreleased <a href=\"https://github.com/imath/buddydrive/tree/1.3\" target=\"_blank\">version 1.3</a> is also available on GitHub.</p>
<p>If you want to learn more about using the new BP Attachments API, check out Viet&#8217;s comprehensive <a href=\"https://codex.buddypress.org/plugindev/bp_attachment/\" target=\"_blank\">BP codex article</a>. It walks you through extending the <code>BP_Attachment</code> class to validate and store files in a subdirectory of wp-content/uploads. The documentation also includes a sample plugin to demonstrate how you might add attachments to private messages.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 05 Jun 2015 04:20:05 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:30;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:72:\"WPTavern: How to Add a Default Image to Jetpack’s Related Posts Module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44865\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"http://wptavern.com/how-to-add-a-default-image-to-jetpacks-related-posts-module\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2712:\"<p>Jetpack&#8217;s related posts module is a great way to show related content without using the same server resources used to host a site. When activated, the module displays three related posts. One of two options available is to use a large and visually striking layout.</p>
<a href=\"http://wptavern.com/wp-content/uploads/2015/06/JetpackRelatedPostsConfiguration.png\"><img class=\"size-full wp-image-44867\" src=\"http://wptavern.com/wp-content/uploads/2015/06/JetpackRelatedPostsConfiguration.png\" alt=\"Jetpack Related Posts Configuration\" width=\"1105\" height=\"402\" /></a>Jetpack Related Posts Configuration
<p>When enabled, the module looks for a large image that&#8217;s at least 350x200px in posts and uses it when displaying related posts.</p>
<p>The downside to using this option is that related posts that don&#8217;t use images will display as a post excerpt instead. This can cause an undesirable look, especially if one or two related posts have images.</p>
<a href=\"http://wptavern.com/wp-content/uploads/2015/06/RelatedPostsUsingText.png\"><img class=\"size-full wp-image-44869\" src=\"http://wptavern.com/wp-content/uploads/2015/06/RelatedPostsUsingText.png\" alt=\"Related Posts Displaying a Post Excerpt\" width=\"990\" height=\"333\" /></a>Related Posts Displaying a Post Excerpt
<p>Jeremy Herve who works on the Jetpack team <a href=\"http://jeremy.hu/jetpack-missing-images-related-posts/\">published a tutorial</a> that explains how to show a default image if one is not detected. Both of his solutions require the user to add code which is a barrier for many users.</p>
<p>Brian Krogsgard of <a href=\"https://poststatus.com/\">PostStatus.com</a> recommends that a conditional option be added that allows users who use a large and visually striking layout to easily configure a default image.</p>
<blockquote><p>Currently, the user can click a checkbox to enable images for related posts output. I propose that an image upload option conditionally appear upon the image option being selected.</p>
<p>That keeps the option out of sight for folks that don&#8217;t use images for related posts but makes it easier for normal folks to upload a default image for what I imagine would be an incredibly well adopted feature.</p></blockquote>
<p>It&#8217;s a great suggestion and removes the need to edit or modify code. Although one of WordPress&#8217; philosophies is <a href=\"https://wordpress.org/about/philosophy/\">decisions not options</a>, this is a scenario where I think it makes sense. If this is an option you&#8217;d like to see added or have a different suggestion, you&#8217;re encouraged to <a href=\"https://github.com/Automattic/jetpack/issues/2220\">participate in the discussion</a> on GitHub.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Jun 2015 23:03:22 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:31;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: All Official Easy Digital Downloads Themes are Now 100% Free\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44831\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:79:\"http://wptavern.com/all-official-easy-digital-downloads-themes-are-now-100-free\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4235:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2015/03/EasyDigitalDownloadsFeaturedImage-e1429138648237.png\"><img src=\"http://wptavern.com/wp-content/uploads/2015/03/EasyDigitalDownloadsFeaturedImage-e1429138648237.png\" alt=\"EasyDigitalDownloadsFeaturedImage\" width=\"620\" height=\"220\" class=\"aligncenter size-full wp-image-40496\" /></a></p>
<p>Easy Digital Downloads <a href=\"https://easydigitaldownloads.com/blog/easy-digital-downloads-themes/\" target=\"_blank\">announced</a> a major change to its <a href=\"https://easydigitaldownloads.com/themes/\" target=\"_blank\">themes marketplace</a> today. All official EDD themes (those that are built by the EDD core team) are now 100% free. This includes half a dozen themes that are guaranteed to be fully compatible with EDD, including the new <a href=\"https://easydigitaldownloads.com/downloads/vendd/\" target=\"_blank\">Vendd</a> theme launching today.</p>
<p>EDD support manager Sean Davis clarified how the free themes will be supported:</p>
<blockquote><p>Official EDD themes are available to you at absolutely no cost. They will still be licensed so that you can receive theme updates directly from your WordPress dashboard and we will also provide support. The only thing changing is the price.</p></blockquote>
<p>Responding to <a href=\"https://twitter.com/nphaskins/status/606478597851746304\" target=\"_blank\">criticism</a> on Twitter saying that the change contributes to the <a href=\"https://philiparthurmoore.com/ruining-wordpress/\" target=\"_blank\">undervaluation of WordPress themes</a>, EDD founder <a href=\"https://pippinsplugins.com/\" target=\"_blank\">Pippin Williamson</a> said, &#8220;For us it&#8217;s not about the themes. It&#8217;s about the entire package. By making it easy for users to have a good shop up and running in minutes, we significantly increase the potential value to that customer and of that customer. We also dramatically reduce the cost of support by having more users on more reliable themes that are built for EDD.&#8221;</p>
<p>Making half a dozen themes free might seem like it would significantly increase EDD&#8217;s support burden, but Williamson expects that the move will pay off in other ways. Like many other WordPress business owners who have made some of their best work free, Williamson has a strategy for how it will work.</p>
<p>&#8220;The change lowers the barrier to entry,&#8221; Williamson said. &#8220;When the barrier is lowered, the user base grows. When the user base grows, the customer base grows. From a business side, we will have far more success converting free users to paid customers after they&#8217;ve already been given a great experience with a theme.&#8221;</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/nphaskins\">@nphaskins</a> Not sugar coating it at all. We\'ll make 5x more by giving them away than we did selling them <a href=\"https://twitter.com/SDavisMedia\">@sdavismedia</a> <a href=\"https://twitter.com/NateWr\">@natewr</a></p>
<p>&mdash; Pippinsplugins (@pippinsplugins) <a href=\"https://twitter.com/pippinsplugins/status/606480064448995329\">June 4, 2015</a></p></blockquote>
<p></p>
<p>This major change is in line with EDD&#8217;s basic freemium business model, which has been in place from the start. The core product(s) are free and satisfied users go on to make purchases from the <a href=\"https://easydigitaldownloads.com/downloads/\" target=\"_blank\">add-ons marketplace</a>.</p>
<p>&#8220;By setting them up with a good theme from the get go, the likelihood that they become a paying customer is substantially higher,&#8221; Williamson said.</p>
<p>So far, the freemium model has worked well for the company and making six theme products free makes sense when the business primarily revolves around plugins. After just <a href=\"http://wptavern.com/easy-digital-downloads-turns-3-years-old\" target=\"_blank\">three years in business</a>, EDD pulled in roughly half a million dollars in <a href=\"https://pippinsplugins.com/2014-review/\" target=\"_blank\">revenue in 2014</a>. As themes were not a significant portion of the revenue, Williamson is re-assigning them to be free products in order to continue to build a customer base for his plugins.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Jun 2015 19:13:47 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:32;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Matt: WordCamp US Survey\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45127\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:40:\"http://ma.tt/2015/06/wordcamp-us-survey/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:506:\"<p>We&#8217;re trying something new this year: instead of WordCamp San Francisco being the main WordCamp event of the year doing a WordCamp US in a rotating city. I&#8217;ve heard some great in-person pitches for places like Phoenix already. Do you think your city would be the coolest place in the 50 states for the first ever WordCamp US? <a href=\"http://wordcampcentral.polldaddy.com/s/apply-to-host-wordcamp-us\">Submit your city in this new survey</a>. It&#8217;s open until the end of the month.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Jun 2015 07:01:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:33;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"WPTavern: WordCamp US 2015 Now Accepting Applications for Host City\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44810\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"http://wptavern.com/wordcamp-us-2015-now-accepting-applications-for-host-city\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3841:\"<p><a href=\"http://wptavern.com/wp-content/uploads/2015/06/usa-flag.jpg\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/usa-flag.jpg\" alt=\"usa-flag\" width=\"1022\" height=\"507\" class=\"aligncenter size-full wp-image-44819\" /></a></p>
<p>WordCamp San Francisco has traditionally been one of the most important WordPress events of the year where Matt Mullenweg delivers his annual State of the Word address. Last year, he <a href=\"http://wptavern.com/matt-mullenwegs-state-of-the-word-highlights-internationalization-mobile-and-new-tools-for-wordpress-contributors\" target=\"_blank\">announced</a> that the the event had outgrown the Mission Bay venue and that it would be expanding to become WordCamp US in 2015.</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\">Touch the walls as you walk out, as this is the last time we\'ll have <a href=\"https://twitter.com/hashtag/WordCampSF?src=hash\">#WordCampSF</a> here! ~ <a href=\"https://twitter.com/photomatt\">@photomatt</a> <a href=\"https://twitter.com/hashtag/wcsf14?src=hash\">#wcsf14</a> <a href=\"https://twitter.com/hashtag/endofanera?src=hash\">#endofanera</a></p>
<p>&mdash; WordCamp SF (@WordCampSF) <a href=\"https://twitter.com/WordCampSF/status/526454529584549889\">October 26, 2014</a></p></blockquote>
<p></p>
<p>The decision to seek a new venue in a new city was partly based on the need to make room for more attendees and presentations. Another benefit of moving the event out of San Francisco, one of the most expensive cities in the world, is that it will likely become more accessible to a greater number of people.</p>
<p>WordCamp US will follow a format similar to WordCamp Europe in that it will be held in a rotating city. The city has not yet been selected, which is surprising given that the year is nearly halfway finished.</p>
<p>Mullenweg put out <a href=\"http://ma.tt/2015/06/wordcamp-us-survey/\" target=\"_blank\">a call for host city applications</a> on his blog and linked to a <a href=\"http://wordcampcentral.polldaddy.com/s/apply-to-host-wordcamp-us\" target=\"_blank\">survey</a> where candidates can apply.</p>
<p>There are a lot of cities out there that might be an excellent fit for WordCamp US, but many are lacking a vibrant local WordPress community to help support the event. While this is not stated as an explicit requirement, it would be difficult to pull off such a large event without an army of local volunteers.</p>
<p>WordPress is aiming big for its first ever WordCamp US. The survey states that host city applicants must secure a venue with hotels within three miles that can support 1,500 &#8211; 2,000 attendees. Potential organizers must supply average hotel costs for a range of budgets and average flight costs from the West Coast, East Coast, Midwest, Mexico, and Canada.</p>
<p>Hosting the event will be a massive undertaking that will require an organization team capable of putting everything together in a very short amount of time. Events of this size normally have the benefit of longer planning periods. For example, <a href=\"http://wptavern.com/applications-to-host-wordcamp-europe-2016-closing-soon\" target=\"_blank\">applications to host WordCamp Europe 2016 closed two months ago</a> and the team is already training volunteers for next year&#8217;s event.</p>
<p>If your team is up to the challenge of hosting WordCamp US, you&#8217;ll need to be prepared to submit venue information with room capacities, a detailed event budget, potential dates, and contributor day options. So far, Mullenweg has received in-person pitches for Phoenix but the application process is open to teams from any city. When <a href=\"http://wptavern.com/where-will-wordcamp-usa-be-held\" target=\"_blank\">WP Tavern readers were surveyed seven months ago</a>, commenters favored Chicago, Las Vegas, Kansas City, Houston, and Dallas.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Jun 2015 04:58:10 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:34;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"Matt: Unsubscribing from Newsletters\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45117\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"http://ma.tt/2015/06/unsubscribing-from-newsletters/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2593:\"<p>When <a href=\"http://ma.tt/2004/04/trying-gmail/\">Gmail first came out I got on pretty early and procured what I thought was a cool email address</a>, mmmmmm@gmail.com. That&#8217;s because matt@ was too short, and matthew@ was taken. Ask anyone with a &#8220;cool&#8221; email address on a major service or Twitter handle and you&#8217;ll mostly hear about what a pain it is constantly getting spam, other people&#8217;s email, and people trying to log in to your account. These days it seems that address is used mostly by people forced to put something into an email form at places they don&#8217;t want to, so constant mail from mortgage places, car dealerships, porn sites, and countless email newsletters. I never ended up using the account for anything myself besides normal Google stuff.</p>
<p>There&#8217;s a service to help you unsubscribe from things <a href=\"https://unroll.me/\">called Unroll.me</a> which is pretty neat, and it&#8217;ll scan your account to find all of the newsletters and things you can unsubscribe from, and gives you a one-click interface to do so. Unfortunately if you had over 5,000 &#8220;subscriptions&#8221; as I had, that becomes a 5,000 click operation and they provide no bulk tools, and apparently no plans to add them:</p>
<blockquote class=\"twitter-tweet\" width=\"550\"><p lang=\"en\" dir=\"ltr\"><a href=\"https://twitter.com/photomatt\">@photomatt</a> unfortunately there\'s no mass unsubscribe option at this time, though  we are seriously considering it for the future!</p>
<p>&mdash; Unroll.Me (@Unrollme) <a href=\"https://twitter.com/Unrollme/status/595680719495634949\">May 5, 2015</a></p></blockquote>
<p></p>
<p>I assume this is because they want people to add newsletters to their digest service instead of just unsubscribing. Code to the rescue! Written by the <a href=\"https://profiles.wordpress.org/coffee2code\">inimitable Scott Reilly</a>. After you sign up and sign in, go <a href=\"https://unroll.me/rollup/edit/new\">to this page</a>, go to the javascript console (in Chrome: View → Developer → Javascript Console), then copy and paste the below code and press enter.</p>
.gist table { margin-bottom: 0; }
<p></p>
<p>Then sit back and wait, it&#8217;s set so every 1.5 seconds it clicks an unsubscribe link. I do this about once a week now since I can accumulate 20-100 new subscriptions in that time. This code will break if they change anything, but should be pretty easy to update when they do. It currently shows me as unsubscribed from 7,868 things! If there was a way to pay for my account on Unroll.me I would do so happily.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 04 Jun 2015 02:23:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:35;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:82:\"WPTavern: BuddyPress 2.3 “Livio” Released, Features the New BP Attachments API\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44666\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"http://wptavern.com/buddypress-2-3-livio-released-features-the-new-bp-attachments-api\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4503:\"<a href=\"http://wptavern.com/wp-content/uploads/2015/06/chez-livio.jpg\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/chez-livio.jpg\" alt=\"photo credit: Chez Livio on TripAdvisor.com\" width=\"700\" height=\"348\" class=\"size-full wp-image-44799\" /></a>photo credit: <a href=\"http://www.tripadvisor.com/Restaurant_Review-g196581-d714980-Reviews-Chez_Livio-Neuilly_sur_Seine_Hauts_de_Seine_Ile_de_France.html#photos\">Chez Livio on TripAdvisor.com</a>
<p>BuddyPress 2.3 &#8220;Livio&#8221; was released today, named in honor of <a href=\"http://www.chezlivio.com/\" target=\"_blank\">Chez Livio</a>, a famous Italian restaurant and pizza joint in Paris. Development on the 2.3 release cycle began in March with contributors <a href=\"http://wptavern.com/buddypress-2-3-development-kicks-off-contributors-prioritize-work-on-new-apis\" target=\"_blank\">prioritizing work on new APIs</a> alongside improvements to BuddyPress&#8217; existing APIs. Here&#8217;s a quick overview of what&#8217;s new:</p>
<h4>BP Attachments API</h4>
<p>The highlight of this release is the <a href=\"https://codex.buddypress.org/plugindev/bp_attachment/\" target=\"_blank\">BP Attachments API</a>, a new library that enables developers to create components that have the ability to manage uploads. You can see it in action in the greatly <a href=\"http://wptavern.com/buddypress-2-3-will-improve-avatar-uploads-with-the-new-bp-attachments-api\" target=\"_blank\">improved avatar uploads UI</a>, which now supports drag-and-drop uploads and includes mobile integration with phone/tablet/laptop cameras.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2015/06/avatar-ui.gif\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/avatar-ui.gif\" alt=\"avatar-ui\" width=\"657\" height=\"355\" class=\"aligncenter size-full wp-image-44742\" /></a></p>
<h4>Companion Stylesheets for WordPress Default Themes</h4>
<p>If you want to test BuddyPress and you&#8217;re not sure which theme to use, check out one of WordPress&#8217; most recent default themes. Version 2.3 of the plugin ships with <a href=\"http://wptavern.com/buddypress-2-3-will-introduce-companion-stylesheets-for-wordpress-default-themes\" target=\"_blank\">companion stylesheets</a> for Twenty Fourteen and Twenty Fifteen, which tidy up the appearance of BuddyPress components and UI elements when the default themes are active. The stylesheets also introduce vertical menus that eliminate the crowding often seen in the horizontal user/group navigation.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2015/05/bp-user-account-nav.png\"><img src=\"http://wptavern.com/wp-content/uploads/2015/05/bp-user-account-nav.png\" alt=\"bp-user-account-nav\" width=\"1300\" height=\"1004\" class=\"aligncenter size-full wp-image-43323\" /></a></p>
<h4>Better Excerpts for Blog Post Activity</h4>
<p>Version 2.3 has better support for blog post activity items. If the Site Tracking component is activated, BuddyPress will now display better excerpts in the activity stream for posts containing images or other embedded media. This improvement pairs nicely with the custom post type support that was added to the activity stream in the <a href=\"http://wptavern.com/buddypress-2-2-spumoni-released-featuring-new-member-type-api\" target=\"_blank\">2.2. release</a>.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2015/06/activity-stream-blog-post.jpg\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/activity-stream-blog-post.jpg\" alt=\"activity-stream-blog-post\" width=\"616\" height=\"443\" class=\"aligncenter size-full wp-image-44744\" /></a></p>
<p>Other highlights in BuddyPress 2.3 include:</p>
<ul>
<li><strong>Member Type Directories</strong> – Create directories of member types on your site using the <a href=\"https://codex.buddypress.org/developer/member-types/\" target=\"_blank\">Member Type API</a>.</li>
<li><strong>Star Private Messages</strong> – Mark important messages in your inbox with a star.</li>
<li><strong>Notification Meta</strong> – Notifications are now more extensible with an additional metadata table.</li>
</ul>
<p>Overall this release offers an excellent balance between new features and improvements upon existing features, which combine to make BuddyPress more extensible and more enjoyable to use. It includes hundreds of bug fixes and enhancements from 40 volunteer contributors. For a full list of changes, check out the <a href=\"https://codex.buddypress.org/releases/version-2-3-0/\" target=\"_blank\">BuddyPress codex page for version 2.3</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jun 2015 21:19:53 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:36;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:74:\"WPTavern: Menu Customizer Officially Proposed for Merge Into WordPress 4.3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44729\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:84:\"http://wptavern.com/menu-customizer-officially-proposed-for-merge-into-wordpress-4-3\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:5536:\"<p>Contributors on the <a href=\"https://wordpress.org/plugins/menu-customizer/\" target=\"_blank\">Menu Customizer</a> feature plugin are proposing its inclusion in WordPress 4.3. Nick Halsey posted the Customizer Team&#8217;s <a href=\"https://make.wordpress.org/core/2015/06/03/feature-plugin-merge-proposal-menu-customizer/\" target=\"_blank\">proposal</a> last night, beginning with a summary of the purpose of moving menu management into the customizer:</p>
<blockquote><p>In the process, we hope to offer an updated design with improved user flow, a mobile-first interface, improved accessibility, rebuild the administration UI from the ground up to be JavaScript-driven, solve long-standing problems with the current implementation, and clarify the purposes and capabilities of the menus feature. Additionally, Menu Customizer contributes significantly to the long-term goal to move all appearance functionality and, really, everything that could benefit from live previewing, from the admin to the Customizer.</p></blockquote>
<p>Menu management in the customizer is essentially a full replacement of all the capabilities previously housed in the admin. It allows for editing, reordering, deleting, and adding individual menu items within any menu. The plugin adds a convenient global search that includes all post types, terms, and taxonomies.</p>
<p>The video below was prepared by Halsey&#8217;s team to demonstrate the capabilities of the Menu Customizer:</p>
<p></p>
<p>The dizzying speed with which she flips between panels in the demo is not representative of the capabilities of your average WordPress user. Given that the plugin currently requires WordPress 4.3 alpha, it&#8217;s not likely that it has not been widely tested by users of varying experience levels.</p>
<p>My initial impression after testing is that managing menus in the customizer makes me feel claustrophobic. The live previews and the mobile friendliness are the big wins here, but they come at the expense of a squished menu management experience. For sites that use WordPress as a CMS, with dozens and sometimes hundreds of pages and subpages, menu management in the customizer could become rather cumbersome.</p>
<p><a href=\"http://wptavern.com/wp-content/uploads/2015/06/menu-customizer-test-add-page.jpg\"><img src=\"http://wptavern.com/wp-content/uploads/2015/06/menu-customizer-test-add-page.jpg\" alt=\"menu-customizer-test-add-page\" width=\"848\" height=\"644\" class=\"aligncenter size-full wp-image-44768\" /></a></p>
<p>I have no doubt that the Menu Customizer has been architected to perform better as a JavaScript-driven solution for managing menus. Halsey and the team employed no small amount of wizardry in creating the custom panel for implementing screen options and the sections that lazy load menu items.</p>
<p>But if you put a relatively new WordPress user in front of the customizer menu panel, will it be intuitive to use?  Will stuffing menus into the customizer cause the usability of the feature to decline?</p>
<p><a href=\"https://www.facebook.com/groups/advancedwp/permalink/962590793803135/\" target=\"_blank\">Reactions to the proposal</a> in the Advanced WordPress Facebook group were less than enthusiastic, as not many favor expanding the customizer&#8217;s reach into menu management.</p>
<p>&#8220;I really don&#8217;t feel the Customizer is the correct place to <em>manage</em> menus or any content for that matter,&#8221; member Tom Hemsley commented. &#8220;If a theme offers <em>styling</em> options for a menu then fair enough &#8211; put those styling options in the customizer. But the customizer is not the place for managing content. Why not force people to create new posts using the Customizer, too?&#8221;</p>
<p>Lisa League&#8217;s comment accurately summarizes many others&#8217; initial reactions to the demo video: &#8220;My first impression of Make was not &#8216;Cool, look how they did this with the customizer&#8217; but &#8216;Whoa, there&#8217;s too much stuff in this tiny space.\'&#8221;</p>
<p>If the Menu Customizer plugin is approved to merge into core, Halsey outlined a plan for the removal of the old menu admin screen in favor of focusing all new development on the UI in the customizer. WordPress 4.3 would point the Menus link in the admin bar to Menus in the customizer and later releases would remove all core links to the Menus admin screen, or point them to the customizer.</p>
<p>&#8220;The above plan is fairly aggressive, to eliminate any ambiguity about future plans and intentions and to avoid the potential for mass trac ticket rot,&#8221; Halsey said.</p>
<p>WordPress cannot move forward without making changes and taking risks. The question of whether or not to merge the Menu Customizer plugin should inspire some fairly active discussion in the days ahead. If you want to test the plugin for yourself, the easiest way is to install the <a href=\"https://wordpress.org/plugins/wordpress-beta-tester/\" target=\"_blank\">WordPress Beta Tester</a> plugin to get 4.3-alpha running and then install <a href=\"https://wordpress.org/plugins/menu-customizer\" target=\"_blank\">Menu Customizer</a> from WordPress.org.</p>
<p>Core contributors will discuss the Menu Customizer proposal today during the regularly scheduled development meeting on Slack. According to the <a href=\"https://make.wordpress.org/core/version-4-3-project-schedule/\" target=\"_blank\">WordPress 4.3 project schedule</a>, the feature plugin merge window will close June 17th and the official release is expected in mid-August.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jun 2015 18:15:20 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:37;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:70:\"WPTavern: Steven Gliebe Launches WordPress Commercial Plugin Directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44649\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:80:\"http://wptavern.com/steven-gliebe-launches-wordpress-commercial-plugin-directory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:6532:\"<p>More than 38k plugins are available for free on the <a href=\"https://wordpress.org/plugins/\">WordPress plugin directory</a>. While the theme directory has a <a href=\"https://wordpress.org/themes/commercial/\">category for commercial themes</a>, the plugin directory does not.</p>
<p>When <a href=\"https://mattreport.com/interview-matt-mullenweg/\">Matt Medeiros interviewed Matt Mullenweg</a> earlier this year and asked if the plugin directory could turn into something similar to an app store, Mullenweg replied that the plugin directory will not turn into a market place or an app store and will never host commercial plugins. Outside of <a href=\"http://codecanyon.net/\">CodeCanyon</a>, I&#8217;m not aware of any WordPress plugin directory that focuses on commercial plugins.</p>
<h2>Introducing Pro Plugin Directory</h2>
<p>Steven Gliebe who <a href=\"http://wptavern.com/hostingreviews-io-webhosting-reviews-without-the-affliate-links\">runs HostingReviews.io</a> and is the founder of <a title=\"http://churchthemes.com/\" href=\"http://churchthemes.com/\">Churchthemes.com</a> has launched the<a href=\"https://proplugindirectory.com/2015/05/30/launching/\"> Pro Plugin Directory</a>. The site lists commercial plugins from a variety of categories including, forms, performance, and security. Its design is based on a modified child theme of <a href=\"https://array.is/themes/checkout-wordpress-theme/\">Checkout by ArrayHQ</a>.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/ProPluginDirectory.png\"><img class=\"size-full wp-image-44750\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/ProPluginDirectory.png?resize=960%2C609\" alt=\"Pro Plugin Directory Home Page\" /></a>Pro Plugin Directory Home Page
<p>Gliebe created the site because he was frustrated that there was no resource for easily locating commercial WordPress plugins.</p>
<p>&#8220;Most of the time I do find what I need in the free directory. Sometimes though, I want to see what the commercial options are,&#8221; he said.</p>
<p>After asking several members of the community if such a site already exists, he came up empty. &#8220;I asked around and found that apparently there is no definitive <em>Pro</em> plugin directory as I suspected, so I thought I&#8217;d give it a go. WordPress is 12 years old and it&#8217;s beyond time to establish this.&#8221;</p>
<h2>Monetization Strategy</h2>
<p>Maintaining a directory can be hard work and without a way to be paid for the effort involved, interest can disappear quickly. Affiliate links are a natural strategy for the site while another is to sell upgraded listings.</p>
<p>His focus is getting the site established with as many listings as possible. &#8220;Right now, my focus is on building up the site and making it useful. If it proves to be successful in that respect then I&#8217;m sure there will be a reasonable way to turn a profit and take it to the next level,&#8221; Gliebe said.</p>
<h2>Scalability</h2>
<p>One of the largest obstacles of running a directory is scalability. In the case of Pro Plugin Directory, the submissions come directly from the plugin sellers. The <a href=\"https://proplugindirectory.com/submissions/\">Submission Guidelines</a> have certain requirements to help ensure quality content.</p>
<p>&#8220;The original content they submit is in a sense their <em>payment</em> for being listed and gaining exposure. There surely is work to be done but it will not be as heavy as <a href=\"http://themesorter.com/\">ThemeSorter</a> or similar failed plugin and theme directory endeavors. I basically click <strong>approve</strong> or <strong>reject</strong> with the way it&#8217;s setup,&#8221; Gliebe said.</p>
<a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/SearchWPPluginListing.png\"><img class=\"size-full wp-image-44752\" src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/SearchWPPluginListing.png?resize=1025%2C601\" alt=\"Search WP Plugin Directory Listing\" /></a>SearchWP Plugin Directory Listing
<h2>How Success will be Measured</h2>
<p>Without monetizing the site up front and being a new resource within the community, Gliebe tells the Tavern what metrics he&#8217;ll use to measure success.</p>
<p>&#8220;Repeat visitors. If I see that people return to the site to find commercial plugin options then I&#8217;ll know that it is a <em>go-to</em> resource. I would also like to see search engine results for specific types of plugins return the free plugin directory at position number one and a Pro Plugin Directory category at number two, so that the user has a complete picture of his options readily available.&#8221;</p>
<h2>The Directory is Useless Without Plugin Submissions</h2>
<p>The directory won&#8217;t become what Gliebe envisions unless commercial plugin authors <a href=\"https://proplugindirectory.com/submissions/\">submit their plugins</a>. &#8220;In order for these things to happen, the directory needs plugins. It needs a very wide selection of commercial WordPress plugins. I need the support of plugin authors above all.&#8221;</p>
<p>Although Gliebe is encouraged with the number of plugins already submitted to the site, he needs the directory to be the first thing people think of when searching for a commercial option.</p>
<p>&#8220;If it becomes a <em>go-to</em> place for plugin sellers to market their new plugins then it just might work. I figure, if they know about it, why wouldn&#8217;t they list their plugins? It&#8217;s free, it&#8217;s easy, and I&#8217;d do it myself before other, harder, marketing tactics.&#8221;</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/PluginSubmissionForm.png\"><img class=\"size-full wp-image-44753\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/PluginSubmissionForm.png?resize=676%2C734\" alt=\"Pro Plugin Directory Submission Form\" /></a>Pro Plugin Directory Submission Form
<h2>Does it Stand a Chance?</h2>
<p>Creating a commercial plugin directory is not a new idea. Brad Touesnard founded the WordPress App Store which tried to be a commercial plugin directory while making it easier to browse and buy plugins. It didn&#8217;t attract the number of eyeballs needed to make the business sustainable and <a href=\"http://wptavern.com/brad-touesnard-explains-why-the-wp-app-store-failed\">ultimately shut down</a>.</p>
<p>If Gliebe can&#8217;t get the support of commercial plugin authors and find a way to get a large number of plugins into the directory within a year, it will likely suffer the same fate.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jun 2015 04:38:34 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:38;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Matt: Jefferson on Idleness\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45122\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"http://ma.tt/2015/06/jefferson-on-idleness/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:153:\"<blockquote><p>
Determine never to be idle. It is wonderful how much may be done if we are always doing.</p>
<p>&#8212; Thomas Jefferson</p></blockquote>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jun 2015 04:26:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:39;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:63:\"WPTavern: The Quest for the Perfect WordPress Admin Search Tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44660\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"http://wptavern.com/the-quest-for-the-perfect-wordpress-admin-search-tool\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:8586:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/journey.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/journey.jpg?resize=1025%2C547\" alt=\"photo credit: Jesse Bowser\" class=\"size-full wp-image-44709\" /></a>photo credit: <a href=\"https://stocksnap.io/photo/2DEL42UQ7M\">Jesse Bowser</a>
<p>The quest for the perfect WordPress admin search tool continues with yet another plugin designed to help you zip around the backend. Those who are familiar with <a href=\"http://www.alfredapp.com/\" target=\"_blank\">Alfred</a> for Mac will find many similarities in <a href=\"https://wordpress.org/plugins/aladdin/\" target=\"_blank\">Aladdin</a>, which was released today by <a href=\"https://twitter.com/tsiger\" target=\"_blank\">Gerasimos Tsiamalos</a> and the folks at <a href=\"http://www.cssigniter.com/\" target=\"_blank\">CSSIgniter</a>.</p>
<p>Aladdin joins the ranks of <a href=\"http://wptavern.com/jarvis-a-free-quicksearch-tool-for-the-wordpress-dashboard\" target=\"_blank\">Jarvis</a>, <a href=\"http://wpbutler.com/\" target=\"_blank\">WP Butler</a>, <a href=\"https://wordpress.org/plugins/wp-jump-menu/\" target=\"_blank\">WP Jump Menu</a>, and Jetpack&#8217;s <a href=\"http://jetpack.me/support/omnisearch/\" target=\"_blank\">Omnisearch</a> in the recent proliferation of WordPress admin search tools. The plugin provides a simple keyboard quick launcher for accessing WordPress admin menu items.</p>
<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/aladdin-example.png\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/aladdin-example.png?resize=800%2C600\" alt=\"aladdin-example\" class=\"aligncenter size-full wp-image-44678\" /></a></p>
<p>After installing the plugin, users can launch Aladdin by pressing the <strong>Shift key</strong> twice. Start typing in the search modal until you see the menu option then press enter. Here&#8217;s a quick demo of how it works:</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/aladdin.gif\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/aladdin.gif?resize=797%2C767\" alt=\"aladdin\" class=\"aligncenter size-full wp-image-44673\" /></a></p>
<h3>How Does Aladdin Compare to Other WordPress Admin Search Tools?</h3>
<p>Aladdin cannot yet measure up to other admin search tools without adding the capability of searching through content. Tsiamalos posted his plugin in the <a href=\"https://www.facebook.com/groups/advancedwp/permalink/962183043843910/\" target=\"_blank\">Advanced WordPress users Facebook</a> group this morning, requesting feedback.</p>
<p>&#8220;I&#8217;m thinking of adding auto-complete for user-generated content as well &#8211; Posts, Pages, Post Types etc.,&#8221; he said.</p>
<p>Initial testers of the plugin were enthusiastic about the interface but could not see a use for it outside of a large website with lots of menus for custom post types and/or a long list of plugins installed. Small, simple blogging sites would not benefit from this tool unless Tsiamalos adds the ability to search for user-generated content. In its current state, it&#8217;s best suited to those who are using WordPress as a CMS.</p>
<p>&#8220;I initially built it for my local multisite (60+ plus themes to maintain) and I thought others would find it useful, too,&#8221; Tsiamalos told the Tavern. This kind of scenario makes sense for the plugin&#8217;s current capabilities.</p>
<p>Aladdin&#8217;s interface, with its convenient launch and lightning fast filtering, is the golden feature of this plugin. After testing Aladdin, I believe the tool has a lot of promise, especially once the author expands its capabilities to include content searching. The search modal is currently positioned too low on the page, but that&#8217;s an easy fix. The fact that the modal is always hidden unless summoned is also a bonus.</p>
<p>The interface for Jetpack&#8217;s <a href=\"http://jetpack.me/support/omnisearch/\" target=\"_blank\">Omnisearch</a> module cannot compare. While it functions well to search through the admin and content, it requires the user to scroll to the top to type into the admin search bar or visit the dedicated Omnisearch page. Searching redirects you to a cluttered results page that is not convenient to browse.</p>
<p>Overall, the experience of searching with <a href=\"https://wordpress.org/plugins/jarvis/\" target=\"_blank\">Jarvis</a> is simpler and more visually appealing than Aladdin or the Omnisearch module. It searches both admin menu items and user-generated content. It can be launched using the quick key &#8220;/&#8221; or by typing in the admin search bar. The demo below demonstrates how it works:</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/jarvis-demo.gif\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/jarvis-demo.gif?resize=992%2C578\" alt=\"jarvis-demo\" class=\"aligncenter size-full wp-image-44695\" /></a></p>
<p>Unfortunately, Jarvis hasn&#8217;t been updated in more than year. Similarly, <a href=\"https://wordpress.org/plugins/wp-butler/\" target=\"_blank\">WP Butler</a>, which provides a slightly less polished experience, hasn&#8217;t been updated in more than two years.</p>
<p><a href=\"https://wordpress.org/plugins/wp-jump-menu/\" target=\"_blank\">WP Jump Menu</a> is faster than all of the solutions above, but it doesn&#8217;t include WordPress admin menu items. Its somewhat clunky interface, anchored to the admin search bar, is almost forgivable given its speedy searching capabilities. However, WP Jump Menu is limited to searching user-generated content and isn&#8217;t designed for quickly jumping to admin menu items.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/wp-jump-menu.gif\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/wp-jump-menu.gif?resize=1025%2C521\" alt=\"wp-jump-menu\" class=\"aligncenter size-full wp-image-44697\" /></a></p>
<h3>WordPress Core Needs a Convenient Admin Search Experience</h3>
<p><a href=\"https://wordpress.org/plugins/omnisearch/\" target=\"_blank\">The Search Initiative</a>, which is currently an inactive feature plugin for WordPress core, essentially <a href=\"https://make.wordpress.org/core/2014/01/15/search-initiative-on-hold/\" target=\"_blank\">fell off the map in January 2014</a> after the feature <a href=\"http://wptavern.com/wordpress-global-admin-search-evolves-to-tackle-bigger-problems\" target=\"_blank\">failed to merge into WordPress 3.8 at the end of 2013</a>. The project&#8217;s contributors no longer had time to devote to the plugin and its development has never regained the momentum it had in 2013.</p>
<p>Nevertheless, there&#8217;s no doubt that WordPress users are eager to add some sort of global search capability to the admin. It&#8217;s a feature that helps mitigate the complexity of the admin when many custom post types are active and plugins add in their own menu items. The ability to search both content and menu items is beneficial to new and experienced users alike.</p>
<p>Responses to <a href=\"https://www.facebook.com/groups/advancedwp/permalink/962183043843910/\" target=\"_blank\">Tsiamalos&#8217; post on Aladdin</a> indicate that users are willing to test and help refine any extension that demonstrates a convenient way of solving the admin search problem. Many disparate solutions have cropped up over the past few years and often the plugins&#8217; creators were not aware of the other options before building their own.</p>
<p>WordPress core improvement projects like the <a href=\"https://make.wordpress.org/core/tag/omnisearch/\" target=\"_blank\">Search Initiative</a> are led by volunteers and are at the mercy of contributors&#8217; available time. That means there is no guarantee that the project will move forward to become a more elegant solution for tackling current issues with searching the admin. As with any open source project, it will take motivated folks to step forward to propose a new path forward.</p>
<p>Admin search is a complex problem but one many plugin developers have found worthy of pursuit. If reception to the Aladdin plugin is any indication, WordPress users are ready to embrace an easier way of navigating the admin. A collaborative effort combining the best features all admin search attempts would make for an excellent feature plugin, as core contributors have already <a href=\"https://make.wordpress.org/core/2013/10/23/omnisearch-global-admin-search-final-pitch/\" target=\"_blank\">demonstrated interest in merging a solution</a> with the right implementation to adequately serve WordPress users.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 22:09:01 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:40;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"Post Status: Automattic to acquire WP Job Manager from Mike Jolley\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"https://poststatus.com/?p=12810\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"https://poststatus.com/automattic-to-acquire-wp-job-manager-from-mike-jolley/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:11800:\"<p><a href=\"http://mikejolley.com/\">Mike Jolley</a> is the lead developer of WooCommerce by day, and has managed the very successful WP Job Manager plugin by night.</p>
<p>Mike created <a href=\"https://wpjobmanager.com/\">WP Job Manager</a> (<a href=\"https://wordpress.org/plugins/wp-job-manager/\">also on WordPress.org</a>) as a side project for fun <a href=\"https://poststatus.com/notes/mike-jolley-releases-alpha-of-a-new-job-manager-plugin/\">in June 2013</a>. He released paid extensions through Gumroad (a hosted tool for selling digital downloads) in September 2013 and in May of 2014 &#8212; after the plugin had really taken off &#8212; <a href=\"http://mikejolley.com/2014/05/launching-wpjobmanager-com/\">he moved to WooCommerce</a>.</p>
<p>WP Job Manager filled a void in the WordPress plugin space. It now has more than 30,000 active installs, according to WordPress.org, and the suite of add-on plugins and themes has been very successful.</p>
<h3>WP Job Manager to be acquired by Automattic</h3>
<p>As most readers know, <a href=\"https://poststatus.com/automattic-acquired-woocommerce-woothemes/\">WooThemes and WooCommerce were acquired by Automattic</a> in May. Mike joined the other WooThemes employees at <a href=\"http://automattic.com\">Automattic</a>. Automattic has a strict policy that employees cannot have paid side projects, whether client or product work. For Mike to stay at Automattic, he had to figure out what the future of WP Job Manager would be.</p>
<p>Mike decided to sell WP Job Manager to Automattic after they expressed interest, and they have reached an agreement for a deal. While the terms of the deal are not public and Matt Mullenweg and Mike would not comment on the deal, I&#8217;m able to offer some additional insight based on conversations with others that have knowledge of the situation.</p>
<h3>Revenue and WP Job Manager ecosystem</h3>
<p>According to sources, WP Job Manager was bringing in $35,000-$40,000 revenue per month at its peak. I believe that Automattic paid greater than one year of expected income to retain rights to the plugin and paid add-ons.</p>
<p>In March, Mark Forrester <a href=\"http://wordpress.tv/2015/03/09/mark-forrester-going-small-to-grow-big/\">spoke at WordCamp Cape Town</a> on plugin sales models, where he noted that Mike&#8217;s <a href=\"https://wpjobmanager.com/add-ons/\">add-ons</a> were making around $20,000 per month, a number which has grown considerably since then.</p>
<p>The move from Gumroad to WooCommerce &#8212; and the addition of a bundle option, were quite successful, it appears. Furthermore, add-on products from third parties helped drive growth to WP Job Manager.</p>
<p>For example, <a href=\"https://astoundify.com\">Astoundify</a> has two themes that utilize WP Job Manager &#8212; Listify and Jobify &#8212; which gross between $45,000 and $50,000 per month alone. In addition to their themes, they make another $5,000-$7,000 from WP Job Manager related plugins. So Astoundify makes around $55,000 per month on top of the WP Job Manager plugin, and in result drive considerable sales back to WP Job Manager&#8217;s other paid add-ons.</p>
<p>There are other developers with add-ons and themes for WP Job Manager as well. It&#8217;s a successful ecosystem with a mix of themes and plugins.</p>
<p>Mike was able to create the product with relatively low support costs as well. He hired two part-time support providers, but otherwise managed development and other tasks himself.</p>
<p>By all means, WP Job Manager is a ridiculously successful product, especially as a side project. It&#8217;s important to remember that this is not the status-quo, but Mike did an incredible job finding the right market combined with a truly terrific product.</p>
<h3>Q&amp;A with Mike Jolley and Matt Mullenweg</h3>
<p>I sent some questions to Mike and both Mike and Matt Mullenweg responded. Here are those questions and answers in full:</p>
<p><strong>When did the acquisition take place? After WooThemes was acquired, same time?</strong></p>
<p><strong>MJ</strong>: The acquisition of WPJM came after the Woo deal was finalised.</p>
<p>I had known that an acquisition may be happening, but when this was official and it was revealed that Automattic were the acquirers I wasn’t actually aware of their policies surrounding paid projects. I should have read “Year Without Pants” <img src=\"https://poststatus.com/wp-includes/images/smilies/simple-smile.png\" alt=\":)\" class=\"wp-smiley\" /></p>
<p><strong>MM</strong>: We want for everyone at Automattic to be fully focused on our shared business and projects, it’s part of what brings everyone together. We had been aware of WPJM from pretty early in the process and thought it could be a nice complement to the WooCommerce business since its approach was so similar.</p>
<p><strong>What options did you have for the acquisition? I know A8C [Automattic] doesn’t allow paid side projects, so did a change have to happen for you to stay on with Automattic to work on WooCommerce?</strong></p>
<p><strong>MM</strong>: Anything was an option, including making WPJM free or selling it to a third party, but I’m glad we came to the solution we did. Since WPJM is part of Automattic now there’s no real or perceived conflict to the continuing work on it or revenue from it.</p>
<p><strong>MJ</strong>: I didn’t want to stop working on WooCommerce. It’s still the project I’m most passionate about and I’m not ready to walk away just yet. Although it was a really tough and emotional decision to make, I feel I made the right decision to part ways with WPJM to continue working on WooCommerce.</p>
<p><strong>Did you explore other options? Selling to someone else, etc?</strong></p>
<p><strong>MJ</strong>: I looked into a few options before I knew the details of the deal from Automattic, naturally. I thought about offloading it to a developer-friend, making it all free, or doing it full time. Ultimately though, the appeal of working for Automattic, the benefits surrounding that, being able to continue working on WooCommerce and with the people I respect, and the acquisition itself won the day.</p>
<p><strong>Did you have any support, dev, or other paid help for managing WPJM?</strong></p>
<p><strong>MJ</strong>: Yes; I’ve had help on the support front from both Bryce Adams and Scott Basgaard whom have done work for me on a freelance basis. They have both been a tremendous help, and crucial given the time I have available. Really thankful to those guys.</p>
<p>On the development side it’s been largely me, although Bryce and Remi Corson have both built an add-on, again freelance based.</p>
<p><strong>Will you still be the lead on WPJM development at A8C?</strong></p>
<p><strong>MJ</strong>: This is not yet certain. WooCommerce demands most of my time as team lead so it may be difficult to work on both, however if possible I’d still like to contribute to the project and help where I can. The core project at least is GPL and public on Github so I can definitely see myself contributing there to keep my Github commit streak going.</p>
<p><strong>What does the third party ecosystem look like on WPJM? Jobify, etc. How many folks have products based on it? How could life change for these products?</strong></p>
<p><strong>MJ</strong>: The 3rd party system for WPJM differs to that of WooCommerce in that I do not sell 3rd party items myself via a marketplace. All 3rd party stuff is external.</p>
<p>Plugin wise, Smyl.es has a cool field editor, Remi Corson, Tiny Giant Studios and Astoundify have several, and there are a few integrations with other plugins ranging from search to geolocation.</p>
<p>On the theme front, Jobify (and Listify) by Astoundify are the most prominent. Tiny Giant Studios have a few, I’m aware of some for sale on TemplateMonster (unsure of quality), and then there is one-that-shall-not-be-named on Themeforest which bundles paid add-ons (shame).</p>
<p>The theme side is diverse. Even though I’m targeting the jobs niche, Listify is a generic listings theme which can list everything, powered by WPJM. There are even also even more-niche themes such as Petsitter and Babysitter themes which customise the plugin further.</p>
<p>Overall, a lot of things going on in this space. If the plugin grows from a8c involvement (which I hope to see) these developers should benefit from an increased user base. Really glad they chose to back my little project.</p>
<p><strong>Will the format for sales of WPJM change in the future, under the umbrella of A8C? Will it become free?</strong></p>
<p><strong>MJ</strong>: Short term, things should remain as-is, with Automattic taking over the site, sales, and support. Medium- to long-term I cannot say for certain what will happen, but with more time and resources devoted to it (more than my weekends and evenings) I hope to see the ecosystem grow and support for the plugin to continue.</p>
<p><strong>What kind of revenue was WP Job Manager seeing in the months prior to the acquisition?</strong></p>
<p><strong>MM</strong>: No comment on the economics of the plugin.</p>
<p><strong>How many paid users do you have?</strong></p>
<p><strong>MM</strong>: Still no comment on the economics of the plugin.</p>
<p><strong>What kind of acquisition occurred? Cash and stock? Cash or stock only?</strong></p>
<p><strong>MM</strong>: Sorry we don’t comment on this.</p>
<p><strong>Can you tell me the ballpark of the acquisition value?</strong></p>
<p><strong>MM</strong>: Definitely Astrodome.</p>
<h3>What we&#8217;ve learned here</h3>
<p>There&#8217;s a lot we can take away from the WP Job Manager acquisition.</p>
<p>For one, it proves that a single individual can have a massive impact on the WordPress ecosystem. It&#8217;s impossible to deny how influential Mike has been. He&#8217;s the lead developer of the world&#8217;s most popular eCommerce plugin, while he runs an incredible successful job manager plugin on the side.</p>
<p>His success is astonishingly impressive to me. I&#8217;m quite happy for him and everything he&#8217;s achieved.</p>
<p>It also appears to me based on discussions that it was not well known that Automattic restricts side projects for their employees. It&#8217;s a long standing policy and I think it works for them; however it does make for certain challenges when they hire self-employed product makers or acquire companies with different policies.</p>
<p>The acquisition of WooThemes brought a number of challenges. Mike being on board would have been a huge priority for me, if I were acquiring WooThemes. The half a million dollars or more (I am just guessing) to acquire WP Job Manager would be well worth it, even if I didn&#8217;t have big plans for the product.</p>
<p>That said, I think in this case Automattic could make great use of WP Job Manager. It would be another terrific fit for their WordPress.com VIP clients, and if they actively develop it, it could receive even more adoption long term.</p>
<p>However, just as I thought with WooCommerce, I wouldn&#8217;t be surprised if they make Mike&#8217;s traditionally paid add-ons free, as paid plugins don&#8217;t particularly jive with Matt Mullenweg&#8217;s historical viewpoints. And WP Job Manager &#8212; while it has quite a bit of potential for a normal person &#8212; doesn&#8217;t likely have the same growth potential as WooCommerce to be an attractive monetization avenue as an Automattic product.</p>
<p>So I would expect that the plugin model will change over the coming months.</p>
<p>Congratulations to both Mike and Automattic; this is a win for both parties. Mike is a huge asset to any organization, and I&#8217;m really glad he is able to be financially rewarded for all of his contributions making great WordPress products.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 17:45:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"Brian Krogsgard\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:41;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:77:\"WPTavern: WPShout Releases New WordPress Plugin that Displays all Image Sizes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44654\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:87:\"http://wptavern.com/wpshout-releases-new-wordpress-plugin-that-displays-all-image-sizes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:2581:\"<p>When images are uploaded to the WordPress media library, several different sized images are generated. Image sizes are based on the settings on the Media Settings screen and from themes that often contain custom image sizes that are specific, such as featured images.</p>
<p>Locating images with custom sizes in the WordPress media library is difficult since they&#8217;re not listed and the file URL points to the original image.</p>
<a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/DefaultMediaLibrarySettings.png\"><img class=\"size-full wp-image-44655\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/06/DefaultMediaLibrarySettings.png?resize=758%2C415\" alt=\"Media Library Image Settings\" /></a>Media Library Image Settings
<p>The team at <a href=\"http://wpshout.com/\">WPShout</a> released a new plugin called <a href=\"https://wordpress.org/plugins/display-all-image-sizes/\">Display All Image Sizes</a> that displays all available image sizes, their permalinks, and dimensions. Once activated, you&#8217;ll see a list of all sizes of each image in the Add Media modal and in each image&#8217;s individual page in the Media Library.</p>
<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/DisplayAllImageSizesInAction.png\"><img class=\"size-full wp-image-44656\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/DisplayAllImageSizesInAction.png?resize=1025%2C519\" alt=\"All Image Sizes and Their URLs\" /></a>All Image Sizes and Their URLs
<p>With the plugin activated, a vertical scroll wheel is added to the attachment details screen. Depending on the size of your monitor,  you may encounter the same thing.</p>
<p>The scroll bar is annoying, because I commonly use the image sizes in the attachment display settings drop down menu. This requires me to scroll every time I need to access that menu.</p>
<h2>Ideas for Improvement</h2>
<p>Instead of showing all image sizes in a blocky manner and vertically stretching the screen, they should be moved to the existing drop down menu where you can select an image&#8217;s size. When a user selects an image size from the menu, the file URL could automatically change to point to that image. This way, the plugin would use native interface elements and make the default attachment details screen more useful.</p>
<p>Display all image sizes works as advertised with WordPress 4.2.2. If the team improves the user interface and can minimize the screen real-estate it uses, the plugin could turn out to be a very useful addition to sites that use a lot of custom image sizes.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 15:39:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:42;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"WPTavern: Matt Mullenweg’s Keynote at WordCamp Dallas 2008\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44639\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"http://wptavern.com/matt-mullenwegs-keynote-at-wordcamp-dallas-2008\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3206:\"<a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/WordCampDallas2008FeaturedImage.png\"><img class=\"size-full wp-image-44643\" src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/WordCampDallas2008FeaturedImage.png?resize=650%2C200\" alt=\"WordCamp Dallas Featured Image\" /></a>Photo courtesy of <a href=\"http://ma.tt/2008/03/first-day-of-wordcamp/\">Matt Mullenweg</a>
<p>The following is a recording of Matt Mullenweg&#8217;s keynote presentation at WordCamp Dallas 2008. <a href=\"http://onemansblog.com/2008/04/03/wordcamp-dallas-2008-matt-mullenweg-wordpress-25-and-beyond/\">Recorded by John Pozadzides</a> who helped organize the event, it&#8217;s the only video of Mullenweg&#8217;s keynote that exists. In the video, Mullenweg walks the audience through WordPress 2.5, the redesign of WordPress.org, and the future of WordPress. There&#8217;s also a question and answer segment in the second half of the presentation.</p>
<p><!--[if IE]><object width=\"545\" height=\"405\" id=\"viddlerOuter-33a80f5b\" classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000\"><param name=\"movie\" value=\"//www.viddler.com/player/33a80f5b/0/\"><param name=\"allowScriptAccess\" value=\"always\"><param name=\"allowNetworking\" value=\"all\"><param name=\"allowFullScreen\" value=\"true\"><param name=\"flashVars\" value=\"f=1&#038;autoplay=f&#038;disablebranding=f\"><object id=\"viddlerInner-33a80f5b\"><video id=\"viddlerVideo-33a80f5b\" src=\"//www.viddler.com/file/33a80f5b/html5mobile/\" type=\"video/mp4\" width=\"545\" height=\"363\" poster=\"//www.viddler.com/thumbnail/33a80f5b/\" controls=\"controls\" x-webkit-airplay=\"allow\"></video></object></object><![endif]--> <!--[if !IE]> <!-->  <!--<![endif]--></p>
<p>WordCamp Dallas 2008 was the first WordCamp I&#8217;ve ever attended and is the first time I met Mullenweg in person. Minutes before he took the stage, <a href=\"https://wordpress.org/news/2008/03/wordpress-25-brecker/\">WordPress 2.5 &#8220;Michael Brecker&#8221;</a> was released to the world.</p>
<p>WordPress 2.5 was the culmination of six months of work. In fact, Mullenweg <a href=\"http://lists.automattic.com/pipermail/wp-hackers/2008-January/016993.html\">announced</a> on the WP-Hackers mailing list that WordPress 2.4 would be skipped so that extra focus could be applied to 2.5.</p>
<blockquote><p>In light of the big changes happening in the codebase and admin section, we&#8217;re going to push back the next release to be aimed for early March.</p>
<p>This is the timeframe when 2.5 was originally scheduled for, so we&#8217;re treating the originally planned 2.4 in December as a skipped release, as a result of both the holidays and the large changes which we weren&#8217;t able to start on until late October.</p>
<p>There&#8217;s some good stuff in the oven, and we don&#8217;t want to rush it. The new release shall be called 2.5. Various official docs and roadmaps will be updated in due course.</p></blockquote>
<p>The video is an important piece of WordPress history that needs to be preserved and if possible, uploaded to <a href=\"http://wordpress.tv/\">WordPress.tv</a>. I&#8217;ve asked Pozadzides for permission to upload it to WordPress.tv and will update the post once I receive a response.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Tue, 02 Jun 2015 04:40:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:43;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"Matt: Webmonkey Podcast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45115\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"http://ma.tt/2015/06/webmonkey-podcast/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:239:\"<p>I was on the <a href=\"http://www.wired.com/2015/05/webmonkey-podcast-e-commerce-coming-wordpress-com/\">Webmonkey Podcast talking about WooCommerce and tech in general</a>, my part starts around 26 minutes in.</p>
<p></p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 23:34:55 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:44;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:89:\"WPTavern: WordPress.com Launches Insights: Better Stats for Visualizing Publishing Trends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44598\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"http://wptavern.com/wordpress-com-launches-insights-better-stats-for-visualizing-publishing-trends\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3505:\"<p>WordPress.com <a href=\"https://en.blog.wordpress.com/2015/06/01/insights-a-new-view-of-your-stats/\" target=\"_blank\">announced</a> major improvements to its Stats feature today. The new Insights tab gives users a bird&#8217;s eye view of posting activity and visitor trends. The Stats panel now displays all-time numbers for posts, views, visitors, and the day the site received the most number of views.</p>
<p>Insights also calculates the most popular day of the week and the most popular hour based on when the site gets the most views on average.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-all-time-stats.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-all-time-stats.jpg?resize=667%2C362\" alt=\"insights-all-time-stats\" class=\"aligncenter size-full wp-image-44604\" /></a></p>
<p>Posting Activity is another new addition that provides a way to visualize how often you are publishing. The feature is reminiscent of GitHub&#8217;s <a href=\"https://help.github.com/articles/viewing-contributions-on-your-profile-page/#viewing-contributions-from-specific-times\" target=\"_blank\">Contributions calendar</a>, which makes it easy to view contributions from specific times. Insights allows you to mouse over a specific date with a color marker to see how many posts were published that day.</p>
<p><a href=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-posting-activity.jpg\"><img src=\"http://i2.wp.com/wptavern.com/wp-content/uploads/2015/06/insights-posting-activity.jpg?resize=658%2C256\" alt=\"insights-posting-activity\" class=\"aligncenter size-full wp-image-44615\" /></a></p>
<p>If, for some reason, you&#8217;re missing the old version of WordPress.com&#8217;s stats, it is available for a limited time under <a href=\"https://wordpress.com/my-stats/\" target=\"_blank\">wordpress.com/my-stats/</a>.</p>
<p>Insights is not yet available on WordPress mobile apps but will likely be added soon. When asked when Insights will be available to self-hosted users, WordPress.com representative Jonathan Sadowski replied, &#8220;If you install Jetpack and enable the Stats module, you’ll be able to view these stats on WordPress.com for your .org blog.&#8221;</p>
<p>Stats is arguably one of the most popular features in Jetpack and a major factor for many in the decision to connect with WordPress.com. However, the view from inside the self-hosted Jetpack stats panel is starting to look a little dated when compared to the mobile apps or WordPress.com. Adding Insights to Jetpack&#8217;s stats panel would save users a trip over to WordPress.com to discover this information.</p>
<p>Most people don&#8217;t have the time or motivation to log into Google Analytics and create a meaningful interpretation of that data to improve their publishing habits. The new and improved stats with Insights offers a better understanding of when you&#8217;re posting and even interprets your traffic to provide actionable data, such as what hour might be the best for scheduling a post, what months lend you the most time to commit to blogging, etc.</p>
<p>The all-time stats also make it easier to track your blogging progress and set milestones for increasing posts, views, and visitors, and ultimately beating your best traffic day on record. The new feature is <a href=\"https://wordpress.com/stats/insights\" target=\"_blank\">live on WordPress.com</a> today and we&#8217;ll be watching for it in future updates to the mobile apps.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 22:07:23 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:45;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"WPTavern: Sergej Müller, Creator of Antispam Bee, Says Goodbye to WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44567\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:83:\"http://wptavern.com/sergej-muller-creator-of-antispam-bee-says-goodbye-to-wordpress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4847:\"<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/Sergej-Müller.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/06/Sergej-Müller.jpg?resize=250%2C382\" alt=\"Sergej-Müller\" class=\"alignright size-full wp-image-44590\" /></a>Sergej Müller is <a href=\"https://gist.github.com/sergejmueller/bccd658a5cdeb5b57deb\" target=\"_blank\">saying goodbye to WordPress</a> after nine years and nearly three million downloads of his <a href=\"https://profiles.wordpress.org/sergejmueller/#content-plugins\" target=\"_blank\">free plugins</a>. <a href=\"https://wordpress.org/plugins/antispam-bee/\" target=\"_blank\">Antispam Bee</a>, his most popular contribution, is currently in use on more than 200,000 WordPress sites.</p>
<p>Müller penned a <a href=\"https://gist.github.com/sergejmueller/bccd658a5cdeb5b57deb\" target=\"_blank\">farewell</a> Gist on GitHub in his native German, which <a href=\"http://glueckpress.com/\" target=\"_blank\">Caspar Hübinger</a> was kind enough to <a href=\"https://gist.github.com/glueckpress/ed370acc556c475c3be5\" target=\"_blank\">translate</a> into English.</p>
<blockquote><p>For me, a chapter of my life is coming to an end. A chapter that has brought an abundance of experience, learning, and fun. A chapter that, on the other hand, demanded a lot of time, nerves, and motivation. But where there’s a will, there’s a way, and I deeply hope my software and my commitment may have made the WordPress community a bit better in terms of quality.</p></blockquote>
<p>Müller is discontinuing his WordPress contributions due to health reasons, but he plans to find a suitable successor who will be able to deliver the level of quality and support that his users have come to expect. His plugins, most notably <a href=\"https://wordpress.org/plugins/antispam-bee/\" target=\"_blank\">Antispam Bee</a>, <a href=\"https://wordpress.org/plugins/cachify/\" target=\"_blank\">Cachify</a>, <a href=\"https://wordpress.org/plugins/statify/\" target=\"_blank\">Statify</a>, <a href=\"https://wpseo.de/\" target=\"_blank\">wpSEO</a> and <a href=\"https://optimus.io/\" target=\"_blank\">Optimus</a>, are used widely around the world, particularly throughout Germany, Austria, and the germanophone parts of Switzerland.</p>
<p>Hübinger, who is active in the German and European WordPress communities, has been using Müller&#8217;s plugins for the past six years.</p>
<p>&#8220;Just as valuable for me personally were his blog posts and tutorials,&#8221; he said. &#8220;I pretty much learned WordPress development from his blog, and <a href=\"http://bueltge.de/\" target=\"_blank\">Frank Bueltge</a>&#8216;s.</p>
<p>&#8220;There are a lot of comments expressing great surprise. No one saw him quitting, obviously. Sergej has been a key figure of the German-speaking WordPress community for the last nine years. While not quite so popular beyond the Germanophone context, I think his note that almost every WordPress user over here has heard of or uses at least one of his plugins is no exaggeration.&#8221;</p>
<p>While Müller does have a couple commercial plugins available, he has never made a living from them. For the past nine years he has been working as a software engineer outside of WordPress. Anyone aspiring to adopt his plugins will need to meet the high standards that he has set in terms of quality and support, especially in regards to supporting the German community.</p>
<p>&#8220;Monika Thon-Soun, a WordPress veteran from Austria, <a href=\"http://www.texto.de/sergej-einfach-danke-fuer-alles-2192/\" target=\"_blank\">mentions</a> she doesn’t remember a single instance where one of Sergej’s plugins would have been hacked,&#8221; Hübinger said. &#8220;Given the popularity of his plugins, that’s truly worth mentioning, as it underlines a character feature that everyone loves him for: reliability.&#8221;</p>
<p>Müller&#8217;s plugin contributions have always been a hobby for him but he is no longer able to sustain their development and support. He is currently in conversations with parties who are interested in his projects and will announce the new maintainers once it has been finalized.</p>
<p>Sergej Müller&#8217;s contributions signify the importance of having WordPress extensions and tutorials available for users to learn WordPress in their own language. His role in cultivating the German development community and supporting its many users will not be easily filled.</p>
<p>&#8220;As a friend, I understand and support his decision completely,&#8221; Hübinger said. &#8220;As a WordPress user, it’s&#8230;a catastrophe.</p>
<p>&#8220;Whoever follows him on G+ will have seen occasional moments of disappointment. In those moments, you could see all his passion. Because it really wasn’t about money for him. Acknowledgement and paying it forward is his favorite currency.&#8221;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 17:11:02 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:46;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:29:\"Matt: Beethoven, Mozart, Bach\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45099\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:43:\"http://ma.tt/2015/05/beethoven-mozart-bach/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:238:\"<blockquote><p>Beethoven tells you what it&#8217;s like to be Beethoven and Mozart tells you what it&#8217;s like to be human. Bach tells you what it&#8217;s like to be the universe.</p></blockquote>
<p>― Douglas Adams</p>
<p>&nbsp;</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 01 Jun 2015 05:42:00 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:47;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"Matt: Martian Review\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"http://ma.tt/?p=45110\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"http://ma.tt/2015/05/martian-review/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:1727:\"<p>On the recommendation of my friend <a href=\"https://twitter.com/timyoung\">Timothy Young</a> I checked out the book <a href=\"http://www.amazon.com/dp/B00EMXBDMA\"><em>The Martian: A Novel</em> by Andy Weir</a>. Think of it like <a href=\"http://www.amazon.com/dp/B00IC8VF10/\">Shackleton&#8217;s Voyage</a> (a great recommendation from <a href=\"http://toni.org/\">Toni</a>) but on Mars. I really enjoyed the book, and if you like geeky, science-filled novels you will too.  One thing about the publishing I thought was really cool, as <a href=\"http://en.wikipedia.org/wiki/The_Martian_(Weir_novel)\">the Wikipedia puts it</a>:</p>
<blockquote><p>Having been rebuffed by literary agents when trying to get prior books published, Weir decided to put the book online in serial format one chapter at a time for free at his website. At the request of fans he made an Amazon Kindle version available through Amazon.com at 99 cents (the minimum he could set the price). The Kindle edition rose to the top of Amazon&#8217;s list of best-selling science-fiction titles, where it sold 35,000 copies in three months, more than had previously downloaded it for free. This garnered the attention of publishers: Podium Publishing, an audiobook publisher, signed for the audiobook rights in January 2013. Weir sold the print rights to Crown in March 2013 for six figures.</p></blockquote>
<p>I was hoping it was on a WordPress blog, but <a href=\"http://www.galactanet.com/writing.html\">it appears to be more of a static HTML site</a> (his <a href=\"http://www.andyweirauthor.com/\">official site is WP-powered</a>) and includes some awesome short vignettes like <a href=\"http://www.galactanet.com/oneoff/meetingsarah.html\">Meeting Sarah</a>.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 30 May 2015 10:54:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:4:\"Matt\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:48;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:66:\"WPTavern: Why Cloudup is Not Replacing the WordPress Media Library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44516\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:76:\"http://wptavern.com/why-cloudup-is-not-replacing-the-wordpress-media-library\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:4027:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png\"><img class=\"aligncenter size-full wp-image-42250\" src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png?resize=650%2C200\" alt=\"CloudUpFeaturedImage2\" /></a>When <a href=\"http://en.blog.wordpress.com/2013/09/25/cloudup-joins-the-automattic-family/\">Automattic acquired Cloudup</a> in 2013, two of the most exciting parts <a href=\"http://techcrunch.com/2013/09/25/automattic-acquires-file-sharing-service-cloudup-to-build-faster-media-library-and-enable-co-editing/\">of the announcement</a> was replacing the WordPress media library with <a href=\"https://cloudup.com/\">Cloudup</a> and the ability to co-edit posts similar to Google Docs. We <a href=\"http://wptavern.com/cloudup-makes-file-sharing-incredibly-easy\">discussed the concept</a> in early 2014 and readers were concerned about owning their data.</p>
<p>Two years later, the <a href=\"https://wordpress.org/news/2014/04/smith/\">WordPress media library and the visual post editor</a> have received major improvements while integration with Cloudup is non-existent. When Matt Mullenweg was asked about the integration in a <a href=\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\">recent interview</a>, he responded,</p>
<blockquote><p>We did a lot of really awesome UI improvements to the editor and did some things we were very excited about, but because we weren&#8217;t working on a TinyMCE base, some of the basic editing stuff was really difficult.</p></blockquote>
<p>The team spent about six months to complete the first 80% of the project then spent a year and a half to reach 85%. Setbacks included a lot of rabbit holes and hidden complexity. The team now works on different things within Automattic that revolve around data.</p>
<h2>Zeditor is an Educational Resource</h2>
<p>The work completed by the team is <a href=\"https://github.com/Automattic/zeditor\">open source and available on GitHub</a>. It&#8217;s called Zeditor and serves as an educational resource. &#8220;We learned a ton through the way we architected the JavaScript and we think it serves as a good model for doing lots of JavaScript projects going forward,&#8221; Mullenweg said.</p>
<p>Listen to Mullenweg explain why Cloudup is not replacing the WordPress media library in the following audio clip. Be sure to <a href=\"http://wptavern.com/wpweekly-episode-194-celebrating-wordpress-12th-birthday-with-matt-mullenweg\">check out the entire interview</a> where we discuss a variety of other WordPress topics.</p>
<div class=\"audio-shortcode-wrap\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/04/CloudUpFeaturedImage2.png?resize=175%2C131\" alt=\"Why Cloudup is Not Replacing the WordPress Media Library\" class=\"landscape thumbnail post-thumbnail audio-image\" /><!--[if lt IE 9]><script>document.createElement(\'audio\');</script><![endif]-->
<a href=\"http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3\">http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3</a></div><div class=\"media-shortcode-extend\"><div class=\"media-info audio-info\"><ul class=\"media-meta\"><li><span class=\"prep\">Run Time</span> <span class=\"data\">3:14</span></li><li><span class=\"prep\">Artist</span> <span class=\"data\">Jeff Chandler and Marcus Couch</span></li><li><span class=\"prep\">Album</span> <span class=\"data\">WordPress Weekly</span></li><li><span class=\"prep\">File Name</span> <span class=\"data\"><a href=\"http://wptavern.com/wp-content/uploads/2015/05/CloudupWordPressMediaLibraryZeditor.mp3\">CloudupWordPressMediaLibraryZeditor.mp3</a></span></li><li><span class=\"prep\">File Size</span> <span class=\"data\">1.36 MB</span></li><li><span class=\"prep\">File Type</span> <span class=\"data\">MP3</span></li><li><span class=\"prep\">Mime Type</span> <span class=\"data\">audio/mpeg</span></li></ul></div><button class=\"media-info-toggle\">Audio Info</button></div>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 21:11:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Jeff Chandler\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:49;a:6:{s:4:\"data\";s:13:\"
	
	
	
	
	
	
\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:90:\"WPTavern: Fight for the Future Leads Congress Blackout Campaign to Protest the Patriot Act\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"http://wptavern.com/?p=44507\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:100:\"http://wptavern.com/fight-for-the-future-leads-congress-blackout-campaign-to-protest-the-patriot-act\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:3501:\"<p><a href=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/congress-blackout.jpg\"><img src=\"http://i0.wp.com/wptavern.com/wp-content/uploads/2015/05/congress-blackout.jpg?resize=1025%2C481\" alt=\"congress-blackout\" class=\"aligncenter size-full wp-image-44522\" /></a></p>
<p>Three key provisions within the Patriot Act will expire at the stroke of midnight on Sunday. The Senate needs 60 votes in order to provide an extension or renew the provisions past June 1st. <a href=\"http://en.wikipedia.org/wiki/Section_summary_of_the_Patriot_Act,_Title_II#Section_215:_Access_to_records_and_other_items_under_FISA\" target=\"_blank\">Section 215</a> of the measure is particularly controversial in that it allows the National Security Agency (NSA) to collect data from Americans&#8217; phone records.</p>
<p><a href=\"https://www.fightforthefuture.org/\" target=\"_blank\">Fight for the Future</a> is leading an internet campaign wherein 14,000+ websites will be blocking access to Congress&#8217; IP addresses, redirecting that traffic to the <a href=\"https://www.blackoutcongress.org/\" target=\"_blank\">blackout protest page</a> where they will see the following message:</p>
<blockquote><p>You have conducted mass surveillance of everyone illegally and are now on record for trying to enact those programs into law. You have presented Americans with the false dichotomy of reauthorizing the PATRIOT Act or passing the USA Freedom Act. The real answer is to end all authorities used to conduct mass surveillance. Until you do, thousands of web sites have blocked your access, and more are joining every day.</p></blockquote>
<p>The campaign is coordinated by the <a href=\"https://www.internetdefenseleague.org/\" target=\"_blank\">Internet Defense League</a>, an organization that has been instrumental in <a href=\"http://wptavern.com/join-the-september-10th-internet-slowdown-protest-with-these-wordpress-plugins\" target=\"_blank\">defending net neutrality</a> and protesting the SOPA/PIPA censorship bills.</p>
<p>Self-hosted WordPress site owners who want to participate in protesting the renewal of the Patriot Act can install the <a href=\"https://wordpress.org/plugins/cat-signal/\" target=\"_blank\">Internet Defense League Cat Signal</a> plugin from WordPress.org. It includes the blackout script as well as a dismissable notice to site visitors, asking them to <a href=\"https://www.sunsetthepatriotact.com/\" target=\"_blank\">urge Congress to sunset the Patriot Act</a>.</p>
<p><a href=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/cat-signal-modal.jpg\"><img src=\"http://i1.wp.com/wptavern.com/wp-content/uploads/2015/05/cat-signal-modal.jpg?resize=749%2C426\" alt=\"cat-signal-modal\" class=\"aligncenter size-full wp-image-44519\" /></a></p>
<p>The Cat Signal plugin will link your site up to the Internet Defense League&#8217;s online activist group. When an important bill is up for action, it will automatically enqueue the JavaScript required to post a notice on your site. It also includes an options page for selecting the pages where it should be active and for setting the notice as a banner or a modal.</p>
<p>If sunsetting the Patriot Act is important to you, the Cat Signal plugin is the easiest way to get your WordPress site into the protest. Alternatively, you can <a href=\"https://github.com/fightforthefuture/breakcongressinternet/blob/gh-pages/README.md\" target=\"_blank\">manually add the JavaScript to join the Congress Blackout</a> that will block Congress&#8217; IP addresses.</p>\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 29 May 2015 20:32:48 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Sarah Gooding\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:10:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Mon, 15 Jun 2015 19:42:58 GMT\";s:12:\"content-type\";s:8:\"text/xml\";s:14:\"content-length\";s:6:\"209055\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:13:\"last-modified\";s:29:\"Mon, 15 Jun 2015 19:30:14 GMT\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";s:13:\"accept-ranges\";s:5:\"bytes\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("118","_transient_timeout_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1434440581","no");
INSERT INTO `arc1542_options` VALUES("119","_transient_feed_mod_d117b5738fbd35bd8c0391cda1f2b5d9","1434397381","no");
INSERT INTO `arc1542_options` VALUES("120","_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109","1434440586","no");
INSERT INTO `arc1542_options` VALUES("121","_transient_feed_b9388c83948825c1edaef0d856b7b109","a:4:{s:5:\"child\";a:1:{s:0:\"\";a:1:{s:3:\"rss\";a:1:{i:0;a:6:{s:4:\"data\";s:3:\"
	
\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:7:\"version\";s:3:\"2.0\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:1:{s:0:\"\";a:1:{s:7:\"channel\";a:1:{i:0;a:6:{s:4:\"data\";s:117:\"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:7:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:45:\"https://wordpress.org/plugins/browse/popular/\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"WordPress Plugins » View: Popular\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:8:\"language\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"en-US\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 15 Jun 2015 19:17:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:9:\"generator\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"http://bbpress.org/?v=1.1\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"item\";a:30:{i:0;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"Akismet\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:46:\"https://wordpress.org/plugins/akismet/#post-15\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:11:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"15@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:98:\"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Matt Mullenweg\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:1;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Contact Form 7\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/contact-form-7/#post-2141\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 02 Aug 2007 12:45:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2141@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"Just another contact form plugin. Simple but flexible.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Takayuki Miyoshi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:2;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"WordPress SEO by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:54:\"https://wordpress.org/plugins/wordpress-seo/#post-8321\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 Jan 2009 20:34:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8321@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:131:\"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast&#039;s WordPress SEO plugin.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:3;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"Wordfence Security\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/wordfence/#post-29832\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 04 Sep 2011 03:13:51 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29832@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"Wordfence Security is a free enterprise class security and performance plugin that makes your site up to 50 times faster and more secure.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Wordfence\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:4;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"WooCommerce - excelling eCommerce\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/woocommerce/#post-29860\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Sep 2011 08:13:36 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"29860@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:97:\"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"WooThemes\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:5;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:33:\"Google Analytics Dashboard for WP\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:75:\"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 10 Mar 2013 17:07:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"50539@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Displays Google Analytics reports and real-time statistics in your WordPress Dashboard. Inserts the latest tracking code in every page of your site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Alin Marcu\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:6;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"All in One SEO Pack\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 30 Mar 2007 20:08:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"753@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:126:\"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"uberdose\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:7;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:24:\"Jetpack by WordPress.com\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:49:\"https://wordpress.org/plugins/jetpack/#post-23862\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 Jan 2011 02:21:38 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"23862@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:28:\"Your WordPress, Streamlined.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Tim Moore\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:8;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:18:\"WordPress Importer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:60:\"https://wordpress.org/plugins/wordpress-importer/#post-18101\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 20 May 2010 17:42:45 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"18101@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:101:\"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Brian Colinger\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:9;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"UpdraftPlus Backup and Restoration\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:53:\"https://wordpress.org/plugins/updraftplus/#post-38058\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 21 May 2012 15:14:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38058@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:148:\"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"David Anderson\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:10;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Responsive Lightbox by dFactory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:61:\"https://wordpress.org/plugins/responsive-lightbox/#post-55352\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 03 Jul 2013 10:58:18 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"55352@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:141:\"Responsive Lightbox allows users to view larger versions of images and galleries in a lightbox (overlay) effect optimized for mobile devices.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"dFactory\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:11;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Meta Slider\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:51:\"https://wordpress.org/plugins/ml-slider/#post-49521\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 14 Feb 2013 16:56:31 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"49521@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:145:\"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Matcha Labs\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:12;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"NextGEN Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/nextgen-gallery/#post-1169\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 23 Apr 2007 20:08:06 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"1169@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:121:\"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 12 million downloads.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"Alex Rabe\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:13;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:21:\"WPtouch Mobile Plugin\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/wptouch/#post-5468\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 01 May 2008 04:58:09 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"5468@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:67:\"Make your WordPress website mobile-friendly with just a few clicks.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:17:\"BraveNewCode Inc.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:14;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Photo Gallery\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/photo-gallery/#post-63299\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 27 Jan 2014 15:58:41 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"63299@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:143:\"Photo Gallery is an advanced plugin with a list of tools and options for adding and editing images for different views. It is fully responsive.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:9:\"webdorado\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:15;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:22:\"Advanced Custom Fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/advanced-custom-fields/#post-25254\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 17 Mar 2011 04:07:30 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"25254@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:68:\"Customise WordPress with powerful, professional and intuitive fields\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"elliotcondon\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:16;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"TinyMCE Advanced\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/tinymce-advanced/#post-2082\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 27 Jun 2007 15:00:26 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2082@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"Andrew Ozz\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:17;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:19:\"Google XML Sitemaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:64:\"https://wordpress.org/plugins/google-sitemap-generator/#post-132\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 09 Mar 2007 22:31:32 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"132@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:105:\"This plugin will generate a special XML sitemap which will help search engines to better index your blog.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"Arne Brachhold\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:18;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Google Analytics by Yoast\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:71:\"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Fri, 14 Sep 2007 12:15:27 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2316@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:124:\"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Joost de Valk\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:19;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:20:\"EWWW Image Optimizer\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:62:\"https://wordpress.org/plugins/ewww-image-optimizer/#post-38780\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 06 Jun 2012 19:30:37 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"38780@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"Reduce file sizes for images in WordPress including NextGEN, GRAND FlAGallery and more using lossless/lossy methods and image format conversion.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"nosilver4u\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:20;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Breadcrumb NavXT\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:57:\"https://wordpress.org/plugins/breadcrumb-navxt/#post-2634\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 01 Dec 2007 00:15:03 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2634@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:85:\"Adds breadcrumb navigation showing the visitor&#039;s path to their current location.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"John Havlik\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:21;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Super Cache\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-super-cache/#post-2572\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 05 Nov 2007 11:40:04 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2572@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:73:\"A very fast caching engine for WordPress that produces static html files.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Donncha O Caoimh\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:22;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:15:\"BackUpWordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/backupwordpress/#post-2236\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sun, 02 Sep 2007 21:15:07 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"2236@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:59:\"Simple automated backups of your WordPress powered website.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Tom Willmot\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:23;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:14:\"WP Google Maps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:56:\"https://wordpress.org/plugins/wp-google-maps/#post-34206\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 25 Jan 2012 06:23:42 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"34206@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:146:\"The easiest to use Google maps plugin! Create a custom Google map with high quality markers containing categories, descriptions, images and links.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:7:\"WPGMaps\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:24;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:25:\"Share Buttons by AddToAny\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:50:\"https://wordpress.org/plugins/add-to-any/#post-498\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Sat, 17 Mar 2007 23:08:16 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:34:\"498@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:142:\"Share buttons for WordPress including AddToAny&#039;s universal sharing button, Facebook, Twitter, Google+, Pinterest, WhatsApp and many more.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:8:\"micropat\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:25;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:27:\"Black Studio TinyMCE Widget\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:69:\"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 10 Nov 2011 15:06:14 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"31973@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:39:\"The visual editor widget for Wordpress.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:12:\"Marco Chiesi\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:26;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"WP-SpamShield Anti-Spam\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:55:\"https://wordpress.org/plugins/wp-spamshield/#post-65116\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 13 Mar 2014 20:42:08 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"65116@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:137:\"An extremely powerful WordPress anti-spam plugin that eliminates comment spam, trackback spam, contact form spam &#38; registration spam.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:11:\"Scott Allen\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:27;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:10:\"BuddyPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:52:\"https://wordpress.org/plugins/buddypress/#post-10314\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Thu, 23 Apr 2009 17:48:44 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"10314@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:144:\"BuddyPress helps you run any kind of social network on your WordPress, with member profiles, activity streams, user groups, messaging, and more.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:13:\"Andy Peatling\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:28;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"MailChimp for WordPress\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:58:\"https://wordpress.org/plugins/mailchimp-for-wp/#post-54377\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Mon, 10 Jun 2013 17:32:11 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:36:\"54377@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:138:\"The best MailChimp plugin to get more email subscribers. Easily add MailChimp sign-up forms and sign-up checkboxes to your WordPress site.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:16:\"Danny van Kooten\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}i:29;a:6:{s:4:\"data\";s:30:\"
			
			
			
			
			
			
					\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";s:5:\"child\";a:2:{s:0:\"\";a:5:{s:5:\"title\";a:1:{i:0;a:5:{s:4:\"data\";s:23:\"AddThis Sharing Buttons\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:48:\"https://wordpress.org/plugins/addthis/#post-8124\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:7:\"pubDate\";a:1:{i:0;a:5:{s:4:\"data\";s:31:\"Wed, 17 Dec 2008 16:03:39 +0000\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:4:\"guid\";a:1:{i:0;a:5:{s:4:\"data\";s:35:\"8124@https://wordpress.org/plugins/\";s:7:\"attribs\";a:1:{s:0:\"\";a:1:{s:11:\"isPermaLink\";s:5:\"false\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}s:11:\"description\";a:1:{i:0;a:5:{s:4:\"data\";s:78:\"AddThis provides the best sharing tools to help you make your website smarter.\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}s:32:\"http://purl.org/dc/elements/1.1/\";a:1:{s:7:\"creator\";a:1:{i:0;a:5:{s:4:\"data\";s:5:\"_mjk_\";s:7:\"attribs\";a:0:{}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}s:27:\"http://www.w3.org/2005/Atom\";a:1:{s:4:\"link\";a:1:{i:0;a:5:{s:4:\"data\";s:0:\"\";s:7:\"attribs\";a:1:{s:0:\"\";a:3:{s:4:\"href\";s:46:\"https://wordpress.org/plugins/rss/view/popular\";s:3:\"rel\";s:4:\"self\";s:4:\"type\";s:19:\"application/rss+xml\";}}s:8:\"xml_base\";s:0:\"\";s:17:\"xml_base_explicit\";b:0;s:8:\"xml_lang\";s:0:\"\";}}}}}}}}}}}}s:4:\"type\";i:128;s:7:\"headers\";a:12:{s:6:\"server\";s:5:\"nginx\";s:4:\"date\";s:29:\"Mon, 15 Jun 2015 19:43:06 GMT\";s:12:\"content-type\";s:23:\"text/xml; charset=UTF-8\";s:10:\"connection\";s:5:\"close\";s:4:\"vary\";s:15:\"Accept-Encoding\";s:25:\"strict-transport-security\";s:11:\"max-age=360\";s:7:\"expires\";s:29:\"Mon, 15 Jun 2015 19:52:03 GMT\";s:13:\"cache-control\";s:0:\"\";s:6:\"pragma\";s:0:\"\";s:13:\"last-modified\";s:31:\"Mon, 15 Jun 2015 19:17:03 +0000\";s:15:\"x-frame-options\";s:10:\"SAMEORIGIN\";s:4:\"x-nc\";s:11:\"HIT lax 249\";}s:5:\"build\";s:14:\"20130911080210\";}","no");
INSERT INTO `arc1542_options` VALUES("122","_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109","1434440586","no");
INSERT INTO `arc1542_options` VALUES("123","_transient_feed_mod_b9388c83948825c1edaef0d856b7b109","1434397386","no");
INSERT INTO `arc1542_options` VALUES("124","_transient_timeout_plugin_slugs","1434485883","no");
INSERT INTO `arc1542_options` VALUES("125","_transient_plugin_slugs","a:3:{i:0;s:19:\"akismet/akismet.php\";i:1;s:41:\"better-wp-security/better-wp-security.php\";i:2;s:23:\"wordfence/wordfence.php\";}","no");
INSERT INTO `arc1542_options` VALUES("126","_transient_timeout_dash_4077549d03da2e451c8b5f002294ff51","1434440586","no");
INSERT INTO `arc1542_options` VALUES("127","_transient_dash_4077549d03da2e451c8b5f002294ff51","<div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'https://wordpress.org/news/2015/05/wordpress-4-2-2/\'>WordPress 4.2.2 Security and Maintenance Release</a> <span class=\"rss-date\">May 7, 2015</span><div class=\"rssSummary\">WordPress 4.2.2 is now available. This is a critical security release for all previous versions and we strongly encourage you to update your sites immediately. Version 4.2.2 addresses two security issues: The Genericons icon font package, which is used in a number of popular themes and plugins, contained an HTML file vulnerable to a cross-site [&hellip;]</div></li></ul></div><div class=\"rss-widget\"><ul><li><a class=\'rsswidget\' href=\'http://wptavern.com/o2-is-now-available-on-github\'>WPTavern: o2 is Now Available on GitHub</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/06/priceless-words/\'>Matt: Priceless Words</a></li><li><a class=\'rsswidget\' href=\'http://ma.tt/2015/06/how-tesla-will-change-the-world/\'>Matt: How Tesla Will Change The World</a></li></ul></div><div class=\"rss-widget\"><ul><li class=\'dashboard-news-plugin\'><span>Popular Plugin:</span> <a href=\'https://wordpress.org/plugins/google-analytics-dashboard-for-wp/\' class=\'dashboard-news-plugin-link\'>Google Analytics Dashboard for WP</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=google-analytics-dashboard-for-wp&amp;_wpnonce=18424aa54d&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Google Analytics Dashboard for WP\'>Install</a>)</span></li></ul></div>","no");
INSERT INTO `arc1542_options` VALUES("128","_site_transient_timeout_poptags_40cd750bba9870f18aada2478b24840a","1434408279","yes");
INSERT INTO `arc1542_options` VALUES("129","_site_transient_poptags_40cd750bba9870f18aada2478b24840a","a:40:{s:6:\"widget\";a:3:{s:4:\"name\";s:6:\"widget\";s:4:\"slug\";s:6:\"widget\";s:5:\"count\";s:4:\"5223\";}s:4:\"post\";a:3:{s:4:\"name\";s:4:\"Post\";s:4:\"slug\";s:4:\"post\";s:5:\"count\";s:4:\"3269\";}s:6:\"plugin\";a:3:{s:4:\"name\";s:6:\"plugin\";s:4:\"slug\";s:6:\"plugin\";s:5:\"count\";s:4:\"3204\";}s:5:\"admin\";a:3:{s:4:\"name\";s:5:\"admin\";s:4:\"slug\";s:5:\"admin\";s:5:\"count\";s:4:\"2734\";}s:5:\"posts\";a:3:{s:4:\"name\";s:5:\"posts\";s:4:\"slug\";s:5:\"posts\";s:5:\"count\";s:4:\"2503\";}s:7:\"sidebar\";a:3:{s:4:\"name\";s:7:\"sidebar\";s:4:\"slug\";s:7:\"sidebar\";s:5:\"count\";s:4:\"2001\";}s:9:\"shortcode\";a:3:{s:4:\"name\";s:9:\"shortcode\";s:4:\"slug\";s:9:\"shortcode\";s:5:\"count\";s:4:\"1906\";}s:6:\"google\";a:3:{s:4:\"name\";s:6:\"google\";s:4:\"slug\";s:6:\"google\";s:5:\"count\";s:4:\"1836\";}s:7:\"twitter\";a:3:{s:4:\"name\";s:7:\"twitter\";s:4:\"slug\";s:7:\"twitter\";s:5:\"count\";s:4:\"1787\";}s:6:\"images\";a:3:{s:4:\"name\";s:6:\"images\";s:4:\"slug\";s:6:\"images\";s:5:\"count\";s:4:\"1769\";}s:4:\"page\";a:3:{s:4:\"name\";s:4:\"page\";s:4:\"slug\";s:4:\"page\";s:5:\"count\";s:4:\"1738\";}s:8:\"comments\";a:3:{s:4:\"name\";s:8:\"comments\";s:4:\"slug\";s:8:\"comments\";s:5:\"count\";s:4:\"1728\";}s:5:\"image\";a:3:{s:4:\"name\";s:5:\"image\";s:4:\"slug\";s:5:\"image\";s:5:\"count\";s:4:\"1621\";}s:8:\"facebook\";a:3:{s:4:\"name\";s:8:\"Facebook\";s:4:\"slug\";s:8:\"facebook\";s:5:\"count\";s:4:\"1419\";}s:3:\"seo\";a:3:{s:4:\"name\";s:3:\"seo\";s:4:\"slug\";s:3:\"seo\";s:5:\"count\";s:4:\"1357\";}s:9:\"wordpress\";a:3:{s:4:\"name\";s:9:\"wordpress\";s:4:\"slug\";s:9:\"wordpress\";s:5:\"count\";s:4:\"1299\";}s:5:\"links\";a:3:{s:4:\"name\";s:5:\"links\";s:4:\"slug\";s:5:\"links\";s:5:\"count\";s:4:\"1207\";}s:6:\"social\";a:3:{s:4:\"name\";s:6:\"social\";s:4:\"slug\";s:6:\"social\";s:5:\"count\";s:4:\"1165\";}s:7:\"gallery\";a:3:{s:4:\"name\";s:7:\"gallery\";s:4:\"slug\";s:7:\"gallery\";s:5:\"count\";s:4:\"1150\";}s:5:\"email\";a:3:{s:4:\"name\";s:5:\"email\";s:4:\"slug\";s:5:\"email\";s:5:\"count\";s:4:\"1021\";}s:7:\"widgets\";a:3:{s:4:\"name\";s:7:\"widgets\";s:4:\"slug\";s:7:\"widgets\";s:5:\"count\";s:3:\"975\";}s:11:\"woocommerce\";a:3:{s:4:\"name\";s:11:\"woocommerce\";s:4:\"slug\";s:11:\"woocommerce\";s:5:\"count\";s:3:\"942\";}s:5:\"pages\";a:3:{s:4:\"name\";s:5:\"pages\";s:4:\"slug\";s:5:\"pages\";s:5:\"count\";s:3:\"932\";}s:6:\"jquery\";a:3:{s:4:\"name\";s:6:\"jquery\";s:4:\"slug\";s:6:\"jquery\";s:5:\"count\";s:3:\"896\";}s:3:\"rss\";a:3:{s:4:\"name\";s:3:\"rss\";s:4:\"slug\";s:3:\"rss\";s:5:\"count\";s:3:\"865\";}s:5:\"media\";a:3:{s:4:\"name\";s:5:\"media\";s:4:\"slug\";s:5:\"media\";s:5:\"count\";s:3:\"853\";}s:5:\"video\";a:3:{s:4:\"name\";s:5:\"video\";s:4:\"slug\";s:5:\"video\";s:5:\"count\";s:3:\"806\";}s:4:\"ajax\";a:3:{s:4:\"name\";s:4:\"AJAX\";s:4:\"slug\";s:4:\"ajax\";s:5:\"count\";s:3:\"791\";}s:7:\"content\";a:3:{s:4:\"name\";s:7:\"content\";s:4:\"slug\";s:7:\"content\";s:5:\"count\";s:3:\"767\";}s:5:\"login\";a:3:{s:4:\"name\";s:5:\"login\";s:4:\"slug\";s:5:\"login\";s:5:\"count\";s:3:\"743\";}s:9:\"ecommerce\";a:3:{s:4:\"name\";s:9:\"ecommerce\";s:4:\"slug\";s:9:\"ecommerce\";s:5:\"count\";s:3:\"738\";}s:10:\"javascript\";a:3:{s:4:\"name\";s:10:\"javascript\";s:4:\"slug\";s:10:\"javascript\";s:5:\"count\";s:3:\"736\";}s:10:\"buddypress\";a:3:{s:4:\"name\";s:10:\"buddypress\";s:4:\"slug\";s:10:\"buddypress\";s:5:\"count\";s:3:\"695\";}s:5:\"photo\";a:3:{s:4:\"name\";s:5:\"photo\";s:4:\"slug\";s:5:\"photo\";s:5:\"count\";s:3:\"687\";}s:4:\"feed\";a:3:{s:4:\"name\";s:4:\"feed\";s:4:\"slug\";s:4:\"feed\";s:5:\"count\";s:3:\"682\";}s:4:\"link\";a:3:{s:4:\"name\";s:4:\"link\";s:4:\"slug\";s:4:\"link\";s:5:\"count\";s:3:\"669\";}s:7:\"youtube\";a:3:{s:4:\"name\";s:7:\"youtube\";s:4:\"slug\";s:7:\"youtube\";s:5:\"count\";s:3:\"649\";}s:8:\"security\";a:3:{s:4:\"name\";s:8:\"security\";s:4:\"slug\";s:8:\"security\";s:5:\"count\";s:3:\"645\";}s:4:\"spam\";a:3:{s:4:\"name\";s:4:\"spam\";s:4:\"slug\";s:4:\"spam\";s:5:\"count\";s:3:\"640\";}s:6:\"photos\";a:3:{s:4:\"name\";s:6:\"photos\";s:4:\"slug\";s:6:\"photos\";s:5:\"count\";s:3:\"639\";}}","yes");
INSERT INTO `arc1542_options` VALUES("134","itsec_data","a:5:{s:5:\"build\";i:4036;s:20:\"activation_timestamp\";i:1434397534;s:17:\"already_supported\";b:0;s:15:\"setup_completed\";b:1;s:18:\"tooltips_dismissed\";b:1;}","yes");
INSERT INTO `arc1542_options` VALUES("135","itsec_global","a:24:{s:11:\"write_files\";b:1;s:18:\"notification_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:12:\"digest_email\";b:1;s:12:\"backup_email\";a:1:{i:0;s:22:\"andre.hayter@gmail.com\";}s:15:\"lockout_message\";s:5:\"error\";s:20:\"user_lockout_message\";s:64:\"You have been locked out due to too many invalid login attempts.\";s:25:\"community_lockout_message\";s:77:\"Your IP address has been flagged as a threat by the iThemes Security network.\";s:9:\"blacklist\";b:1;s:15:\"blacklist_count\";i:3;s:16:\"blacklist_period\";i:7;s:14:\"lockout_period\";i:15;s:18:\"lockout_white_list\";a:0:{}s:19:\"email_notifications\";b:1;s:8:\"log_type\";i:0;s:12:\"log_rotation\";i:14;s:12:\"log_location\";s:66:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/logs\";s:11:\"did_upgrade\";b:0;s:14:\"allow_tracking\";b:0;s:10:\"nginx_file\";s:36:\"/Users/ahayter/Sites/test/nginx.conf\";s:24:\"infinitewp_compatibility\";b:0;s:8:\"log_info\";s:13:\"arc-g8FzN7rLD\";s:9:\"lock_file\";b:0;s:14:\"proxy_override\";b:0;s:14:\"hide_admin_bar\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("136","itsec_initials","a:3:{s:5:\"login\";b:0;s:5:\"admin\";b:0;s:11:\"file_editor\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("138","itsec_ipcheck","a:1:{s:7:\"api_ban\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("139","itsec_four_oh_four","a:5:{s:7:\"enabled\";b:1;s:12:\"check_period\";i:5;s:15:\"error_threshold\";i:20;s:10:\"white_list\";a:9:{i:0;s:12:\"/favicon.ico\";i:1;s:11:\"/robots.txt\";i:2;s:21:\"/apple-touch-icon.png\";i:3;s:33:\"/apple-touch-icon-precomposed.png\";i:4;s:17:\"/wp-content/cache\";i:5;s:18:\"/browserconfig.xml\";i:6;s:16:\"/crossdomain.xml\";i:7;s:11:\"/labels.rdf\";i:8;s:27:\"/trafficbasedsspsitemap.xml\";}s:5:\"types\";a:5:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".gif\";i:4;s:4:\".css\";}}","yes");
INSERT INTO `arc1542_options` VALUES("140","itsec_away_mode","a:4:{s:4:\"type\";i:1;s:7:\"enabled\";b:0;s:5:\"start\";i:1434412800;s:3:\"end\";i:1434520800;}","yes");
INSERT INTO `arc1542_options` VALUES("141","itsec_ban_users","a:4:{s:7:\"default\";b:1;s:7:\"enabled\";b:1;s:9:\"host_list\";a:46:{i:0;s:10:\"8.21.4.254\";i:1;s:15:\"65.46.48.192/30\";i:2;s:17:\"65.160.238.176/28\";i:3;s:14:\"85.92.222.0/24\";i:4;s:14:\"206.51.36.0/22\";i:5;s:14:\"216.52.23.0/24\";i:6;s:14:\"38.100.19.8/29\";i:7;s:14:\"38.100.21.0/24\";i:8;s:15:\"38.100.41.64/26\";i:9;s:14:\"38.105.71.0/25\";i:10;s:14:\"38.105.83.0/27\";i:11;s:16:\"38.112.21.140/30\";i:12;s:15:\"38.118.42.32/29\";i:13;s:17:\"65.213.208.128/27\";i:14;s:16:\"65.222.176.96/27\";i:15;s:16:\"65.222.185.72/29\";i:16;s:16:\"38.103.17.160/27\";i:17;s:14:\"66.113.96.0/20\";i:18;s:16:\"70.35.113.192/27\";i:19;s:14:\"204.15.80.0/22\";i:20;s:15:\"66.17.15.128/26\";i:21;s:15:\"69.84.207.32/27\";i:22;s:16:\"69.84.207.128/25\";i:23;s:14:\"72.36.128.0/17\";i:24;s:13:\"72.232.0.0/16\";i:25;s:13:\"72.233.0.0/17\";i:26;s:13:\"216.32.0.0/14\";i:27;s:17:\"67.192.231.224/29\";i:28;s:15:\"208.90.236.0/22\";i:29;s:18:\"209.147.127.208/28\";i:30;s:16:\"198.186.190.0/23\";i:31;s:16:\"198.186.192.0/23\";i:32;s:16:\"198.186.194.0/24\";i:33;s:16:\"207.210.99.32/29\";i:34;s:11:\"4.53.120.22\";i:35;s:13:\"66.194.6.0/24\";i:36;s:17:\"67.117.201.128/28\";i:37;s:13:\"69.67.32.0/20\";i:38;s:15:\"131.191.87.0/24\";i:39;s:14:\"204.15.64.0/21\";i:40;s:15:\"208.80.192.0/21\";i:41;s:15:\"212.62.26.64/27\";i:42;s:16:\"213.168.226.0/24\";i:43;s:16:\"213.168.241.0/30\";i:44;s:16:\"213.168.242.0/30\";i:45;s:17:\"213.236.150.16/28\";}s:10:\"agent_list\";a:1:{i:0;s:0:\"\";}}","yes");
INSERT INTO `arc1542_options` VALUES("143","itsec_brute_force","a:5:{s:7:\"enabled\";b:1;s:17:\"max_attempts_host\";i:5;s:17:\"max_attempts_user\";i:10;s:12:\"check_period\";i:5;s:14:\"auto_ban_admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("144","itsec_backup","a:9:{s:6:\"method\";i:0;s:8:\"location\";s:69:\"/Users/ahayter/Sites/test/arc-assets/uploads/ithemes-security/backups\";s:6:\"retain\";i:0;s:3:\"zip\";b:1;s:7:\"exclude\";a:3:{i:0;s:14:\"itsec_lockouts\";i:1;s:9:\"itsec_log\";i:2;s:10:\"itsec_temp\";}s:7:\"enabled\";b:1;s:8:\"interval\";i:1;s:9:\"all_sites\";b:0;s:8:\"last_run\";i:1434397838;}","yes");
INSERT INTO `arc1542_options` VALUES("145","itsec_file_change","a:9:{s:7:\"enabled\";b:1;s:5:\"split\";b:1;s:6:\"method\";b:1;s:9:\"file_list\";a:1:{i:0;s:0:\"\";}s:5:\"types\";a:6:{i:0;s:4:\".jpg\";i:1;s:5:\".jpeg\";i:2;s:4:\".png\";i:3;s:4:\".log\";i:4;s:3:\".mo\";i:5;s:3:\".po\";}s:5:\"email\";b:1;s:12:\"notify_admin\";b:1;s:10:\"last_chunk\";b:0;s:8:\"last_run\";d:1434383948;}","yes");
INSERT INTO `arc1542_options` VALUES("146","itsec_hide_backend","a:7:{s:7:\"enabled\";b:1;s:4:\"slug\";s:8:\"arclogin\";s:12:\"theme_compat\";b:1;s:17:\"theme_compat_slug\";s:9:\"not_found\";s:16:\"post_logout_slug\";s:0:\"\";s:12:\"show-tooltip\";b:0;s:8:\"register\";s:15:\"wp-register.php\";}","yes");
INSERT INTO `arc1542_options` VALUES("147","itsec_malware","a:2:{s:7:\"enabled\";b:1;s:7:\"api_key\";s:64:\"91f63fb64116aa3269a33bb0e05891edf78a823f2fc7383ef3a03850c1f2bd59\";}","yes");
INSERT INTO `arc1542_options` VALUES("148","itsec_ssl","a:3:{s:8:\"frontend\";i:0;s:5:\"login\";b:0;s:5:\"admin\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("150","itsec_strong_passwords","a:2:{s:7:\"enabled\";b:1;s:4:\"roll\";s:6:\"author\";}","yes");
INSERT INTO `arc1542_options` VALUES("151","itsec_tweaks","a:22:{s:13:\"protect_files\";b:1;s:18:\"directory_browsing\";b:1;s:15:\"request_methods\";b:1;s:24:\"suspicious_query_strings\";b:1;s:16:\"long_url_strings\";b:1;s:17:\"write_permissions\";b:1;s:11:\"uploads_php\";b:1;s:13:\"generator_tag\";b:1;s:18:\"wlwmanifest_header\";b:1;s:14:\"edituri_header\";b:1;s:12:\"comment_spam\";b:1;s:14:\"random_version\";b:1;s:11:\"file_editor\";b:1;s:14:\"disable_xmlrpc\";i:1;s:12:\"login_errors\";b:1;s:21:\"force_unique_nicename\";b:1;s:27:\"disable_unused_author_pages\";b:1;s:22:\"non_english_characters\";b:0;s:13:\"theme_updates\";b:0;s:14:\"plugin_updates\";b:0;s:12:\"core_updates\";b:0;s:11:\"safe_jquery\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("153","recently_activated","a:0:{}","yes");
INSERT INTO `arc1542_options` VALUES("157","itsec_temp_whitelist_ip","a:2:{s:2:\"ip\";s:3:\"::1\";s:3:\"exp\";i:1434483993;}","yes");
INSERT INTO `arc1542_options` VALUES("158","itsec_message_queue","a:2:{s:9:\"last_sent\";i:1437026028;s:8:\"messages\";a:0:{}}","yes");
INSERT INTO `arc1542_options` VALUES("162","_site_transient_timeout_available_translations","1434408549","yes");
INSERT INTO `arc1542_options` VALUES("163","_site_transient_available_translations","a:56:{s:2:\"ar\";a:8:{s:8:\"language\";s:2:\"ar\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:57:37\";s:12:\"english_name\";s:6:\"Arabic\";s:11:\"native_name\";s:14:\"العربية\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ar.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ar\";i:2;s:3:\"ara\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"المتابعة\";}}s:2:\"az\";a:8:{s:8:\"language\";s:2:\"az\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-01 14:30:22\";s:12:\"english_name\";s:11:\"Azerbaijani\";s:11:\"native_name\";s:16:\"Azərbaycan dili\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/az.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"az\";i:2;s:3:\"aze\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Davam\";}}s:5:\"bg_BG\";a:8:{s:8:\"language\";s:5:\"bg_BG\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 06:36:25\";s:12:\"english_name\";s:9:\"Bulgarian\";s:11:\"native_name\";s:18:\"Български\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/bg_BG.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bg\";i:2;s:3:\"bul\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:22:\"Продължение\";}}s:5:\"bs_BA\";a:8:{s:8:\"language\";s:5:\"bs_BA\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-25 18:55:51\";s:12:\"english_name\";s:7:\"Bosnian\";s:11:\"native_name\";s:8:\"Bosanski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/bs_BA.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"bs\";i:2;s:3:\"bos\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:2:\"ca\";a:8:{s:8:\"language\";s:2:\"ca\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-24 05:23:15\";s:12:\"english_name\";s:7:\"Catalan\";s:11:\"native_name\";s:7:\"Català\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ca.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ca\";i:2;s:3:\"cat\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"cy\";a:8:{s:8:\"language\";s:2:\"cy\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-30 08:59:10\";s:12:\"english_name\";s:5:\"Welsh\";s:11:\"native_name\";s:7:\"Cymraeg\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/cy.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"cy\";i:2;s:3:\"cym\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Parhau\";}}s:5:\"da_DK\";a:8:{s:8:\"language\";s:5:\"da_DK\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-03 00:26:43\";s:12:\"english_name\";s:6:\"Danish\";s:11:\"native_name\";s:5:\"Dansk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/da_DK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"da\";i:2;s:3:\"dan\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Forts&#230;t\";}}s:5:\"de_CH\";a:8:{s:8:\"language\";s:5:\"de_CH\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:20:\"German (Switzerland)\";s:11:\"native_name\";s:17:\"Deutsch (Schweiz)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/de_CH.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:5:\"de_DE\";a:8:{s:8:\"language\";s:5:\"de_DE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 09:28:00\";s:12:\"english_name\";s:6:\"German\";s:11:\"native_name\";s:7:\"Deutsch\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/de_DE.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"de\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Fortfahren\";}}s:2:\"el\";a:8:{s:8:\"language\";s:2:\"el\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-01 09:29:51\";s:12:\"english_name\";s:5:\"Greek\";s:11:\"native_name\";s:16:\"Ελληνικά\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/el.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"el\";i:2;s:3:\"ell\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:16:\"Συνέχεια\";}}s:5:\"en_CA\";a:8:{s:8:\"language\";s:5:\"en_CA\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:16:\"English (Canada)\";s:11:\"native_name\";s:16:\"English (Canada)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_CA.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_AU\";a:8:{s:8:\"language\";s:5:\"en_AU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:19:\"English (Australia)\";s:11:\"native_name\";s:19:\"English (Australia)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_AU.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:5:\"en_GB\";a:8:{s:8:\"language\";s:5:\"en_GB\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:12:\"English (UK)\";s:11:\"native_name\";s:12:\"English (UK)\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/en_GB.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"en\";i:2;s:3:\"eng\";i:3;s:3:\"eng\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continue\";}}s:2:\"eo\";a:8:{s:8:\"language\";s:2:\"eo\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:9:\"Esperanto\";s:11:\"native_name\";s:9:\"Esperanto\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/eo.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eo\";i:2;s:3:\"epo\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Daŭrigi\";}}s:5:\"es_PE\";a:8:{s:8:\"language\";s:5:\"es_PE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-25 13:39:01\";s:12:\"english_name\";s:14:\"Spanish (Peru)\";s:11:\"native_name\";s:17:\"Español de Perú\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_PE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_ES\";a:8:{s:8:\"language\";s:5:\"es_ES\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-04 14:48:26\";s:12:\"english_name\";s:15:\"Spanish (Spain)\";s:11:\"native_name\";s:8:\"Español\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_ES.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"es\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_MX\";a:8:{s:8:\"language\";s:5:\"es_MX\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-29 17:53:27\";s:12:\"english_name\";s:16:\"Spanish (Mexico)\";s:11:\"native_name\";s:19:\"Español de México\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/es_MX.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"es_CL\";a:8:{s:8:\"language\";s:5:\"es_CL\";s:7:\"version\";s:3:\"4.0\";s:7:\"updated\";s:19:\"2014-09-04 19:47:01\";s:12:\"english_name\";s:15:\"Spanish (Chile)\";s:11:\"native_name\";s:17:\"Español de Chile\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.0/es_CL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"es\";i:2;s:3:\"spa\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:2:\"eu\";a:8:{s:8:\"language\";s:2:\"eu\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:09\";s:12:\"english_name\";s:6:\"Basque\";s:11:\"native_name\";s:7:\"Euskara\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/eu.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"eu\";i:2;s:3:\"eus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Jarraitu\";}}s:5:\"fa_IR\";a:8:{s:8:\"language\";s:5:\"fa_IR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-16 10:01:41\";s:12:\"english_name\";s:7:\"Persian\";s:11:\"native_name\";s:10:\"فارسی\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/fa_IR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fa\";i:2;s:3:\"fas\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:2:\"fi\";a:8:{s:8:\"language\";s:2:\"fi\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-15 10:49:37\";s:12:\"english_name\";s:7:\"Finnish\";s:11:\"native_name\";s:5:\"Suomi\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/fi.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"fi\";i:2;s:3:\"fin\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Jatka\";}}s:5:\"fr_FR\";a:8:{s:8:\"language\";s:5:\"fr_FR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 09:59:32\";s:12:\"english_name\";s:15:\"French (France)\";s:11:\"native_name\";s:9:\"Français\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/fr_FR.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"fr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuer\";}}s:2:\"gd\";a:8:{s:8:\"language\";s:2:\"gd\";s:7:\"version\";s:3:\"4.0\";s:7:\"updated\";s:19:\"2014-09-05 17:37:43\";s:12:\"english_name\";s:15:\"Scottish Gaelic\";s:11:\"native_name\";s:9:\"Gàidhlig\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/translation/core/4.0/gd.zip\";s:3:\"iso\";a:3:{i:1;s:2:\"gd\";i:2;s:3:\"gla\";i:3;s:3:\"gla\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"Lean air adhart\";}}s:5:\"gl_ES\";a:8:{s:8:\"language\";s:5:\"gl_ES\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:8:\"Galician\";s:11:\"native_name\";s:6:\"Galego\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/gl_ES.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"gl\";i:2;s:3:\"glg\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:3:\"haz\";a:8:{s:8:\"language\";s:3:\"haz\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 15:20:27\";s:12:\"english_name\";s:8:\"Hazaragi\";s:11:\"native_name\";s:15:\"هزاره گی\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.1.5/haz.zip\";s:3:\"iso\";a:1:{i:2;s:3:\"haz\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"ادامه\";}}s:5:\"he_IL\";a:8:{s:8:\"language\";s:5:\"he_IL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 19:32:58\";s:12:\"english_name\";s:6:\"Hebrew\";s:11:\"native_name\";s:16:\"עִבְרִית\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/he_IL.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"he\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"להמשיך\";}}s:2:\"hr\";a:8:{s:8:\"language\";s:2:\"hr\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 08:22:08\";s:12:\"english_name\";s:8:\"Croatian\";s:11:\"native_name\";s:8:\"Hrvatski\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/hr.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hr\";i:2;s:3:\"hrv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Nastavi\";}}s:5:\"hu_HU\";a:8:{s:8:\"language\";s:5:\"hu_HU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:43:50\";s:12:\"english_name\";s:9:\"Hungarian\";s:11:\"native_name\";s:6:\"Magyar\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/hu_HU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"hu\";i:2;s:3:\"hun\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:7:\"Tovább\";}}s:5:\"id_ID\";a:8:{s:8:\"language\";s:5:\"id_ID\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:07:32\";s:12:\"english_name\";s:10:\"Indonesian\";s:11:\"native_name\";s:16:\"Bahasa Indonesia\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/id_ID.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"id\";i:2;s:3:\"ind\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Lanjutkan\";}}s:5:\"is_IS\";a:8:{s:8:\"language\";s:5:\"is_IS\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 11:14:20\";s:12:\"english_name\";s:9:\"Icelandic\";s:11:\"native_name\";s:9:\"Íslenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/is_IS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"is\";i:2;s:3:\"isl\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Áfram\";}}s:5:\"it_IT\";a:8:{s:8:\"language\";s:5:\"it_IT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-31 19:34:18\";s:12:\"english_name\";s:7:\"Italian\";s:11:\"native_name\";s:8:\"Italiano\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/it_IT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"it\";i:2;s:3:\"ita\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Continua\";}}s:2:\"ja\";a:8:{s:8:\"language\";s:2:\"ja\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-07 07:33:53\";s:12:\"english_name\";s:8:\"Japanese\";s:11:\"native_name\";s:9:\"日本語\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/ja.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ja\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"続ける\";}}s:5:\"ko_KR\";a:8:{s:8:\"language\";s:5:\"ko_KR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:57:22\";s:12:\"english_name\";s:6:\"Korean\";s:11:\"native_name\";s:9:\"한국어\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ko_KR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ko\";i:2;s:3:\"kor\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"계속\";}}s:5:\"lt_LT\";a:8:{s:8:\"language\";s:5:\"lt_LT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:10:\"Lithuanian\";s:11:\"native_name\";s:15:\"Lietuvių kalba\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/lt_LT.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"lt\";i:2;s:3:\"lit\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Tęsti\";}}s:5:\"my_MM\";a:8:{s:8:\"language\";s:5:\"my_MM\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 15:57:42\";s:12:\"english_name\";s:17:\"Myanmar (Burmese)\";s:11:\"native_name\";s:15:\"ဗမာစာ\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/my_MM.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"my\";i:2;s:3:\"mya\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:54:\"ဆက်လက်လုပ်ေဆာင်ပါ။\";}}s:5:\"nb_NO\";a:8:{s:8:\"language\";s:5:\"nb_NO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-27 10:29:43\";s:12:\"english_name\";s:19:\"Norwegian (Bokmål)\";s:11:\"native_name\";s:13:\"Norsk bokmål\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nb_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nb\";i:2;s:3:\"nob\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Fortsett\";}}s:5:\"nl_NL\";a:8:{s:8:\"language\";s:5:\"nl_NL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 06:59:29\";s:12:\"english_name\";s:5:\"Dutch\";s:11:\"native_name\";s:10:\"Nederlands\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nl_NL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nl\";i:2;s:3:\"nld\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"Doorgaan\";}}s:5:\"nn_NO\";a:8:{s:8:\"language\";s:5:\"nn_NO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-08 07:10:14\";s:12:\"english_name\";s:19:\"Norwegian (Nynorsk)\";s:11:\"native_name\";s:13:\"Norsk nynorsk\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/nn_NO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"nn\";i:2;s:3:\"nno\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Hald fram\";}}s:3:\"oci\";a:8:{s:8:\"language\";s:3:\"oci\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-10 17:07:58\";s:12:\"english_name\";s:7:\"Occitan\";s:11:\"native_name\";s:7:\"Occitan\";s:7:\"package\";s:62:\"https://downloads.wordpress.org/translation/core/4.2.2/oci.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"oc\";i:2;s:3:\"oci\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Contunhar\";}}s:5:\"pl_PL\";a:8:{s:8:\"language\";s:5:\"pl_PL\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-09 10:15:05\";s:12:\"english_name\";s:6:\"Polish\";s:11:\"native_name\";s:6:\"Polski\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pl_PL.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pl\";i:2;s:3:\"pol\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Kontynuuj\";}}s:2:\"ps\";a:8:{s:8:\"language\";s:2:\"ps\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-29 22:19:48\";s:12:\"english_name\";s:6:\"Pashto\";s:11:\"native_name\";s:8:\"پښتو\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.1.5/ps.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"ps\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:8:\"دوام\";}}s:5:\"pt_PT\";a:8:{s:8:\"language\";s:5:\"pt_PT\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-27 09:25:14\";s:12:\"english_name\";s:21:\"Portuguese (Portugal)\";s:11:\"native_name\";s:10:\"Português\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pt_PT.zip\";s:3:\"iso\";a:1:{i:1;s:2:\"pt\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"pt_BR\";a:8:{s:8:\"language\";s:5:\"pt_BR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-12 01:38:15\";s:12:\"english_name\";s:19:\"Portuguese (Brazil)\";s:11:\"native_name\";s:20:\"Português do Brasil\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/pt_BR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"pt\";i:2;s:3:\"por\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuar\";}}s:5:\"ro_RO\";a:8:{s:8:\"language\";s:5:\"ro_RO\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-21 15:14:01\";s:12:\"english_name\";s:8:\"Romanian\";s:11:\"native_name\";s:8:\"Română\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ro_RO.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ro\";i:2;s:3:\"ron\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Continuă\";}}s:5:\"ru_RU\";a:8:{s:8:\"language\";s:5:\"ru_RU\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-31 11:58:44\";s:12:\"english_name\";s:7:\"Russian\";s:11:\"native_name\";s:14:\"Русский\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/ru_RU.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ru\";i:2;s:3:\"rus\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продолжить\";}}s:5:\"sk_SK\";a:8:{s:8:\"language\";s:5:\"sk_SK\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 09:29:23\";s:12:\"english_name\";s:6:\"Slovak\";s:11:\"native_name\";s:11:\"Slovenčina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sk_SK.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sk\";i:2;s:3:\"slk\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:12:\"Pokračovať\";}}s:5:\"sl_SI\";a:8:{s:8:\"language\";s:5:\"sl_SI\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 16:25:46\";s:12:\"english_name\";s:9:\"Slovenian\";s:11:\"native_name\";s:13:\"Slovenščina\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/sl_SI.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sl\";i:2;s:3:\"slv\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:10:\"Nadaljujte\";}}s:2:\"sq\";a:8:{s:8:\"language\";s:2:\"sq\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-29 08:27:12\";s:12:\"english_name\";s:8:\"Albanian\";s:11:\"native_name\";s:5:\"Shqip\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/sq.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sq\";i:2;s:3:\"sqi\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"Vazhdo\";}}s:5:\"sr_RS\";a:8:{s:8:\"language\";s:5:\"sr_RS\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-06-04 20:54:02\";s:12:\"english_name\";s:7:\"Serbian\";s:11:\"native_name\";s:23:\"Српски језик\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sr_RS.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sr\";i:2;s:3:\"srp\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:14:\"Настави\";}}s:5:\"sv_SE\";a:8:{s:8:\"language\";s:5:\"sv_SE\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:08:28\";s:12:\"english_name\";s:7:\"Swedish\";s:11:\"native_name\";s:7:\"Svenska\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/sv_SE.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"sv\";i:2;s:3:\"swe\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:9:\"Fortsätt\";}}s:2:\"th\";a:8:{s:8:\"language\";s:2:\"th\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 15:16:26\";s:12:\"english_name\";s:4:\"Thai\";s:11:\"native_name\";s:9:\"ไทย\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/th.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"th\";i:2;s:3:\"tha\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:15:\"ต่อไป\";}}s:5:\"tr_TR\";a:8:{s:8:\"language\";s:5:\"tr_TR\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-26 07:01:28\";s:12:\"english_name\";s:7:\"Turkish\";s:11:\"native_name\";s:8:\"Türkçe\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/tr_TR.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"tr\";i:2;s:3:\"tur\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:5:\"Devam\";}}s:5:\"ug_CN\";a:8:{s:8:\"language\";s:5:\"ug_CN\";s:7:\"version\";s:5:\"4.1.5\";s:7:\"updated\";s:19:\"2015-03-26 16:45:38\";s:12:\"english_name\";s:6:\"Uighur\";s:11:\"native_name\";s:9:\"Uyƣurqə\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.1.5/ug_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"ug\";i:2;s:3:\"uig\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:26:\"داۋاملاشتۇرۇش\";}}s:2:\"uk\";a:8:{s:8:\"language\";s:2:\"uk\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-05-28 13:43:48\";s:12:\"english_name\";s:9:\"Ukrainian\";s:11:\"native_name\";s:20:\"Українська\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/translation/core/4.2.2/uk.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"uk\";i:2;s:3:\"ukr\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:20:\"Продовжити\";}}s:5:\"zh_CN\";a:8:{s:8:\"language\";s:5:\"zh_CN\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-23 15:23:08\";s:12:\"english_name\";s:15:\"Chinese (China)\";s:11:\"native_name\";s:12:\"简体中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/zh_CN.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"继续\";}}s:5:\"zh_TW\";a:8:{s:8:\"language\";s:5:\"zh_TW\";s:7:\"version\";s:5:\"4.2.2\";s:7:\"updated\";s:19:\"2015-04-29 06:37:03\";s:12:\"english_name\";s:16:\"Chinese (Taiwan)\";s:11:\"native_name\";s:12:\"繁體中文\";s:7:\"package\";s:64:\"https://downloads.wordpress.org/translation/core/4.2.2/zh_TW.zip\";s:3:\"iso\";a:2:{i:1;s:2:\"zh\";i:2;s:3:\"zho\";}s:7:\"strings\";a:1:{s:8:\"continue\";s:6:\"繼續\";}}}","yes");
INSERT INTO `arc1542_options` VALUES("164","WPLANG","","yes");
INSERT INTO `arc1542_options` VALUES("188","itsec_local_file_list_0","a:389:{s:18:\"wp-admin/about.php\";a:2:{s:1:\"d\";i:1430967808;s:1:\"h\";s:32:\"5863f4e68b87af955a3c6a15a68ca6e0\";}s:23:\"wp-admin/admin-ajax.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"57c0bcd9ee3a9e92656deb0d2d584c24\";}s:25:\"wp-admin/admin-footer.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"62134b74766f43dcca4e776a76f44182\";}s:28:\"wp-admin/admin-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"e3f39d6761a2cdce12638d33ad6171bd\";}s:25:\"wp-admin/admin-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"a013ac49d93a73142cce8ad419c71987\";}s:23:\"wp-admin/admin-post.php\";a:2:{s:1:\"d\";i:1417362144;s:1:\"h\";s:32:\"9405e022d36cdf45f029d94518ce4103\";}s:18:\"wp-admin/admin.php\";a:2:{s:1:\"d\";i:1422546802;s:1:\"h\";s:32:\"3490100547f0bfa48258b7ce974ee5c4\";}s:25:\"wp-admin/async-upload.php\";a:2:{s:1:\"d\";i:1423718130;s:1:\"h\";s:32:\"f83c42723f64875427828b5a179c3058\";}s:20:\"wp-admin/comment.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d7d2857905104581460d4024a44439bc\";}s:20:\"wp-admin/credits.php\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"6d600524bee7a3f198bd1788c559e44a\";}s:26:\"wp-admin/css/about-rtl.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"a2812f9bae76c25229981a60a3452159\";}s:22:\"wp-admin/css/about.css\";a:2:{s:1:\"d\";i:1429818206;s:1:\"h\";s:32:\"f0c69f88bca95e586cd57cf7b50d56ce\";}s:31:\"wp-admin/css/admin-menu-rtl.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"9f8a90c453ec305769a851ceba7e13b5\";}s:27:\"wp-admin/css/admin-menu.css\";a:2:{s:1:\"d\";i:1429742310;s:1:\"h\";s:32:\"833e64b0003fc66897e82fcfc7fc0121\";}s:33:\"wp-admin/css/color-picker-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f9e65b1bb803a9710e3447d689c1d361\";}s:37:\"wp-admin/css/color-picker-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b95a1b3477b0c06cfa7f65a11d24bbe8\";}s:29:\"wp-admin/css/color-picker.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2d0d4dc75f8710681395c1b31c6c662f\";}s:33:\"wp-admin/css/color-picker.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b4bbb3b27d8fa55598129646b3bf278f\";}s:31:\"wp-admin/css/colors/_admin.scss\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3dbce149457e880a29693684cecd425\";}s:32:\"wp-admin/css/colors/_mixins.scss\";a:2:{s:1:\"d\";i:1409135536;s:1:\"h\";s:32:\"53e25fcbec91e57c9127342e6f2736ee\";}s:35:\"wp-admin/css/colors/_variables.scss\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"3ab501096b1a091972d84c85b284135a\";}s:39:\"wp-admin/css/colors/blue/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"18340a88bc601743b7c70439cec488ed\";}s:43:\"wp-admin/css/colors/blue/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"a3ef984189150a8810a060747213016b\";}s:35:\"wp-admin/css/colors/blue/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"3518d1b1e45e704aeecc47c0b5e5fae0\";}s:39:\"wp-admin/css/colors/blue/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"998f2d1f4b8565cb04f4c28a3a38b611\";}s:36:\"wp-admin/css/colors/blue/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"d9d03549d79484672c29145aad594db3\";}s:41:\"wp-admin/css/colors/coffee/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"2272c3bc872bdcce77a6b8d0ec902701\";}s:45:\"wp-admin/css/colors/coffee/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"fc48153c9c53bf2d871067cbfca6c8c4\";}s:37:\"wp-admin/css/colors/coffee/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b4cd3218e3c6e52336a8da60cf847d4c\";}s:41:\"wp-admin/css/colors/coffee/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c8796229a84fa15d28de61c772a0d67a\";}s:38:\"wp-admin/css/colors/coffee/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"397e3820b27a234330c95e05250f61ce\";}s:44:\"wp-admin/css/colors/ectoplasm/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58f1d1b2e4ed824585e5cfa1757f49c1\";}s:48:\"wp-admin/css/colors/ectoplasm/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"6f85716a47597c040d5549bbd61ff927\";}s:40:\"wp-admin/css/colors/ectoplasm/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9538ad4bdbecfe10e0bfac3898ee6286\";}s:44:\"wp-admin/css/colors/ectoplasm/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"d392ab4aa1d7ba0fc2c7538e62b30448\";}s:41:\"wp-admin/css/colors/ectoplasm/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"940171d1392bd8071122a905d12b9195\";}s:40:\"wp-admin/css/colors/light/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"ca985fbb17060a4a54e0c2b9c9e4c54a\";}s:44:\"wp-admin/css/colors/light/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"14e0f61252198b7f5bc6b3954f86495c\";}s:36:\"wp-admin/css/colors/light/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"25e706f4ca9277b6f5c09ec85e8360ac\";}s:40:\"wp-admin/css/colors/light/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"c64378da84783433e12a436eabb62f79\";}s:37:\"wp-admin/css/colors/light/colors.scss\";a:2:{s:1:\"d\";i:1395957374;s:1:\"h\";s:32:\"20a8567ba70294295c115f7ed9e071b7\";}s:43:\"wp-admin/css/colors/midnight/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7386ebd85ed17227277f38bf986ec649\";}s:47:\"wp-admin/css/colors/midnight/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"46d38df7939457add9e0cb01862625fd\";}s:39:\"wp-admin/css/colors/midnight/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"7828a09a10e456933f4f44a27bc9e760\";}s:43:\"wp-admin/css/colors/midnight/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b048ef915d1fa35107bc54d96bdca463\";}s:40:\"wp-admin/css/colors/midnight/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"26dc8daaf0c47c4457b8bc2145f48634\";}s:40:\"wp-admin/css/colors/ocean/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83320550041b6ac4a3b224f8cd66a156\";}s:44:\"wp-admin/css/colors/ocean/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"9b6c0b762c7c8c9edb0fdf22fd85084f\";}s:36:\"wp-admin/css/colors/ocean/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"58be4f65a594e084222693e8fba9867e\";}s:40:\"wp-admin/css/colors/ocean/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"b020388806a04a345a11b54a667b0f0a\";}s:37:\"wp-admin/css/colors/ocean/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"1a7c5bfd9faf7f6cc77cd9b166062568\";}s:42:\"wp-admin/css/colors/sunrise/colors-rtl.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"1579864ea35ebc26521222e136a961e7\";}s:46:\"wp-admin/css/colors/sunrise/colors-rtl.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"be0732f8240abe60df1783354817ade5\";}s:38:\"wp-admin/css/colors/sunrise/colors.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"43709ad04cfe4981c074767db4cec654\";}s:42:\"wp-admin/css/colors/sunrise/colors.min.css\";a:2:{s:1:\"d\";i:1428525506;s:1:\"h\";s:32:\"83453647da515355dc45a661ab42ea38\";}s:39:\"wp-admin/css/colors/sunrise/colors.scss\";a:2:{s:1:\"d\";i:1391682318;s:1:\"h\";s:32:\"5692871a8a7a1914ee0968ddf9923dec\";}s:27:\"wp-admin/css/common-rtl.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"81f0f785dbd8eee0a11d054a3cbdf606\";}s:23:\"wp-admin/css/common.css\";a:2:{s:1:\"d\";i:1428477568;s:1:\"h\";s:32:\"6942f692b44491261619b43859b8acfc\";}s:39:\"wp-admin/css/customize-controls-rtl.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"1d0e5ded99e0c19c6deab1602412ad4d\";}s:43:\"wp-admin/css/customize-controls-rtl.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"27d9de08d110062db4c26b9fea3b21cc\";}s:35:\"wp-admin/css/customize-controls.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"183493ffd9bb469e92882434bb95f33c\";}s:39:\"wp-admin/css/customize-controls.min.css\";a:2:{s:1:\"d\";i:1429743446;s:1:\"h\";s:32:\"f94aad7c60a799b4bf28b0e6ea0b0134\";}s:38:\"wp-admin/css/customize-widgets-rtl.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7ab3411bcab95d99021791a7da6a39c8\";}s:42:\"wp-admin/css/customize-widgets-rtl.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"86d0504f3f24934ce87ed755d6d16a98\";}s:34:\"wp-admin/css/customize-widgets.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"7cec3fb121b9608cfb8c6a089bdc1a78\";}s:38:\"wp-admin/css/customize-widgets.min.css\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"868832fcafbffba43f5ba4fbf31d3ca5\";}s:30:\"wp-admin/css/dashboard-rtl.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"ebb761dcfd6cb62a9983a41f6c69266a\";}s:26:\"wp-admin/css/dashboard.css\";a:2:{s:1:\"d\";i:1428526166;s:1:\"h\";s:32:\"c178ee058ec19c709f30baed82db8392\";}s:37:\"wp-admin/css/deprecated-media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"558fe352dfdab9790dab9710438af5a9\";}s:41:\"wp-admin/css/deprecated-media-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"017b6102507494583f9241b9f8854959\";}s:33:\"wp-admin/css/deprecated-media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0ada8c65bb367cab1cabc0defa1ac6a6\";}s:37:\"wp-admin/css/deprecated-media.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"625227ce35e802591f85a974db531d36\";}s:25:\"wp-admin/css/edit-rtl.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"be99c57389c7d414f0f58f33678a0824\";}s:21:\"wp-admin/css/edit.css\";a:2:{s:1:\"d\";i:1428453868;s:1:\"h\";s:32:\"dca1f2c9b549b0c85b279a27e4adc142\";}s:31:\"wp-admin/css/farbtastic-rtl.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"118f1189ffbb71e014402121b5456bc2\";}s:27:\"wp-admin/css/farbtastic.css\";a:2:{s:1:\"d\";i:1384719492;s:1:\"h\";s:32:\"f9e33829b8faed7d7bbef843fb683255\";}s:26:\"wp-admin/css/forms-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"fe5319684165959b7b00b618009c3e81\";}s:22:\"wp-admin/css/forms.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8f95818bedd2456f61d3f82926bbe549\";}s:23:\"wp-admin/css/ie-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0b9e0977caa2f7f8f935d5b5536cf6d7\";}s:27:\"wp-admin/css/ie-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"46dca3fdd473c8b6cec51e3ff5d700c6\";}s:19:\"wp-admin/css/ie.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f146885900f710c867cd48f030851e97\";}s:23:\"wp-admin/css/ie.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"494254d427a06ead698729501d1706c9\";}s:28:\"wp-admin/css/install-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"2a0fc0a9434d3aa6abfda715dfe80ca2\";}s:32:\"wp-admin/css/install-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"e3e8c235f96ea51104cde0104ae12010\";}s:24:\"wp-admin/css/install.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"42c906bd2400b2ab11aa44a8f8396a9e\";}s:28:\"wp-admin/css/install.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"333fb17a509abf264fd13c529939608b\";}s:25:\"wp-admin/css/l10n-rtl.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"fcb0063a38cf8348351737634db3f947\";}s:21:\"wp-admin/css/l10n.css\";a:2:{s:1:\"d\";i:1426832428;s:1:\"h\";s:32:\"5dda0b5411fecbe1fac83dfe21c7540e\";}s:32:\"wp-admin/css/list-tables-rtl.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"a44b142006df40f488aec4ea1357883c\";}s:28:\"wp-admin/css/list-tables.css\";a:2:{s:1:\"d\";i:1429663288;s:1:\"h\";s:32:\"b34413b3174ac624919ce065ebb29aba\";}s:26:\"wp-admin/css/login-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"35f23fc2280b36e67ad2afb8c6737a03\";}s:30:\"wp-admin/css/login-rtl.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"563cb2edac2f1e28bc7ba07afcdda851\";}s:22:\"wp-admin/css/login.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"0e01b8fa9ea4487455a587c852b405c5\";}s:26:\"wp-admin/css/login.min.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"c4661abb4164f292618baa46c3b04235\";}s:26:\"wp-admin/css/media-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"b5f2073fd98bf22e2f2b2353a2475f9f\";}s:22:\"wp-admin/css/media.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f578fae6b47beea325ee8dc1a8551e88\";}s:30:\"wp-admin/css/nav-menus-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"91ff408d32eacbd28e621c34b7565f8d\";}s:26:\"wp-admin/css/nav-menus.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d3266344ddb105a2e774a071dd05a361\";}s:38:\"wp-admin/css/press-this-editor-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"8de2501460648d4cb12d23774d21dd5f\";}s:34:\"wp-admin/css/press-this-editor.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"953fa7568d1de29bc722de0c8d27c59d\";}s:31:\"wp-admin/css/press-this-rtl.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"7f2b2879d22aa540d113a4af70999990\";}s:35:\"wp-admin/css/press-this-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"c6dcd57eb62b059f20223ca862046a02\";}s:27:\"wp-admin/css/press-this.css\";a:2:{s:1:\"d\";i:1429578206;s:1:\"h\";s:32:\"dca19314e2e3871f91e07bcf64b23e53\";}s:31:\"wp-admin/css/press-this.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"48180a7b52dd60bec1fc7a0ae2be0826\";}s:30:\"wp-admin/css/revisions-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"cc328e9ddbef2ef2c495786078ff612a\";}s:26:\"wp-admin/css/revisions.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d266c3e67470bf8f70d91d920b1b50f1\";}s:27:\"wp-admin/css/themes-rtl.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"ed00d87745e51769e94fb921930d997d\";}s:23:\"wp-admin/css/themes.css\";a:2:{s:1:\"d\";i:1429733728;s:1:\"h\";s:32:\"0f2c9837f4d58bec62e54c49bc2b7794\";}s:28:\"wp-admin/css/widgets-rtl.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d81963de7dff71f3295c5a42fba00ab7\";}s:24:\"wp-admin/css/widgets.css\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"4dc79b8deabc48edc3cb04b90633810d\";}s:29:\"wp-admin/css/wp-admin-rtl.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"7fbe22c3651b774033fa758ca07ccbbb\";}s:33:\"wp-admin/css/wp-admin-rtl.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"030caf3660328d0bb366809887d33a2a\";}s:25:\"wp-admin/css/wp-admin.css\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"ada11abbeb8553e9524605cbfc29d26d\";}s:29:\"wp-admin/css/wp-admin.min.css\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"225d1ef58b5ab0f793d3952967df269a\";}s:30:\"wp-admin/custom-background.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"89d8a54f939a110003510e982d8fe57f\";}s:26:\"wp-admin/custom-header.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5488cf2e8e9630388723c51a7a0726bc\";}s:22:\"wp-admin/customize.php\";a:2:{s:1:\"d\";i:1428009388;s:1:\"h\";s:32:\"5481909613787611390e7c3548337820\";}s:26:\"wp-admin/edit-comments.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"294f99f28d493d34925d56791d4b16ab\";}s:31:\"wp-admin/edit-form-advanced.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"833ab8eb05e8b63fb56b8c62363b9591\";}s:30:\"wp-admin/edit-form-comment.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"8325c6fe38489470c57f3f4832e17892\";}s:27:\"wp-admin/edit-link-form.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"fa37a6bab69f64e1479847f5008e4725\";}s:26:\"wp-admin/edit-tag-form.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"463fb3100f9f45fbd0ca2f297725e68f\";}s:22:\"wp-admin/edit-tags.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4dfc7b236b076202eda683d2616fb77e\";}s:17:\"wp-admin/edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"e181a2ab1d1838d41a71df7d75fe8a91\";}s:19:\"wp-admin/export.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d62d73bc749f99ef989dba3f5fc85f4a\";}s:21:\"wp-admin/freedoms.php\";a:2:{s:1:\"d\";i:1429072708;s:1:\"h\";s:32:\"65830b9bbe81aac353761e4c5879c2b8\";}s:32:\"wp-admin/images/bubble_bg-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"16523d5bf9efd8ca3b92e7631edfc513\";}s:29:\"wp-admin/images/bubble_bg.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3d2cb3f7baa628c9e51a326356e72038\";}s:34:\"wp-admin/images/date-button-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2952932c246bf9828429361643a8bb63\";}s:31:\"wp-admin/images/date-button.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"979d8e2e08aada49819556950ec48ff6\";}s:27:\"wp-admin/images/loading.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2d5b92b61674c850bff00cecaf0864ec\";}s:38:\"wp-admin/images/media-button-image.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7ea2c9c157c38edb40b1ce62d572d5b3\";}s:38:\"wp-admin/images/media-button-music.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"eff55df37f325c5aae2f02e4d913de95\";}s:38:\"wp-admin/images/media-button-other.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8bc6b46bc70c7c1918dce62c4fe3229c\";}s:38:\"wp-admin/images/media-button-video.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"abaac3dfd81fbf72e578f13451eae7d0\";}s:29:\"wp-admin/images/resize-2x.gif\";a:2:{s:1:\"d\";i:1392292994;s:1:\"h\";s:32:\"f5e118653f892606682ee9c51d0aba99\";}s:33:\"wp-admin/images/resize-rtl-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"f7c99ee74014fe92541012303aaadc7d\";}s:30:\"wp-admin/images/resize-rtl.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"db9217196313c95a59d43601da19c51d\";}s:26:\"wp-admin/images/resize.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"3fba1544df24f40dde5876c8c0aec461\";}s:27:\"wp-admin/images/sort-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"186e51267fca5d20b230c72d9a8983ee\";}s:24:\"wp-admin/images/sort.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"2e8acb8dee99bfbcb61bd46c486a995d\";}s:30:\"wp-admin/images/spinner-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"5c1371bcb4392968647852a9c9df5d6c\";}s:27:\"wp-admin/images/spinner.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"b0a3dde331637e27aa6476d476481871\";}s:40:\"wp-admin/images/wordpress-logo-white.svg\";a:2:{s:1:\"d\";i:1384078330;s:1:\"h\";s:32:\"e1af633d59dcb5988cacff73b6dee9ff\";}s:34:\"wp-admin/images/wordpress-logo.svg\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"f34ef6259364f7ef0ccf67cd1dddc970\";}s:35:\"wp-admin/images/wpspin_light-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"7def33aad959cd289d49ddf2a41f076d\";}s:32:\"wp-admin/images/wpspin_light.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"dd4e6dd268a70ce4c1c5143b1a4092dd\";}s:26:\"wp-admin/images/xit-2x.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"8fb0729c541cbdc4609faf3f4ad02fc7\";}s:23:\"wp-admin/images/xit.gif\";a:2:{s:1:\"d\";i:1414548142;s:1:\"h\";s:32:\"e5012902a358fbb96031acdcf048d7ca\";}s:19:\"wp-admin/import.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6e389b5d3ce9c49472c2f65737894057\";}s:27:\"wp-admin/includes/admin.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"be54224152f2b4ec6879ffdbba435129\";}s:34:\"wp-admin/includes/ajax-actions.php\";a:2:{s:1:\"d\";i:1429670486;s:1:\"h\";s:32:\"8d262c73247924453f1692cd240c75c3\";}s:30:\"wp-admin/includes/bookmark.php\";a:2:{s:1:\"d\";i:1416132982;s:1:\"h\";s:32:\"5682d92e5f2542298a6ab34186891a61\";}s:36:\"wp-admin/includes/class-ftp-pure.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"2cfd5c1b2e4288cef60faddbedeff8d3\";}s:39:\"wp-admin/includes/class-ftp-sockets.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"54d9e85b94c4e6368813852b9a81273c\";}s:31:\"wp-admin/includes/class-ftp.php\";a:2:{s:1:\"d\";i:1415803464;s:1:\"h\";s:32:\"ad8496325608fb75875c49f64c0b84fc\";}s:34:\"wp-admin/includes/class-pclzip.php\";a:2:{s:1:\"d\";i:1255652782;s:1:\"h\";s:32:\"01363728c843ff93e96b6983ce38eba6\";}s:50:\"wp-admin/includes/class-wp-comments-list-table.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"03b99541cc4e471541f6eb52fc993cdb\";}s:46:\"wp-admin/includes/class-wp-filesystem-base.php\";a:2:{s:1:\"d\";i:1424944104;s:1:\"h\";s:32:\"053d3e7194eb24bd010794b2e45f8070\";}s:48:\"wp-admin/includes/class-wp-filesystem-direct.php\";a:2:{s:1:\"d\";i:1419122424;s:1:\"h\";s:32:\"7c687f407b517d35e8986321df4b3059\";}s:48:\"wp-admin/includes/class-wp-filesystem-ftpext.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"b18e349ccc50fc1b3f7e240dd365347e\";}s:52:\"wp-admin/includes/class-wp-filesystem-ftpsockets.php\";a:2:{s:1:\"d\";i:1426720948;s:1:\"h\";s:32:\"4eb43c52d18090a544df4676af189b9e\";}s:46:\"wp-admin/includes/class-wp-filesystem-ssh2.php\";a:2:{s:1:\"d\";i:1425889948;s:1:\"h\";s:32:\"d43d02e98585870d63d76fd7e23cb732\";}s:39:\"wp-admin/includes/class-wp-importer.php\";a:2:{s:1:\"d\";i:1421463082;s:1:\"h\";s:32:\"d04b79a26c434bac92572eb31da8a135\";}s:47:\"wp-admin/includes/class-wp-links-list-table.php\";a:2:{s:1:\"d\";i:1421288062;s:1:\"h\";s:32:\"7050b4928ed9e9a71e7b34570ff74557\";}s:41:\"wp-admin/includes/class-wp-list-table.php\";a:2:{s:1:\"d\";i:1424656106;s:1:\"h\";s:32:\"15b7819b8098a83efa5b124cd8736842\";}s:47:\"wp-admin/includes/class-wp-media-list-table.php\";a:2:{s:1:\"d\";i:1427846246;s:1:\"h\";s:32:\"5eaa024ba0f05d24b8ee56be1dc7c6f6\";}s:50:\"wp-admin/includes/class-wp-ms-sites-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"1603c869a83696c7f27c914b13aa7b68\";}s:51:\"wp-admin/includes/class-wp-ms-themes-list-table.php\";a:2:{s:1:\"d\";i:1421093842;s:1:\"h\";s:32:\"b7d8cddc268e99caa0fd867cc57a9d15\";}s:50:\"wp-admin/includes/class-wp-ms-users-list-table.php\";a:2:{s:1:\"d\";i:1426796548;s:1:\"h\";s:32:\"e4f826892bb47ac498e17de592c4b023\";}s:56:\"wp-admin/includes/class-wp-plugin-install-list-table.php\";a:2:{s:1:\"d\";i:1428032968;s:1:\"h\";s:32:\"c169312a5c0d45bf60729cefc606cd43\";}s:49:\"wp-admin/includes/class-wp-plugins-list-table.php\";a:2:{s:1:\"d\";i:1427232808;s:1:\"h\";s:32:\"52c76d175bde8b9781e1600a6adcb812\";}s:47:\"wp-admin/includes/class-wp-posts-list-table.php\";a:2:{s:1:\"d\";i:1428178106;s:1:\"h\";s:32:\"eff04c61fdbf46485b95e161271493d8\";}s:41:\"wp-admin/includes/class-wp-press-this.php\";a:2:{s:1:\"d\";i:1429421668;s:1:\"h\";s:32:\"18e8b8c6e4c4abc97ffa4d4acb283651\";}s:47:\"wp-admin/includes/class-wp-terms-list-table.php\";a:2:{s:1:\"d\";i:1423035984;s:1:\"h\";s:32:\"5eb2173c2679ce21f141199be9f1165c\";}s:55:\"wp-admin/includes/class-wp-theme-install-list-table.php\";a:2:{s:1:\"d\";i:1425783808;s:1:\"h\";s:32:\"8ff475a867be95d6fdfd7fae9add0f34\";}s:48:\"wp-admin/includes/class-wp-themes-list-table.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"40cc946d84ea606286c8f15479544835\";}s:45:\"wp-admin/includes/class-wp-upgrader-skins.php\";a:2:{s:1:\"d\";i:1424639244;s:1:\"h\";s:32:\"3c5d0b0c99fe3af5504756355d661688\";}s:39:\"wp-admin/includes/class-wp-upgrader.php\";a:2:{s:1:\"d\";i:1428034708;s:1:\"h\";s:32:\"1fd2dd8f3265df13718ff7c90aa2eeb2\";}s:47:\"wp-admin/includes/class-wp-users-list-table.php\";a:2:{s:1:\"d\";i:1428196168;s:1:\"h\";s:32:\"936fe59e0bf3a8ed7ae1d91a34854015\";}s:29:\"wp-admin/includes/comment.php\";a:2:{s:1:\"d\";i:1414792582;s:1:\"h\";s:32:\"a2a4e95cdac0b8a2e42733ae29dea751\";}s:39:\"wp-admin/includes/continents-cities.php\";a:2:{s:1:\"d\";i:1242345926;s:1:\"h\";s:32:\"024b57d99bbe8b9e133316d1e98fc79d\";}s:31:\"wp-admin/includes/dashboard.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"7755ef730ecdc36415c482dbaf471b04\";}s:32:\"wp-admin/includes/deprecated.php\";a:2:{s:1:\"d\";i:1426101928;s:1:\"h\";s:32:\"0c665b41c9d916f3cbb7786711960e4b\";}s:28:\"wp-admin/includes/export.php\";a:2:{s:1:\"d\";i:1420715126;s:1:\"h\";s:32:\"78e46f3d610ca92a41acbea60e546496\";}s:26:\"wp-admin/includes/file.php\";a:2:{s:1:\"d\";i:1430292030;s:1:\"h\";s:32:\"aaf31744d17c235f7835b359cb5768d1\";}s:32:\"wp-admin/includes/image-edit.php\";a:2:{s:1:\"d\";i:1425070286;s:1:\"h\";s:32:\"dd6f097ac32ab3dac81fe65287bafde3\";}s:27:\"wp-admin/includes/image.php\";a:2:{s:1:\"d\";i:1425978448;s:1:\"h\";s:32:\"c13371e2d82ee708e7e8f3d09e84faa2\";}s:28:\"wp-admin/includes/import.php\";a:2:{s:1:\"d\";i:1419124224;s:1:\"h\";s:32:\"deb1db7743721bdda9411c8a5c04d70f\";}s:32:\"wp-admin/includes/list-table.php\";a:2:{s:1:\"d\";i:1405303756;s:1:\"h\";s:32:\"039a82ba14a35438ace23efba15fdf82\";}s:27:\"wp-admin/includes/media.php\";a:2:{s:1:\"d\";i:1428197726;s:1:\"h\";s:32:\"7ffe0152492297cb75fd7d96ef5b6461\";}s:26:\"wp-admin/includes/menu.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"58264a1bca858e1f712ec7f98f109899\";}s:32:\"wp-admin/includes/meta-boxes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"97773e9daa2b252b840c25f1ee5fda9f\";}s:26:\"wp-admin/includes/misc.php\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"d28646b454f9f4e03fcf3be9b8d580cb\";}s:35:\"wp-admin/includes/ms-deprecated.php\";a:2:{s:1:\"d\";i:1425870568;s:1:\"h\";s:32:\"0b2f626d4faa139d644e4c0969f6aa58\";}s:24:\"wp-admin/includes/ms.php\";a:2:{s:1:\"d\";i:1426751788;s:1:\"h\";s:32:\"aba87ff132e62a01485b10c37340f5bd\";}s:30:\"wp-admin/includes/nav-menu.php\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"914aebacbcbf40acb90559e04f53fe70\";}s:36:\"wp-admin/includes/plugin-install.php\";a:2:{s:1:\"d\";i:1428390566;s:1:\"h\";s:32:\"3eba38bff1614bec4d1a1f9650d04fff\";}s:28:\"wp-admin/includes/plugin.php\";a:2:{s:1:\"d\";i:1421457562;s:1:\"h\";s:32:\"ada165c90f5c7985fccb101bdf3afb38\";}s:26:\"wp-admin/includes/post.php\";a:2:{s:1:\"d\";i:1428198746;s:1:\"h\";s:32:\"d889e18d2c2714b9841da7bd03774b74\";}s:30:\"wp-admin/includes/revision.php\";a:2:{s:1:\"d\";i:1427091268;s:1:\"h\";s:32:\"02ae8504c79255eebb2b7a6de6f65ca6\";}s:28:\"wp-admin/includes/schema.php\";a:2:{s:1:\"d\";i:1423568848;s:1:\"h\";s:32:\"d3e3579ef079b924c3dd4789fb6df040\";}s:28:\"wp-admin/includes/screen.php\";a:2:{s:1:\"d\";i:1426015948;s:1:\"h\";s:32:\"f5423c59bdc088834ed8e526c8bce73e\";}s:30:\"wp-admin/includes/taxonomy.php\";a:2:{s:1:\"d\";i:1422545662;s:1:\"h\";s:32:\"e345a18b9436e50ee17c4af7ffe1b2b5\";}s:30:\"wp-admin/includes/template.php\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"6699a307eb2ae234e38c6406b38956c3\";}s:35:\"wp-admin/includes/theme-install.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"e66174127b56d0eb51c685c32ad68455\";}s:27:\"wp-admin/includes/theme.php\";a:2:{s:1:\"d\";i:1429733486;s:1:\"h\";s:32:\"ebfda92f8dec9d6ba85462864b78c05a\";}s:41:\"wp-admin/includes/translation-install.php\";a:2:{s:1:\"d\";i:1423841006;s:1:\"h\";s:32:\"81931f61c70a5dbaa17236c86fe965ba\";}s:33:\"wp-admin/includes/update-core.php\";a:2:{s:1:\"d\";i:1430951968;s:1:\"h\";s:32:\"89bb7c2af227e6554315c3ee61ddff63\";}s:28:\"wp-admin/includes/update.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"83440a93ab1d6d7a2fd9d53a1589fdf4\";}s:29:\"wp-admin/includes/upgrade.php\";a:2:{s:1:\"d\";i:1430975550;s:1:\"h\";s:32:\"f0e28fe081e8a3a12087a695d3cb7a68\";}s:26:\"wp-admin/includes/user.php\";a:2:{s:1:\"d\";i:1428259468;s:1:\"h\";s:32:\"17eacf5ff7e5f4827a64d6c5424fd956\";}s:29:\"wp-admin/includes/widgets.php\";a:2:{s:1:\"d\";i:1421396184;s:1:\"h\";s:32:\"f94a23c52573d5aab9c36b0c612e52c8\";}s:18:\"wp-admin/index.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2c75aa13fe1b4abb250879085a2efb0f\";}s:27:\"wp-admin/install-helper.php\";a:2:{s:1:\"d\";i:1416822444;s:1:\"h\";s:32:\"5480b0fabf52c37eee8bfed6db52335a\";}s:20:\"wp-admin/install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a48aee948fe2ea5d3a6b9a325b604f5\";}s:24:\"wp-admin/js/accordion.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"f25e56e30af6382e3770be437493373a\";}s:28:\"wp-admin/js/accordion.min.js\";a:2:{s:1:\"d\";i:1414637482;s:1:\"h\";s:32:\"cfa0d94d00f7a8a147c3815dc819e114\";}s:26:\"wp-admin/js/bookmarklet.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"599601c1e1bcbf766f466722e50cb06b\";}s:30:\"wp-admin/js/bookmarklet.min.js\";a:2:{s:1:\"d\";i:1426553486;s:1:\"h\";s:32:\"07603898b017e6cc23f7a5b90c003314\";}s:27:\"wp-admin/js/color-picker.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"0e948ad7ea32644d4dcadc0f54fac1e3\";}s:31:\"wp-admin/js/color-picker.min.js\";a:2:{s:1:\"d\";i:1415896464;s:1:\"h\";s:32:\"1aa57d225b7d9bb8bfa8500e0c2de029\";}s:22:\"wp-admin/js/comment.js\";a:2:{s:1:\"d\";i:1384047010;s:1:\"h\";s:32:\"a3fefb4998b3f534e144db4f235d0f03\";}s:26:\"wp-admin/js/comment.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"38ff692f79a3e57df9b9192a9e43b4ea\";}s:21:\"wp-admin/js/common.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"dc9e2fa5c5e058e9a9466f48322e0f32\";}s:25:\"wp-admin/js/common.min.js\";a:2:{s:1:\"d\";i:1427940388;s:1:\"h\";s:32:\"d3a3f5d88670f6fea04b6f523f67b528\";}s:32:\"wp-admin/js/custom-background.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"f26af7294ee07fb9a0cb88c2a8697623\";}s:36:\"wp-admin/js/custom-background.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"82d07f23593e578820b19fc9faad65a0\";}s:28:\"wp-admin/js/custom-header.js\";a:2:{s:1:\"d\";i:1384422012;s:1:\"h\";s:32:\"32b3005887a4cb606fecc09c756605bb\";}s:33:\"wp-admin/js/customize-controls.js\";a:2:{s:1:\"d\";i:1428977430;s:1:\"h\";s:32:\"7c0e981e54ea85d7971d0a9b25a9c263\";}s:37:\"wp-admin/js/customize-controls.min.js\";a:2:{s:1:\"d\";i:1429820770;s:1:\"h\";s:32:\"fa9142f8d88f8566d3dd0b40b602ce2e\";}s:32:\"wp-admin/js/customize-widgets.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"07f1519a2a074eb51cce3ec5cb9810d5\";}s:36:\"wp-admin/js/customize-widgets.min.js\";a:2:{s:1:\"d\";i:1429640126;s:1:\"h\";s:32:\"ef95bf9c8588420084c724b541ec9fa0\";}s:24:\"wp-admin/js/dashboard.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"dcaf4f687c6c523cf0e2d5515234faa5\";}s:28:\"wp-admin/js/dashboard.min.js\";a:2:{s:1:\"d\";i:1406662456;s:1:\"h\";s:32:\"39f67345a12faf1a3c53c9289fc59f86\";}s:28:\"wp-admin/js/edit-comments.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f6947b28c386e3637c99d199c4a32a33\";}s:32:\"wp-admin/js/edit-comments.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"f303c21d68b4ebff99aab2df75f81db9\";}s:28:\"wp-admin/js/editor-expand.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"001eee141532f8fc1fac023dbb945a92\";}s:32:\"wp-admin/js/editor-expand.min.js\";a:2:{s:1:\"d\";i:1430893528;s:1:\"h\";s:32:\"78a1af5d700f31280bfc20621bce8e50\";}s:21:\"wp-admin/js/editor.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"1e33af23a168b21a333bf6ba71ac4671\";}s:25:\"wp-admin/js/editor.min.js\";a:2:{s:1:\"d\";i:1421382442;s:1:\"h\";s:32:\"a71c41c4b1c1f15084fe96f5f6d5e095\";}s:25:\"wp-admin/js/farbtastic.js\";a:2:{s:1:\"d\";i:1289507662;s:1:\"h\";s:32:\"a73af354a03241715d8698feea340b92\";}s:22:\"wp-admin/js/gallery.js\";a:2:{s:1:\"d\";i:1384873810;s:1:\"h\";s:32:\"1be9174b160c7eb40e6cdce4031ae89e\";}s:26:\"wp-admin/js/gallery.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"1c986fe3039dbacf126de2f0dc644f6f\";}s:25:\"wp-admin/js/image-edit.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c21931f1eecd6c1532a4c2ca7a7faa5e\";}s:29:\"wp-admin/js/image-edit.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"40c9a1866d7ab4aec2346e02d82f4758\";}s:31:\"wp-admin/js/inline-edit-post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"8c56d38ee4c4c97d875fdbc20ac029dd\";}s:35:\"wp-admin/js/inline-edit-post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"167e7b26c864699559d930fc5ce72a7a\";}s:30:\"wp-admin/js/inline-edit-tax.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"a920718b385e75e18193ee293ffdfd3c\";}s:34:\"wp-admin/js/inline-edit-tax.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4aa2a2e6ee60243f003d3ebb47edf4b4\";}s:23:\"wp-admin/js/iris.min.js\";a:2:{s:1:\"d\";i:1417362262;s:1:\"h\";s:32:\"75c63560c640c4a6c31f5565dfb0e8a9\";}s:31:\"wp-admin/js/language-chooser.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"09e20150c7561d0330d7158f744abb4a\";}s:35:\"wp-admin/js/language-chooser.min.js\";a:2:{s:1:\"d\";i:1407199636;s:1:\"h\";s:32:\"1d6822384a71090c74add106e4468581\";}s:19:\"wp-admin/js/link.js\";a:2:{s:1:\"d\";i:1384506970;s:1:\"h\";s:32:\"1c8675dcd035cfb374f67bfcbf117a8c\";}s:23:\"wp-admin/js/link.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"f9ff4694933001933bdec2c133b2252d\";}s:28:\"wp-admin/js/media-gallery.js\";a:2:{s:1:\"d\";i:1384571950;s:1:\"h\";s:32:\"7cf21db8661f9201a784f638f77d2b26\";}s:32:\"wp-admin/js/media-gallery.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"3296d1fa20d292b002bba10490f1ba6e\";}s:27:\"wp-admin/js/media-upload.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"5f66a88c118be462a566029db50aa3a2\";}s:31:\"wp-admin/js/media-upload.min.js\";a:2:{s:1:\"d\";i:1403732356;s:1:\"h\";s:32:\"61ea709a3314ba200a885e2465267aa2\";}s:20:\"wp-admin/js/media.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"cf85d75e70304c42f77553ee9b9ec585\";}s:24:\"wp-admin/js/media.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"2e8efd83242126157ff0bffd5e249159\";}s:23:\"wp-admin/js/nav-menu.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"d6facb8a8fe8d2ed1cdef140d006942a\";}s:27:\"wp-admin/js/nav-menu.min.js\";a:2:{s:1:\"d\";i:1429529966;s:1:\"h\";s:32:\"e2fe94b081c4f0bb2e673b75b2d72b23\";}s:38:\"wp-admin/js/password-strength-meter.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"4d912846975670c9e2232a19ef7bb41b\";}s:42:\"wp-admin/js/password-strength-meter.min.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"3185f27c8fa4123db79a1d6de055c9d7\";}s:29:\"wp-admin/js/plugin-install.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"90585237ad358716313a1f5d9b9353b9\";}s:33:\"wp-admin/js/plugin-install.min.js\";a:2:{s:1:\"d\";i:1428283228;s:1:\"h\";s:32:\"7a6211c90a9364fa26b36f9866d53e9e\";}s:19:\"wp-admin/js/post.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"995f94db4b9e67b27b3d71ca72624988\";}s:23:\"wp-admin/js/post.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"c47dac85d54efe4352e7e5d6045970ab\";}s:22:\"wp-admin/js/postbox.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"87a08ca86f25ee997a627ce4a88ec359\";}s:26:\"wp-admin/js/postbox.min.js\";a:2:{s:1:\"d\";i:1408338796;s:1:\"h\";s:32:\"8bf00b23dafb248f022d8b21693e0418\";}s:25:\"wp-admin/js/press-this.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"91993a940f719edbe2ad8a259973527e\";}s:29:\"wp-admin/js/press-this.min.js\";a:2:{s:1:\"d\";i:1428714510;s:1:\"h\";s:32:\"682e5b74d3791a9c09b8c5317f84aa4a\";}s:24:\"wp-admin/js/revisions.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"41f746a4087bec7e9b0db4152759d169\";}s:28:\"wp-admin/js/revisions.min.js\";a:2:{s:1:\"d\";i:1418392466;s:1:\"h\";s:32:\"3253906cffe4523bc05d0632af4c6af8\";}s:33:\"wp-admin/js/set-post-thumbnail.js\";a:2:{s:1:\"d\";i:1384506730;s:1:\"h\";s:32:\"2b5153576d1eee4002fb7ed9e5831251\";}s:37:\"wp-admin/js/set-post-thumbnail.min.js\";a:2:{s:1:\"d\";i:1384393512;s:1:\"h\";s:32:\"8bc5ca12fa38a607d5af2181311b7a5b\";}s:26:\"wp-admin/js/svg-painter.js\";a:2:{s:1:\"d\";i:1386295270;s:1:\"h\";s:32:\"87dcfbe97f902fa77cc4a9889c827afc\";}s:30:\"wp-admin/js/svg-painter.min.js\";a:2:{s:1:\"d\";i:1390985010;s:1:\"h\";s:32:\"8db7f2acb2c205b766167517ccce7f8a\";}s:23:\"wp-admin/js/tags-box.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"74a49b1066cf04c0e5c92020e0ff23af\";}s:27:\"wp-admin/js/tags-box.min.js\";a:2:{s:1:\"d\";i:1427347408;s:1:\"h\";s:32:\"e5824b6ec80b938c3c17d7a19e78d9a9\";}s:19:\"wp-admin/js/tags.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"4cc64266f1b35a86c63cc1b2c42f7306\";}s:23:\"wp-admin/js/tags.min.js\";a:2:{s:1:\"d\";i:1426179146;s:1:\"h\";s:32:\"172f499d40d4217bbf684cd552031acb\";}s:20:\"wp-admin/js/theme.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"ce08e4628996a70a5d5deac9221e1130\";}s:24:\"wp-admin/js/theme.min.js\";a:2:{s:1:\"d\";i:1428043052;s:1:\"h\";s:32:\"3bb1a6dc71edb4b953c6dec624b162c5\";}s:22:\"wp-admin/js/updates.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"79c9c0056693f2eba1f6007ccc6fb20b\";}s:26:\"wp-admin/js/updates.min.js\";a:2:{s:1:\"d\";i:1429736246;s:1:\"h\";s:32:\"0f5a5b69ce6a28ec4efcaf68a55c21d5\";}s:27:\"wp-admin/js/user-profile.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"28090921c47b8aab172ab53dcc269d00\";}s:31:\"wp-admin/js/user-profile.min.js\";a:2:{s:1:\"d\";i:1424451928;s:1:\"h\";s:32:\"6a1e4023a877503c50771b02f2d332c2\";}s:27:\"wp-admin/js/user-suggest.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"1e33290807fa8b2829ddb0347d0a9305\";}s:31:\"wp-admin/js/user-suggest.min.js\";a:2:{s:1:\"d\";i:1390878612;s:1:\"h\";s:32:\"e089545cd7fcde5c7cd70de3a70139e1\";}s:22:\"wp-admin/js/widgets.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"485de2b76d48a457394827f2f5c5e0fb\";}s:26:\"wp-admin/js/widgets.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"4c2c339725d1719abe9809b79e89d390\";}s:25:\"wp-admin/js/word-count.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"66256995400e51a5f931a11bc11e1e4e\";}s:29:\"wp-admin/js/word-count.min.js\";a:2:{s:1:\"d\";i:1384512730;s:1:\"h\";s:32:\"c71cccaeb645b4e75e963aecff2f5fc6\";}s:28:\"wp-admin/js/wp-fullscreen.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"669dfa41fd076fadd200112960a46fcb\";}s:32:\"wp-admin/js/wp-fullscreen.min.js\";a:2:{s:1:\"d\";i:1428051148;s:1:\"h\";s:32:\"d6a88a01bdc839e38c5a25c3533d32c4\";}s:18:\"wp-admin/js/xfn.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"e2d6eecbd774af1e2bb1a16ec117286b\";}s:22:\"wp-admin/js/xfn.min.js\";a:2:{s:1:\"d\";i:1384480690;s:1:\"h\";s:32:\"66b227ca28f41f2e0615b04a390d5e04\";}s:21:\"wp-admin/link-add.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"759747ef8d44c52fadcfa5c457f3f283\";}s:25:\"wp-admin/link-manager.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"416c4e2eadb0a92b516391bed0b8ac02\";}s:28:\"wp-admin/link-parse-opml.php\";a:2:{s:1:\"d\";i:1428015688;s:1:\"h\";s:32:\"446ddcd3dec1e48190e666b238eba7e1\";}s:17:\"wp-admin/link.php\";a:2:{s:1:\"d\";i:1405602856;s:1:\"h\";s:32:\"63adfdd74e61e01c62e1a1e41cd37f64\";}s:25:\"wp-admin/load-scripts.php\";a:2:{s:1:\"d\";i:1420268242;s:1:\"h\";s:32:\"3e0837db719900ab7dce30025b92ab30\";}s:24:\"wp-admin/load-styles.php\";a:2:{s:1:\"d\";i:1404431834;s:1:\"h\";s:32:\"e4fe4585bf1930564ff8d572a0a5eac2\";}s:25:\"wp-admin/maint/repair.php\";a:2:{s:1:\"d\";i:1404065416;s:1:\"h\";s:32:\"3ba2182300e632340850329b7065da34\";}s:22:\"wp-admin/media-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d37f8ace789522fe8d82eafda85bfbaf\";}s:25:\"wp-admin/media-upload.php\";a:2:{s:1:\"d\";i:1422964042;s:1:\"h\";s:32:\"54bfe84a40818aa5f0b886ef21e1f6ce\";}s:18:\"wp-admin/media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"a3323d084b4298fcada382ed48eed842\";}s:24:\"wp-admin/menu-header.php\";a:2:{s:1:\"d\";i:1427908648;s:1:\"h\";s:32:\"1f77220052f77c59724983b5d782529a\";}s:17:\"wp-admin/menu.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"c6ee46bcfb7abb6568569add0aa18120\";}s:23:\"wp-admin/moderation.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"541242a293805952a0e22234f09d6fa9\";}s:21:\"wp-admin/ms-admin.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9a05b49740dfcdaf4516851b623606e4\";}s:27:\"wp-admin/ms-delete-site.php\";a:2:{s:1:\"d\";i:1425795030;s:1:\"h\";s:32:\"19c0d841bde03b74c53f4f615176518b\";}s:20:\"wp-admin/ms-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"16d42ff617c4a616c3bd94ba103a4582\";}s:23:\"wp-admin/ms-options.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a21d278e00ca7dccfe3a81d4e386afa9\";}s:21:\"wp-admin/ms-sites.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"5d186224ebf4ddd0f1719c9ef4b80468\";}s:22:\"wp-admin/ms-themes.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"521cb94b9501ca24bc495a31c66925d8\";}s:31:\"wp-admin/ms-upgrade-network.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"7cb492260f22ee53816d96be3868be6d\";}s:21:\"wp-admin/ms-users.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4823c8667b23ca83b31bf9093647e5a2\";}s:21:\"wp-admin/my-sites.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"575f48b933eeb0ec3809b68584b56af6\";}s:22:\"wp-admin/nav-menus.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0378f1ac1491adffb9be1acd89a3a3e1\";}s:26:\"wp-admin/network/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"e9e33df9da15a95356e6da0e56889fec\";}s:26:\"wp-admin/network/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"4e85d4354373cc17b9099b130b121f12\";}s:28:\"wp-admin/network/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"38192cde34142cc7ecf558f58ef475f0\";}s:25:\"wp-admin/network/edit.php\";a:2:{s:1:\"d\";i:1417360882;s:1:\"h\";s:32:\"0deb5ea059c21f268c973b5ea0fcd21a\";}s:29:\"wp-admin/network/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"109efa9312c00370894f7e2ba27e9c31\";}s:26:\"wp-admin/network/index.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"8d5631ed02722fccdaef052efbdbcb4a\";}s:25:\"wp-admin/network/menu.php\";a:2:{s:1:\"d\";i:1412279358;s:1:\"h\";s:32:\"1ae13d535ba56678c4e08acf1989a3d5\";}s:34:\"wp-admin/network/plugin-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"3fb5cd9ab947024d84585a0d693dcc12\";}s:35:\"wp-admin/network/plugin-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"6bbd804f795fa5a934f529a51a9886bf\";}s:28:\"wp-admin/network/plugins.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"4193887cb9cb7f4d4d3000bdf303bf1e\";}s:28:\"wp-admin/network/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d86926a7511d1d5cd3a2f0a502e7b6a8\";}s:29:\"wp-admin/network/settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"97e11d59cdfc86f0a6bb7b443d6cde65\";}s:26:\"wp-admin/network/setup.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ee19cf426d3e6e397a5d891f08d19ae2\";}s:30:\"wp-admin/network/site-info.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"817cc350d57c04ae4eec460ace8e6d36\";}s:29:\"wp-admin/network/site-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"710cf4cd7985b5acd028f46caf236e4b\";}s:34:\"wp-admin/network/site-settings.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"996a40c97e25b119ed171083c5f47873\";}s:32:\"wp-admin/network/site-themes.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"91216c7ce232e5b8d4565faf0e0c038a\";}s:31:\"wp-admin/network/site-users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"fada8422fa27bae1ad0d2e0ce6c8138d\";}s:26:\"wp-admin/network/sites.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"e67f0b0fd462649c592e7cbb11d24bad\";}s:33:\"wp-admin/network/theme-editor.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"804f9a460fa9e3646d83f915c51cd36a\";}s:34:\"wp-admin/network/theme-install.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"26d5b7cd315570d025e09e11313d24e4\";}s:27:\"wp-admin/network/themes.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"db78a791b08f071379027c1c93fa0543\";}s:32:\"wp-admin/network/update-core.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"a1223f017d52327b385cac03833f52ea\";}s:27:\"wp-admin/network/update.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"ba45a05ecc211e8cab75b4d529ff75f7\";}s:28:\"wp-admin/network/upgrade.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"a123393039314ec615e2a706fd64f548\";}s:30:\"wp-admin/network/user-edit.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"318173b6ccb63ed80ba3d08563c3ff14\";}s:29:\"wp-admin/network/user-new.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"96a0ac3684162747bcb8150467241ca2\";}s:26:\"wp-admin/network/users.php\";a:2:{s:1:\"d\";i:1429514848;s:1:\"h\";s:32:\"5a765cddcc0698c1c79d067b1d9d6732\";}s:20:\"wp-admin/network.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"26ff9c3919857b65f02c596a8505b10a\";}s:31:\"wp-admin/options-discussion.php\";a:2:{s:1:\"d\";i:1429049366;s:1:\"h\";s:32:\"637b93ae37dcc1d6ba58f8e42e7452bf\";}s:28:\"wp-admin/options-general.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f8d0d4d971959bb780039e37d69404e1\";}s:25:\"wp-admin/options-head.php\";a:2:{s:1:\"d\";i:1362172450;s:1:\"h\";s:32:\"bad695605e6db04e400a546f667eb70b\";}s:26:\"wp-admin/options-media.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"bf8e37c333ae3154ff77263bf0a17fd8\";}s:30:\"wp-admin/options-permalink.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4b6a1fc27255843534fc5a02d252a624\";}s:28:\"wp-admin/options-reading.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"56e7717583d57de60217fe2d2ec84a61\";}s:28:\"wp-admin/options-writing.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"5f94fd48e5cd4a3164026b8e18fa898c\";}s:20:\"wp-admin/options.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2ceb6fed736ecaede0135d13f254b61a\";}s:26:\"wp-admin/plugin-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"0d7eedb060331aa2ca7d40b25b56c150\";}s:27:\"wp-admin/plugin-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"c4e4f72fe3511fc7d9a9ccaa7d352c0a\";}s:20:\"wp-admin/plugins.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"adb4146ada0e0cbe08da010f9b189cb0\";}s:21:\"wp-admin/post-new.php\";a:2:{s:1:\"d\";i:1420882162;s:1:\"h\";s:32:\"5ae636173e213f7e459d9cd6d64465e9\";}s:17:\"wp-admin/post.php\";a:2:{s:1:\"d\";i:1425609084;s:1:\"h\";s:32:\"131721684c0879e83aaccf102245a2e1\";}s:23:\"wp-admin/press-this.php\";a:2:{s:1:\"d\";i:1424843426;s:1:\"h\";s:32:\"e53a55cd2ffb9f76c59963d54bc0124a\";}s:20:\"wp-admin/profile.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"9184e53f96bade3e7ae7cda9eddf7a26\";}s:21:\"wp-admin/revision.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"f38ac6fdd266bcc623cd3dc27c9b428b\";}s:25:\"wp-admin/setup-config.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"b7b732e94ba1185b442b5efd8cfad02f\";}s:25:\"wp-admin/theme-editor.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"4e47516edb5d0f2ff241ee455fab19fc\";}s:26:\"wp-admin/theme-install.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"6a1f48e9aef5c17759f3b38807e4cb1f\";}s:19:\"wp-admin/themes.php\";a:2:{s:1:\"d\";i:1429525646;s:1:\"h\";s:32:\"4c673870742ef8131cf78de2a5d7a56e\";}s:18:\"wp-admin/tools.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"7b8738972ea367f2d5d45f5c2b185513\";}s:24:\"wp-admin/update-core.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"75c977ae43d7215f48fa3b44c080ab81\";}s:19:\"wp-admin/update.php\";a:2:{s:1:\"d\";i:1428042748;s:1:\"h\";s:32:\"86b7431cd724423305464f6c19608838\";}s:30:\"wp-admin/upgrade-functions.php\";a:2:{s:1:\"d\";i:1387925832;s:1:\"h\";s:32:\"5ef6dfd8ec7550e071581d5c14658efc\";}s:20:\"wp-admin/upgrade.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"2d2636f9b8db893c678c6ba5367312de\";}s:19:\"wp-admin/upload.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3227b777a925fc4d90c7bc0408eb0582\";}s:23:\"wp-admin/user/about.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"99ec00da8d914b4efd2098a3e44ebe2d\";}s:23:\"wp-admin/user/admin.php\";a:2:{s:1:\"d\";i:1397275276;s:1:\"h\";s:32:\"8de88527f924b455fb6d14bb7805f25a\";}s:25:\"wp-admin/user/credits.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"d920b4fb1be2c2c780081d5b4b7de55a\";}s:26:\"wp-admin/user/freedoms.php\";a:2:{s:1:\"d\";i:1380082692;s:1:\"h\";s:32:\"1ba6cbb9e2a9d3deb348997492ed692e\";}s:23:\"wp-admin/user/index.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"c8fd98f7fdd52d78bdadf74e620789fa\";}s:22:\"wp-admin/user/menu.php\";a:2:{s:1:\"d\";i:1399377496;s:1:\"h\";s:32:\"a529e3d3c2bb86671fb9cc1145cf70ee\";}s:25:\"wp-admin/user/profile.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"b9fa17a9811195800079dda4b1262d03\";}s:27:\"wp-admin/user/user-edit.php\";a:2:{s:1:\"d\";i:1415133142;s:1:\"h\";s:32:\"2a7a75a363b0f88f0b6d094a91ef65ea\";}s:22:\"wp-admin/user-edit.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"d666cfa73d8a691a77a5559afef67889\";}s:21:\"wp-admin/user-new.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"3a7fc7ec50ea3e2eabb6f2bef44d5eef\";}s:18:\"wp-admin/users.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"349265703c279fb2dd960cc53f35a581\";}s:20:\"wp-admin/widgets.php\";a:2:{s:1:\"d\";i:1428888572;s:1:\"h\";s:32:\"86cb82a0d791c45f2f1a680f8f0a1f3a\";}}","no");
INSERT INTO `arc1542_options` VALUES("200","itsec_salts","1434398983","yes");
INSERT INTO `arc1542_options` VALUES("211","itsec_jquery_version","","yes");
INSERT INTO `arc1542_options` VALUES("212","_transient_is_multi_author","0","yes");
INSERT INTO `arc1542_options` VALUES("213","_transient_twentyfifteen_categories","1","yes");
INSERT INTO `arc1542_options` VALUES("214","_site_transient_timeout_theme_roots","1434401096","yes");
INSERT INTO `arc1542_options` VALUES("215","_site_transient_theme_roots","a:1:{s:10:\"ut-thehill\";s:7:\"/themes\";}","yes");
INSERT INTO `arc1542_options` VALUES("216","theme_mods_twentyfifteen","a:1:{s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1434399272;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}","yes");
INSERT INTO `arc1542_options` VALUES("217","current_theme","The Hill","yes");
INSERT INTO `arc1542_options` VALUES("218","theme_mods_ut-thehill","a:1:{i:0;b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("219","theme_switched","","yes");
INSERT INTO `arc1542_options` VALUES("220","_site_transient_update_plugins","O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1434399476;s:7:\"checked\";a:3:{s:19:\"akismet/akismet.php\";s:5:\"3.1.2\";s:41:\"better-wp-security/better-wp-security.php\";s:6:\"4.6.13\";s:23:\"wordfence/wordfence.php\";s:5:\"6.0.6\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:3:{s:19:\"akismet/akismet.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:2:\"15\";s:4:\"slug\";s:7:\"akismet\";s:6:\"plugin\";s:19:\"akismet/akismet.php\";s:11:\"new_version\";s:5:\"3.1.2\";s:3:\"url\";s:38:\"https://wordpress.org/plugins/akismet/\";s:7:\"package\";s:56:\"https://downloads.wordpress.org/plugin/akismet.3.1.2.zip\";}s:41:\"better-wp-security/better-wp-security.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"18308\";s:4:\"slug\";s:18:\"better-wp-security\";s:6:\"plugin\";s:41:\"better-wp-security/better-wp-security.php\";s:11:\"new_version\";s:6:\"4.6.13\";s:3:\"url\";s:49:\"https://wordpress.org/plugins/better-wp-security/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/better-wp-security.4.6.13.zip\";}s:23:\"wordfence/wordfence.php\";O:8:\"stdClass\":6:{s:2:\"id\";s:5:\"25305\";s:4:\"slug\";s:9:\"wordfence\";s:6:\"plugin\";s:23:\"wordfence/wordfence.php\";s:11:\"new_version\";s:5:\"6.0.6\";s:3:\"url\";s:40:\"https://wordpress.org/plugins/wordfence/\";s:7:\"package\";s:58:\"https://downloads.wordpress.org/plugin/wordfence.6.0.6.zip\";}}}","yes");
INSERT INTO `arc1542_options` VALUES("221","wordfence_version","6.0.6","yes");
INSERT INTO `arc1542_options` VALUES("222","wordfenceActivated","1","yes");
INSERT INTO `arc1542_options` VALUES("223","wf_plugin_act_error","","yes");
INSERT INTO `arc1542_options` VALUES("224","_site_transient_timeout_itsec_upload_dir","1437112428","yes");
INSERT INTO `arc1542_options` VALUES("225","_site_transient_itsec_upload_dir","a:6:{s:4:\"path\";s:52:\"/Users/ahayter/Sites/test/arc-assets/uploads/2015/07\";s:3:\"url\";s:42:\"http://test.dev/arc-assets/uploads/2015/07\";s:6:\"subdir\";s:8:\"/2015/07\";s:7:\"basedir\";s:44:\"/Users/ahayter/Sites/test/arc-assets/uploads\";s:7:\"baseurl\";s:34:\"http://test.dev/arc-assets/uploads\";s:5:\"error\";b:0;}","yes");
INSERT INTO `arc1542_options` VALUES("226","_site_transient_timeout_itsec_random_version","1437112428","yes");
INSERT INTO `arc1542_options` VALUES("227","_site_transient_itsec_random_version","204","yes");
INSERT INTO `arc1542_options` VALUES("228","_transient_doing_cron","1437026028.4515581130981445312500","yes");
INSERT INTO `arc1542_options` VALUES("229","_site_transient_timeout_itsec_notification_running","1437029628","yes");
INSERT INTO `arc1542_options` VALUES("230","_site_transient_itsec_notification_running","1","yes");


DROP TABLE IF EXISTS `arc1542_postmeta`;

CREATE TABLE `arc1542_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_postmeta` VALUES("1","2","_wp_page_template","default");


DROP TABLE IF EXISTS `arc1542_posts`;

CREATE TABLE `arc1542_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_posts` VALUES("1","2","2015-06-15 19:42:40","2015-06-15 19:42:40","Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!","Hello world!","","publish","open","open","","hello-world","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?p=1","0","post","","1");
INSERT INTO `arc1542_posts` VALUES("2","2","2015-06-15 19:42:40","2015-06-15 19:42:40","This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href=\"http://test.dev/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!","Sample Page","","publish","open","open","","sample-page","","","2015-06-15 19:42:40","2015-06-15 19:42:40","","0","http://test.dev/?page_id=2","0","page","","0");
INSERT INTO `arc1542_posts` VALUES("3","2","2015-06-15 19:42:53","0000-00-00 00:00:00","","Auto Draft","","auto-draft","open","open","","","","","2015-06-15 19:42:53","0000-00-00 00:00:00","","0","http://test.dev/?p=3","0","post","","0");


DROP TABLE IF EXISTS `arc1542_term_relationships`;

CREATE TABLE `arc1542_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_relationships` VALUES("1","1","0");


DROP TABLE IF EXISTS `arc1542_term_taxonomy`;

CREATE TABLE `arc1542_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_term_taxonomy` VALUES("1","1","category","","0","1");


DROP TABLE IF EXISTS `arc1542_terms`;

CREATE TABLE `arc1542_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_terms` VALUES("1","Uncategorized","uncategorized","0");


DROP TABLE IF EXISTS `arc1542_usermeta`;

CREATE TABLE `arc1542_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_usermeta` VALUES("1","2","nickname","Andre Hayter");
INSERT INTO `arc1542_usermeta` VALUES("2","2","first_name","");
INSERT INTO `arc1542_usermeta` VALUES("3","2","last_name","");
INSERT INTO `arc1542_usermeta` VALUES("4","2","description","");
INSERT INTO `arc1542_usermeta` VALUES("5","2","rich_editing","true");
INSERT INTO `arc1542_usermeta` VALUES("6","2","comment_shortcuts","false");
INSERT INTO `arc1542_usermeta` VALUES("7","2","admin_color","fresh");
INSERT INTO `arc1542_usermeta` VALUES("8","2","use_ssl","0");
INSERT INTO `arc1542_usermeta` VALUES("9","2","show_admin_bar_front","true");
INSERT INTO `arc1542_usermeta` VALUES("10","2","arc1542_capabilities","a:1:{s:13:\"administrator\";b:1;}");
INSERT INTO `arc1542_usermeta` VALUES("11","2","arc1542_user_level","10");
INSERT INTO `arc1542_usermeta` VALUES("12","2","dismissed_wp_pointers","wp360_locks,wp390_widgets");
INSERT INTO `arc1542_usermeta` VALUES("13","2","show_welcome_panel","1");
INSERT INTO `arc1542_usermeta` VALUES("14","2","session_tokens","a:3:{s:64:\"bd8e38e3c8522410dcd69cc7b38cecb1f3cf26ca1d7a9796160a3021c4dd80d1\";a:4:{s:10:\"expiration\";i:1434570172;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36\";s:5:\"login\";i:1434397372;}s:64:\"e0f014d307bed8d8ceeb8e7231424b16761b69ca2acca0b96e4d13bd700aec65\";a:4:{s:10:\"expiration\";i:1434570969;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36\";s:5:\"login\";i:1434398169;}s:64:\"238ae15f204b92defffb03ca2911e581dc7b19bff35dbe635d421e477ffd018a\";a:4:{s:10:\"expiration\";i:1434571786;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:121:\"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.124 Safari/537.36\";s:5:\"login\";i:1434398986;}}");
INSERT INTO `arc1542_usermeta` VALUES("15","2","arc1542_dashboard_quick_press_last_post_id","3");


DROP TABLE IF EXISTS `arc1542_users`;

CREATE TABLE `arc1542_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `arc1542_users` VALUES("2","ahayter","$P$Bv7PyMKGXpEmyukWPx7wtK5UuTwoO10","andre-hayter","andre.hayter+arc@gmail.com","","2015-06-15 19:42:40","","0","Andre Hayter");


DROP TABLE IF EXISTS `arc1542_wfBadLeechers`;

CREATE TABLE `arc1542_wfBadLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfBlockedIPLog`;

CREATE TABLE `arc1542_wfBlockedIPLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `countryCode` varchar(2) NOT NULL,
  `blockCount` int(10) unsigned NOT NULL DEFAULT '0',
  `unixday` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`,`unixday`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocks`;

CREATE TABLE `arc1542_wfBlocks` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  `wfsn` tinyint(3) unsigned DEFAULT '0',
  `permanent` tinyint(3) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`),
  KEY `k1` (`wfsn`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfBlocksAdv`;

CREATE TABLE `arc1542_wfBlocksAdv` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `blockType` char(2) NOT NULL,
  `blockString` varchar(255) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `reason` varchar(255) NOT NULL,
  `totalBlocked` int(10) unsigned DEFAULT '0',
  `lastBlocked` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfConfig`;

CREATE TABLE `arc1542_wfConfig` (
  `name` varchar(100) NOT NULL,
  `val` longblob,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfConfig` VALUES("actUpdateInterval","");
INSERT INTO `arc1542_wfConfig` VALUES("addCacheComment","0");
INSERT INTO `arc1542_wfConfig` VALUES("advancedCommentScanning","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertEmails","andre.hayter+arc@gmail.com");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_adminLogin","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_block","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_critical","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_loginLockout","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_lostPasswdForm","1");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_nonAdminLogin","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_throttle","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_update","0");
INSERT INTO `arc1542_wfConfig` VALUES("alertOn_warnings","1");
INSERT INTO `arc1542_wfConfig` VALUES("alert_maxHourly","0");
INSERT INTO `arc1542_wfConfig` VALUES("allowHTTPSCaching","0");
INSERT INTO `arc1542_wfConfig` VALUES("apiKey","db0301f529f254dbf9220171caf7ddd101ee22964ad7cd38e529908964a2239b77621a5354eba6cd87e15b40cce0d2013dc4d1933782fba373cf1551df12afda");
INSERT INTO `arc1542_wfConfig` VALUES("autoBlockScanners","1");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("autoUpdateChoice","1");
INSERT INTO `arc1542_wfConfig` VALUES("bannedURLs","");
INSERT INTO `arc1542_wfConfig` VALUES("blockedTime","300");
INSERT INTO `arc1542_wfConfig` VALUES("blockFakeBots","0");
INSERT INTO `arc1542_wfConfig` VALUES("cacheType","falcon");
INSERT INTO `arc1542_wfConfig` VALUES("cbl_restOfSiteBlocked","1");
INSERT INTO `arc1542_wfConfig` VALUES("checkSpamIP","0");
INSERT INTO `arc1542_wfConfig` VALUES("currentCronKey","");
INSERT INTO `arc1542_wfConfig` VALUES("debugOn","0");
INSERT INTO `arc1542_wfConfig` VALUES("deleteTablesOnDeact","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCodeExecutionUploads","0");
INSERT INTO `arc1542_wfConfig` VALUES("disableCookies","0");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_dashboard_widget_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_enabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_excluded_directories","wp-content/cache,wp-content/wfcache,wp-content/plugins/wordfence/tmp");
INSERT INTO `arc1542_wfConfig` VALUES("email_summary_interval","biweekly");
INSERT INTO `arc1542_wfConfig` VALUES("encKey","5d42a085342fd5d7");
INSERT INTO `arc1542_wfConfig` VALUES("firewallEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("howGetIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("lastScanCompleted","There was an error connecting to the the Wordfence scanning servers: Failed to connect to noc1.wordfence.com port 443: Connection refused");
INSERT INTO `arc1542_wfConfig` VALUES("liveTrafficEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreIPs","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignorePublishers","1");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUA","");
INSERT INTO `arc1542_wfConfig` VALUES("liveTraf_ignoreUsers","");
INSERT INTO `arc1542_wfConfig` VALUES("loginSecurityEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_blockAdminReg","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_countFailMins","240");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_disableAuthorScan","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockInvalidUsers","0");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_lockoutMins","240");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maskLoginErrors","1");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxFailures","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_maxForgotPasswd","20");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_strongPasswds","pubs");
INSERT INTO `arc1542_wfConfig` VALUES("loginSec_userBlacklist","");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Crawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("max404Humans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxExecutionTime","");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxGlobalRequests_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxMem","256");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsCrawlers_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxRequestsHumans_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits","DISABLED");
INSERT INTO `arc1542_wfConfig` VALUES("maxScanHits_action","throttle");
INSERT INTO `arc1542_wfConfig` VALUES("neverBlockBG","neverBlockVerified");
INSERT INTO `arc1542_wfConfig` VALUES("other_blockBadPOST","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_hideWPVersion","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_noAnonMemberComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_pwStrengthOnUpdate","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanComments","1");
INSERT INTO `arc1542_wfConfig` VALUES("other_scanOutside","0");
INSERT INTO `arc1542_wfConfig` VALUES("other_WFNet","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_comments","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_core","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_database","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_diskSpace","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_dns","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_fileContents","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_heartbleed","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_highSense","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_malware","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_oldVersions","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_options","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_passwds","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_plugins","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_posts","1");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_public","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_scanImages","0");
INSERT INTO `arc1542_wfConfig` VALUES("scansEnabled_themes","0");
INSERT INTO `arc1542_wfConfig` VALUES("scan_exclude","");
INSERT INTO `arc1542_wfConfig` VALUES("scheduledScansEnabled","1");
INSERT INTO `arc1542_wfConfig` VALUES("securityLevel","2");
INSERT INTO `arc1542_wfConfig` VALUES("spamvertizeCheck","0");
INSERT INTO `arc1542_wfConfig` VALUES("ssl_verify","1");
INSERT INTO `arc1542_wfConfig` VALUES("startScansRemotely","0");
INSERT INTO `arc1542_wfConfig` VALUES("totalScansRun","1");
INSERT INTO `arc1542_wfConfig` VALUES("tourClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("vulnRegex","/(?:wordfence_test_vuln_match|\\/timthumb\\.php|\\/thumb\\.php|\\/thumbs\\.php|\\/thumbnail\\.php|\\/thumbnails\\.php|\\/thumnails\\.php|\\/cropper\\.php|\\/picsize\\.php|\\/resizer\\.php|connectors\\/uploadtest\\.html|connectors\\/test\\.html|mingleforumaction|uploadify\\.php|allwebmenus-wordpress-menu-plugin|wp-cycle-playlist|count-per-day|wp-autoyoutube|pay-with-tweet|comment-rating\\/ck-processkarma\\.php)/i");
INSERT INTO `arc1542_wfConfig` VALUES("welcomeClosed","1");
INSERT INTO `arc1542_wfConfig` VALUES("wfKillRequested","0");
INSERT INTO `arc1542_wfConfig` VALUES("wfPeakMemory","41191760");
INSERT INTO `arc1542_wfConfig` VALUES("wfsd_engine","");
INSERT INTO `arc1542_wfConfig` VALUES("wfStatusStartMsgs","a:7:{i:0;s:0:\"\";i:1;s:0:\"\";i:2;s:0:\"\";i:3;s:0:\"\";i:4;s:0:\"\";i:5;s:57:\"Scanning file contents for infections and vulnerabilities\";i:6;s:54:\"Scanning files for URLs in Google\'s Safe Browsing List\";}");
INSERT INTO `arc1542_wfConfig` VALUES("wf_scanRunning","");
INSERT INTO `arc1542_wfConfig` VALUES("wf_summaryItems","a:15:{s:10:\"totalUsers\";i:1;s:10:\"totalPages\";s:1:\"1\";s:10:\"totalPosts\";s:1:\"1\";s:13:\"totalComments\";s:1:\"1\";s:15:\"totalCategories\";s:1:\"1\";s:11:\"totalTables\";i:34;s:9:\"totalRows\";i:300;s:12:\"totalPlugins\";i:3;s:10:\"lastUpdate\";i:1434399557;s:11:\"totalThemes\";i:1;s:9:\"totalData\";s:8:\"15.56 MB\";s:10:\"totalFiles\";i:1007;s:9:\"totalDirs\";i:88;s:10:\"linesOfPHP\";i:250981;s:10:\"linesOfJCH\";i:125698;}");
INSERT INTO `arc1542_wfConfig` VALUES("whitelisted","");


DROP TABLE IF EXISTS `arc1542_wfCrawlers`;

CREATE TABLE `arc1542_wfCrawlers` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `patternSig` binary(16) NOT NULL,
  `status` char(8) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  `PTR` varchar(255) DEFAULT '',
  PRIMARY KEY (`IP`,`patternSig`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfFileMods`;

CREATE TABLE `arc1542_wfFileMods` (
  `filenameMD5` binary(16) NOT NULL,
  `filename` varchar(1000) NOT NULL,
  `knownFile` tinyint(3) unsigned NOT NULL,
  `oldMD5` binary(16) NOT NULL,
  `newMD5` binary(16) NOT NULL,
  PRIMARY KEY (`filenameMD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfFileMods` VALUES("\00��#�9���Z4�j$","wp-admin/network/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1�s�̶>��Ѕc��");
INSERT INTO `arc1542_wfFileMods` VALUES("\05g���꫔c�0�\"D","wp-includes/css/media-views-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2q_�9�5VLT");
INSERT INTO `arc1542_wfFileMods` VALUES("\0C_
��jD��@k","wp-admin/network/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�V1�r/���.���J");
INSERT INTO `arc1542_wfFileMods` VALUES("\0`Y�ϭrG����","wp-includes/SimplePie/Restriction.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*qhd�s�;�y");
INSERT INTO `arc1542_wfFileMods` VALUES("\0���;f��Q�=*Ǖ�","wp-includes/js/wp-emoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\'��ٽ�, �[�");
INSERT INTO `arc1542_wfFileMods` VALUES("\0�|9��u�e���@��","wp-admin/includes/image.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�3q��.����О���");
INSERT INTO `arc1542_wfFileMods` VALUES("NQ�\"*hz�r�w|�","wp-admin/images/media-button-other.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ƴk�|��,O�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�T�h���zP��r�","wp-admin/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˂�ב�_/h�
:");
INSERT INTO `arc1542_wfFileMods` VALUES("t]�ٟu��u���j�","wp-admin/images/menu-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q���L�,_�;1/�E�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~�w`�5;F㮮","wp-includes/js/jquery/ui/effect-size.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":I�k�C�*���]�");
INSERT INTO `arc1542_wfFileMods` VALUES("�=��q�ljA+","wp-admin/user/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*zu�c���m	J��e�");
INSERT INTO `arc1542_wfFileMods` VALUES("<)8T*.�SuS�ĺ�","wp-includes/SimplePie/Cache/MySQL.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B�C�H�xV�");
INSERT INTO `arc1542_wfFileMods` VALUES("HC���!���\"(�","wp-includes/js/tinymce/plugins/compat3x/css/dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͕�\0A��It�dH");
INSERT INTO `arc1542_wfFileMods` VALUES("u��s��y6\'v,��=","wp-includes/js/tinymce/plugins/wordpress/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�Bf��n�`��");
INSERT INTO `arc1542_wfFileMods` VALUES("����7�&��Ȁ","wp-includes/js/tinymce/skins/lightgray/content.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","oS�pZ5��Ǜ4�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���љ����\0H<_","wp-admin/includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J물�@��Y�OS�p");
INSERT INTO `arc1542_wfFileMods` VALUES("i��PÙ��ld\0��","wp-includes/css/jquery-ui-dialog.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
��d����\\6�");
INSERT INTO `arc1542_wfFileMods` VALUES("!���@|�4��n���","wp-includes/class-http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Qc.F��B�6�l��");
INSERT INTO `arc1542_wfFileMods` VALUES("\'ڞ\0;��?�+VҪ�","wp-admin/network/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�Y�&��;^���");
INSERT INTO `arc1542_wfFileMods` VALUES("E�&��VN���\"N","wp-admin/css/ie.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F�Y\0��g�H�0��");
INSERT INTO `arc1542_wfFileMods` VALUES("�P\0\'�0l���v�#J<","wp-includes/js/jquery/ui/effect-fold.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6^�����<��DEl");
INSERT INTO `arc1542_wfFileMods` VALUES("Ȅ���xy�����","wp-includes/js/tinymce/skins/wordpress/images/embedded.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�N��y~�n\"");
INSERT INTO `arc1542_wfFileMods` VALUES("ϴ 3P`#8^��Z","wp-admin/css/colors/coffee/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2���#6��`τ}L");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��N߬jj)��\0��N","wp-admin/images/menu-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jG�����{�>�^;$��");
INSERT INTO `arc1542_wfFileMods` VALUES("tZQ��Yz0����跫","wp-admin/images/wordpress-logo.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ư�y��o�8��8S�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k�5S�H���Ы","wp-includes/SimplePie/Author.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�q�_�A�%�Nw�1");
INSERT INTO `arc1542_wfFileMods` VALUES("���e�bW�A0�d","wp-admin/images/comment-grey-bubble.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�*\'����t���F");
INSERT INTO `arc1542_wfFileMods` VALUES("Q� ��(;ؠ|~R8�b","wp-admin/includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_���zd��BO�V");
INSERT INTO `arc1542_wfFileMods` VALUES("���%bQ�bM<�x","wp-includes/js/imgareaselect/border-anim-h.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��,�ntZ^6�{Lp�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ѧ�_�4a!�F��","wp-admin/css/ie.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","IBT�\'�n�i�)P�");
INSERT INTO `arc1542_wfFileMods` VALUES("��i)33ܥ��s�*","wp-admin/includes/class-wp-ms-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��&�+�zĘ�}�İ#");
INSERT INTO `arc1542_wfFileMods` VALUES("���#����	>�7","wp-includes/js/tinymce/skins/wordpress/images/pagebreak.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I��m���LWyݓH");
INSERT INTO `arc1542_wfFileMods` VALUES("k����b��gS�","wp-includes/js/tinymce/plugins/wplink/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���`�{WﺾUi\'w");
INSERT INTO `arc1542_wfFileMods` VALUES("����g�~�w�hh","wp-admin/css/themes-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\0�wE�i�O�!��}");
INSERT INTO `arc1542_wfFileMods` VALUES("	QW���~-�\0d�","wp-includes/class-phpass.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�FDP�\0�f�G�Ƨ");
INSERT INTO `arc1542_wfFileMods` VALUES("	?������q�uM","wp-includes/js/mediaelement/mediaelementplayer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�ؗx�����[�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("	,��/Օ�!�gy�d","wp-includes/js/media-editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��$�m+�:xܔ��D");
INSERT INTO `arc1542_wfFileMods` VALUES("	P=N>��b\"j:~[Q{�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[ߢ�9��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("	X�t\\4vNI5��j��","wp-admin/async-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<Br?d�T\'��Z�0X");
INSERT INTO `arc1542_wfFileMods` VALUES("	�9��fވU�f����","wp-includes/js/tinymce/tinymce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/ZV�9��N.{�Ћ");
INSERT INTO `arc1542_wfFileMods` VALUES("	����09��-b��ͩW","wp-admin/network/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Zv\\����ǝ{�g2");
INSERT INTO `arc1542_wfFileMods` VALUES("
f���Y��4&�L�","wp-admin/images/se.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȔB�`��.}\'7:");
INSERT INTO `arc1542_wfFileMods` VALUES("
���b-�V�:��|m��","wp-admin/edit-link-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7����d�G�G�\0�G%");
INSERT INTO `arc1542_wfFileMods` VALUES("
��NNM��ۑ4;�p�4","wp-includes/js/customize-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","OK�.�q;�t��N�
");
INSERT INTO `arc1542_wfFileMods` VALUES("
��B��p̭","wp-admin/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH���wY���");
INSERT INTO `arc1542_wfFileMods` VALUES("\"w%�_��K\\��u�","wp-admin/images/wpspin_light.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("&c�YD�#�P{+��","wp-includes/js/jquery/ui/effect-blind.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<O�mA�_;OL");
INSERT INTO `arc1542_wfFileMods` VALUES("���,H(b�_F�O","wp-admin/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�G𿤂X�ΗN��");
INSERT INTO `arc1542_wfFileMods` VALUES("��HVե�d��p�Vp","wp-includes/images/media/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���4���\0T��̇?�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c\"ml� �Ǟ>o","wp-admin/images/wordpress-logo.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N�%�d���g���p");
INSERT INTO `arc1542_wfFileMods` VALUES("{�M��i�i2n��6�","wp-includes/js/jquery/ui/effect-highlight.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����*��øN���!");
INSERT INTO `arc1542_wfFileMods` VALUES("xݍ�^������<;","wp-admin/my-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W_H�3��8	����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ҧxOz���z���h","wp-includes/class-wp-customize-panel.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����v�x~;)�]��l�");
INSERT INTO `arc1542_wfFileMods` VALUES("��:�:���HH�:d","wp-admin/css/edit.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܡ�ɵI��[\'�\'��B");
INSERT INTO `arc1542_wfFileMods` VALUES("�%����%�yS�`�","wp-includes/js/crop/cropper.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����H.s�o����");
INSERT INTO `arc1542_wfFileMods` VALUES("Ѫ1s1=��`(�y","wp-admin/options-head.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֕`^m�N@
Tof~�");
INSERT INTO `arc1542_wfFileMods` VALUES("X��H奥(�:�Z��","wp-admin/admin-ajax.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����:��em�-XL$");
INSERT INTO `arc1542_wfFileMods` VALUES("go�s�V�;����
$","wp-includes/js/tinymce/plugins/compat3x/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=�\\�-����e���U");
INSERT INTO `arc1542_wfFileMods` VALUES("� ��C�Y���","wp-includes/pomo/entry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�L�ǼƢ�v�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�M�8� ٵ��|","wp-includes/images/crystal/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S������I0An�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"J\04��\'i�","wp-admin/js/password-strength-meter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�(F�Vp��#*�{�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�&�nb��i�ٷ�","wp-includes/js/mediaelement/silverlightmediaelement.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�:=C\".K�|�n\0t�");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����AV*籿","wp-includes/js/jquery/ui/slider.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}	1l4�&��QW��L�");
INSERT INTO `arc1542_wfFileMods` VALUES("\0��]�a�v���CY","wp-includes/class-wp-walker.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W#�\'����m");
INSERT INTO `arc1542_wfFileMods` VALUES("���NVԱ��z�Z","wp-includes/js/jquery/ui/effect-shake.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'JgV�̯\0�@p�");
INSERT INTO `arc1542_wfFileMods` VALUES(")��_���J�����","wp-includes/js/media-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".xd��#c�n�3{��");
INSERT INTO `arc1542_wfFileMods` VALUES("`�&��锥~K3/d","wp-admin/css/login.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f�Ad�a��FðB5");
INSERT INTO `arc1542_wfFileMods` VALUES("�~��L��*�,�<:�","wp-admin/includes/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�at{V��Qƅ�*քU");
INSERT INTO `arc1542_wfFileMods` VALUES("�Sx��4�@o�w�N","wp-admin/js/widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L,3�%�q���	���Ӑ");
INSERT INTO `arc1542_wfFileMods` VALUES("���:m��[ݢ�:#","wp-includes/l10n.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","j��!K����s87[");
INSERT INTO `arc1542_wfFileMods` VALUES("�I��\\j���x���g","wp-admin/images/date-button-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")R�,$k���)6C��c");
INSERT INTO `arc1542_wfFileMods` VALUES("���j7r[�,���Z��","wp-admin/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-&6��ۉ<g�k�6s�");
INSERT INTO `arc1542_wfFileMods` VALUES("D�8hFޛBViR�","wp-admin/css/colors/blue/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�
��`trk");
INSERT INTO `arc1542_wfFileMods` VALUES("j׻���q.�*;��2","wp-admin/css/colors/sunrise/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y�N�^�&R\"�6�a�");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�W�3���᥾V","wp-admin/css/color-picker-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z4w��l�e�$��");
INSERT INTO `arc1542_wfFileMods` VALUES(":�X��2�M���~��","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G6	=���<�%�#");
INSERT INTO `arc1542_wfFileMods` VALUES("L����8���\\�ݼ+","wp-admin/images/imgedit-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",��\'��6U�������t");
INSERT INTO `arc1542_wfFileMods` VALUES("p۞�2N<:Z�7�r�","wp-includes/js/tw-sack.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���������9>���");
INSERT INTO `arc1542_wfFileMods` VALUES("u�)8FG9�C�(���","wp-includes/js/wp-ajax-response.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bC;�s�{�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Clo�������","wp-admin/nav-menus.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x������͉���");
INSERT INTO `arc1542_wfFileMods` VALUES("��-��i>bs��1�","wp-includes/js/jquery/ui/resizable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�*��W�i�X㝶տ");
INSERT INTO `arc1542_wfFileMods` VALUES("��4r�%����j���","wp-includes/SimplePie/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���kU�6�
�+�)%�");
INSERT INTO `arc1542_wfFileMods` VALUES("��KS+�e׎A�@��","wp-admin/css/colors/light/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �V{��)\\_~��q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0��5��mk��","wp-includes/js/wp-a11y.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����z�L�u�Jg��k");
INSERT INTO `arc1542_wfFileMods` VALUES("΢�S˪�
��B�V\"","wp-includes/fonts/dashicons.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�)x䌉��[�w�");
INSERT INTO `arc1542_wfFileMods` VALUES("��ܡ9�u_\\
�9�\'","wp-admin/css/color-picker.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����}��U��F��\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("�KU�g0MU�/��ʇ","wp-admin/admin-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ga���c�3�aq�");
INSERT INTO `arc1542_wfFileMods` VALUES("4;V��\'�/����f�","wp-includes/js/jquery/ui/effect-scale.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}0e,)����+m�T");
INSERT INTO `arc1542_wfFileMods` VALUES("���C
���U���","wp-admin/js/custom-header.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2�\0X���`o���uf�");
INSERT INTO `arc1542_wfFileMods` VALUES("��0l��j�0+%�","wp-includes/SimplePie/Source.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������S{�*���");
INSERT INTO `arc1542_wfFileMods` VALUES("�)����t�,�Jڼ","wp-admin/options-permalink.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Kj�rU�54�Z�R�$");
INSERT INTO `arc1542_wfFileMods` VALUES("Ր(������@��","wp-admin/js/press-this.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h.[t�y�	��1��J");
INSERT INTO `arc1542_wfFileMods` VALUES("Wl��y:�\0Vn`�d\0�","wp-includes/js/tinymce/plugins/wpview/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f둽�塴�;����");
INSERT INTO `arc1542_wfFileMods` VALUES("�,�4#��(�#","wp-signup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���*�I
�gF�t");
INSERT INTO `arc1542_wfFileMods` VALUES("�:8�Ia��øl�m","wp-admin/includes/class-ftp-pure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�\\.B���������");
INSERT INTO `arc1542_wfFileMods` VALUES("����KqM���{���","wp-admin/css/dashboard.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����p�0��ۃ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�TB��O>�v2��}Ea","wp-includes/SimplePie/Locator.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s����;�uvf^��");
INSERT INTO `arc1542_wfFileMods` VALUES("F��e���}�(��","wp-includes/js/jquery/ui/dialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$aV�{Ԅ��,�0");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�/ᡇ_�����","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4 �\\B�i�M銋");
INSERT INTO `arc1542_wfFileMods` VALUES("�&UX�L4{����","wp-includes/js/utils.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�9����!�;�	��x�");
INSERT INTO `arc1542_wfFileMods` VALUES("�e���j!^��	��","wp-includes/js/mediaelement/bigplay.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","qd6�=�Ҟk7�b�Rgj");
INSERT INTO `arc1542_wfFileMods` VALUES("������)qtsCI9","wp-includes/functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�Q��oNw�}��$7");
INSERT INTO `arc1542_wfFileMods` VALUES("�y��8R#O�y��","wp-admin/css/nav-menus-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��@�2��Ҏb4�V_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�UE�s(���#E�p","wp-includes/images/smilies/icon_mrgreen.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J����Rw��w��");
INSERT INTO `arc1542_wfFileMods` VALUES("A�Z�哖̅L��(","wp-includes/js/mediaelement/skipback.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�m�0�E���k��o�HF");
INSERT INTO `arc1542_wfFileMods` VALUES("�y���!�\0pZ�[A","wp-includes/js/mediaelement/mediaelement-and-player.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5:���\0 vu�k�");
INSERT INTO `arc1542_wfFileMods` VALUES("ֻE
�<�B�[�,","wp-includes/class-wp-ajax-response.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r6`0}�dmĂQ���\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�m��n9�F�6�","wp-admin/css/admin-menu-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�0Wi�Qκ~�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�M��^�ûoz�","wp-admin/images/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-[��t�P���d�");
INSERT INTO `arc1542_wfFileMods` VALUES("4%�IH�O��ʰ�L","wp-includes/css/media-views.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w�0**�b6��Џ�");
INSERT INTO `arc1542_wfFileMods` VALUES("C�/�;)��ّ�o","wp-admin/js/comment.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���I���4�D�O#]");
INSERT INTO `arc1542_wfFileMods` VALUES("T�gslF���ʞ��Ly","wp-admin/js/set-post-thumbnail.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����8�կ!�1z[");
INSERT INTO `arc1542_wfFileMods` VALUES("vs�%�z�����F�","wp-admin/css/ie-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Fܣ��sȶ��?��\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
$z�X�`�1Bw","wp-includes/js/tinymce/plugins/charmap/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a���w��g��\\c�H�");
INSERT INTO `arc1542_wfFileMods` VALUES("��=b�6��hs���t","wp-admin/ms-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�K��$�IZ1�i%�");
INSERT INTO `arc1542_wfFileMods` VALUES("
��O�_��;]/^��","wp-includes/images/down_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��]:u�Wv���\"��");
INSERT INTO `arc1542_wfFileMods` VALUES("G_bc�.,]&���","wp-admin/js/image-edit.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�1���l2���z�^");
INSERT INTO `arc1542_wfFileMods` VALUES("fMx�����	�+9�U�","wp-admin/js/customize-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���B\0��$�A쟠");
INSERT INTO `arc1542_wfFileMods` VALUES("�%��\\��MA�����","wp-admin/images/wordpress-logo-white.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c=Yܵ����s����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"j�ǧ`�����1�","wp-admin/css/press-this-editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�?�V���\"��\'ŝ");
INSERT INTO `arc1542_wfFileMods` VALUES("�=�}C���i��HT","wp-admin/network/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i&�Q\\Ӣ�綨");
INSERT INTO `arc1542_wfFileMods` VALUES("�g��I�!٭���_�","wp-includes/ms-blogs.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",	�-�U{�%��	 �");
INSERT INTO `arc1542_wfFileMods` VALUES("��]/~���q��XŎE","wp-includes/js/jquery/ui/button.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~���B��h�F��Vml");
INSERT INTO `arc1542_wfFileMods` VALUES("|�&;�r�Ls5��","wp-admin/includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\\�����\'3�)ާQ");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ye�.�0s��","wp-admin/includes/class-wp-comments-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A�NGA��R��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'-�p�-���f�","wp-admin/css/l10n-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:8σH57cM��G");
INSERT INTO `arc1542_wfFileMods` VALUES("L��bP�-I׭1f�","wp-includes/theme-compat/header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x������vY����");
INSERT INTO `arc1542_wfFileMods` VALUES("�{��Y�\\�z錿�}c","wp-includes/images/smilies/rolleyes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ���O�2�Ofݣi�");
INSERT INTO `arc1542_wfFileMods` VALUES(" *@ADғ�=pu���E","wp-admin/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":��P�>.����M^�");
INSERT INTO `arc1542_wfFileMods` VALUES(" ��c̫)I�
p,͑��","wp-includes/css/jquery-ui-dialog-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����7���ִ�F3");
INSERT INTO `arc1542_wfFileMods` VALUES(" �p(?Qn����a��Z","wp-includes/js/plupload/plupload.silverlight.xap","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<RGPTmᳪ�o���");
INSERT INTO `arc1542_wfFileMods` VALUES("!o���A��v7��e","wp-admin/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�$B3FOl`�8");
INSERT INTO `arc1542_wfFileMods` VALUES("!1b݅9��*���\\��","wp-admin/admin-footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bKtvoC��Nwjv�A�");
INSERT INTO `arc1542_wfFileMods` VALUES("!_��輵p3p�n��L","wp-includes/images/smilies/icon_eek.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��s���jN��_z�");
INSERT INTO `arc1542_wfFileMods` VALUES("!�R���p�nL�w�m7","wp-includes/js/tinymce/plugins/lists/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4,~I�i%E���[");
INSERT INTO `arc1542_wfFileMods` VALUES("!����Y0-z1�dm>�","wp-admin/js/plugin-install.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zb�
�d�&�o�f�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"(}G��r�	0��V(","wp-admin/ms-options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'�\0�}��:��ㆯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("\"IFn����@�a�}�9","wp-admin/includes/class-wp-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@̔m��`b���TyTH5");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����b9��e�|�_�","wp-includes/feed-atom-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�D1;�)��-�B?6s");
INSERT INTO `arc1542_wfFileMods` VALUES("\"�����u>1�7���","wp-includes/class-pop3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���S��|����/}");
INSERT INTO `arc1542_wfFileMods` VALUES("\"����c���9�&","wp-includes/js/plupload/plupload.full.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�6�G��
�!:D");
INSERT INTO `arc1542_wfFileMods` VALUES("\"��6+K{�!a","wp-admin/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�҅yE�F@$�D9�");
INSERT INTO `arc1542_wfFileMods` VALUES("$����0S�r���","wp-includes/images/smilies/icon_redface.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m��A��R!4a");
INSERT INTO `arc1542_wfFileMods` VALUES("$���C����/�9��","wp-includes/class-wp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�iG!��Q�l�3nI%�");
INSERT INTO `arc1542_wfFileMods` VALUES("%����8^�V<�t�","wp-admin/edit-tag-form.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F?��E���/)w%�");
INSERT INTO `arc1542_wfFileMods` VALUES("&*���dĆָ�	�H5","wp-admin/images/align-center.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�ݶ�4y�dY1�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("&=�+t�\"�/k\'
","wp-includes/js/jquery/jquery.form.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�À�s���E�VM�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("&ee�
3K���vZ��","wp-admin/ms-delete-site.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A��;t�?OaQvQ�");
INSERT INTO `arc1542_wfFileMods` VALUES("&t!0^g��bJ�c,>3","wp-admin/upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2\'�w�%�M�Ǽ��");
INSERT INTO `arc1542_wfFileMods` VALUES("&���Rw?~�j�hJ�D","wp-includes/Text/Diff/Renderer/inline.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�n5�P�����B\'�");
INSERT INTO `arc1542_wfFileMods` VALUES("&��]0W��
)�=��","wp-includes/js/tinymce/plugins/directionality/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�W%<�:oJ��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("&�`�O�Q5�Q�43�","wp-admin/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NGQn�]/�A�E_��");
INSERT INTO `arc1542_wfFileMods` VALUES("(��g%\0��4��l>��","wp-includes/js/jquery/jquery.schedule.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��T�k�f؞���");
INSERT INTO `arc1542_wfFileMods` VALUES("(?���>��S�N揚�&","wp-includes/images/media/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-����I�B�h�@���b");
INSERT INTO `arc1542_wfFileMods` VALUES("([d��������BQ��","wp-admin/js/updates.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z[i�j(�N��h�\\!�");
INSERT INTO `arc1542_wfFileMods` VALUES("(~6vqV�0�{�\"","wp-includes/ID3/readme.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����Ɯ���VLN[�");
INSERT INTO `arc1542_wfFileMods` VALUES("(���v|T�— ¥�","wp-admin/includes/screen.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B<Y����N��&ȼ�>");
INSERT INTO `arc1542_wfFileMods` VALUES("(�^�3N������3","wp-includes/wp-diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z{�&���Q����\"");
INSERT INTO `arc1542_wfFileMods` VALUES("){�jW-_�Q=?�GlҢ","wp-includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k&` ��C8�]:�t�");
INSERT INTO `arc1542_wfFileMods` VALUES(")�Oz=�u����˷","wp-includes/rewrite.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j˨�D��~^��T�");
INSERT INTO `arc1542_wfFileMods` VALUES("* a�F���4��u�vU","wp-admin/images/menu-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J�ZY<�i�Y��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("*t$�ߋv��n��s�","wp-includes/js/swfupload/swfupload.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z%�5�e,�r��HO");
INSERT INTO `arc1542_wfFileMods` VALUES("*��-3�u��E�[�O#","wp-includes/images/down_arrow-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�s���$�6(�@�a");
INSERT INTO `arc1542_wfFileMods` VALUES("*���L�m&&2��
b","wp-includes/js/tinymce/utils/form_utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�D{}��wk��k|");
INSERT INTO `arc1542_wfFileMods` VALUES("*�07ѥ1O���َ8","wp-includes/js/json2.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t������uD�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("+9���[BU�E�e","wp-admin/js/updates.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��f����\0|�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("+��G*#�������f�","wp-admin/network/site-info.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|�P�|�N�F
Ύm6");
INSERT INTO `arc1542_wfFileMods` VALUES("+���t�%R?������","wp-admin/network/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8,�4,���X���u�");
INSERT INTO `arc1542_wfFileMods` VALUES(",<�� �?C]�0A�","wp-includes/js/tinymce/plugins/colorpicker/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��(oT���R��a�");
INSERT INTO `arc1542_wfFileMods` VALUES(",B�c���ԛZ�4Y","wp-includes/js/swfupload/plugins/swfupload.speed.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AZ7��k���E`,*�s�");
INSERT INTO `arc1542_wfFileMods` VALUES(",���@��hj�qrޒ�","wp-includes/ID3/module.tag.id3v2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U[��,j�}jAؚ��c");
INSERT INTO `arc1542_wfFileMods` VALUES(",�hɃs?4B[�^՝","wp-includes/SimplePie/Cache/DB.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y�OU���.�b���");
INSERT INTO `arc1542_wfFileMods` VALUES("-kdϯ���X�w\\7���","wp-includes/admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.A�~E��L+,H[d�");
INSERT INTO `arc1542_wfFileMods` VALUES("-����Ǹ�%w=��","wp-admin/css/colors/ocean/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|[���l�|ٱf%h");
INSERT INTO `arc1542_wfFileMods` VALUES("-��)7�5y�8c��Wv�","wp-admin/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Xc�拇��Z<j����");
INSERT INTO `arc1542_wfFileMods` VALUES("-�_��+��Yn��S","wp-includes/js/jquery/ui/tooltip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]G҃������@EQ");
INSERT INTO `arc1542_wfFileMods` VALUES("-�f��4]�#\"u��l","wp-admin/css/colors/light/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R�[Ƴ�O�I\\");
INSERT INTO `arc1542_wfFileMods` VALUES("-��藂��Y{]ns�","wp-includes/css/wp-pointer.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ȡN�mH˟,3g\"��b");
INSERT INTO `arc1542_wfFileMods` VALUES(". �\0_oE�]A�_�0PJ","wp-includes/js/tinymce/plugins/wpautoresize/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","d�\0Xc�O�@p��%�");
INSERT INTO `arc1542_wfFileMods` VALUES(".IhU���3��+B��","wp-includes/images/admin-bar-sprite-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q����8��o��");
INSERT INTO `arc1542_wfFileMods` VALUES(".Z{=U�uߩAJ��*","wp-admin/css/press-this.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H
{R�`���z
�&");
INSERT INTO `arc1542_wfFileMods` VALUES("/<ا^ɼf}�\"���$�","wp-includes/images/media/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�4�8�Αy�6�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("/�s��C4��������","wp-admin/network/setup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Bm>n9z]�њ�");
INSERT INTO `arc1542_wfFileMods` VALUES("/鹠���ΰ1�iw��","wp-includes/images/uploader-icons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���&-��O��Õ�~");
INSERT INTO `arc1542_wfFileMods` VALUES("0<�����lڿ��J��","wp-includes/js/wp-backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i���H.�^�V!");
INSERT INTO `arc1542_wfFileMods` VALUES("0]�qK\'�f�x����","wp-includes/js/tinymce/plugins/compat3x/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W����������r��");
INSERT INTO `arc1542_wfFileMods` VALUES("0���E\00���X�H","wp-includes/js/colorpicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5
���w�-g���:OH�");
INSERT INTO `arc1542_wfFileMods` VALUES("1s�)6�Ӷ���C��Η","wp-admin/user/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\'�$�U�m�x�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("1�EfQ�v#)�
�0EkQ","wp-admin/images/media-button-image.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~���WÎ�@��b�rճ");
INSERT INTO `arc1542_wfFileMods` VALUES("1��X�/�t60^Ҁ!�7","wp-includes/js/comment-reply.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���~��i_");
INSERT INTO `arc1542_wfFileMods` VALUES("2@�j�j\0�kӲ��Ә","wp-admin/includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f���*�4�d��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("2j�L,���W��W$��","wp-admin/css/colors/sunrise/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2�$
�`��5H��");
INSERT INTO `arc1542_wfFileMods` VALUES("2��^(��ʭ�-^x��","wp-includes/SimplePie/Enclosure.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�B�n΍K�s]");
INSERT INTO `arc1542_wfFileMods` VALUES("3k��oW�5	k[mq","wp-admin/includes/continents-cities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","KWٛ���3��ǝ");
INSERT INTO `arc1542_wfFileMods` VALUES("3���\'���RK�Bf�","wp-includes/js/tinymce/plugins/wpdialogs/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���G���7�(tt�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("3��fQ3�h�5[��W�<","wp-includes/Text/Diff/Renderer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����������菨)");
INSERT INTO `arc1542_wfFileMods` VALUES("48�Vt���+^X�","wp-includes/pomo/mo.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�h�^2�.��t��a");
INSERT INTO `arc1542_wfFileMods` VALUES("4AI�n09��7c`","wp-includes/js/tinymce/utils/validate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hf�
[�ٺ��V�}4");
INSERT INTO `arc1542_wfFileMods` VALUES("4a��[I�}���H�m)","wp-admin/css/deprecated-media.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","bR\'�5�Y��t�S6");
INSERT INTO `arc1542_wfFileMods` VALUES("4ڂ��L$�,K[�u��","xmlrpc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���u�w��nƻ1��");
INSERT INTO `arc1542_wfFileMods` VALUES("5�?��y��<�2�","wp-admin/css/dashboard-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a��l�*���li&j");
INSERT INTO `arc1542_wfFileMods` VALUES("58�d�`S61K>ۮ�v","wp-admin/css/colors/blue/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4
��`C��9�Ĉ�");
INSERT INTO `arc1542_wfFileMods` VALUES("5C�)
Wu�꽝/F�cK","wp-includes/js/plupload/wp-plupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e��;�2�@_e��R|");
INSERT INTO `arc1542_wfFileMods` VALUES("5Z����Sμ�v�`6�9","wp-includes/version.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-����@����S��");
INSERT INTO `arc1542_wfFileMods` VALUES("5\\h>��w	���N�","wp-includes/registration.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q�ύH^�ܲ��I��i�");
INSERT INTO `arc1542_wfFileMods` VALUES("5`�]\\ͭi\0���J�T","wp-includes/class-wp-embed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�J7د�ŏ���,");
INSERT INTO `arc1542_wfFileMods` VALUES("6����X/��HL","wp-includes/js/mediaelement/wp-playlist.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ɘY8@v��\'ٿ�");
INSERT INTO `arc1542_wfFileMods` VALUES("6;I(�H�m�%��f�","wp-admin/css/farbtastic-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�@!!�Ek�");
INSERT INTO `arc1542_wfFileMods` VALUES("6�]j�v�W�k3-�","wp-admin/load-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">7�q�\0�}�0[��0");
INSERT INTO `arc1542_wfFileMods` VALUES("6̠,��_���q���u�","wp-admin/includes/class-wp-filesystem-ftpext.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��4��P�?~$�e4~");
INSERT INTO `arc1542_wfFileMods` VALUES("6٨	��:{�^D�","wp-includes/js/jquery/ui/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","asy��6�=�(�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("7|oOU���z\0Ef���","wp-admin/network/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"?}R2{8\\��?R�");
INSERT INTO `arc1542_wfFileMods` VALUES("7�%Wy~׹P?�x��","wp-includes/js/tinymce/skins/wordpress/images/playlist-video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lzV6`wmZBs���");
INSERT INTO `arc1542_wfFileMods` VALUES("7��O+�����ǋ\'n","wp-includes/js/mediaelement/bigplay.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	qm�^@$��ȍ");
INSERT INTO `arc1542_wfFileMods` VALUES("7�c�¢)��S�eb�","wp-includes/js/jquery/ui/menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�Y����-�9|�l�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("8=�I��a�%��k�~�","wp-admin/js/editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�#�h�3;��q�Fq");
INSERT INTO `arc1542_wfFileMods` VALUES("8�R6�DH��q�-{�:`","wp-admin/includes/translation-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a�
]��r6�o�e�");
INSERT INTO `arc1542_wfFileMods` VALUES("8�@)��6yg[y�sQR","wp-admin/css/deprecated-media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U��R�ڹy��C���");
INSERT INTO `arc1542_wfFileMods` VALUES("9�5\'X���>?�","wp-includes/js/customize-preview-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z{�Y}q�y�ڴ�");
INSERT INTO `arc1542_wfFileMods` VALUES("9ψ[�1d{���@","wp-includes/class.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�4� �?�M�nI��t�");
INSERT INTO `arc1542_wfFileMods` VALUES("9:��d�o
��p`Ry��","wp-includes/js/tinymce/langs/wp-langs-en.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f�tS�uc�.k�7a7");
INSERT INTO `arc1542_wfFileMods` VALUES("9�} B^��?	�\"�","wp-includes/script-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<l
ԟW:L#㐢");
INSERT INTO `arc1542_wfFileMods` VALUES("9ՍҢ��9��d�Y","wp-includes/ID3/license.commercial.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�GD �.}�c�H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("9��s�3�SZ,p�8g","wp-includes/images/media/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z��s��0�ȝ�Q�K");
INSERT INTO `arc1542_wfFileMods` VALUES(":{���{7�9����","wp-admin/link.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c���Na�b���d");
INSERT INTO `arc1542_wfFileMods` VALUES(":�|L�H6(��c�g��","wp-includes/ID3/module.audio.ogg.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���v�N�5�O۬��");
INSERT INTO `arc1542_wfFileMods` VALUES(":<�$��0,w\"&e({","wp-includes/class-feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<��Byْ���");
INSERT INTO `arc1542_wfFileMods` VALUES(":���%H`!����Z","wp-admin/js/media-gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2��� Ғ�����n");
INSERT INTO `arc1542_wfFileMods` VALUES(":�Xqݝ�J\\�5P�4","wp-includes/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES(":�n̣RM�ti#��=","wp-includes/images/media/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�taCA����.��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES(";�b�fȖ0����x","wp-admin/css/colors/midnight/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x(���V�?OD�{��`");
INSERT INTO `arc1542_wfFileMods` VALUES(";1ы#�Y_N��t�","wp-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ���r(�l2}+��");
INSERT INTO `arc1542_wfFileMods` VALUES(";R�yh���RxK�","wp-admin/js/farbtastic.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�T�2Aq]����4�");
INSERT INTO `arc1542_wfFileMods` VALUES(";�Wct���*+��Br�","wp-includes/images/smilies/icon_surprised.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")�r�����i�^@8��");
INSERT INTO `arc1542_wfFileMods` VALUES(";����*1n��4�","wp-includes/js/wp-emoji-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&�i��׽-}�_��{)l");
INSERT INTO `arc1542_wfFileMods` VALUES("<F���Pz�22��~","wp-includes/js/imgareaselect/imgareaselect.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}(��()��3���󵕯");
INSERT INTO `arc1542_wfFileMods` VALUES("<��9�u�j����!�$","wp-admin/css/install.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B��$\0���D��9j�");
INSERT INTO `arc1542_wfFileMods` VALUES("<�hj�	�4���4a�2�","wp-includes/js/utils.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����o���o,Ê");
INSERT INTO `arc1542_wfFileMods` VALUES("<��u꿖ܜ��Y�^","wp-includes/js/tinymce/plugins/wpeditimage/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c<�{��!���o");
INSERT INTO `arc1542_wfFileMods` VALUES("=f�u�A><Th���@","wp-includes/js/jquery/ui/progressbar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��C�{��˚q��t	�");
INSERT INTO `arc1542_wfFileMods` VALUES("=��k�[4��� ��=�","wp-includes/comment-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$j���M6��Yb�x}Q");
INSERT INTO `arc1542_wfFileMods` VALUES(">hЩ�XX*�v1���","wp-includes/theme-compat/comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�Q�K?G��}�1");
INSERT INTO `arc1542_wfFileMods` VALUES(">ql�+�m�\05Ħ\"�^","wp-includes/js/customize-preview.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��%Hh�������T�");
INSERT INTO `arc1542_wfFileMods` VALUES(">��X��b��ڟ�$W","wp-includes/class-wp-image-editor-gd.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��3��\0P\0C6�o");
INSERT INTO `arc1542_wfFileMods` VALUES("?]�P�.��1����2b","wp-includes/js/tinymce/plugins/textcolor/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ޔ��]|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("@V�$�K���<�1*��","wp-includes/css/jquery-ui-dialog.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�(}��eB{xS	");
INSERT INTO `arc1542_wfFileMods` VALUES("@b�Hf�Q�\"$��S","wp-admin/js/press-this.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:�q��⭊%�sR~");
INSERT INTO `arc1542_wfFileMods` VALUES("@k/�����I�?T,","wp-includes/js/jquery/ui/datepicker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I�N�u��QA�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("@��̘9�#�L�y(��","wp-includes/images/arrow-pointer-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w��b�·*L���[��");
INSERT INTO `arc1542_wfFileMods` VALUES("@�XD
�
RN��t���","wp-admin/images/menu.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��9#�d�Y`	���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�;5�X��V��O�Z","wp-admin/images/mask.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���g~�\"��J��䩎�");
INSERT INTO `arc1542_wfFileMods` VALUES("@�m����O��W","wp-admin/admin-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��I�:s,Ί���");
INSERT INTO `arc1542_wfFileMods` VALUES("@�s�Z��^����q�v","wp-admin/images/media-button-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#�WI��\\��?��");
INSERT INTO `arc1542_wfFileMods` VALUES("@��+�T΄\'����٤","wp-includes/ID3/module.audio.flac.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,�g�\0.���i�");
INSERT INTO `arc1542_wfFileMods` VALUES("AE���[�`����","wp-includes/js/thickbox/thickbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���C�eR���wS�%");
INSERT INTO `arc1542_wfFileMods` VALUES("Aa�@J������Ł�","wp-includes/js/tinymce/plugins/colorpicker/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�{�\'sVnш�ӹ|�");
INSERT INTO `arc1542_wfFileMods` VALUES("A{&� ��V>��Νs","wp-admin/css/login-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�?�(6�zү��sz");
INSERT INTO `arc1542_wfFileMods` VALUES("B��j�)��q�D�S","wp-admin/install-helper.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T����R�~����R3Z");
INSERT INTO `arc1542_wfFileMods` VALUES("Dm�
��z�H��S���","wp-includes/images/crystal/document.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'^c�s���D��3T\\");
INSERT INTO `arc1542_wfFileMods` VALUES("D.���:�\0��S�R8","wp-includes/ID3/module.audio-video.asf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��H�!�0�� �s�W");
INSERT INTO `arc1542_wfFileMods` VALUES("D6m�e�r{pK�O�","wp-includes/locale.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��~h]:�T�1��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("D����)ba�k��{��","wp-admin/includes/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T\"AR��hy�ۺCQ)");
INSERT INTO `arc1542_wfFileMods` VALUES("Dչ������$Oa����","wp-admin/css/colors/ectoplasm/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o�qjGY|UI���\'");
INSERT INTO `arc1542_wfFileMods` VALUES("D��5
\'�\\��~W��","wp-includes/category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'�*ˀ�j��5 e�");
INSERT INTO `arc1542_wfFileMods` VALUES("E4��fu#R:k!jgh","wp-includes/js/wp-list-revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��OBy��MK�/�l");
INSERT INTO `arc1542_wfFileMods` VALUES("Eh���������@aq��","wp-includes/session.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")|o�.;eX�+}N�");
INSERT INTO `arc1542_wfFileMods` VALUES("E�V���,�%��,SM=","wp-admin/ms-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�/�Ħý��:E�");
INSERT INTO `arc1542_wfFileMods` VALUES("F�Hȝl�e��#�","wp-includes/js/tinymce/skins/wordpress/images/more-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l,��r�%�^x�%");
INSERT INTO `arc1542_wfFileMods` VALUES("FF�v��V;v�8/���","wp-includes/SimplePie/Misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���y�-���^�K�");
INSERT INTO `arc1542_wfFileMods` VALUES("FH���30m�:��s��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-edit.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","xR�	�Y�X���ݤ���");
INSERT INTO `arc1542_wfFileMods` VALUES("F���Ã\\�O�fg�","wp-includes/js/tinymce/skins/wordpress/images/gallery-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1����v��R");
INSERT INTO `arc1542_wfFileMods` VALUES("F�\'�B�/�4{J�{w","wp-admin/js/edit-comments.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�������u��");
INSERT INTO `arc1542_wfFileMods` VALUES("F���?�C;$��H","wp-admin/css/color-picker.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-M�_�h���lf/");
INSERT INTO `arc1542_wfFileMods` VALUES("G6U�2\01R������J","wp-admin/js/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";���q���S���$�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gm��:�MľV��LЉ","wp-includes/js/tinymce/utils/editable_selects.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y��\0!�e�f��");
INSERT INTO `arc1542_wfFileMods` VALUES("Gq�@����gm屪","wp-includes/js/mediaelement/controls.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@�oZsm������ۊR�");
INSERT INTO `arc1542_wfFileMods` VALUES("Gu�^�/1��ՁS�7","wp-includes/atomlib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�e�.���[�\0
f�A");
INSERT INTO `arc1542_wfFileMods` VALUES("G�9q���=ʥ[3?a�","wp-admin/images/bubble_bg-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R=[����;��c��");
INSERT INTO `arc1542_wfFileMods` VALUES("G�7��I&:�x","wp-admin/edit-form-comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%��8H�p�?H2�x�");
INSERT INTO `arc1542_wfFileMods` VALUES("H+�E~�}�1Q���","wp-includes/js/wp-util.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9�f1��bQ
�ʭ&2");
INSERT INTO `arc1542_wfFileMods` VALUES("Hý��i�Z�U,H�L","wp-admin/includes/meta-boxes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�w>��+%+�%��_ڟ");
INSERT INTO `arc1542_wfFileMods` VALUES("If@n����;c>�8","wp-includes/js/tinymce/wp-mce-help.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�G;e�������Eq�\'");
INSERT INTO `arc1542_wfFileMods` VALUES("I��:Bs�#����@�","wp-blog-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��n:�����5�S�5�");
INSERT INTO `arc1542_wfFileMods` VALUES("I�V/��6�s���","wp-admin/js/editor-expand.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x��]p1(� bΎP");
INSERT INTO `arc1542_wfFileMods` VALUES("Jf�3?���_r�C�","wp-admin/images/w-logo-white.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*�,K��i�l��<�");
INSERT INTO `arc1542_wfFileMods` VALUES("J��E[�7U���~","wp-includes/js/plupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��WPIʿ���F�Ug)");
INSERT INTO `arc1542_wfFileMods` VALUES("J{�ֹZi^ùx�I","wp-admin/media-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���x�\"������[��");
INSERT INTO `arc1542_wfFileMods` VALUES("J򾁬��Oh���sDؾ","wp-includes/js/zxcvbn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�;��uc���<��");
INSERT INTO `arc1542_wfFileMods` VALUES("K��W�&\0\0K�\06�G�","wp-admin/js/set-post-thumbnail.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","+QSWm�@�~��Q");
INSERT INTO `arc1542_wfFileMods` VALUES("L<#�������}","wp-includes/js/tinymce/skins/lightgray/img/loader.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9K���M�:�Tf�9");
INSERT INTO `arc1542_wfFileMods` VALUES("L#��/۰*��3���","wp-admin/includes/class-wp-terms-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�<&y�!�A���\\");
INSERT INTO `arc1542_wfFileMods` VALUES("L(���n�9[2�C6�","wp-includes/js/zxcvbn-async.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��p9	�9�~��");
INSERT INTO `arc1542_wfFileMods` VALUES("LsЇś
�c}>�K��","wp-includes/css/editor.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","JE�0I	,l�95�y");
INSERT INTO `arc1542_wfFileMods` VALUES("L��e�t\"pc(	�e�","wp-includes/wp-db.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1�� ���q\\�j�");
INSERT INTO `arc1542_wfFileMods` VALUES("L�>t���N�����","wp-admin/css/colors/blue/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��5Iה�g,)Z�YM�");
INSERT INTO `arc1542_wfFileMods` VALUES("L��)��a$�D-�Ӯ�J","wp-includes/js/tinymce/plugins/wplink/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�.\"C��b>��K�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("M?,5�*�����K*�f","wp-admin/js/post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}���N�CR���Yp�");
INSERT INTO `arc1542_wfFileMods` VALUES("MW�	���:��ي","wp-admin/images/align-none.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�eqd2���u����");
INSERT INTO `arc1542_wfFileMods` VALUES("MР\0�A���9Q�+��","wp-includes/js/admin-bar.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�Oas�{�-v\'�&#");
INSERT INTO `arc1542_wfFileMods` VALUES("M�;C�����8Yyﲏ","wp-includes/js/twemoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|A\0^ֆl�,·MF");
INSERT INTO `arc1542_wfFileMods` VALUES("M���I�M����rD��-","wp-includes/post-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b��
�U\'���(�{�m�");
INSERT INTO `arc1542_wfFileMods` VALUES("N|�Jв�zn��sw","wp-includes/pluggable-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۠���v�!l\"Ȥ�-");
INSERT INTO `arc1542_wfFileMods` VALUES("N�3�j@pu5����^��","wp-includes/js/tinymce/skins/wordpress/images/more.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
�
m\0;�˫�z");
INSERT INTO `arc1542_wfFileMods` VALUES("N���HV����}�4G","wp-admin/css/customize-widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�Aʹ]����j9�");
INSERT INTO `arc1542_wfFileMods` VALUES("O	��S����#��Yi�v","wp-admin/includes/class-wp-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������>�[L�shB");
INSERT INTO `arc1542_wfFileMods` VALUES("OlqCcێ���������","wp-admin/css/forms-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ShAe��{\0�\0�>�");
INSERT INTO `arc1542_wfFileMods` VALUES("O��\\���P5���{�R�","wp-admin/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��j������");
INSERT INTO `arc1542_wfFileMods` VALUES("O����&�r�蓏�� ","wp-admin/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e������SvLXy¸");
INSERT INTO `arc1542_wfFileMods` VALUES("O����R�r����D�?�","wp-admin/js/postbox.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#��$�-�!i>");
INSERT INTO `arc1542_wfFileMods` VALUES("O�hu�G���&\0�L�","wp-includes/Text/Diff/Engine/native.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'*�����*�x");
INSERT INTO `arc1542_wfFileMods` VALUES("PE۫�7r|oI�6��>","wp-includes/js/backbone.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���z�����)�b�");
INSERT INTO `arc1542_wfFileMods` VALUES("P\'�(���?+�z��$�","wp-admin/js/postbox.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����o%�zb|䨎�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("P73o�	��\0�=��","wp-admin/js/word-count.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f%i�@Q��1��N");
INSERT INTO `arc1542_wfFileMods` VALUES("P��iz�t�a�}�a","wp-admin/users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4�ep<\'��ݖ�?5��");
INSERT INTO `arc1542_wfFileMods` VALUES("P�1$���\\*�C","wp-admin/images/stars-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��A���#�S�Me.^");
INSERT INTO `arc1542_wfFileMods` VALUES("P��0��a��R�z= ","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�|hּk8ʙ");
INSERT INTO `arc1542_wfFileMods` VALUES("QT���*�f�P��.�","wp-admin/includes/file.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��D�|#_x5�Y�Wh�");
INSERT INTO `arc1542_wfFileMods` VALUES("QY��1�Tl��Vr<","wp-includes/js/customize-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��;�z��	�YM�#y�");
INSERT INTO `arc1542_wfFileMods` VALUES("QuoPX��\0��Sڞ","wp-admin/images/bubble_bg.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=,����(��2cV� 8");
INSERT INTO `arc1542_wfFileMods` VALUES("Q�`���8�M�8","wp-admin/press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:U�/��vřc�K�J");
INSERT INTO `arc1542_wfFileMods` VALUES("Q������l��g�-��","wp-admin/js/comment.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","8�i/y��}��*�C��");
INSERT INTO `arc1542_wfFileMods` VALUES("R3�Us�3��}T���","wp-includes/js/autosave.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�i|}f���C�S�/");
INSERT INTO `arc1542_wfFileMods` VALUES("RQ�b7f�� |~ۓ�(","wp-admin/js/widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H]�mH�W9H\'�����");
INSERT INTO `arc1542_wfFileMods` VALUES("R�x�4Mp@�9u
֊ p","wp-includes/images/wpspin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Nm�h����;@��");
INSERT INTO `arc1542_wfFileMods` VALUES("R��|Rx/�bzn9\0*�J","wp-admin/includes/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">�8��aK�M�P�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("R�\\SC�|ju�9��A","wp-includes/js/media-grid.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<fl� � �~\\����");
INSERT INTO `arc1542_wfFileMods` VALUES("R¥�����Le�q	�&�","wp-admin/js/user-suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3)��()ݰ4}
�");
INSERT INTO `arc1542_wfFileMods` VALUES("S.FȫA�j���(�:","wp-includes/js/hoverIntent.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�P
ޅL1A�Wb��\0");
INSERT INTO `arc1542_wfFileMods` VALUES("S0�־��K/17u���","wp-includes/js/jquery/ui/selectmenu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}�˪2�9Zhxi\"6�");
INSERT INTO `arc1542_wfFileMods` VALUES("SX+7��1?����-","wp-includes/js/jcrop/Jcrop.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z��7e�����Q�%K");
INSERT INTO `arc1542_wfFileMods` VALUES("S����p�>��Wr�YE","wp-comments-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����Х�l��%�f�");
INSERT INTO `arc1542_wfFileMods` VALUES("S��&�az8�Jض9�","wp-includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Z6����̒��$2�p");
INSERT INTO `arc1542_wfFileMods` VALUES("T^Ih�����Ύ���(","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v����W`?�I_����=");
INSERT INTO `arc1542_wfFileMods` VALUES("T�.o@Ψ2�w�v��X�","wp-includes/js/jcrop/jquery.Jcrop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/a��Lru�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("T���vm?,�a���T4�","wp-includes/ID3/module.audio-video.quicktime.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�`��f�.�0�F˼");
INSERT INTO `arc1542_wfFileMods` VALUES("U�\\p{J��O�Q�&","wp-includes/SimplePie/Cache/Base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�C�����2]�]#|j");
INSERT INTO `arc1542_wfFileMods` VALUES("U���$i\"u��&���9","wp-includes/images/crystal/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����l��ڤ�;�=");
INSERT INTO `arc1542_wfFileMods` VALUES("V
��U`�_�5���8","wp-includes/js/customize-base.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".��ҖX�`�5A");
INSERT INTO `arc1542_wfFileMods` VALUES("VL6�7G^l%D5z3��","wp-includes/default-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%�ܴ�l�Z��)��");
INSERT INTO `arc1542_wfFileMods` VALUES("Vne!�z0u1?��","wp-includes/shortcodes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","(�+�#1m�ҫ�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("Vrm�KE�p�j��6�","wp-admin/images/w-logo-blue.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�[N�W��_p�w�0");
INSERT INTO `arc1542_wfFileMods` VALUES("V�����댏$�x","wp-admin/js/post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_��K�g�{=q�rbI�");
INSERT INTO `arc1542_wfFileMods` VALUES("W{�g- X���\'=n8","wp-admin/moderation.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","TB���YR��\"4�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("W})Ӗ7���e�}5�9,","wp-admin/load-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��E��0VO��r����");
INSERT INTO `arc1542_wfFileMods` VALUES("X,�E�Cj$_��8I��0","wp-includes/images/smilies/icon_cool.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�F~��ߢ.���>t8");
INSERT INTO `arc1542_wfFileMods` VALUES("X�:8+˓2>V]��8�","wp-admin/images/sort-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","nQ&�] �0�-����");
INSERT INTO `arc1542_wfFileMods` VALUES("X���G������z�X","wp-admin/includes/class-wp-upgrader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ݏ2e�q���
��");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�La���h�(","wp-admin/edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ၢ�8�q�}u���");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�,�e�A��w�`���","wp-includes/images/media/archive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9����h�\0��ì�u");
INSERT INTO `arc1542_wfFileMods` VALUES("Y�68�H;%,�_c
�","wp-includes/css/wp-auth-check.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�`�4j@9��Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("Y����]���ŞI���","wp-includes/js/jquery/ui/effect-slide.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#G_��MVژ�y�");
INSERT INTO `arc1542_wfFileMods` VALUES("Y֝��U����}�r/","wp-includes/SimplePie/Cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y���:�oMh�vL�4");
INSERT INTO `arc1542_wfFileMods` VALUES("ZҌ�[��
v���	F","wp-includes/SimplePie/gzdecode.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8��a��al�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("Z����� %/�Z�z9��","wp-admin/includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E���6��|J��Ჵ");
INSERT INTO `arc1542_wfFileMods` VALUES("Z�\0��Y���� æfg","wp-includes/js/crop/marqueeVert.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\0���9��R���");
INSERT INTO `arc1542_wfFileMods` VALUES("[��#ܧ>]��<�","wp-admin/css/colors/ectoplasm/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ӓ�J�׺��S�b�H");
INSERT INTO `arc1542_wfFileMods` VALUES("[�>�x�;�wn/t�H","wp-includes/js/wp-emoji.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":;���8�%G�/ws ");
INSERT INTO `arc1542_wfFileMods` VALUES("[���1�YAdk�,","wp-includes/SimplePie/Sanitize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Bظ��F�إ�H��u");
INSERT INTO `arc1542_wfFileMods` VALUES("[ꠏ�|K�o�یb7�","wp-admin/user/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������-x���Nb��");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�����9������","wp-admin/ms-upgrade-network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��&\"�S�m��8h�m");
INSERT INTO `arc1542_wfFileMods` VALUES("\\[��i%Ͱ<��e�>�","wp-includes/css/wp-pointer-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��͆���j_�L�J");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�т�?$�̈́8����","wp-admin/includes/dashboard.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","wU�s��dĂۯG");
INSERT INTO `arc1542_wfFileMods` VALUES("\\�\0��>�+���Fb��","wp-admin/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����f��#�=�|�B�");
INSERT INTO `arc1542_wfFileMods` VALUES("](R�&!��1;�3��","wp-includes/js/wp-ajax-response.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��#Pv�\\��p��");
INSERT INTO `arc1542_wfFileMods` VALUES("]B#�2�z���bU��/","wp-includes/Text/Diff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��gkj@b�%���\0�");
INSERT INTO `arc1542_wfFileMods` VALUES("]��P���Tkvt��8A","wp-admin/network/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=S[�fx�������");
INSERT INTO `arc1542_wfFileMods` VALUES("]�����\"}[�Y�R�","wp-admin/css/edit-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���s������3g�$");
INSERT INTO `arc1542_wfFileMods` VALUES("^9(-(Ų�y ���0q*","wp-admin/user/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\0ڍ�KN� ���N�-");
INSERT INTO `arc1542_wfFileMods` VALUES("^@ղ{\'��_���92","wp-admin/upgrade-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^����uP�qX\\e��");
INSERT INTO `arc1542_wfFileMods` VALUES("^�Ð����+�y|�","wp-includes/images/crystal/spreadsheet.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5�9�Т1�T��n��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�\0��d �MP~��D","wp-includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{)8\'\'���8���u");
INSERT INTO `arc1542_wfFileMods` VALUES("_*�⽞L�0�>","wp-includes/feed-rss2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��`\'r}��b� QG");
INSERT INTO `arc1542_wfFileMods` VALUES("_j���_��/���yӱ","wp-includes/load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�T�fuJ�\0�G�G0");
INSERT INTO `arc1542_wfFileMods` VALUES("_�|��T�M^���J","wp-includes/css/editor.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����m-o>�q��");
INSERT INTO `arc1542_wfFileMods` VALUES("_���4�3���=��","wp-includes/images/uploader-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\\M�����m��");
INSERT INTO `arc1542_wfFileMods` VALUES("_�(�C���M6�9�","wp-admin/includes/class-wp-links-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pP�����{4W�EW");
INSERT INTO `arc1542_wfFileMods` VALUES("_�����8}���?�","wp-includes/css/media-views-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t[kn�i�+�/���j�I");
INSERT INTO `arc1542_wfFileMods` VALUES("`���S�`NI�^G�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�a5Dn��r-m�@5P");
INSERT INTO `arc1542_wfFileMods` VALUES("`%�ֽ�j��\'��P��","wp-admin/js/edit-comments.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{(Æ�c|�љģ*3");
INSERT INTO `arc1542_wfFileMods` VALUES("`���;�\"�-���+~;","wp-includes/js/tinymce/plugins/media/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~�\"��ʧ�Z�¥v
");
INSERT INTO `arc1542_wfFileMods` VALUES("a)�TMW�Oo��Q�|�","wp-admin/images/media-button.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6@p�z^ye��");
INSERT INTO `arc1542_wfFileMods` VALUES("a\\c,I\"5T��#̋�","wp-admin/images/media-button-music.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��]�2\\Z�/��ޕ");
INSERT INTO `arc1542_wfFileMods` VALUES("a�?��_�ˢ��6j��X","readme.html","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��O��ڂs�B��");
INSERT INTO `arc1542_wfFileMods` VALUES("a�����(m�EB�l�","wp-includes/media-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������K��Y�?�");
INSERT INTO `arc1542_wfFileMods` VALUES("a�c�CH��=l@ĸ","wp-admin/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~��`3��}@�[V�P");
INSERT INTO `arc1542_wfFileMods` VALUES("bY�,��ϥY�r۝�;�","wp-includes/js/crop/cropper.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ky5�ni*M(��");
INSERT INTO `arc1542_wfFileMods` VALUES("b�����Ҍ &�?�{","wp-includes/js/customize-loader.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����<�ܽL-�Im");
INSERT INTO `arc1542_wfFileMods` VALUES("c,���[xޫ�3�
�@","wp-includes/js/jquery/jquery.masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����R�(��e^");
INSERT INTO `arc1542_wfFileMods` VALUES("d��:w���O�І","wp-includes/ID3/getid3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"�
Q�Q.���b�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("d��1�쵓-�;O��","wp-admin/js/custom-background.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j�)N���ˈ¨iv#");
INSERT INTO `arc1542_wfFileMods` VALUES("d�(��%J���@�G�","wp-admin/options.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�o�sn���]�T�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�hħ{q4�2�K\"�","wp-includes/SimplePie/Rating.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=p�m	�K�دat�");
INSERT INTO `arc1542_wfFileMods` VALUES("d�4�j�2U�V��$�P","wp-admin/css/wp-admin.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����S�RF��)�m");
INSERT INTO `arc1542_wfFileMods` VALUES("e.PȴNB�Sx[�&��","wp-admin/includes/class-wp-plugin-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i1*\\E�`r����C");
INSERT INTO `arc1542_wfFileMods` VALUES("e��__�%��x���","wp-includes/class-snoopy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mMz�Mr�;v��");
INSERT INTO `arc1542_wfFileMods` VALUES("e�^#|ۍ�TЩ��z","wp-includes/Text/Diff/Engine/xdiff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ֹ�b�t�X8�GX");
INSERT INTO `arc1542_wfFileMods` VALUES("f�u3
�M\\�}6*0�","wp-includes/class-wp-customize-setting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=t��$Q����I");
INSERT INTO `arc1542_wfFileMods` VALUES("f�霰f؟|h��U�L","wp-admin/includes/ms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�*H[�s@��");
INSERT INTO `arc1542_wfFileMods` VALUES("f�����e��R�)�","wp-includes/SimplePie/Item.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�!�Cz�\0�c<ܧ");
INSERT INTO `arc1542_wfFileMods` VALUES("g#�,vM������:��","wp-includes/js/jquery/jquery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N*ht��(�#Y�(JC");
INSERT INTO `arc1542_wfFileMods` VALUES("g+yr���q����D��/","wp-includes/vars.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'���8u���Ƶ8;");
INSERT INTO `arc1542_wfFileMods` VALUES("g|y_�o4\"��X�N���","wp-includes/images/smilies/mrgreen.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-5��^����J�j���");
INSERT INTO `arc1542_wfFileMods` VALUES("g�$G\\��;�r���1X","wp-includes/images/wpicons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","dS��uq��V_���a�");
INSERT INTO `arc1542_wfFileMods` VALUES("g��]bR%� Z��E�","wp-includes/js/shortcode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�X2\0`y��L8�*�");
INSERT INTO `arc1542_wfFileMods` VALUES("g�Ed��1��D}�����","wp-includes/js/jquery/ui/autocomplete.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���PصC��8�zj�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("hOhl��_��Lm/�","wp-includes/class-wp-customize-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","G����.��F���ά(");
INSERT INTO `arc1542_wfFileMods` VALUES("h d��껅2��_�r","wp-includes/functions.wp-styles.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�|{�D�v��	��:B");
INSERT INTO `arc1542_wfFileMods` VALUES("h0X-�i����^�G`8","wp-includes/pluggable.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�Y�C��eF��H3��");
INSERT INTO `arc1542_wfFileMods` VALUES("h4���#3�`�-݈�\"�","wp-admin/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���?���>z�ͩ��z&");
INSERT INTO `arc1542_wfFileMods` VALUES("h@Z�%�R�F�;ti\\m","wp-admin/css/login-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V<���/(�{�z�ݨQ");
INSERT INTO `arc1542_wfFileMods` VALUES("h|hE��f:Ʊ2��~","wp-admin/network/theme-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&շ�1Up�%��1=$�");
INSERT INTO `arc1542_wfFileMods` VALUES("iAh{���M(�|J,��","wp-admin/js/wp-fullscreen.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f��A�o��\0)`�o�");
INSERT INTO `arc1542_wfFileMods` VALUES("i�-��X�8V[~E�","wp-admin/css/install-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���5�n���J� ");
INSERT INTO `arc1542_wfFileMods` VALUES("i�\\����=X�h$","wp-admin/js/language-chooser.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	�P�V0��tJ�J");
INSERT INTO `arc1542_wfFileMods` VALUES("jQ���e���;�e","wp-includes/css/wp-pointer-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l>SR1�i�Y�7��");
INSERT INTO `arc1542_wfFileMods` VALUES("jmE��AX�uw�>܆","wp-admin/css/colors/ectoplasm/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Ѳ��E��ϡuI�");
INSERT INTO `arc1542_wfFileMods` VALUES("j�䱋����%���]�","wp-includes/class-wp-xmlrpc-server.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WUT��W��r��͜");
INSERT INTO `arc1542_wfFileMods` VALUES("j�����5F+���o","wp-includes/images/crystal/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�R�m`���`�9��");
INSERT INTO `arc1542_wfFileMods` VALUES("k���$6O��-N�x�","wp-includes/js/tinymce/plugins/charmap/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��c������ni�?K%");
INSERT INTO `arc1542_wfFileMods` VALUES("kM�������̙Ysp","wp-admin/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","m`$�����Y�J");
INSERT INTO `arc1542_wfFileMods` VALUES("k��B˞�b=y��","wp-includes/user.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q��*�;\'�ep");
INSERT INTO `arc1542_wfFileMods` VALUES("mD��T�ms���A�}","wp-includes/certificates/ca-bundle.crt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��vǻ��!�o
�f��o");
INSERT INTO `arc1542_wfFileMods` VALUES("mA��Y�����Rb|�S�","wp-includes/ms-default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NM�������9�b�%");
INSERT INTO `arc1542_wfFileMods` VALUES("mE������\\�)��o�","wp-includes/js/jquery/ui/spinner.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ש�/k&HQ��;j��");
INSERT INTO `arc1542_wfFileMods` VALUES("mY����}ɽ��?","wp-includes/js/jquery/jquery.ui.touch-punch.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�m�Q4փ��]�");
INSERT INTO `arc1542_wfFileMods` VALUES("m��-m1�����w��","wp-includes/js/jquery/ui/sortable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Xw���k^�");
INSERT INTO `arc1542_wfFileMods` VALUES("n]�j7<3ISsQ�","wp-admin/images/post-formats32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t.E���5G�N��v");
INSERT INTO `arc1542_wfFileMods` VALUES("n#�t=�\'�����b]{�","wp-includes/js/tinymce/themes/modern/theme.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL]�����Tg2%�");
INSERT INTO `arc1542_wfFileMods` VALUES("nZ/1T:{&^�/n���","wp-admin/js/media-gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��f����8�}+&");
INSERT INTO `arc1542_wfFileMods` VALUES("nef���A@���R�?��","wp-includes/js/jquery/ui/position.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}��{:�pKv�ht�");
INSERT INTO `arc1542_wfFileMods` VALUES("n����@��A��F�","wp-admin/network/sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��bd�Y.|��K�");
INSERT INTO `arc1542_wfFileMods` VALUES("oP��c����o�.�r","wp-includes/js/tinymce/skins/lightgray/img/object.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�rdP�E}u
/M�A�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("oZ0�������<c�0","wp-includes/SimplePie/IRI.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n� �憒�;a{�_6�");
INSERT INTO `arc1542_wfFileMods` VALUES("o㮚-�;?X:��pҡ","wp-trackback.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��d���#k�l");
INSERT INTO `arc1542_wfFileMods` VALUES("o�[��n3u��ʹ�P5","wp-admin/options-general.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����q�����7֔�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��7u�L�_{2Û�","wp-includes/js/jquery/ui/draggable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","PV�d��@��Y��");
INSERT INTO `arc1542_wfFileMods` VALUES("pUy�a	�b��va�;�8","wp-includes/js/comment-reply.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
�(e=N�(ZMV{�");
INSERT INTO `arc1542_wfFileMods` VALUES("p��.а��[ÍD�","wp-includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v��_�S��^Yv�");
INSERT INTO `arc1542_wfFileMods` VALUES("q\"�co���>�2Rh�]","wp-admin/includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e�\\y����:�8");
INSERT INTO `arc1542_wfFileMods` VALUES("qh�665�y|�=�?S	","wp-includes/js/jquery/jquery.serialize-object.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\)������J�l<�\"");
INSERT INTO `arc1542_wfFileMods` VALUES("r��h��v��Lk/��","wp-admin/network/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#9091N���d�H");
INSERT INTO `arc1542_wfFileMods` VALUES("r+zk;� 4��WI","wp-includes/js/tinymce/themes/modern/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<ڎ\'�,s�bP�;S�");
INSERT INTO `arc1542_wfFileMods` VALUES("r�(n՞���j��b\"","wp-admin/js/media.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","υ�^p0LB�uSŅ");
INSERT INTO `arc1542_wfFileMods` VALUES("r�_�/��HG=�%�<�","wp-includes/images/arrow-pointer-blue-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%m�rތ]4�9c�");
INSERT INTO `arc1542_wfFileMods` VALUES("r��r�(J�g�(�y�t","wp-includes/js/mce-view.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ���W�0`��G̪摟");
INSERT INTO `arc1542_wfFileMods` VALUES("r��
��b��#��","wp-admin/css/media-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��?ً�./+#S�G_�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�ŏU\'���e@�d�","wp-includes/js/tinymce/plugins/fullscreen/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�y�_1u�݇�bo�");
INSERT INTO `arc1542_wfFileMods` VALUES("s�C4M�*��*B�)�","wp-includes/css/wp-pointer.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=|t��r`�֖}|?�");
INSERT INTO `arc1542_wfFileMods` VALUES("t6��O�a��Ȇ�f","wp-admin/js/plugin-install.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XR7�5�1:]��S�");
INSERT INTO `arc1542_wfFileMods` VALUES("t8����p�̋�z{jDp","wp-includes/css/buttons-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1>�����:�z^��");
INSERT INTO `arc1542_wfFileMods` VALUES("tU�/Ds�Iڤ�st�","wp-includes/js/wp-auth-check.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�	�8��_oDdJy��s");
INSERT INTO `arc1542_wfFileMods` VALUES("tm6ۗ�q���.��=j","wp-admin/css/colors/blue/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��-K�e��:8�");
INSERT INTO `arc1542_wfFileMods` VALUES("ue�,\"
	�h�g.","wp-admin/css/colors/_mixins.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S�_���|�\'4.o\'6�");
INSERT INTO `arc1542_wfFileMods` VALUES("u��3!pA�f�)R�M�","wp-includes/js/tinymce/plugins/wpgallery/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���A�#j�d�&�S�");
INSERT INTO `arc1542_wfFileMods` VALUES("u�qg\0�8�hԭ�\0�","wp-admin/custom-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��.��08�#�z&�");
INSERT INTO `arc1542_wfFileMods` VALUES("vڴ����V���K��P","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��6�_¸�f���");
INSERT INTO `arc1542_wfFileMods` VALUES("vK;@�s�aU1;�	^�","wp-config.php","0","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�;����8�f���o");
INSERT INTO `arc1542_wfFileMods` VALUES("vw��@�H��z�F�","wp-admin/ms-admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���@�ͯE�b6�");
INSERT INTO `arc1542_wfFileMods` VALUES("v]�z������3�tB","wp-admin/includes/class-wp-importer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ky�lCK��W.���5");
INSERT INTO `arc1542_wfFileMods` VALUES("v��ޣ��R�","wp-includes/js/jquery/jquery-migrate.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7��5�X��QN�z");
INSERT INTO `arc1542_wfFileMods` VALUES("v�G�.�g�A��#�r�","wp-admin/images/align-right-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h�l�>r�]�lW��x");
INSERT INTO `arc1542_wfFileMods` VALUES("v����4�|>�<����","wp-admin/js/xfn.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����t�+��n�(k");
INSERT INTO `arc1542_wfFileMods` VALUES("v�{#��l��b\0}��B","wp-admin/css/colors/light/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%��ʒw�����^�`�");
INSERT INTO `arc1542_wfFileMods` VALUES("v�Ҹ);�D��~J\"��q","wp-includes/js/jquery/jquery.form.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.�,�+��
q");
INSERT INTO `arc1542_wfFileMods` VALUES("wu�l|��p��Q","wp-includes/js/autosave.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�,@��g�h/7");
INSERT INTO `arc1542_wfFileMods` VALUES("w���L��0���]r.","wp-includes/images/crystal/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�1������1�9");
INSERT INTO `arc1542_wfFileMods` VALUES("w������:}V��P","wp-admin/js/common.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܞ/���X�FoH2.2");
INSERT INTO `arc1542_wfFileMods` VALUES("x	G!N�$�.�d�Tb�","wp-includes/ID3/module.audio-video.flv.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ֈ?�d�h�@�D��");
INSERT INTO `arc1542_wfFileMods` VALUES("xIH�.�9�Y��BO","wp-admin/css/colors/coffee/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9~8 �z#C0�^%a�");
INSERT INTO `arc1542_wfFileMods` VALUES("x�^m�]̲�/��L4vU","wp-admin/includes/revision.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ǒU�+zm��\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("x덂��@}Y��i�+","wp-includes/js/tinymce/plugins/tabfocus/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j��dFЂ�\"Ex�");
INSERT INTO `arc1542_wfFileMods` VALUES("y���E�a��:�[\0","wp-includes/class.wp-dependencies.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T_[@j��j�\\?ou");
INSERT INTO `arc1542_wfFileMods` VALUES("y���G�\\`����MR�","wp-admin/network/site-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q��y����(�l�#nK");
INSERT INTO `arc1542_wfFileMods` VALUES("z;j2WD�6��[�V","wp-admin/js/accordion.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^V�
�8.7p�Ct�7:");
INSERT INTO `arc1542_wfFileMods` VALUES("z����JX�w{!F���","wp-admin/includes/class-wp-upgrader-skins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<]��:�PGV5]f�");
INSERT INTO `arc1542_wfFileMods` VALUES("{��a�t�
\">��S","wp-includes/js/mediaelement/flashmediaelement.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�{�l9�N���	�");
INSERT INTO `arc1542_wfFileMods` VALUES("{N���2�Q�u��=	�","wp-admin/network/theme-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�F��dm����j");
INSERT INTO `arc1542_wfFileMods` VALUES("{t�E~��P�A�1��","wp-admin/js/tags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�Bf�Z��<���/s");
INSERT INTO `arc1542_wfFileMods` VALUES("{�)�4e4p:�fW�","wp-includes/js/jquery/jquery.query.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�Xz�ǰ����wC");
INSERT INTO `arc1542_wfFileMods` VALUES("{�RC���.*\"�Q","wp-includes/feed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\\3!/���)Tj");
INSERT INTO `arc1542_wfFileMods` VALUES("{��-��}�^��","wp-includes/images/smilies/frownie.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q���������");
INSERT INTO `arc1542_wfFileMods` VALUES("{��P8���5x��-�","wp-includes/js/tinymce/plugins/wpfullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","݃�r\\�+zJ���");
INSERT INTO `arc1542_wfFileMods` VALUES("{���?������
\'","wp-admin/images/imgedit-icons.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K�\\2���}�G�i;O");
INSERT INTO `arc1542_wfFileMods` VALUES("|j��x7�(Q}�0�\'�","wp-admin/css/list-tables.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D�J�$���e벚�");
INSERT INTO `arc1542_wfFileMods` VALUES("|/ڒ�\0[*4��x��","wp-includes/js/admin-bar.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�o�\0�H�[�H");
INSERT INTO `arc1542_wfFileMods` VALUES("|��Y�>���	�Ɔ�","wp-admin/link-add.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�G�D�/�ϥ�W��");
INSERT INTO `arc1542_wfFileMods` VALUES("}ĉ=�t�����","wp-includes/images/toggle-arrow-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","F���\\����CDr�");
INSERT INTO `arc1542_wfFileMods` VALUES("}`��g\"P�2��V��","wp-includes/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("}���>/���+i�V","wp-admin/js/wp-fullscreen.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","֨���9�Z%�S=2�");
INSERT INTO `arc1542_wfFileMods` VALUES("}�7 ޘ�DHD�Pl","wp-includes/SimplePie/Registry.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ȣ����1v9�d\0�ٸ");
INSERT INTO `arc1542_wfFileMods` VALUES("}�Ȑ�\\L��`���i)","wp-includes/ID3/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�����jQ���#1�");
INSERT INTO `arc1542_wfFileMods` VALUES("}���{RҢ����\"","wp-includes/default-constants.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j����vj�$��%��+");
INSERT INTO `arc1542_wfFileMods` VALUES("~79�h�g$+�=���\\0","wp-admin/js/bookmarklet.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`8����#���\03");
INSERT INTO `arc1542_wfFileMods` VALUES("~?�J�I�b*׺�e�C","wp-admin/images/resize.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�D�$��Xv����a");
INSERT INTO `arc1542_wfFileMods` VALUES("~F��㫎>dy��j�","wp-includes/css/jquery-ui-dialog-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2iy6�v���&]�2��");
INSERT INTO `arc1542_wfFileMods` VALUES("~ť�s\0�1y�$�L}h","wp-config-sample.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","o\"M�p��q��$vB");
INSERT INTO `arc1542_wfFileMods` VALUES("j&��^����b����","wp-includes/ms-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��sv�ɂhz�*�e��");
INSERT INTO `arc1542_wfFileMods` VALUES("�K�Q�}U&;&���Q","wp-includes/meta.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�؏�oS�Byy}�;�");
INSERT INTO `arc1542_wfFileMods` VALUES("�tr�εF_� ���","wp-includes/js/wp-emoji-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ԩ�?�WJ���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�R�*�����������",".htaccess","0","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6fMk6͓��");
INSERT INTO `arc1542_wfFileMods` VALUES("��ں�u���M���[","wp-admin/images/wpspin_light-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("����e��97�aJS","wp-includes/images/smilies/icon_smile.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��G)ö��u��\\
M");
INSERT INTO `arc1542_wfFileMods` VALUES("�el�5�s��E�úQ�","wp-admin/js/media-upload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","a�p�3� 
�^$e&z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��,CUU����9i-","wp-includes/css/wp-auth-check.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�^�G7���_�h�Q�^");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȉV?	��]�)A","wp-includes/js/media-views.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�@�<d4�z��1��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\'>�[��·�","wp-admin/js/user-profile.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","(		!�{��*�=�&�\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�3��Ƈe�(ú9�","wp-includes/js/jquery/suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!����^�~k�ۥ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\�(��wB��I�","wp-admin/network/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E�^�!��u��)�u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�(tTlDά7&��MP.�","wp-includes/js/tinymce/tiny_mce_popup.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�B3�)7�{U�/�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�B��ه�v<Sv稳","wp-includes/SimplePie/Parse/Date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�
2m0�H�����n\'`");
INSERT INTO `arc1542_wfFileMods` VALUES("�F� �GJ��B��s7�","wp-includes/js/media-models.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u|z���kNئ��");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0���+OW+�","index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%0;��s��Dm\\�:[");
INSERT INTO `arc1542_wfFileMods` VALUES("�����A���1�;�","wp-includes/rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VYhƤ�3����u	�");
INSERT INTO `arc1542_wfFileMods` VALUES("���ʆ��n�D㮖�(","wp-admin/css/install.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3?�zP��&O�<R�9`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�:+[��g��CZ���","wp-includes/template-loader.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s�~ǹ��Q9�Zl�=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�B%v6�I\"Jb��4ӡT","wp-admin/link-manager.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","AlN.���+Qc��и�");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�A�B�7�Sz!�e","wp-admin/includes/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�o=a�*A���Td�");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�eU��MV��^��","wp-admin/includes/misc.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","҆F�T���?�;�Հ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0�>#����z(","wp-includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���F��a*�s�<�7");
INSERT INTO `arc1542_wfFileMods` VALUES("���������}��","wp-admin/media-upload.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��J@�����!���");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�w���0�h�9","wp-includes/js/tinymce/plugins/fullscreen/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x�2����]�D�yZC");
INSERT INTO `arc1542_wfFileMods` VALUES("�J�&_#��3S�q���","wp-admin/images/spinner-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\q��9)hdxR���]l");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\:��ڈ��)g,\\","wp-includes/images/smilies/icon_twisted.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","b���.�8|`�Q�LF");
INSERT INTO `arc1542_wfFileMods` VALUES("���3v�U�3�P�^O ","wp-admin/css/widgets-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c�}�q�)\\ZB��
�");
INSERT INTO `arc1542_wfFileMods` VALUES("��L �U����f��u�<","wp-admin/images/icons32-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�P*���{>v��Uf");
INSERT INTO `arc1542_wfFileMods` VALUES("��`��kYL_��h%\'","wp-includes/theme-compat/comments-popup.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�U/����aڌ.u<.");
INSERT INTO `arc1542_wfFileMods` VALUES("�:=�%�����M�۵","wp-includes/template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_���Q��G������");
INSERT INTO `arc1542_wfFileMods` VALUES("�I�{�?��r�]��7","wp-admin/images/resize-rtl.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ےc�ZY�6��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7*���\"{��
�K<","wp-admin/includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/bmO��dNL	i��X");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�8������Z��N�","wp-includes/ID3/module.tag.lyrics3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K�׬㑎��0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j��I���<꟟��iU","wp-includes/category-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��v�uW����dai");
INSERT INTO `arc1542_wfFileMods` VALUES("��B]nȄ�8�7g��","wp-includes/images/smilies/icon_rolleyes.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȼ�_�Ҹ*>,�!j");
INSERT INTO `arc1542_wfFileMods` VALUES("�Mj�A�M��O�\"If","wp-includes/SimplePie/Net/IPv6.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Fy!j�ـ�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��$��xM1>�_8P\0","wp-includes/js/swfupload/swfupload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:�E%ρz���s~");
INSERT INTO `arc1542_wfFileMods` VALUES("���6�d��x�D��","wp-includes/js/mediaelement/background.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","p<e�K�c�\\c8�r~\0l");
INSERT INTO `arc1542_wfFileMods` VALUES("�n97�I.O�ҝ޿�","wp-includes/js/heartbeat.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��톙�@��Cm");
INSERT INTO `arc1542_wfFileMods` VALUES("����h+��B����","wp-includes/js/tw-sack.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���\'��7�ē��n�̄");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�\"��vh�$Lb��","wp-includes/js/imgareaselect/border-anim-v.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," �z!�<�7������*�");
INSERT INTO `arc1542_wfFileMods` VALUES("��yc�0O�g)ρ�Mf�","wp-admin/network/site-settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�j@�~%�����xs");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�
5��H�?������","wp-admin/css/customize-controls.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4��ٻF���$4���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����juGCtO����","wp-admin/css/colors/coffee/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"rü�+��w����\'");
INSERT INTO `arc1542_wfFileMods` VALUES("��l�.H|S���{��","wp-includes/js/jquery/ui/effect-transfer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ި\0w}����n�");
INSERT INTO `arc1542_wfFileMods` VALUES("���an���V=Ty X�","wp-includes/SimplePie/Copyright.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h�T��	Ù���j");
INSERT INTO `arc1542_wfFileMods` VALUES("�} �yT��Z�H�cDJ","wp-admin/js/custom-background.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��#Y>W� �����e�");
INSERT INTO `arc1542_wfFileMods` VALUES("��{�0l(Ʋu9,wS�u","wp-includes/js/media-audiovideo.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ur�������F\'&�");
INSERT INTO `arc1542_wfFileMods` VALUES("� �A$ۤfC�N��37","wp-includes/query.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�qN��
��b��");
INSERT INTO `arc1542_wfFileMods` VALUES("�(���ה�W�h@=a","wp-includes/images/smilies/icon_mad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","׾�iec�{��0");
INSERT INTO `arc1542_wfFileMods` VALUES("����v���ό�Y9�","wp-includes/ID3/getid3.lib.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�sQ�F����0");
INSERT INTO `arc1542_wfFileMods` VALUES("��֗]NR���S{qv?�","wp-admin/css/wp-admin-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"�ew@3�u��|˻");
INSERT INTO `arc1542_wfFileMods` VALUES("��+�Ϳ�#Ft�EǍ7","wp-includes/js/mediaelement/froogaloop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*�B����#�D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�����j�X�])D:","wp-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!�i�A��>\'����ж�");
INSERT INTO `arc1542_wfFileMods` VALUES("�j%M�ɍ��p)Z��","wp-admin/images/generic.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����\'�[#98!�");
INSERT INTO `arc1542_wfFileMods` VALUES("��;(Xp`ҙ��pݷ","wp-includes/js/plupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<�`a*6Y$�qpM�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("��t�0�g�a�/���","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce-small.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%���ցl R
1�O�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
�qo�qZVyX��9","wp-admin/includes/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X&Jʅ�q.�����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ư	\'CԻ��ګ","wp-includes/images/admin-bar-sprite.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","S���:�W����^");
INSERT INTO `arc1542_wfFileMods` VALUES("��\"�Z0\0ؿe�Ԧp�","wp-admin/css/admin-menu.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�>d�\0?�h��/���!");
INSERT INTO `arc1542_wfFileMods` VALUES("����x8[!>�X","wp-admin/includes/class-wp-users-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o���z��4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("�S����KK2iɈ","wp-includes/comment.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�I�D�ǅ<�}F�>UJ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y�g��zaU\"�	XKG","wp-includes/js/hoverIntent.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʳY�C��c�On�כ");
INSERT INTO `arc1542_wfFileMods` VALUES("�v{L�Jlō�Yz�`�(","wp-includes/js/thickbox/thickbox.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","%R��j��o�AYx�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X�VטO|8}���","wp-includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�T�u�޷����<#O");
INSERT INTO `arc1542_wfFileMods` VALUES("�V}�P���m�/�|I*�","wp-includes/js/customize-loader.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!0�&�q���\0�~�");
INSERT INTO `arc1542_wfFileMods` VALUES("��.��v8-rJŕ�qQ","wp-includes/js/wp-auth-check.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����]k���Z!V");
INSERT INTO `arc1542_wfFileMods` VALUES("��7��E#�wŧj���","wp-admin/includes/image-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o	z�*����R����");
INSERT INTO `arc1542_wfFileMods` VALUES("��v���|�-��","wp-includes/js/tinymce/plugins/tabfocus/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6������t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�!HUN&�\"����z��","wp-admin/css/widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","MǛ��H����3�");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�tU�q�^!�0ƣl�","wp-includes/post-formats.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�M�ґ�VȔ$L;Cd�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k���zߣ����bo�R","wp-admin/post-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Z�6>!?~E����De�");
INSERT INTO `arc1542_wfFileMods` VALUES("��@��{�J��5䷴X","wp-includes/js/tinymce/skins/wordpress/images/playlist-audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U,�:)��؋\"�QqY");
INSERT INTO `arc1542_wfFileMods` VALUES("����L��6	���׳","wp-includes/ID3/module.audio.ac3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�N��E�p:�A��Z��");
INSERT INTO `arc1542_wfFileMods` VALUES("��T��V�����\\��","wp-admin/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n8�]<�Ĕr��W7�@W");
INSERT INTO `arc1542_wfFileMods` VALUES("�ܵ[Ҳm%�6�S8:D","wp-includes/images/toggle-arrow.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��·�a��;�d��*�");
INSERT INTO `arc1542_wfFileMods` VALUES("����!ެ��߳���p","wp-includes/images/crystal/default.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�>)*/��!�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�h�����FuQe� �","wp-includes/images/wlw/wp-comments.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�6]P����.s���");
INSERT INTO `arc1542_wfFileMods` VALUES("��f0��ͭ��~�)","wp-includes/fonts/dashicons.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x�����a�I�~t~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�|;�;8�Q�4�k��","wp-admin/install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","jH��H�.�Ӧ��%��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9�e�E��bݾl�3�","wp-includes/js/wp-lists.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�t|r��5��xŇ�ґ");
INSERT INTO `arc1542_wfFileMods` VALUES("��5o��#R\'/��l","wp-includes/fonts/dashicons.eot","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","΢6d����HD��Qك");
INSERT INTO `arc1542_wfFileMods` VALUES("����E�?��Юᾠ","wp-includes/js/media-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ԣ~蜿���gį�");
INSERT INTO `arc1542_wfFileMods` VALUES("��Cg����}|�E��","wp-admin/js/word-count.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮�E��^�:��/_�");
INSERT INTO `arc1542_wfFileMods` VALUES("�	v�O.�|ߤҵ�","wp-includes/js/tinymce/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�t\"ٞ3��[�t�|");
INSERT INTO `arc1542_wfFileMods` VALUES("��b�������|e~�","wp-admin/css/customize-widgets.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�����?[���<�");
INSERT INTO `arc1542_wfFileMods` VALUES("����8(�j�Z]}","wp-includes/js/jquery/ui/effect-pulsate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&`������f��");
INSERT INTO `arc1542_wfFileMods` VALUES("�X����g5����(�=c","wp-includes/js/tinymce/skins/lightgray/img/trans.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7I �1F�Gu�j^");
INSERT INTO `arc1542_wfFileMods` VALUES("�pt_ Y����7L�Kt","wp-admin/css/deprecated-media-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{aPt�X?�A���IY");
INSERT INTO `arc1542_wfFileMods` VALUES("����T��D��F�K1�","wp-admin/css/media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x��{�%���U�");
INSERT INTO `arc1542_wfFileMods` VALUES("��/GΞӶ[�ǜ��C","wp-admin/js/gallery.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K~�l���");
INSERT INTO `arc1542_wfFileMods` VALUES("���[�/�9}�`:w�P","license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","98��v���hP֡�>q");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0�����.}�fwA","wp-includes/date.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u���<��OI");
INSERT INTO `arc1542_wfFileMods` VALUES("�[���QH\"pS1Ȫ�c","wp-admin/images/arrows-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Q��}��ydb#6�");
INSERT INTO `arc1542_wfFileMods` VALUES("��[ixT�q��~Wv�e","wp-admin/network/plugin-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�͚�GM�XZi=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�-��x7��(A�4���","wp-includes/js/swfupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�`�^�-�o�QWz");
INSERT INTO `arc1542_wfFileMods` VALUES("�1W;c�����N��\"�u","wp-includes/pomo/streams.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q;�}���,ʠ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��B�GT�;,l��T","wp-includes/images/smilies/icon_exclaim.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�qE�!HY__=�{_�");
INSERT INTO `arc1542_wfFileMods` VALUES("���7�M3�$��","wp-includes/images/smilies/icon_question.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\'u��&E�qA���mN�");
INSERT INTO `arc1542_wfFileMods` VALUES("����2@�k�w>K�2","wp-includes/feed-atom.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q5B���4���D
W");
INSERT INTO `arc1542_wfFileMods` VALUES("�����H\0ۙ��h�C��","wp-admin/css/colors/ectoplasm/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8�K���࿬8��b�");
INSERT INTO `arc1542_wfFileMods` VALUES("��wt�H���-s�\0�n","wp-includes/js/wplink.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�$m��y�l�e���");
INSERT INTO `arc1542_wfFileMods` VALUES("����=֬H�@-i��","wp-includes/css/admin-bar-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��`��
L�&6;");
INSERT INTO `arc1542_wfFileMods` VALUES("���^��\'�q���0��","wp-links-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�c���v��Il�mf�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%n��Tߒ	^�gXΰ","wp-admin/js/inline-edit-post.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Vӎ���}�_��
�)�");
INSERT INTO `arc1542_wfFileMods` VALUES("�5������k��","wp-admin/js/color-picker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����2dMM��T���");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�������P5aĨ�	","wp-includes/images/smilies/icon_wink.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O�Z���g9�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y85���æb�","wp-admin/css/colors/sunrise/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Cp��L�I��tv}���T");
INSERT INTO `arc1542_wfFileMods` VALUES("����PQ�E|E}7+","wp-admin/includes/class-wp-filesystem-ftpsockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�<Rр��D�Fv���");
INSERT INTO `arc1542_wfFileMods` VALUES("��U���$�\\*�1^�S�","wp-includes/js/jquery/ui/effect-clip.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ǔ�W�#�GZas");
INSERT INTO `arc1542_wfFileMods` VALUES("��P��/���l%�","wp-includes/js/jquery/jquery.hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","┃��&�݋Fư��");
INSERT INTO `arc1542_wfFileMods` VALUES("�
%f[!aE�r�tg�i","wp-includes/images/media/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����u�h����q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�S짿o�$��0�n","wp-includes/author-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","l�@Ñ��P>�itz\0");
INSERT INTO `arc1542_wfFileMods` VALUES("�G�|$p֠+(�","wp-admin/js/tags-box.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","t��f����  ��#�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Q����ԁ�2�7u��L","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.svg","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��W�)�˩��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ѻ�\"�P5��^U�i","wp-admin/index.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",u��J�%yZ.�");
INSERT INTO `arc1542_wfFileMods` VALUES("��m���z4�L��K","wp-admin/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("����A�G,��<���","wp-includes/js/jquery/ui/effect-fade.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�OO_��;{r�5$m");
INSERT INTO `arc1542_wfFileMods` VALUES("���<��po@S�q��","wp-admin/includes/class-wp-press-this.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���ī��MJ�(6Q");
INSERT INTO `arc1542_wfFileMods` VALUES("� �n�$��q��^qf��","wp-includes/images/smilies/icon_lol.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M�Z8|����,���");
INSERT INTO `arc1542_wfFileMods` VALUES("�*T�u�����~�m","wp-admin/css/colors/ocean/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� 8��J4Z�Jf{
");
INSERT INTO `arc1542_wfFileMods` VALUES("�E-j��1j���E�","wp-includes/registration-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_?<���&T�xH�X�CL");
INSERT INTO `arc1542_wfFileMods` VALUES("��p?E^�@�\'��PE�","wp-admin/edit-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",")O��I=4�]VyK�");
INSERT INTO `arc1542_wfFileMods` VALUES("�<��(����*A]�O��","wp-admin/css/colors/ocean/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2Pjģ�$��f�V");
INSERT INTO `arc1542_wfFileMods` VALUES("�bv��E��H���΄","wp-includes/js/wp-lists.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�L�.�+#/*إ�I08o");
INSERT INTO `arc1542_wfFileMods` VALUES("���&��N�,���6P","wp-admin/images/icons32-vs-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�*04�G4F�	&Z�i}\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�h���Bc�92��","wp-admin/network/site-themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�!l|�2��V_��");
INSERT INTO `arc1542_wfFileMods` VALUES("��d]\0F�mŲp�D","wp-includes/js/tinymce/plugins/media/moxieplayer.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","NY�N�-���3Yj���");
INSERT INTO `arc1542_wfFileMods` VALUES("���v��\\Q���-��","wp-includes/js/tinymce/plugins/hr/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\#%Z����,3�I�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��і�q��SGKy(�","wp-includes/kses.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�+�\\`��s�	");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�Hn[P�.~���FU|","wp-includes/nav-menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7h�ޝ�:޿�-�7");
INSERT INTO `arc1542_wfFileMods` VALUES("����Z�xcy�d��\'","wp-admin/js/language-chooser.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","h\"8Jq	t���F��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:x��=�}�","wp-includes/js/jquery/ui/mouse.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8\']��!��Iٲ��");
INSERT INTO `arc1542_wfFileMods` VALUES("� a\"KwT�bc1S","wp-admin/css/revisions.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�f��tp��p��P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4g��e���>���ߝ","wp-admin/images/list-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","hջIS�2��i�g�");
INSERT INTO `arc1542_wfFileMods` VALUES("�fkj��N�Uei4=%�","wp-admin/js/tags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","/I�@�!{�hL�R�");
INSERT INTO `arc1542_wfFileMods` VALUES("�y%���Ǻ~�ne\"V","wp-admin/css/list-tables-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K �@���W�<");
INSERT INTO `arc1542_wfFileMods` VALUES("�1�o%��q�A��","wp-admin/js/inline-edit-post.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","~{&�di�Y�0�\\�*z");
INSERT INTO `arc1542_wfFileMods` VALUES("��E����Q?��	(�","wp-includes/class-oembed.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-fO������Ó�f��|");
INSERT INTO `arc1542_wfFileMods` VALUES("�.݁B��xK�Y�","wp-includes/ms-default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ӱ���eu`�.@7");
INSERT INTO `arc1542_wfFileMods` VALUES("�*O-�Lτ���[�u","wp-admin/css/about-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��/��v�R)�`�E!Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�??n������_2g��j","wp-includes/js/wp-util.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����
��%;�I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R;lzO�8m<3�Nie","wp-admin/user/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�˹��޳H�t��i.");
INSERT INTO `arc1542_wfFileMods` VALUES("�afh=F���T�:��6�","wp-admin/includes/class-ftp-sockets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T��[���6��+��\'<");
INSERT INTO `arc1542_wfFileMods` VALUES("�����;~ӷR�>��","wp-includes/class.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��
s? Ei9{�w��");
INSERT INTO `arc1542_wfFileMods` VALUES("���nvp�e������}�","wp-admin/js/customize-controls.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�T�ח
�%��c");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�|n���sARF�+","wp-includes/js/crop/marqueeHoriz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�̮����;���Lo
");
INSERT INTO `arc1542_wfFileMods` VALUES("�����:[&b�[�hY��","wp-includes/images/smilies/icon_razz.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��˭��=��J�@��");
INSERT INTO `arc1542_wfFileMods` VALUES("����8`9��?Bb�Б","wp-includes/js/jquery/ui/effect-puff.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Iml�c�G�@�ȳ� �");
INSERT INTO `arc1542_wfFileMods` VALUES("�c�̎��$
\'@���","wp-admin/setup-config.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��2�K�[D+^����/");
INSERT INTO `arc1542_wfFileMods` VALUES("���J1��M�F��<�","wp-admin/js/tags-box.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Kn���<ס�x٩");
INSERT INTO `arc1542_wfFileMods` VALUES("���?ڟ�E���$PF","wp-includes/pomo/translations.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fWۥ�\"�\0Dwf��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����6��b�g�>_�","wp-includes/images/wlw/wp-watermark.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";��uMmܭD|�w���D");
INSERT INTO `arc1542_wfFileMods` VALUES("� �(T5!��h�u","wp-admin/css/press-this-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���~�+� \"<�bj");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�?���Gc	¯l1e","wp-includes/class-wp-theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6���qߒAz`!�d");
INSERT INTO `arc1542_wfFileMods` VALUES("�H�����Pw��%8��","wp-includes/images/smilies/icon_sad.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'=��Oj�?�uA|��");
INSERT INTO `arc1542_wfFileMods` VALUES("�[�n�G{��\'��q:�","wp-includes/ms-deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_Y+�W��+Ŗ Lp�");
INSERT INTO `arc1542_wfFileMods` VALUES("���Ȁ�~_q�I��S�","wp-admin/js/password-strength-meter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1��|��=��m�U��");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\�D �>�F,���","wp-admin/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��z�ehV��
�� ");
INSERT INTO `arc1542_wfFileMods` VALUES("��=CѠ��*TX���4","wp-admin/css/colors/_variables.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",":�	k	r�L���Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�� ��It13&","wp-admin/js/nav-menu.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��ˊ������@��*");
INSERT INTO `arc1542_wfFileMods` VALUES("�&F�g��25xm��J&","robots.txt","0","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��m�`��=F^+(");
INSERT INTO `arc1542_wfFileMods` VALUES("�;?2��S��\0��p","wp-admin/customize.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","T���xv9|5H3x ");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�.�1PXL�","wp-admin/includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�D
��mz/��:���");
INSERT INTO `arc1542_wfFileMods` VALUES("������|� ��","wp-includes/js/masonry.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iq}Eigo@���T��");
INSERT INTO `arc1542_wfFileMods` VALUES("��p�$^���d�Z","wp-admin/network/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��Oy_��4�)����");
INSERT INTO `arc1542_wfFileMods` VALUES("��[K���b���28�","wp-includes/pomo/po.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6+\0��n�_HSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("�o����l>��x~I� �","wp-admin/network/about.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��=���SV��V���");
INSERT INTO `arc1542_wfFileMods` VALUES("���0j�l�S��K�","wp-includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z/��4��+Zclc�iv[");
INSERT INTO `arc1542_wfFileMods` VALUES("�«��-j=�u�N\\q\'","wp-admin/css/farbtastic.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��8)���}{��C�h2U");
INSERT INTO `arc1542_wfFileMods` VALUES("���ᗏ�3�-��4�","wp-admin/css/colors/midnight/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","FӍ���W�����&%�");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"ڕK[@�G����9�","wp-admin/includes/class-wp-theme-install-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��u�g��������4");
INSERT INTO `arc1542_wfFileMods` VALUES("�3!9�=�6�ݡ","wp-admin/images/resize-rtl-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ɞ�@��T0:��}");
INSERT INTO `arc1542_wfFileMods` VALUES("�)[\"J�H��|�jk��$","wp-admin/js/customize-widgets.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q�*N��>�˘�");
INSERT INTO `arc1542_wfFileMods` VALUES("�JTV0D��oTA［@�","wp-admin/options-discussion.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c{��7��ֺX��.tR�");
INSERT INTO `arc1542_wfFileMods` VALUES("����S�h���S�%Tz�","wp-includes/js/mediaelement/wp-mediaelement.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ؒj�F�5ρ�acR�");
INSERT INTO `arc1542_wfFileMods` VALUES("���\"ܒ����nzD","wp-includes/SimplePie/Caption.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����BjM��g[����");
INSERT INTO `arc1542_wfFileMods` VALUES("��Z
u�oK� ��T;e","wp-admin/images/list.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">��*��ӳ�S��");
INSERT INTO `arc1542_wfFileMods` VALUES("���Uy/�*%���;","wp-admin/includes/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��|*�\'�UC��a��c");
INSERT INTO `arc1542_wfFileMods` VALUES("�E��U���̈́��","wp-includes/images/wpspin-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}�3��Y�(�I��m");
INSERT INTO `arc1542_wfFileMods` VALUES("�������sp���e�","wp-admin/includes/class-wp-ms-sites-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�i�6���|�K�{h");
INSERT INTO `arc1542_wfFileMods` VALUES("�-1�8�;�T�/X�]","wp-admin/ms-sites.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]b$�����q����h");
INSERT INTO `arc1542_wfFileMods` VALUES("����(5�aH�yo,X�","wp-includes/js/jquery/ui/tabs.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�gUZ���D�����j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�͓�bHn��,\0-","wp-includes/images/smilies/icon_confused.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�sYFPZ6��,��");
INSERT INTO `arc1542_wfFileMods` VALUES("�L���yE�{��f�","wp-includes/css/dashicons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U�Y��V=}W(}�.N");
INSERT INTO `arc1542_wfFileMods` VALUES("�k�UL��ǡ�$���","wp-admin/ms-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H#�f{#ʃ��	6G�");
INSERT INTO `arc1542_wfFileMods` VALUES("����{^��W����C�","wp-admin/css/colors/ocean/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lv,|����\"��O");
INSERT INTO `arc1542_wfFileMods` VALUES("�_f��;w�a��ځ�","wp-includes/js/tinymce/skins/wordpress/images/gallery.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_���Pw��PU�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�u��<e�x��@ֈ>","wp-includes/js/underscore.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����T��Hk�zd..");
INSERT INTO `arc1542_wfFileMods` VALUES("��q?%��rp��0�7�q","wp-admin/css/colors/coffee/colors-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H<�S�-�g�����");
INSERT INTO `arc1542_wfFileMods` VALUES("����x�Й�)DC��<","wp-includes/js/customize-models.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� Һ�zCp�OE�a�V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�~����U�\"�&��","wp-includes/images/wpicons-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��n�V�o�$��Of~7");
INSERT INTO `arc1542_wfFileMods` VALUES("��W2��D��G�7�V","wp-admin/css/common-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��������J<��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Vb(kt�W\"�6(;ƴ�","wp-admin/includes/class-wp-media-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^�K��]$��V����");
INSERT INTO `arc1542_wfFileMods` VALUES("�tfF	�r{�܇�_I�x","wp-includes/SimplePie/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�.�b���~����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("��߲;��0����","wp-includes/feed-rss2-comments.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<����7Uv9Q�7");
INSERT INTO `arc1542_wfFileMods` VALUES("��3�T.^�ƙ<���","wp-mail.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��R:�߱5�$6��");
INSERT INTO `arc1542_wfFileMods` VALUES("��K���OȖ9�3|<�","wp-admin/maint/repair.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",";�#\0�24P2�pe�4");
INSERT INTO `arc1542_wfFileMods` VALUES("��I����.$U0]\'�S_","wp-admin/includes/widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J#�%sժ��ka.R�");
INSERT INTO `arc1542_wfFileMods` VALUES("��+D�FܿTZ[H7","wp-admin/images/post-formats-vs.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�l��H\\�������");
INSERT INTO `arc1542_wfFileMods` VALUES("�GV\\z��#���!;��","wp-includes/js/media-audiovideo.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�#�Iu�n?���I�X");
INSERT INTO `arc1542_wfFileMods` VALUES("�O�r#���T�G��!","wp-includes/js/swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���,�I}p�e~2�q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�l&�*�������&","wp-includes/SimplePie/Content/Type/Sniffer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|r��i�Ub�lw����3");
INSERT INTO `arc1542_wfFileMods` VALUES("���$(�g�(���P��/","wp-admin/css/wp-admin-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6`2��f����:*");
INSERT INTO `arc1542_wfFileMods` VALUES("�������kM��?�uX","wp-admin/css/ie-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�	wʢ���5յSl��");
INSERT INTO `arc1542_wfFileMods` VALUES("���q�K�U�j��","wp-includes/SimplePie/Category.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~��?��.
ܯd�*");
INSERT INTO `arc1542_wfFileMods` VALUES("��-Z���:E�:","wp-admin/js/image-edit.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","@ɡ�mz���4n�/GX");
INSERT INTO `arc1542_wfFileMods` VALUES("���|�jX����|�fb","wp-admin/css/login.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����HtU���R��");
INSERT INTO `arc1542_wfFileMods` VALUES("�MR��l�B�F�u","wp-includes/option.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��!+��1,�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�r�\\�j�����A$�","wp-includes/js/customize-base.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�0�g���ν����");
INSERT INTO `arc1542_wfFileMods` VALUES("�����\"Sέ`t@","wp-admin/network/plugins.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A��|��MM0\0���");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��.1��-��:","wp-admin/options-media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��7�3�1T�w&;��");
INSERT INTO `arc1542_wfFileMods` VALUES("��ΝH�*��*.ځS","wp-admin/includes/bookmark.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V��._%B)�j�A��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��Ul1�ȕD�bmg�","wp-includes/css/buttons-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��z�e��=�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�
fv�8���1���-I","wp-includes/SimplePie/Exception.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","	K�v&���<\\ڏ�S5");
INSERT INTO `arc1542_wfFileMods` VALUES("���ZQ4��\\(�܇","wp-admin/network/admin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N��5Cs��	�");
INSERT INTO `arc1542_wfFileMods` VALUES("����l����3Ȋ�","wp-includes/js/tinymce/skins/lightgray/fonts/tinymce.woff","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���Ѕ�k��#M��");
INSERT INTO `arc1542_wfFileMods` VALUES("�J|6}�P�,ٛ","wp-admin/css/colors/_admin.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����W耢��hL��%");
INSERT INTO `arc1542_wfFileMods` VALUES("�����[��:�����q","wp-admin/includes/class-wp-plugins-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R�m[ދ���`
jܸ");
INSERT INTO `arc1542_wfFileMods` VALUES("���P�Of;���/��","wp-includes/SimplePie/Decode/HTML/Entities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E�^/�B���Z#�%/a");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\ ��Iѻ���,","wp-includes/class-simplepie.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ys�r�	�m���D;��.");
INSERT INTO `arc1542_wfFileMods` VALUES("�/&�����2�ѡgDs","wp-includes/http.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��w��$~�r�4T$");
INSERT INTO `arc1542_wfFileMods` VALUES("��?�0|���5uơ��","wp-admin/custom-background.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�إO��\0Q�-��");
INSERT INTO `arc1542_wfFileMods` VALUES("���qh�n�J�j�","wp-admin/css/nav-menus.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&cDݱ��t�q��a");
INSERT INTO `arc1542_wfFileMods` VALUES("�ÏuL�,�&Ǒ�1","wp-admin/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2=KB������H��B");
INSERT INTO `arc1542_wfFileMods` VALUES("��$�<@�Řa���c\"","wp-includes/js/swfupload/plugins/swfupload.swfobject.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","̵q�V7�T\\���s");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�@o��\'��kb���","wp-includes/js/jquery/jquery-migrate.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q+�(0�BY�<�4:��");
INSERT INTO `arc1542_wfFileMods` VALUES("����^[X��i�	�","wp-admin/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Lg8pt.����ץn");
INSERT INTO `arc1542_wfFileMods` VALUES("��4T�(�\\9\'��3�)","wp-admin/css/customize-widgets-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��PO?$�L�~�U��j�");
INSERT INTO `arc1542_wfFileMods` VALUES("��k{��&��x
��","wp-includes/class-wp-error.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","4ĸ\'��3��Bd
���");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��%3[$x\0��.��(","wp-admin/images/marker.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","3�*O2/�3I2���");
INSERT INTO `arc1542_wfFileMods` VALUES("�	���Em[�����l�<","wp-includes/js/tinymce/plugins/image/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�6_�� ��N�#�\\");
INSERT INTO `arc1542_wfFileMods` VALUES("�������\"�R�Ŝ","wp-includes/images/crystal/text.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�� Ѳ��#�d�%�[�");
INSERT INTO `arc1542_wfFileMods` VALUES("�v%���S�[�̪�Ѿ","wp-includes/ms-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��}�zn��GNpܯ�");
INSERT INTO `arc1542_wfFileMods` VALUES("���X\"�-{��$48sx","wp-admin/css/deprecated-media.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","
ڌe�6|�����Ʀ");
INSERT INTO `arc1542_wfFileMods` VALUES("���\\��9�ѕ�F�w�","wp-admin/js/revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A�F�{�~��\'Y�i");
INSERT INTO `arc1542_wfFileMods` VALUES("����N����@�(�3�","wp-includes/ID3/module.audio.mp3.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","#��~e�����J�8�");
INSERT INTO `arc1542_wfFileMods` VALUES("��h���)UG@�x��v	","wp-admin/edit-tags.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","M�{#kb����ao�~");
INSERT INTO `arc1542_wfFileMods` VALUES("��(�[3?�H/�[�e]","wp-includes/js/tinymce/skins/lightgray/fonts/readme.md","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","zd��+���E@�1�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#�AuI.F��/���","wp-includes/js/wp-pointer.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ˋ8�.�r:ě���");
INSERT INTO `arc1542_wfFileMods` VALUES("�<{����,-�![M��","wp-includes/js/tinymce/skins/lightgray/skin.ie7.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���m_ҐsԥG");
INSERT INTO `arc1542_wfFileMods` VALUES("�@��,�n\\���+k�","wp-includes/js/tinymce/plugins/wpemoji/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�,s�M������Pm");
INSERT INTO `arc1542_wfFileMods` VALUES("���=V;�����N.K","wp-includes/js/wp-list-revisions.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","GQu`�*�L��n$��");
INSERT INTO `arc1542_wfFileMods` VALUES("��Κ,�Q�a�gl���","wp-includes/class-smtp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P�����ʄb�.");
INSERT INTO `arc1542_wfFileMods` VALUES("��dA#���*�Źo7","wp-admin/js/customize-controls.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��B�؏�f��@��.");
INSERT INTO `arc1542_wfFileMods` VALUES("��3\"�(z�a�4�8�","wp-includes/images/media/code.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","-o��Uʓ��U�U_");
INSERT INTO `arc1542_wfFileMods` VALUES("��5��[,	j�(�ƪ�","wp-includes/js/mediaelement/controls.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","$�\"�Ӭ����?�Ȥ");
INSERT INTO `arc1542_wfFileMods` VALUES("���2zs��4x�EB","wp-includes/ID3/module.tag.id3v1.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��h؜�ٱal��w�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Obc��\" ���|J(","wp-includes/images/smilies/icon_evil.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c����VM<�\"!�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�1��WV(2��6����","wp-admin/images/icons32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�۬[�m9��J�4��");
INSERT INTO `arc1542_wfFileMods` VALUES("��1���|�}���dQ","wp-admin/export.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-s�t���?_�_J");
INSERT INTO `arc1542_wfFileMods` VALUES("��	1��А々�S:(","wp-includes/js/thickbox/loadingAnimation.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�\"h�c�����&�");
INSERT INTO `arc1542_wfFileMods` VALUES("�.�B�|xӳ��E�","wp-admin/css/press-this-editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��P`d�L�-#wM!�_");
INSERT INTO `arc1542_wfFileMods` VALUES("�C�3�!0Q�o�J�e `","wp-includes/js/plupload/plupload.flash.swf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����g�}F�9�\"�~S");
INSERT INTO `arc1542_wfFileMods` VALUES("�_���jSX�2�QQ=","wp-includes/ms-load.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ӎ�p�?k,�H��");
INSERT INTO `arc1542_wfFileMods` VALUES("��tnR�ؔ����%^�","wp-admin/images/align-right.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","B���Oe#�l@:P+\"v");
INSERT INTO `arc1542_wfFileMods` VALUES("���5�V\"�$$�_��","wp-admin/includes/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","؉�,\'����wKt");
INSERT INTO `arc1542_wfFileMods` VALUES("��iY����\0
R)��","wp-includes/post-thumbnail-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","e�1L5R���Y����");
INSERT INTO `arc1542_wfFileMods` VALUES("��u�X�ݼ#�-����","wp-includes/class-wp-http-ixr-client.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","tJr�P�?��bU��a");
INSERT INTO `arc1542_wfFileMods` VALUES("Ĉ^A��+l���o�d��","wp-includes/js/tinymce/skins/wordpress/images/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","7~!���\0�����\"w");
INSERT INTO `arc1542_wfFileMods` VALUES("ĔԼ���pP�Z	H��","wp-includes/images/smilies/icon_cry.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E>z?��Ap�mWlA�`");
INSERT INTO `arc1542_wfFileMods` VALUES("��ʙ\0}��甠K��.�","wp-includes/js/jquery/jquery.color.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���E�G����>vJ");
INSERT INTO `arc1542_wfFileMods` VALUES("��{A��mm��*�K","wp-includes/nav-menu-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��{y�E�-�2�Q�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�`#��G�b�C��֊�","wp-includes/js/swfupload/handlers.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y,k?�X�N�0G�;");
INSERT INTO `arc1542_wfFileMods` VALUES("��-�p�lE���k�/�","wp-includes/js/jquery/jquery.hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�S!}EU�\\b�g�h��=");
INSERT INTO `arc1542_wfFileMods` VALUES("�+���g���q6�^\0�","wp-admin/images/wheel.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","E0� q0m��Y%V�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("ƅ����|_�i/y��	","wp-includes/js/tinymce/plugins/media/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z�/~.SM�6L�5\\");
INSERT INTO `arc1542_wfFileMods` VALUES("Ƭ+���I�d^i <\0","wp-includes/js/jquery/suggest.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�U�k�7*헸Hޞ");
INSERT INTO `arc1542_wfFileMods` VALUES("ǂ-i)�.�\\���z�^a","wp-includes/Text/Diff/Engine/shell.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�Aܑ�~J�^t����");
INSERT INTO `arc1542_wfFileMods` VALUES("ǅ�9��9:����","wp-includes/cache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|��G�-��E���B�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ǥ>z�Ԅ��!J]>","wp-includes/css/wp-auth-check-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����6&B���Kb�");
INSERT INTO `arc1542_wfFileMods` VALUES("ǫ�=��m�/���^","wp-admin/includes/schema.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��W��y�$��G��m�@");
INSERT INTO `arc1542_wfFileMods` VALUES("ǳ\\��_L-Y�Ō%$","wp-includes/ID3/module.audio.dts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�lA��E��O87�$(");
INSERT INTO `arc1542_wfFileMods` VALUES("�{g��?�3gڢ�","wp-admin/images/icons32-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�%�*�����g����");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"u@��T��S��5�","wp-includes/images/smilies/icon_idea.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"m%h�����S��r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y$\'����o���","wp-includes/css/wp-auth-check-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Gn+��i�7���b�$");
INSERT INTO `arc1542_wfFileMods` VALUES("ȍP�� �3����
��","wp-includes/class-wp-customize-control.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ͩ�t��!rl��{~");
INSERT INTO `arc1542_wfFileMods` VALUES("�����~K4(#��","wp-admin/user/credits.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ����ǀ[K}�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�A7�\'�C#�w�S�s�","wp-admin/css/about.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ɵ���^Xl�|��V�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����2D�i�e�","wp-admin/css/l10n.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�T�����=�!�T");
INSERT INTO `arc1542_wfFileMods` VALUES("�!&�i�)^�W���R�","wp-includes/js/jquery/ui/widget.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�5��~�%�]c���<");
INSERT INTO `arc1542_wfFileMods` VALUES("�(�q�4P�}�5Oz�k","wp-admin/js/inline-edit-tax.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� q�8^uၓ�)?��<");
INSERT INTO `arc1542_wfFileMods` VALUES("�R���ш�޿�0","wp-admin/css/themes.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",�7�Ջ�b�LI�+w�");
INSERT INTO `arc1542_wfFileMods` VALUES("�hFM<@`%q-��","wp-admin/includes/class-wp-filesystem-direct.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|h@{Q}5�c!�K0Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�xjP�����!c�x","wp-admin/plugin-install.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/�Q�٩̪}5,
");
INSERT INTO `arc1542_wfFileMods` VALUES("��	b���8�[����y","wp-includes/js/wp-emoji-release.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��)\'RL��N�IN�");
INSERT INTO `arc1542_wfFileMods` VALUES("�!��#��I|���F�","wp-includes/js/tinymce/plugins/directionality/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��V���ʬ� Hy�");
INSERT INTO `arc1542_wfFileMods` VALUES("�6�<��C�﮿�V:(r","wp-includes/js/tinymce/plugins/wpeditimage/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���J¾U�a��g���");
INSERT INTO `arc1542_wfFileMods` VALUES("�U<�?Y,����ػ(","wp-admin/js/svg-painter.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����fu���");
INSERT INTO `arc1542_wfFileMods` VALUES("ˍ�G䯀oe���o�","wp-includes/js/shortcode.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� z�>1���J�92�");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�E,�-O�{���","wp-includes/link-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\\�\\�i�/�:��I");
INSERT INTO `arc1542_wfFileMods` VALUES("�!�LT�3��i��x�","wp-admin/update-core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�w�C�!_H�;D����");
INSERT INTO `arc1542_wfFileMods` VALUES("�M�Tq&[?��>칊�
","wp-admin/css/colors/ectoplasm/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�q�9+�\"��+��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V�ڮ����M��jӁ","wp-includes/js/plupload/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u&
�TI�z����+�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ê5ff�;,G!\'��\'-","wp-admin/css/colors/ocean/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","X�Oe����\"&�����~");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǌ�E�v�c,�صyS^","wp-includes/images/crystal/license.txt","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�]�Lc�iG�fQ���");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�j֛`��w","wp-admin/css/customize-controls-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\'���-��k��;!�");
INSERT INTO `arc1542_wfFileMods` VALUES("�d���lP�O��I�","wp-admin/network.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&��9�{e�,Yj��
");
INSERT INTO `arc1542_wfFileMods` VALUES("�w�9=�_\"h%��v","wp-admin/css/install-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","*��CM:�������");
INSERT INTO `arc1542_wfFileMods` VALUES("͓�Y�36��l�Y��","wp-includes/js/tinymce/plugins/textcolor/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��
�������}�W0�");
INSERT INTO `arc1542_wfFileMods` VALUES("ͽ3��=��O�G�|~�","wp-includes/SimplePie/Credit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��M猋*>
�|");
INSERT INTO `arc1542_wfFileMods` VALUES("����j(g��~jU#��","wp-admin/includes/class-wp-filesystem-ssh2.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=酅�c�o��<�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�_)-�]�ˌkO	���","wp-includes/ID3/module.tag.apetag.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�7��l,�iwF�Q�ql");
INSERT INTO `arc1542_wfFileMods` VALUES("�œ���ϔ�=��#6","wp-admin/images/post-formats32.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","WY~�O��{�+_L�kE;");
INSERT INTO `arc1542_wfFileMods` VALUES("�-�+�e���m�u\"��x","wp-admin/css/colors/sunrise/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�E6G�QSU�E�a�B�8");
INSERT INTO `arc1542_wfFileMods` VALUES("�uF��^G��E+��c","wp-admin/network/freedoms.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����p�O~+�~�1");
INSERT INTO `arc1542_wfFileMods` VALUES("π�tGȩ�����D","wp-includes/js/tinymce/plugins/image/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","?�r�J\0�3��\\�d�");
INSERT INTO `arc1542_wfFileMods` VALUES("ϊ=��X���bBz\' �","wp-includes/js/jquery/ui/effect-explode.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`YU����Q}X�Q�0�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����HԹ��f�k�","wp-includes/js/tinymce/wp-tinymce.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b
��0pr���Hv");
INSERT INTO `arc1542_wfFileMods` VALUES("�ݙ�P(���O\'E��e","wp-includes/js/jquery/ui/effect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","A֢�pi��u+`�");
INSERT INTO `arc1542_wfFileMods` VALUES("�鋭��{^�MU*�_","wp-includes/js/twemoji.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��37�[:.i Ĵ|t�");
INSERT INTO `arc1542_wfFileMods` VALUES("�>�s�l�WD7�M�","wp-includes/bookmark-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���!m<������O4");
INSERT INTO `arc1542_wfFileMods` VALUES("Т�펹�|����@","wp-includes/images/smilies/icon_arrow.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ʵ	�������(");
INSERT INTO `arc1542_wfFileMods` VALUES("��^�\\�X�PvS�\\�{","wp-admin/js/media-upload.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_f����b�f��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("�/��0��
*7�f(��","wp-includes/js/wp-a11y.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�9s�%o����V<4");
INSERT INTO `arc1542_wfFileMods` VALUES("�_\\c9mL�v��1���","wp-includes/compat.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ڲ@;h_�yu]�H���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Jh|��0�`Zp�E","wp-admin/user-edit.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�fϧ=�iw�U���x�");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҟ����ǟ�	Ks���","wp-includes/images/icon-pointer-flag-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2�b��&�Z�r");
INSERT INTO `arc1542_wfFileMods` VALUES("Ҫ*���H���
;t��","wp-admin/includes/ajax-actions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�&,s$y$E?��$u�");
INSERT INTO `arc1542_wfFileMods` VALUES("ҲE5|�ѵ�C�d闼","wp-admin/options-reading.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V�qu��}��-.�Ja");
INSERT INTO `arc1542_wfFileMods` VALUES("��Lt593�u^���)��","wp-admin/images/comment-grey-bubble-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TY�ŝ2�s,�m��");
INSERT INTO `arc1542_wfFileMods` VALUES("�E#l��L��_&ܪ���","wp-admin/images/arrows.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�v�$�>����>�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("�{ڭd3T�Xy����7;","wp-includes/css/admin-bar-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�֥]��_C?��+]�.");
INSERT INTO `arc1542_wfFileMods` VALUES("�].�oo�ȦM-n	�","wp-admin/images/align-none-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�XC�)[���-�4�");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ȇp���]4��L��q�","wp-includes/css/admin-bar.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U(X,�3tB��_");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��S��`�]T]D�","wp-includes/css/dashicons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","}\0�c���\'ޒà�");
INSERT INTO `arc1542_wfFileMods` VALUES("�X��$�a��B��^","wp-admin/js/user-suggest.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��T\\���\\|��9�");
INSERT INTO `arc1542_wfFileMods` VALUES("����ͤ6�\0/��k���","wp-includes/js/imgareaselect/jquery.imgareaselect.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\00ԺLB�wm#��wu�:");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z��	r!ޏf���	�","wp-includes/images/icon-pointer-flag.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��,���E^�j`\'");
INSERT INTO `arc1542_wfFileMods` VALUES("�oҨ*K��o�7{� <","wp-includes/ID3/module.audio-video.matroska.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Y�!�Z0zDj&Cp�");
INSERT INTO `arc1542_wfFileMods` VALUES("�rY�S�xwDY˚J�[","wp-includes/images/media/interactive.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R׬˂���ôŉh�H");
INSERT INTO `arc1542_wfFileMods` VALUES("ֶ��9؞f�po3t","wp-includes/class-wp-admin-bar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","YS�y�Ρ����Q��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Gȩ��6����\0Y","wp-admin/includes/class-wp-posts-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��La��FH[��a\'��");
INSERT INTO `arc1542_wfFileMods` VALUES("מ�y�7mE5���O_�","wp-admin/js/media.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".���$!&��^$�Y");
INSERT INTO `arc1542_wfFileMods` VALUES("��j0���w�E}®R�","wp-admin/css/wp-admin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\"]��Z���ӕ)g�&�");
INSERT INTO `arc1542_wfFileMods` VALUES("��v�I:wm�\'~K-","wp-includes/ID3/module.audio-video.riff.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�TfbpGO�-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�&�Zh�$�Éo�","wp-includes/class-json.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�SA���̈́���%");
INSERT INTO `arc1542_wfFileMods` VALUES("�8/B��$8���`m�","wp-includes/js/imgareaselect/jquery.imgareaselect.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","U���K(t���0���");
INSERT INTO `arc1542_wfFileMods` VALUES("�A�h)I�]Gr���E","wp-admin/includes/import.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ޱ�wCrݩA�\\�");
INSERT INTO `arc1542_wfFileMods` VALUES("�M&�3��3CMaQ{","wp-admin/images/yes.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�+��7܉�qZ�Qk");
INSERT INTO `arc1542_wfFileMods` VALUES("�o�ǣ�	ף�f0�Y","wp-includes/SimplePie/Core.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���#���������");
INSERT INTO `arc1542_wfFileMods` VALUES("�v�������&X��","wp-includes/js/jquery/ui/selectable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Q�\"�{�B�M���");
INSERT INTO `arc1542_wfFileMods` VALUES("�,(�i7:^�^�#","wp-includes/js/tinymce/plugins/paste/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)>�|�K*bH�");
INSERT INTO `arc1542_wfFileMods` VALUES("�k��/y�����&��G","wp-includes/images/rss-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ya[�Q�����rj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��!}�=�`*�gZ=","wp-admin/network/themes.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x����y|��C");
INSERT INTO `arc1542_wfFileMods` VALUES("��>�~�!�g�q��","wp-includes/js/tinymce/skins/lightgray/skin.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-�uw*S������-�]");
INSERT INTO `arc1542_wfFileMods` VALUES("��w�=Ţ�O�&�F�","wp-admin/css/colors/midnight/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","&܍���|DW��!E�4");
INSERT INTO `arc1542_wfFileMods` VALUES("�|�#�԰#�{�����","wp-admin/js/link.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��F��0�;���3�%-");
INSERT INTO `arc1542_wfFileMods` VALUES("��!�(t��<Թ","wp-includes/js/heartbeat.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� �	�1�]�d*D�G");
INSERT INTO `arc1542_wfFileMods` VALUES("��_�JL�#�@B��","wp-admin/css/colors/midnight/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�H�]�Q�T�kܤc");
INSERT INTO `arc1542_wfFileMods` VALUES("� �I�_X�����?","wp-admin/js/gallery.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o����m���dOo");
INSERT INTO `arc1542_wfFileMods` VALUES("۪���	.�ո�\\���","wp-includes/js/tinymce/skins/wordpress/wp-content.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ٞ�R��F1oj�3�X�");
INSERT INTO `arc1542_wfFileMods` VALUES("��r�����؁=�Ԓ�","wp-includes/images/rss.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[�(�.��*NZ�");
INSERT INTO `arc1542_wfFileMods` VALUES("��
p���Gnu:���","wp-includes/js/colorpicker.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��V g�����-�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ȼ�؟�\'`����","wp-includes/feed-rdf.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�<C���H�,D\'��7i");
INSERT INTO `arc1542_wfFileMods` VALUES("�2G�?�_��\\���-B","wp-includes/canonical.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","<!
�4?ζ6�O�Q�");
INSERT INTO `arc1542_wfFileMods` VALUES("�F|
�MN,8�ݪ�\'�","wp-admin/css/press-this.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܡ�����{�d�>S");
INSERT INTO `arc1542_wfFileMods` VALUES("��ջZml��4�ˮU","wp-includes/images/smilies/simple-smile.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K��{��f�w�h");
INSERT INTO `arc1542_wfFileMods` VALUES("��\0FJ��B��e�","wp-login.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Q�S��Y���st�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J0����j�Yg�h�","wp-includes/js/tinymce/plugins/lists/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","k��1�����I���");
INSERT INTO `arc1542_wfFileMods` VALUES("�[6�5��+�	�n9�","wp-admin/images/sort.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",".�ˍ���lHj�]");
INSERT INTO `arc1542_wfFileMods` VALUES("�f��y���ħ�*!","wp-admin/js/nav-menu.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�������.g;u��+#");
INSERT INTO `arc1542_wfFileMods` VALUES("�3^��PM�Y���H�D�","wp-includes/js/tinymce/skins/wordpress/images/video.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�¶��B�=z��3j�");
INSERT INTO `arc1542_wfFileMods` VALUES("�N�\\�|�`*�,)@4","wp-includes/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\'g!�:�H��),�","wp-includes/SimplePie/XML/Declaration/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���p(Å��B��s#b");
INSERT INTO `arc1542_wfFileMods` VALUES("����\"�����c)j�\"","wp-includes/js/wplink.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Μ�^g�o]Dq�`JMi");
INSERT INTO `arc1542_wfFileMods` VALUES("�q����%ű� m+","wp-admin/css/colors/light/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ʘ_�
JT�¹���J");
INSERT INTO `arc1542_wfFileMods` VALUES("ߌ��(������2���","wp-includes/js/quicktags.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","z\0�j��7%�� 4");
INSERT INTO `arc1542_wfFileMods` VALUES("ߗ�Q��u�!ٶx�[","wp-includes/js/wpdialog.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�-���\0�g�Fġ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�%�f\\+,���\0\\Y","wp-admin/includes/class-wp-filesystem-base.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","=>q��$����_�p");
INSERT INTO `arc1542_wfFileMods` VALUES("��^��bR��SI�!�?","wp-includes/class-wp-image-editor-imagick.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","P��,h2�԰�ڙ�2");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z���(>(�1bޫ�Z�","wp-includes/js/tinymce/skins/lightgray/content.inline.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[Θ|.zlˏ.�}լ");
INSERT INTO `arc1542_wfFileMods` VALUES("�q�@/��ꦑٞ-M�","wp-admin/network/site-users.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�ڄ\"�\'��.���");
INSERT INTO `arc1542_wfFileMods` VALUES("��\\9ã>���Iz4�c","wp-includes/js/tinymce/plugins/hr/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��<�<{LU798�ۆ");
INSERT INTO `arc1542_wfFileMods` VALUES("�L�>�ٟ�#{6p}Y��","wp-admin/options-writing.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","_��H��J1dk����");
INSERT INTO `arc1542_wfFileMods` VALUES("��ĸ:�,p�1��Hr","wp-admin/js/dashboard.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ܯOh|lR<���QR4��");
INSERT INTO `arc1542_wfFileMods` VALUES("�\0��וoxi3%+]kg","wp-admin/images/post-formats.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�K���\0���%3���");
INSERT INTO `arc1542_wfFileMods` VALUES("�0�;�-,�A�Ey�","wp-includes/theme-compat/sidebar.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",">���\"}Wuo���.H");
INSERT INTO `arc1542_wfFileMods` VALUES("�a�Oj\'�ŻD*ցV4","wp-cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����hc�����p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��q�82��v�&#M","wp-includes/js/tinymce/plugins/wpview/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","q������Xv�r&�`");
INSERT INTO `arc1542_wfFileMods` VALUES("���<kUJv%��1��","wp-includes/fonts/dashicons.ttf","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ez{�C7|�2�");
INSERT INTO `arc1542_wfFileMods` VALUES("�w����V���!�","wp-admin/includes/class-wp-ms-themes-list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����&��ʠ��|�z�");
INSERT INTO `arc1542_wfFileMods` VALUES("����zpKC�{\\>��","wp-admin/js/dashboard.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","9�sE�/�<S�(�ş�");
INSERT INTO `arc1542_wfFileMods` VALUES("��\00��q�ĊNy)��","wp-includes/plugin.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","N�#���i�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��5?�- S�^H��","wp-admin/js/editor-expand.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\0�2���=��Z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��b\\��ɍ���","wp-admin/edit-form-advanced.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�:���?�k�b6;��");
INSERT INTO `arc1542_wfFileMods` VALUES("�G��5�@����07��","wp-includes/images/blank.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","H�+��51	��f]��9");
INSERT INTO `arc1542_wfFileMods` VALUES("��W���\"���Sk:�","wp-admin/images/align-center-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���-�r�5*J7�If");
INSERT INTO `arc1542_wfFileMods` VALUES("�⣣�M�O����U�","wp-admin/js/editor.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Aı��P��������");
INSERT INTO `arc1542_wfFileMods` VALUES("�\"�ơ���7vs+�","wp-admin/includes/class-pclzip.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","67(�C���ki��8�");
INSERT INTO `arc1542_wfFileMods` VALUES("�b`K�\'��컜���K","wp-includes/functions.wp-scripts.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","x?!�bc�Q��*B36n");
INSERT INTO `arc1542_wfFileMods` VALUES("�J��ёe�Xd��$�","wp-includes/class-wp-customize-widgets.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","p�Ryǣ�K���9�ͯ");
INSERT INTO `arc1542_wfFileMods` VALUES("�l�XNEM�CgVsA:","wp-includes/js/swfupload/plugins/swfupload.queue.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�SR/�J��5�-v͏");
INSERT INTO `arc1542_wfFileMods` VALUES("���K�g���o#�0","wp-activate.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","pUȪ�N�ੌ�{eG�");
INSERT INTO `arc1542_wfFileMods` VALUES("�ŉ�	i����/Э","wp-includes/formatting.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��wSY�N�ڢ*�֗");
INSERT INTO `arc1542_wfFileMods` VALUES("��H���l��{!D#�!","wp-admin/js/color-picker.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}\"[}����P-�)");
INSERT INTO `arc1542_wfFileMods` VALUES("��F�ZY��C8��3E","wp-admin/css/colors/blue/colors.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","5ѱ�^pJ��G�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�%y�>}H�o���(6","wp-includes/js/jquery/ui/core.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," Ms����a���{");
INSERT INTO `arc1542_wfFileMods` VALUES("�f�i�`�=@T��o�","wp-admin/images/spinner.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����1c~\'�dv�vHq");
INSERT INTO `arc1542_wfFileMods` VALUES("�J���y��0m�`�/","wp-includes/class-IXR.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","n�V�8��0�P\"yP_");
INSERT INTO `arc1542_wfFileMods` VALUES("�F�j!Y�{.J=,��","wp-admin/images/stars.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","[����><�k�{��(�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]�W/>�}<8� VF�","wp-admin/includes/theme.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/��k�Tb�Kx�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�^.�jT}�<��I��","wp-admin/js/accordion.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Ϡ�M\0���GÁ]��");
INSERT INTO `arc1542_wfFileMods` VALUES("�\' ��#s��߾U|","wp-includes/js/mediaelement/loading.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","v�&��B\"o�!e���");
INSERT INTO `arc1542_wfFileMods` VALUES("頻�yN<���9�o<","wp-admin/js/xfn.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f�\'�(�.�J9^");
INSERT INTO `arc1542_wfFileMods` VALUES("��m�Mt���W�B","wp-admin/images/align-left.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","\\�y0��d�Z�o.h��");
INSERT INTO `arc1542_wfFileMods` VALUES("����t���Z�O\'� 
","wp-includes/js/thickbox/macFFBgHack.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ȱg�W�,/u�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����V,E@�X���y","wp-includes/SimplePie/Cache/File.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�=�@��B[	S�");
INSERT INTO `arc1542_wfFileMods` VALUES("�4���2�)A.;4�","wp-includes/js/customize-preview.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","C2������,ھ");
INSERT INTO `arc1542_wfFileMods` VALUES("ꍥ��2jEbg؈W�x�","wp-includes/css/editor-rtl.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","`�o��\"�K��PzJ��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ǉ���4˓T`�k","wp-includes/js/wp-pointer.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6��|dMpX\0��fɐ�");
INSERT INTO `arc1542_wfFileMods` VALUES("�0���R�J�{y�ˣ��","wp-includes/general-template.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�G;Y=.����T1!");
INSERT INTO `arc1542_wfFileMods` VALUES("�F �8�+�)��r�P�","wp-admin/images/no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�k�d�$��ܟV7���");
INSERT INTO `arc1542_wfFileMods` VALUES("�Oӿ�;�=\\J�zy","wp-includes/js/tinymce/plugins/wpgallery/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)F.jT&����I�O");
INSERT INTO `arc1542_wfFileMods` VALUES("뭷�!z}ML�K�E","wp-includes/ms-files.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]�yï�<�r �L�F|");
INSERT INTO `arc1542_wfFileMods` VALUES("��Sڰp��GMǯ�l�","wp-includes/css/media-views.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���[52*�6���V�");
INSERT INTO `arc1542_wfFileMods` VALUES("��vA�ds�����K�]","wp-admin/post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!hLy�:��\"E��");
INSERT INTO `arc1542_wfFileMods` VALUES("��YC��o�oR�亞�","wp-includes/capabilities.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���+�!��L�	�\"�");
INSERT INTO `arc1542_wfFileMods` VALUES("�8�ڧ��s}��ն�Ni","wp-includes/class-phpmailer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","BqO7W��vai4c");
INSERT INTO `arc1542_wfFileMods` VALUES("�?�����h�����;","wp-includes/js/quicktags.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�#��:<���T��ʭ");
INSERT INTO `arc1542_wfFileMods` VALUES("�Dh}�����!
","wp-includes/js/jquery/ui/effect-drop.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W�V��ǥ�Y��F2��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Pط��悇̺ƴ$@�","wp-includes/SimplePie/HTTP/Parser.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","W%���4�6���6	");
INSERT INTO `arc1542_wfFileMods` VALUES("��c��.D�r� |��","wp-includes/js/tinymce/skins/wordpress/images/dashicon-no.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","R����Z�?f.��8��	");
INSERT INTO `arc1542_wfFileMods` VALUES("츃�v��6��;�~�","wp-includes/js/tinymce/utils/mctabs.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�x$��
d��,�P��");
INSERT INTO `arc1542_wfFileMods` VALUES("��-x�(�E�oI�=�","wp-includes/class-wp-customize-section.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","!������	�pP~�");
INSERT INTO `arc1542_wfFileMods` VALUES("�]��@�
��>ĺ�Yn","wp-admin/admin-post.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��\"�l�E�)�E�A");
INSERT INTO `arc1542_wfFileMods` VALUES("��QR\"��@3��v�S","wp-admin/js/link.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u��5ϳt�{��z�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a�]]�A��\'h���","wp-admin/network/settings.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Y����{D=l�e");
INSERT INTO `arc1542_wfFileMods` VALUES("����=��c�ه���","wp-admin/includes/upgrade.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����裡 �����zh");
INSERT INTO `arc1542_wfFileMods` VALUES("���eC����Di!��","wp-admin/css/colors/coffee/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�yb)�O�](�a�r��z");
INSERT INTO `arc1542_wfFileMods` VALUES("���f�%u�P���","wp-includes/js/mce-view.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�O���p�?v�+�");
INSERT INTO `arc1542_wfFileMods` VALUES("�D=Jǅ/	6ރa�","wp-includes/js/swfupload/plugins/swfupload.cookies.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�~�ڈ�k\\ 7̴��");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y^~5~��p�G-���","wp-includes/js/customize-views.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��_��%cݹ����");
INSERT INTO `arc1542_wfFileMods` VALUES("�z�������|�z�xv","wp-includes/js/jquery/ui/droppable.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","K\"q�H�d����~A�P");
INSERT INTO `arc1542_wfFileMods` VALUES("���P��a`Xu","wp-admin/css/color-picker-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��[��q4G։��a");
INSERT INTO `arc1542_wfFileMods` VALUES("��X=U�pfp���Z","wp-includes/taxonomy.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���/���ِ��9J1");
INSERT INTO `arc1542_wfFileMods` VALUES("�㯩�	\'��ި��V","wp-includes/images/smilies/icon_biggrin.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�YpR�+�0}k�N{�k");
INSERT INTO `arc1542_wfFileMods` VALUES("����9��r�Mԧ��","wp-includes/js/customize-preview-widgets.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Q~���6�a���");
INSERT INTO `arc1542_wfFileMods` VALUES("�$�ī�I�^��3���","wp-admin/menu-header.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","w\"\0R�|YrI��ׂR�");
INSERT INTO `arc1542_wfFileMods` VALUES("�з&�L۽¨��VN�","wp-includes/css/buttons.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","I@�3�#������");
INSERT INTO `arc1542_wfFileMods` VALUES("�������6$[���O�","wp-admin/css/customize-widgets.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","|�?�!�`���j��x");
INSERT INTO `arc1542_wfFileMods` VALUES("���rp.u�3zx�","wp-admin/includes/class-ftp.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���2V�u�\\I�L��");
INSERT INTO `arc1542_wfFileMods` VALUES("�7s�\\]�}�AA�we1�","wp-admin/tools.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�8�.�g���_\\+U");
INSERT INTO `arc1542_wfFileMods` VALUES("�Z/���{Lt�ծF$�","wp-admin/js/svg-painter.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�����/�|ĩ���z�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?��E_�)�xڅ$��","wp-admin/includes/deprecated.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","f[A���˷xg�K");
INSERT INTO `arc1542_wfFileMods` VALUES("�po���X0%������","wp-includes/css/editor-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�u�]X)�*��﬋��");
INSERT INTO `arc1542_wfFileMods` VALUES("��M�٦M�/`�","wp-includes/js/swfupload/handlers.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��Oۅ��߲�}�");
INSERT INTO `arc1542_wfFileMods` VALUES("򱠭��B�R�z��Y","wp-includes/js/jquery/jquery.table-hotkeys.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�o�go����~i�I	�");
INSERT INTO `arc1542_wfFileMods` VALUES("�?{o_���\'�n�","wp-admin/images/resize-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��e?�&h.��
��");
INSERT INTO `arc1542_wfFileMods` VALUES("���_f $�O<o","wp-admin/js/common.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ӣ�؆p���KoR?g�(");
INSERT INTO `arc1542_wfFileMods` VALUES("��%�\0��z�f�N�pS","wp-includes/js/tinymce/plugins/wpemoji/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","y2\0׳���<�r�");
INSERT INTO `arc1542_wfFileMods` VALUES("�#\\���/�vXR","wp-admin/js/theme.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��b���
]]��\"0");
INSERT INTO `arc1542_wfFileMods` VALUES("�lF����c뒕�L���","wp-admin/js/iris.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","u�5`�@Ħ�Ue߰�");
INSERT INTO `arc1542_wfFileMods` VALUES("��V��k9۴�s���ֿ","wp-admin/css/customize-controls-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","]����m�`$�M");
INSERT INTO `arc1542_wfFileMods` VALUES("���;�^𩸴8c�","wp-includes/css/buttons.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��1R�1��!��\\=P�");
INSERT INTO `arc1542_wfFileMods` VALUES("�J\'#��rN�0a�","wp-includes/images/crystal/audio.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�nV�:�ω�G��-#k");
INSERT INTO `arc1542_wfFileMods` VALUES("�Y��R�Yi/��l@HX�","wp-includes/js/media-grid.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","L�R�G�zpȟ�n��K");
INSERT INTO `arc1542_wfFileMods` VALUES("��j�8���ď����","wp-includes/js/wp-backbone.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���S��Y�|�פ�j)p");
INSERT INTO `arc1542_wfFileMods` VALUES("�-\"D��ʹD�5a�/","wp-includes/cron.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�b�.*�r�T:~�t��");
INSERT INTO `arc1542_wfFileMods` VALUES("�A4e���{�^����Z","wp-includes/js/wpdialog.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","r�9_�M@9\0�S�����");
INSERT INTO `arc1542_wfFileMods` VALUES("�u�N���.A_�_�","wp-includes/js/media-editor.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0"," ��w��\"Wl���c6");
INSERT INTO `arc1542_wfFileMods` VALUES("������>+ܞL[�m","wp-includes/js/tinymce/skins/lightgray/img/anchor.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��a5q��ȑ_4�@");
INSERT INTO `arc1542_wfFileMods` VALUES("����(���%�#�9yn","wp-admin/css/forms.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������Eoa��)&��I");
INSERT INTO `arc1542_wfFileMods` VALUES("�����y��\0�\"��Q","wp-admin/user/menu.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)��»�g��E�p�");
INSERT INTO `arc1542_wfFileMods` VALUES("��~������r�C��","wp-admin/link-parse-opml.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Dm����䁐�f�8��");
INSERT INTO `arc1542_wfFileMods` VALUES("�V9��K���goX��7�","wp-admin/images/align-left-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","i�8�O�����^��c");
INSERT INTO `arc1542_wfFileMods` VALUES("������H�S!;� �","wp-admin/js/user-profile.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","j@#�wP<Pw��2�");
INSERT INTO `arc1542_wfFileMods` VALUES("���+���q�pW��","wp-includes/update.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�_�W�\\F�D�$�,0");
INSERT INTO `arc1542_wfFileMods` VALUES("���`�&X<�aQ�Vh\\","wp-admin/user/profile.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0yݤ�&-");
INSERT INTO `arc1542_wfFileMods` VALUES("����Pq-�t�@l�","wp-includes/images/wlw/wp-icon.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","1	�ʚ�7w3K��*");
INSERT INTO `arc1542_wfFileMods` VALUES("� @�;��*��|��","wp-includes/Text/Diff/Engine/string.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","^��x@�R�ƙ=���");
INSERT INTO `arc1542_wfFileMods` VALUES("�@���sB0<�{l�3��","wp-includes/wlwmanifest.xml","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Ԑ����i�^��");
INSERT INTO `arc1542_wfFileMods` VALUES("�k����e<F��4","wp-admin/js/revisions.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","2S�l��R;�]2�Lj�");
INSERT INTO `arc1542_wfFileMods` VALUES("��6K1���(���}/AX","wp-admin/network/user-new.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���6�\'G��g$�");
INSERT INTO `arc1542_wfFileMods` VALUES("��H�Mz�@�A��","wp-admin/css/press-this-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","+(y�*�@���p���");
INSERT INTO `arc1542_wfFileMods` VALUES("��ɱ%��a{Z�j	%�","wp-includes/class-wp-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","c�;~^$���w�");
INSERT INTO `arc1542_wfFileMods` VALUES("����I�:4P�U���","wp-includes/SimplePie/Cache/Memcache.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��JU���1SQ��?�");
INSERT INTO `arc1542_wfFileMods` VALUES("����p�l4[���e���","wp-admin/js/inline-edit-tax.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","J����`$?\0=>�G���");
INSERT INTO `arc1542_wfFileMods` VALUES("�R��=��*�d��n�","wp-admin/includes/media.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�RI\"��u�}��[da");
INSERT INTO `arc1542_wfFileMods` VALUES("�.ն���Zg{�=��","wp-admin/css/customize-controls.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�J�|`����(���4");
INSERT INTO `arc1542_wfFileMods` VALUES("���~��a%��!�P","wp-includes/js/tinymce/skins/wordpress/images/pagebreak-2x.png","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","{�6�#UQ:��|>#��");
INSERT INTO `arc1542_wfFileMods` VALUES("�����L?@��.~O�","wp-admin/css/colors/midnight/colors-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","s���^�r\'\'8��n�I");
INSERT INTO `arc1542_wfFileMods` VALUES("����T
����e.(��","wp-includes/class-wp-image-editor.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��:T��Xd�L��ܕg");
INSERT INTO `arc1542_wfFileMods` VALUES("��}���PÛ�P\\�","wp-includes/js/tinymce/plugins/wpautoresize/plugin.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","VL��	�gS\'����i");
INSERT INTO `arc1542_wfFileMods` VALUES("��R�,�A����GJ\'-","wp-includes/default-filters.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0",",}�\'�!��J�v�");
INSERT INTO `arc1542_wfFileMods` VALUES("���
\\��ɶ.5���","wp-includes/images/xit.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�)�X��`1���H��");
INSERT INTO `arc1542_wfFileMods` VALUES("�D����]�|߼�$�","wp-includes/js/mediaelement/wp-mediaelement.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�8؟\"{�պ��u�Z");
INSERT INTO `arc1542_wfFileMods` VALUES("�Ph�����rV�","wp-admin/css/revisions-rtl.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�2����.�ĕx`x�a*");
INSERT INTO `arc1542_wfFileMods` VALUES("�\'������}����0","wp-includes/js/tinymce/wp-tinymce.js.gz","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�}���M��3/��m\"");
INSERT INTO `arc1542_wfFileMods` VALUES("�])��	���{�?R}","wp-includes/feed-rss.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�kY���>�]DtH/");
INSERT INTO `arc1542_wfFileMods` VALUES("�0<Ps��מH���22","wp-includes/js/jquery/jquery.table-hotkeys.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��֔#t�gP�g��");
INSERT INTO `arc1542_wfFileMods` VALUES("�9(F�Rj2�n6]��","wp-admin/css/colors/light/colors.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�Cxڄx43�*Cn��/y");
INSERT INTO `arc1542_wfFileMods` VALUES("�g�\"�}_�7����J5","wp-includes/js/jcrop/jquery.Jcrop.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V̞��/K�x����");
INSERT INTO `arc1542_wfFileMods` VALUES("��p��9�6è�R�","wp-admin/css/common.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","iB���D�&�8Y���");
INSERT INTO `arc1542_wfFileMods` VALUES("�����ƪq�悳��","wp-includes/js/tinymce/plugins/paste/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","6�BU@��8�<ba");
INSERT INTO `arc1542_wfFileMods` VALUES("��<l�a��,�bX,��","wp-admin/images/xit-2x.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��r�T��`��?J�/�");
INSERT INTO `arc1542_wfFileMods` VALUES("�G���!#h�9	��&","wp-includes/js/tinymce/plugins/wordpress/plugin.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�6B���û�yם");
INSERT INTO `arc1542_wfFileMods` VALUES("���\'�B���7S�","wp-includes/js/zxcvbn-async.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������\0�V]u#3");
INSERT INTO `arc1542_wfFileMods` VALUES("������)�(��<��","wp-includes/js/json2.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","�A��`� �ȡ�@�");
INSERT INTO `arc1542_wfFileMods` VALUES("��a��\'@T瑓����","wp-admin/images/date-button.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���.��I��V�ď�");
INSERT INTO `arc1542_wfFileMods` VALUES("�����)z]!?��a�","wp-admin/images/media-button-video.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������r�x�4Q���");
INSERT INTO `arc1542_wfFileMods` VALUES("�I\"�p��t�Q��[Z6x","wp-includes/css/admin-bar.min.css","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","���mk�x�Hk�1q�W�");
INSERT INTO `arc1542_wfFileMods` VALUES("�c��wk�(���4�3�","wp-admin/includes/list-table.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","����T8��>��_߂");
INSERT INTO `arc1542_wfFileMods` VALUES("�Qֿ6��yq�88","wp-includes/theme-compat/footer.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","� ~C~�M������=");
INSERT INTO `arc1542_wfFileMods` VALUES("���w��\'�6)","wp-includes/rss-functions.php","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","g�����l]�4j0l=�");
INSERT INTO `arc1542_wfFileMods` VALUES("�L����e5x?e=�&","wp-includes/js/plupload/wp-plupload.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","��S�y�,lf@�@");
INSERT INTO `arc1542_wfFileMods` VALUES("��a5[4�5�Me�pC","wp-includes/js/jquery/ui/effect-bounce.min.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","ؖ�0TQ�5����S");
INSERT INTO `arc1542_wfFileMods` VALUES("���T����Ç=w���","wp-admin/js/bookmarklet.js","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","Y��ἿvoFg\"��k");
INSERT INTO `arc1542_wfFileMods` VALUES("��S�CRC��l��","wp-admin/css/colors/sunrise/colors.scss","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","V���z�	h���=�");
INSERT INTO `arc1542_wfFileMods` VALUES("���k��i��.���\\��","wp-includes/images/smilies/icon_neutral.gif","1","\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0","������	����Z�");


DROP TABLE IF EXISTS `arc1542_wfHits`;

CREATE TABLE `arc1542_wfHits` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `jsRun` tinyint(4) DEFAULT '0',
  `is404` tinyint(4) NOT NULL,
  `isGoogle` tinyint(4) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `newVisit` tinyint(3) unsigned NOT NULL,
  `URL` text,
  `referer` text,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`IP`,`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfHoover`;

CREATE TABLE `arc1542_wfHoover` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `owner` text,
  `host` text,
  `path` text,
  `hostKey` binary(4) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `k2` (`hostKey`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfIssues`;

CREATE TABLE `arc1542_wfIssues` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `time` int(10) unsigned NOT NULL,
  `status` varchar(10) NOT NULL,
  `type` varchar(20) NOT NULL,
  `severity` tinyint(3) unsigned NOT NULL,
  `ignoreP` char(32) NOT NULL,
  `ignoreC` char(32) NOT NULL,
  `shortMsg` varchar(255) NOT NULL,
  `longMsg` text,
  `data` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfLeechers`;

CREATE TABLE `arc1542_wfLeechers` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfLockedOut`;

CREATE TABLE `arc1542_wfLockedOut` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `blockedTime` bigint(20) NOT NULL,
  `reason` varchar(255) NOT NULL,
  `lastAttempt` int(10) unsigned DEFAULT '0',
  `blockedHits` int(10) unsigned DEFAULT '0',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfLocs`;

CREATE TABLE `arc1542_wfLocs` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `failed` tinyint(3) unsigned NOT NULL,
  `city` varchar(255) DEFAULT '',
  `region` varchar(255) DEFAULT '',
  `countryName` varchar(255) DEFAULT '',
  `countryCode` char(2) DEFAULT '',
  `lat` float(10,7) DEFAULT '0.0000000',
  `lon` float(10,7) DEFAULT '0.0000000',
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfLogins`;

CREATE TABLE `arc1542_wfLogins` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `fail` tinyint(3) unsigned NOT NULL,
  `action` varchar(40) NOT NULL,
  `username` varchar(255) NOT NULL,
  `userID` int(10) unsigned NOT NULL,
  `IP` binary(16) DEFAULT NULL,
  `UA` text,
  PRIMARY KEY (`id`),
  KEY `k1` (`IP`,`fail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfNet404s`;

CREATE TABLE `arc1542_wfNet404s` (
  `sig` binary(16) NOT NULL,
  `ctime` int(10) unsigned NOT NULL,
  `URI` varchar(1000) NOT NULL,
  PRIMARY KEY (`sig`),
  KEY `k1` (`ctime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfReverseCache`;

CREATE TABLE `arc1542_wfReverseCache` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `host` varchar(255) NOT NULL,
  `lastUpdate` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfScanners`;

CREATE TABLE `arc1542_wfScanners` (
  `eMin` int(10) unsigned NOT NULL,
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `hits` smallint(5) unsigned NOT NULL,
  PRIMARY KEY (`eMin`,`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



DROP TABLE IF EXISTS `arc1542_wfStatus`;

CREATE TABLE `arc1542_wfStatus` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` double(17,6) unsigned NOT NULL,
  `level` tinyint(3) unsigned NOT NULL,
  `type` char(5) NOT NULL,
  `msg` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `k1` (`ctime`),
  KEY `k2` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8;

INSERT INTO `arc1542_wfStatus` VALUES("1","1434399538.055669","10","info","SUM_PREP:Preparing a new scan.");
INSERT INTO `arc1542_wfStatus` VALUES("2","1434399538.059547","10","info","SUM_PAIDONLY:Remote scan of public facing site only available to paid members");
INSERT INTO `arc1542_wfStatus` VALUES("3","1434399540.061248","10","info","SUM_PAIDONLY:Check if your site is being Spamvertized is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("4","1434399542.064531","10","info","SUM_PAIDONLY:Checking if your IP is generating spam is for paid members only");
INSERT INTO `arc1542_wfStatus` VALUES("5","1434399544.068995","10","info","SUM_START:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("6","1434399546.073104","10","info","SUM_ENDOK:Scanning your site for the HeartBleed vulnerability");
INSERT INTO `arc1542_wfStatus` VALUES("7","1434399546.076709","1","info","Contacting Wordfence to initiate scan");
INSERT INTO `arc1542_wfStatus` VALUES("8","1434399547.096744","2","info","Getting plugin list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("9","1434399547.101950","2","info","Found 3 plugins");
INSERT INTO `arc1542_wfStatus` VALUES("10","1434399547.103554","2","info","Getting theme list from WordPress");
INSERT INTO `arc1542_wfStatus` VALUES("11","1434399547.105148","2","info","Found 1 themes");
INSERT INTO `arc1542_wfStatus` VALUES("12","1434399547.108786","10","info","SUM_START:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("13","1434399549.944095","10","info","SUM_ENDSUCCESS:Fetching core, theme and plugin file signatures from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("14","1434399549.948542","10","info","SUM_START:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("15","1434399554.640653","10","info","SUM_ENDSUCCESS:Fetching list of known malware files from Wordfence");
INSERT INTO `arc1542_wfStatus` VALUES("16","1434399554.644697","10","info","SUM_START:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("17","1434399554.645044","10","info","SUM_DISABLED:Skipping theme scan");
INSERT INTO `arc1542_wfStatus` VALUES("18","1434399554.645342","10","info","SUM_DISABLED:Skipping plugin scan");
INSERT INTO `arc1542_wfStatus` VALUES("19","1434399554.647089","10","info","SUM_START:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("20","1434399555.746919","2","info","Analyzed 100 files containing 1.1 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("21","1434399555.941838","2","info","Analyzed 200 files containing 2.25 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("22","1434399556.219059","2","info","Analyzed 300 files containing 4.41 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("23","1434399556.371454","2","info","Analyzed 400 files containing 5.03 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("24","1434399556.568863","2","info","Analyzed 500 files containing 6.74 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("25","1434399556.822304","2","info","Analyzed 600 files containing 9.75 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("26","1434399556.935451","2","info","Analyzed 700 files containing 10.05 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("27","1434399557.110897","2","info","Analyzed 800 files containing 11.57 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("28","1434399557.259347","2","info","Analyzed 900 files containing 12.63 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("29","1434399557.482302","2","info","Analyzed 1000 files containing 15.47 MB of data so far");
INSERT INTO `arc1542_wfStatus` VALUES("30","1434399557.492406","2","info","Analyzed 1007 files containing 15.56 MB of data.");
INSERT INTO `arc1542_wfStatus` VALUES("31","1434399557.493069","10","info","SUM_ENDOK:Comparing core WordPress files against originals in repository");
INSERT INTO `arc1542_wfStatus` VALUES("32","1434399557.494961","10","info","SUM_ENDOK:Scanning for known malware files");
INSERT INTO `arc1542_wfStatus` VALUES("33","1434399557.516416","10","info","SUM_START:Scanning file contents for infections and vulnerabilities");
INSERT INTO `arc1542_wfStatus` VALUES("34","1434399557.518823","10","info","SUM_START:Scanning files for URLs in Google\'s Safe Browsing List");
INSERT INTO `arc1542_wfStatus` VALUES("35","1434399557.623882","2","error","Scan terminated with error: There was an error connecting to the the Wordfence scanning servers: Failed to connect to noc1.wordfence.com port 443: Connection refused");
INSERT INTO `arc1542_wfStatus` VALUES("36","1434399557.624289","10","info","SUM_KILLED:Previous scan terminated with an error. See below.");


DROP TABLE IF EXISTS `arc1542_wfThrottleLog`;

CREATE TABLE `arc1542_wfThrottleLog` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `startTime` int(10) unsigned NOT NULL,
  `endTime` int(10) unsigned NOT NULL,
  `timesThrottled` int(10) unsigned NOT NULL,
  `lastReason` varchar(255) NOT NULL,
  PRIMARY KEY (`IP`),
  KEY `k2` (`endTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `arc1542_wfVulnScanners`;

CREATE TABLE `arc1542_wfVulnScanners` (
  `IP` binary(16) NOT NULL DEFAULT '\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0\0',
  `ctime` int(10) unsigned NOT NULL,
  `hits` int(10) unsigned NOT NULL,
  PRIMARY KEY (`IP`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;





